import * as i0 from "@angular/core";
import { AfterViewInit, ChangeDetectorRef, DestroyRef, DoCheck, ElementRef, EnvironmentProviders, EventEmitter, InjectionToken, ModuleWithProviders, OnChanges, OnDestroy, OnInit, PipeTransform, Provider, QueryList, Renderer2, SimpleChanges, TemplateRef } from "@angular/core";
import { Modal } from "bootstrap";
import { AbstractControl, ControlContainer, ControlValueAccessor, FormControl, NgControl, ValidationErrors, ValidatorFn } from "@angular/forms";
import { Observable, Subject } from "rxjs";
import Player from "video.js/dist/types/player";
import { TranslatePipe, TranslateService } from "@ngx-translate/core";
import { ProgressDonut } from "bootstrap-italia";
import { Location } from "@angular/common";
import { SafeHtml } from "@angular/platform-browser";
/**
 * The bootstrap-italia asset folder path
 * @default ./bootstrap-italia
 */
export declare const IT_ASSET_BASE_PATH: InjectionToken<string>;
export interface DesignAngularKitConfig {
  /**
   * The bootstrap-italia asset folder path
   * @default ./bootstrap-italia
   */
  assetBasePath?: string;
  /**
   * Load the <a href="https://italia.github.io/bootstrap-italia/docs/come-iniziare/introduzione/#fonts">bootstrap-italia fonts</a>
   * @default true
   */
  loadFont?: boolean;
  /**
   * The TranslateModule loader
   * @param itPrefix the design-angular-kit i18n path
   * @param itSuffix the design-angular-kit i18n suffix
   * @default
   * {
   *   provide: TranslateLoader,
   *   useFactory: (http: HttpClient) => new TranslateHttpLoader(http, `${assetBasePath}/i18n/`, `.json?v${version}`),
   *   deps: [HttpClient],
   * }
   */
  translateLoader?: (itPrefix: string, itSuffix: string) => Provider;
}
declare abstract class ItAbstractComponent implements AfterViewInit, OnChanges {
  /**
   * The element ID
   */
  id: string;
  /**
   * Fired when component input attributes was changed
   */
  valueChanges: EventEmitter<void>;
  /**
   * Counter of active instances
   * @private
   */
  private static instances;
  protected readonly _renderer: Renderer2;
  protected readonly _elementRef: ElementRef;
  protected readonly _changeDetectorRef: ChangeDetectorRef;
  constructor();
  ngAfterViewInit(): void;
  ngOnChanges(changes: SimpleChanges): void;
  /**
   * Generate unique id for components
   * @private
   */
  private getDefaultId;
  static ɵfac: i0.ɵɵFactoryDeclaration<ItAbstractComponent, never>;
  static ɵcmp: i0.ɵɵComponentDeclaration<ItAbstractComponent, "ng-component", never, {
    "id": {
      "alias": "id";
      "required": false;
    };
  }, {
    "valueChanges": "valueChanges";
  }, never, never, false, never>;
}
declare namespace coercion_d_exports {
  export { BooleanInput, inputToBoolean };
}
type BooleanInput = 'false' | 'true' | boolean | undefined;
/**
 * Transforms a value (typically a string) to a boolean.
 * Intended to be used as a transform function of an input.
 *
 *  @usageNotes
 *  ```typescript
 *  @Input({ transform: booleanAttribute }) status?: boolean;
 *  ```
 * @param {BooleanInput} value Value to be transformed.
 *
 * @publicApi
 */
declare function inputToBoolean(value: BooleanInput): boolean;
declare namespace collapse_component_d_exports {
  export { ItCollapseComponent };
}
export declare class ItCollapseComponent extends ItAbstractComponent implements AfterViewInit {
  /**
   * Enable multiple collapse
   * @default false
   */
  multi?: boolean;
  /**
   * Toggles the collapsible element on invocation
   * @default false
   */
  opened?: boolean;
  /**
   * Custom class
   */
  class: string;
  /**
   * This event fires immediately when the show method is called.
   */
  showEvent: EventEmitter<Event>;
  /**
   * This event is triggered when the tooltip has been made visible to the user (it will wait for the CSS transitions to complete).
   */
  shownEvent: EventEmitter<Event>;
  /**
   * This event fires immediately when the hide method is called.
   */
  hideEvent: EventEmitter<Event>;
  /**
   * This event is raised when the tooltip has finished being hidden from the user (it will wait for the CSS transitions to complete).
   */
  hiddenEvent: EventEmitter<Event>;
  private collapse?;
  private open;
  protected collapseDiv?: ElementRef<HTMLDivElement>;
  ngAfterViewInit(): void;
  /**
   * Shows if collapse is open or not
   */
  isOpen(): boolean;
  /**
   * Shows a resealable item
   * NOTE: Returns to the caller before the collapsable element has actually been shown (onShown event).
   */
  show(): void;
  /**
   * Hides a resealable item
   * NOTE: Returns to the caller before the collapsable element has actually been hidden (onHidden Event)
   */
  hide(): void;
  /**
   * Toggle a collapsible item to show or hide it.
   * NOTE: Returns to the caller before the collapsable element has actually been shown or hidden (onShown and onHidden events)
   */
  toggle(): void;
  /**
   * Eliminates the possibility of an item being resealable
   */
  dispose(): void;
  static ɵfac: i0.ɵɵFactoryDeclaration<ItCollapseComponent, never>;
  static ɵcmp: i0.ɵɵComponentDeclaration<ItCollapseComponent, "it-collapse", ["itCollapse"], {
    "multi": {
      "alias": "multi";
      "required": false;
    };
    "opened": {
      "alias": "opened";
      "required": false;
    };
    "class": {
      "alias": "class";
      "required": false;
    };
  }, {
    "showEvent": "showEvent";
    "shownEvent": "shownEvent";
    "hideEvent": "hideEvent";
    "hiddenEvent": "hiddenEvent";
  }, never, ["*"], true, never>;
  static ngAcceptInputType_multi: BooleanInput;
  static ngAcceptInputType_opened: BooleanInput;
}
declare namespace accordion_component_d_exports {
  export { ItAccordionComponent };
}
/**
 * Accordion
 * @description Build vertically collapsible accordions based on Collapse.
 */
export declare class ItAccordionComponent extends ItCollapseComponent implements AfterViewInit {
  /**
   * Accordion Title
   */
  title: string;
  protected collapseDiv?: ElementRef<HTMLDivElement>;
  protected isCollapsed: boolean;
  ngAfterViewInit(): void;
  static ɵfac: i0.ɵɵFactoryDeclaration<ItAccordionComponent, never>;
  static ɵcmp: i0.ɵɵComponentDeclaration<ItAccordionComponent, "it-accordion", ["itAccordion"], {
    "title": {
      "alias": "title";
      "required": true;
    };
  }, {}, never, ["*"], true, never>;
}
export type IconSize = 'xs' | 'sm' | 'lg' | 'xl';
export type IconColor = 'primary' | 'secondary' | 'success' | 'warning' | 'danger' | 'light' | 'white';
export type IconName = (typeof IconNameArray)[number];
export declare const IconNameArray: readonly ["arrow-down", "arrow-down-circle", "arrow-down-triangle", "arrow-left", "arrow-left-circle", "arrow-left-triangle", "arrow-right", "arrow-right-circle", "arrow-right-triangle", "arrow-up", "arrow-up-circle", "arrow-up-triangle", "ban", "bluesky", "bookmark", "box", "burger", "calendar", "camera", "car", "card", "cart", "chart-line", "check", "check-circle", "chevron-left", "chevron-right", "clip", "clock", "close", "close-big", "close-circle", "code-circle", "comment", "copy", "delete", "download", "error", "exchange-circle", "expand", "external-link", "flag", "folder", "fullscreen", "funnel", "hearing", "help", "help-circle", "horn", "inbox", "info-circle", "key", "link", "list", "locked", "logout", "mail", "mail-open", "map-marker", "map-marker-circle", "map-marker-minus", "map-marker-plus", "maximize", "maximize-alt", "minimize", "minus", "minus-circle", "more-actions", "more-items", "note", "pa", "password-invisible", "password-visible", "pencil", "piattaforme", "pin", "plug", "plus", "plus-circle", "presentation", "print", "refresh", "restore", "rss", "rss-square", "search", "settings", "share", "sign", "software", "star-full", "star-outline", "telephone", "tool", "unlocked", "upload", "user", "video", "warning", "warning-circle", "wifi", "zoom-in", "zoom-out", "file", "files", "file-audio", "file-compressed", "file-csv", "file-docx", "file-json", "file-image", "file-odp", "file-ods", "file-odt", "file-pdf", "file-pdf-ext", "file-sheet", "file-slides", "file-ppt", "file-signed", "file-txt", "file-video", "file-xlsx", "file-xml", "behance", "android-square", "android", "apple-square", "apple", "facebook", "facebook-square", "figma", "figma-square", "flickr", "flickr-square", "github", "instagram", "linkedin", "linkedin-square", "mastodon", "mastodon-square", "medium", "medium-square", "moodle", "moodle-square", "pinterest", "pinterest-square", "quora", "quora-square", "reddit", "reddit-square", "slack", "slack-square", "snapchat", "snapchat-square", "stackexchange", "stackexchange-square", "stackoverflow", "stackoverflow-square", "telegram", "threads", "threads-square", "tiktok", "tiktok-square", "twitter", "twitter-square", "vimeo", "vimeo-square", "whatsapp", "whatsapp-square", "youtube", "google", "spotify", "designers-italia", "team-digitale"];
export type AlertColor = 'primary' | 'info' | 'success' | 'warning' | 'danger';
export type ButtonColor = 'primary' | 'outline-primary' | 'secondary' | 'outline-secondary' | 'success' | 'outline-success' | 'danger' | 'outline-danger' | 'warning' | 'outline-warning' | 'info' | 'outline-info' | 'light' | 'outline-light' | 'dark' | 'outline-dark' | 'link';
export type ButtonSize = 'lg' | 'sm' | 'xs';
export type ButtonType = 'submit' | 'button';
export type CalloutColor = 'success' | 'warning' | 'danger' | 'important' | 'note';
export type CalloutAppearance = 'default' | 'highlight' | 'more';
export type ChipColor = 'primary' | 'secondary' | 'success' | 'danger' | 'warning';
export type ElementPlacement = 'top' | 'bottom' | 'left' | 'right';
export type ProgressBarColor = 'primary' | 'success' | 'warning' | 'danger' | 'info';
export type BadgeColor = 'primary' | 'secondary' | 'success' | 'warning' | 'danger';
export type TableColor = 'primary' | 'secondary' | 'success' | 'danger' | 'warning' | 'info' | 'light' | 'dark';
export type TableHeadColor = 'light' | 'dark';
export type TableResponsive = 'responsive' | 'responsive-sm' | 'responsive-md' | 'responsive-lg' | 'responsive-xl' | 'responsive-xxl';
export type VerticalAlignment = 'align-baseline' | 'align-top' | 'align-middle' | 'align-bottom' | 'align-text-bottom' | 'align-text-top';
export type DropdownDirection = 'dropup' | 'dropend' | 'dropstart';
export type CarouselType = 'default' | 'three-cols' | 'three-cols-arrow-visible';
export type TimelinePINType = 'default' | 'evidence' | 'now';
export interface TimelineElement {
  pin: {
    type?: TimelinePINType;
    icon?: IconName;
    text: string;
  };
  category?: {
    title: string;
    link: string;
  };
  title: string;
  text: string;
  signature?: string;
  eventDate?: Date;
  link?: string;
}
export interface Notification {
  /**
   * Notification type
   */
  type: NotificationType;
  /**
   * Notification title
   */
  title: string;
  /**
   * Notification message / text
   */
  message?: string;
  /**
   * Custom duration of notification
   */
  duration?: number;
  /**
   * The close notification button appears
   */
  dismissible?: boolean;
  /**
   * Custom position of notification
   */
  position?: NotificationPosition;
  /**
   * Custom icon of notification
   */
  icon?: IconName;
}
export declare enum NotificationType {
  Standard = "standard",
  Success = "success",
  Error = "error",
  Info = "info",
  Warning = "warning"
}
export declare enum NotificationPosition {
  Top = "top-fix mt-3",
  Bottom = "bottom-fix mb-3",
  Left = "left-fix ms-3",
  Right = "right-fix me-3"
}
declare namespace alert_component_d_exports {
  export { ItAlertComponent };
}
/**
 * Alert
 * @description You can provide feedback to the user via alert messages.
 */
export declare class ItAlertComponent extends ItAbstractComponent implements AfterViewInit {
  /**
   * The alert color
   * @default info
   */
  color: AlertColor;
  /**
   * Inserts the close button
   * @default false
   */
  dismissible?: boolean;
  /**
   * This event fires immediately when the instance's close method is called.
   */
  closeEvent: EventEmitter<Event>;
  /**
   * This event fires when the alert has been closed (it will wait for CSS transitions to complete).
   */
  closedEvent: EventEmitter<Event>;
  private alert?;
  private alertElement?;
  private headingEl?;
  ngAfterViewInit(): void;
  /**
   * Close an alert by removing it from the DOM.
   * If the `.fade` and `.show` classes are present in the element, the alert will be closed with a disappearing effect.
   */
  close(): void;
  /**
   * The alert is removed
   */
  dispose(): void;
  static ɵfac: i0.ɵɵFactoryDeclaration<ItAlertComponent, never>;
  static ɵcmp: i0.ɵɵComponentDeclaration<ItAlertComponent, "it-alert", ["itAlert"], {
    "color": {
      "alias": "color";
      "required": false;
    };
    "dismissible": {
      "alias": "dismissible";
      "required": false;
    };
  }, {
    "closeEvent": "closeEvent";
    "closedEvent": "closedEvent";
  }, never, ["[heading]", "*"], true, never>;
  static ngAcceptInputType_dismissible: BooleanInput;
}
declare namespace avatar_group_component_d_exports {
  export { ItAvatarGroupComponent, ItAvatarGroupItemComponent, ItAvatarListItemDirective };
}
export declare class ItAvatarListItemDirective {
  get hostClasses(): string;
  static ɵfac: i0.ɵɵFactoryDeclaration<ItAvatarListItemDirective, never>;
  static ɵdir: i0.ɵɵDirectiveDeclaration<ItAvatarListItemDirective, "[itAvatarListItem]", ["itAvatarListItem"], {}, {}, never, never, true, never>;
}
export declare class ItAvatarGroupItemComponent {
  _implicitContent: TemplateRef<any>;
  static ɵfac: i0.ɵɵFactoryDeclaration<ItAvatarGroupItemComponent, never>;
  static ɵcmp: i0.ɵɵComponentDeclaration<ItAvatarGroupItemComponent, "it-avatar-item", never, {}, {}, never, ["*"], true, never>;
}
export declare class ItAvatarGroupComponent {
  linkList: boolean;
  avatars: QueryList<ItAvatarGroupItemComponent>;
  static ɵfac: i0.ɵɵFactoryDeclaration<ItAvatarGroupComponent, never>;
  static ɵcmp: i0.ɵɵComponentDeclaration<ItAvatarGroupComponent, "it-avatar-group", never, {
    "linkList": {
      "alias": "linkList";
      "required": false;
    };
  }, {}, ["avatars"], never, true, never>;
  static ngAcceptInputType_linkList: BooleanInput;
}
declare namespace avatar_dropdown_component_d_exports {
  export { ItAvatarDropdownComponent, ItAvatarDropdownItemComponent };
}
export declare class ItAvatarDropdownItemComponent {
  _implicitContent: TemplateRef<any>;
  /**
   * Indica il link che possiamo passare all'elemento
   */
  link: string | any[] | null | undefined;
  /**
   * Permette di utilizzare l'attributo html title
   */
  title?: string;
  /**
   * Permette di utilizzare l'attributo html accesskey
   */
  accesskey?: string;
  /**
   * Permette di utilizzare l'attributo html tabindex
   */
  tabindex?: number;
  static ɵfac: i0.ɵɵFactoryDeclaration<ItAvatarDropdownItemComponent, never>;
  static ɵcmp: i0.ɵɵComponentDeclaration<ItAvatarDropdownItemComponent, "it-avatar-dropdown-item", never, {
    "link": {
      "alias": "link";
      "required": false;
    };
    "title": {
      "alias": "title";
      "required": false;
    };
    "accesskey": {
      "alias": "accesskey";
      "required": false;
    };
    "tabindex": {
      "alias": "tabindex";
      "required": false;
    };
  }, {}, never, ["*"], true, never>;
}
export declare class ItAvatarDropdownComponent {
  componentClass: string;
  items: QueryList<ItAvatarDropdownItemComponent>;
  static ɵfac: i0.ɵɵFactoryDeclaration<ItAvatarDropdownComponent, never>;
  static ɵcmp: i0.ɵɵComponentDeclaration<ItAvatarDropdownComponent, "it-avatar-dropdown", never, {}, {}, ["items"], ["[it-avatar-dropdown-toggle]"], true, never>;
}
declare enum SizesEnum {
  xs = "size-xs",
  sm = "size-sm",
  lg = "size-lg",
  xl = "size-xl",
  xxl = "size-xxl"
}
declare namespace avatar_directive_d_exports {
  export { ItAvatarDirective };
}
export declare class ItAvatarDirective {
  /**
   * Indica il colore dell'avatar. Può assumere i valori:
   * <ul>
   * <li> primary
   * <li> secondary
   * <li> green
   * <li> orange
   * <li> red
   * </ul>
   */
  get color(): string | undefined;
  set color(value: string | undefined);
  private _color?;
  /**
   * Indica la grandezza dell'avatar. Può assumere i valori:
   * <ul>
   * <li> xs
   * <li> sm
   * <li> lg
   * <li> xl
   * <li> xxl
   * </ul>
   */
  get size(): SizesEnum | undefined;
  set size(value: string | undefined);
  private _size?;
  get hostClasses(): string;
  static ɵfac: i0.ɵɵFactoryDeclaration<ItAvatarDirective, never>;
  static ɵdir: i0.ɵɵDirectiveDeclaration<ItAvatarDirective, "[itAvatar]", ["itAvatar"], {
    "color": {
      "alias": "color";
      "required": false;
    };
    "size": {
      "alias": "size";
      "required": false;
    };
  }, {}, never, never, true, never>;
}
declare namespace avatar_extra_text_directive_d_exports {
  export { ItAvatarExtraTextDirective };
}
export declare class ItAvatarExtraTextDirective {
  get hostClasses(): string;
  static ɵfac: i0.ɵɵFactoryDeclaration<ItAvatarExtraTextDirective, never>;
  static ɵdir: i0.ɵɵDirectiveDeclaration<ItAvatarExtraTextDirective, "[itAvatarExtraText]", ["itAvatarExtraText"], {}, {}, never, never, true, never>;
}
declare namespace avatar_wrapper_directive_d_exports {
  export { ItAvatarWrapperDirective };
}
export declare class ItAvatarWrapperDirective {
  extraText: boolean;
  get hostClasses(): string;
  static ɵfac: i0.ɵɵFactoryDeclaration<ItAvatarWrapperDirective, never>;
  static ɵdir: i0.ɵɵDirectiveDeclaration<ItAvatarWrapperDirective, "[itAvatarWrapper]", ["itAvatarWrapper"], {
    "extraText": {
      "alias": "extraText";
      "required": false;
    };
  }, {}, never, never, true, never>;
  static ngAcceptInputType_extraText: BooleanInput;
}
declare namespace avatar_status_directive_d_exports {
  export { ItAvatarStatusDirective };
}
export declare class ItAvatarStatusDirective {
  /**
   * Indica lo stato della presenza. Può assumere i valori:
   * <ul>
   * <li> approved
   * <li> declined
   * <li> notify
   * </ul>
   */
  get status(): string | undefined;
  set status(value: string | undefined);
  private _status?;
  get hostClasses(): string;
  static ɵfac: i0.ɵɵFactoryDeclaration<ItAvatarStatusDirective, never>;
  static ɵdir: i0.ɵɵDirectiveDeclaration<ItAvatarStatusDirective, "[itAvatarStatus]", ["itAvatarStatus"], {
    "status": {
      "alias": "status";
      "required": false;
    };
  }, {}, never, never, true, never>;
}
declare namespace avatar_presence_directive_d_exports {
  export { ItAvatarPresenceDirective };
}
export declare class ItAvatarPresenceDirective {
  /**
   * Indica lo stato della presenza. Può assumere i valori:
   * <ul>
   * <li> active
   * <li> busy
   * <li> hidden
   * </ul>
   */
  get presence(): string | undefined;
  set presence(value: string | undefined);
  private _presence?;
  get hostClasses(): string;
  static ɵfac: i0.ɵɵFactoryDeclaration<ItAvatarPresenceDirective, never>;
  static ɵdir: i0.ɵɵDirectiveDeclaration<ItAvatarPresenceDirective, "[itAvatarPresence]", ["itAvatarPresence"], {
    "presence": {
      "alias": "presence";
      "required": false;
    };
  }, {}, never, never, true, never>;
}
declare namespace avatar_module_d_exports {
  export { ItAvatarModule };
}
export declare class ItAvatarModule {
  static ɵfac: i0.ɵɵFactoryDeclaration<ItAvatarModule, never>;
  static ɵmod: i0.ɵɵNgModuleDeclaration<ItAvatarModule, never, [typeof ItAvatarGroupItemComponent, typeof ItAvatarGroupComponent, typeof ItAvatarDropdownComponent, typeof ItAvatarDropdownItemComponent, typeof ItAvatarDirective, typeof ItAvatarExtraTextDirective, typeof ItAvatarWrapperDirective, typeof ItAvatarStatusDirective, typeof ItAvatarPresenceDirective, typeof ItAvatarListItemDirective], [typeof ItAvatarGroupItemComponent, typeof ItAvatarGroupComponent, typeof ItAvatarDropdownComponent, typeof ItAvatarDropdownItemComponent, typeof ItAvatarDirective, typeof ItAvatarExtraTextDirective, typeof ItAvatarWrapperDirective, typeof ItAvatarStatusDirective, typeof ItAvatarPresenceDirective, typeof ItAvatarListItemDirective]>;
  static ɵinj: i0.ɵɵInjectorDeclaration<ItAvatarModule>;
}
declare namespace badge_directive_d_exports {
  export { ItBadgeDirective };
}
/**
 * Badge
 * @description Useful for small counters and labels
 */
export declare class ItBadgeDirective {
  /**
   * Define the badge color
   * @default undefined
   */
  color: BadgeColor | undefined;
  /**
   * Show rounded badge
   * @default false
   */
  rounded?: boolean;
  protected get badgeClass(): string;
  static ɵfac: i0.ɵɵFactoryDeclaration<ItBadgeDirective, never>;
  static ɵdir: i0.ɵɵDirectiveDeclaration<ItBadgeDirective, "[itBadge]", ["itBadge"], {
    "color": {
      "alias": "itBadge";
      "required": false;
    };
    "rounded": {
      "alias": "rounded";
      "required": false;
    };
  }, {}, never, never, true, never>;
  static ngAcceptInputType_rounded: BooleanInput;
}
declare namespace icon_component_d_exports {
  export { ItIconComponent };
}
export declare class ItIconComponent {
  /**
   * The icon name
   */
  name: IconName;
  /**
   * The icon size
   */
  size: IconSize | undefined;
  /**
   * The icon color
   */
  color: IconColor | undefined;
  /**
   * Create a padding proportional to the size of the surrounding icon.
   * @default false
   */
  padded?: boolean;
  /**
   * Custom class of svg
   */
  svgClass: string | undefined;
  /**
   * Title of the icon
   */
  title: string | undefined;
  /**
   * Custom Waria label
   */
  labelWaria: string | undefined;
  /**
   * Return the icon href
   */
  protected get iconHref(): string;
  /**
   * Return the icon class
   */
  protected get iconClass(): string;
  /**
   * The bootstrap-italia asset folder path
   * @default ./bootstrap-italia
   */
  protected assetBasePath: string;
  get isAriaHidden(): boolean;
  get role(): string | null;
  constructor();
  static ɵfac: i0.ɵɵFactoryDeclaration<ItIconComponent, never>;
  static ɵcmp: i0.ɵɵComponentDeclaration<ItIconComponent, "it-icon", never, {
    "name": {
      "alias": "name";
      "required": true;
    };
    "size": {
      "alias": "size";
      "required": false;
    };
    "color": {
      "alias": "color";
      "required": false;
    };
    "padded": {
      "alias": "padded";
      "required": false;
    };
    "svgClass": {
      "alias": "svgClass";
      "required": false;
    };
    "title": {
      "alias": "title";
      "required": false;
    };
    "labelWaria": {
      "alias": "labelWaria";
      "required": false;
    };
  }, {}, never, never, true, never>;
  static ngAcceptInputType_padded: BooleanInput;
}
declare namespace button_directive_d_exports {
  export { ItButtonDirective };
}
/**
 * Button
 * @description Bootstrap italia custom button styles
 */
export declare class ItButtonDirective {
  private progressButtonComponent;
  /**
   * Button color
   * @default undefined
   */
  color: ButtonColor | undefined;
  /**
   * Button size
   * @default undefined
   */
  size: ButtonSize | undefined;
  /**
   * Indicates whether the button occupies all the width available to it.
   * @default undefined
   */
  block: ButtonSize | undefined;
  /**
   * If button is disabled
   * @default false
   */
  disabled?: boolean;
  /**
   * The type attribute
   * @default button
   */
  type: 'button' | 'reset' | 'submit';
  /**
   * The icon children
   * @default undefined
   */
  protected icons?: QueryList<ItIconComponent>;
  protected get hostClasses(): string;
  static ɵfac: i0.ɵɵFactoryDeclaration<ItButtonDirective, never>;
  static ɵdir: i0.ɵɵDirectiveDeclaration<ItButtonDirective, "[itButton]", ["itButton"], {
    "color": {
      "alias": "itButton";
      "required": false;
    };
    "size": {
      "alias": "size";
      "required": false;
    };
    "block": {
      "alias": "block";
      "required": false;
    };
    "disabled": {
      "alias": "disabled";
      "required": false;
    };
    "type": {
      "alias": "type";
      "required": false;
    };
  }, {}, ["icons"], never, true, never>;
  static ngAcceptInputType_disabled: BooleanInput;
}
declare namespace callout_component_d_exports {
  export { ItCalloutComponent };
}
/**
 * Callout
 * @description Callouts can be used to highlight certain parts of the text that require particular attention. They may contain error messages, warnings, hints, etc.
 */
export declare class ItCalloutComponent {
  /**
   * Callout label
   * @default undefined
   */
  label: string | undefined;
  /**
   * Callout hiddenLabel
   * @default undefined
   */
  hiddenLabel: string | undefined;
  /**
   * Callout color
   * - <b>success</b>
   * - <b>danger</b>
   * - <b>warning</b>
   * - <b>important</b>
   * - <b>note</b>
   * @default undefined
   */
  color: CalloutColor | undefined;
  /**
   * Callout appearance
   * - <b>default</b>
   * - <b>highlight</b>: Callout version with border only on the left side
   * - <b>more</b>: It looks radically different from the other styles available and is suitable for more extensive texts
   * @default default
   */
  appearance: CalloutAppearance;
  /**
   * Custom icon
   * @default undefined
   */
  icon: IconName | undefined;
  /**
   * The input label even get labelWaria icon
   * @default undefined
   */
  labelWaria: string | undefined;
  protected get iconName(): IconName;
  static ɵfac: i0.ɵɵFactoryDeclaration<ItCalloutComponent, never>;
  static ɵcmp: i0.ɵɵComponentDeclaration<ItCalloutComponent, "it-callout", never, {
    "label": {
      "alias": "label";
      "required": false;
    };
    "hiddenLabel": {
      "alias": "hiddenLabel";
      "required": false;
    };
    "color": {
      "alias": "color";
      "required": false;
    };
    "appearance": {
      "alias": "appearance";
      "required": false;
    };
    "icon": {
      "alias": "icon";
      "required": false;
    };
    "labelWaria": {
      "alias": "labelWaria";
      "required": false;
    };
  }, {}, never, ["[bigText]", "*"], true, never>;
}
declare namespace card_component_d_exports {
  export { ItCardComponent };
}
/**
 * Card
 * @description A container of texts and images with many options and variations.
 */
export declare class ItCardComponent extends ItAbstractComponent {
  /**
   * To create inline cards
   * @default false
   */
  inline?: boolean;
  /**
   * To create inline mini cards
   * @default false
   */
  mini?: boolean;
  /**
   * To add border
   * @default true
   */
  border: boolean;
  /**
   * To create banner cards
   * @default false
   */
  banner?: boolean;
  /**
   * To create profile cards
   * @default false
   */
  profile?: boolean;
  /**
   * To create rounded cards
   * @default false
   */
  rounded?: boolean;
  /**
   * To create inline reverse cards
   * @default false
   */
  reverse?: boolean;
  /**
   * To create full height cards
   * @default false
   */
  fullHeight?: boolean;
  /**
   * Card with image
   * @default false
   */
  hasImage?: boolean;
  /**
   * To add top border
   * @default false
   */
  borderTop?: boolean;
  /**
   * Custom card class
   * @default ''
   */
  cardClass: string;
  /**
   * Custom card body class
   * @default ''
   */
  bodyClass: string;
  /**
   * Remove the default padding applied by Bootstrap Italia to the card.
   * Useful for cards with minimal content (e.g. title + image only) where the
   * default padding-bottom makes the content appear off-center.
   * @default false
   */
  noPadding?: boolean;
  /**
   * Shadow type
   * @default 'sm'
   */
  shadow: 'sm' | 'lg' | 'normal' | 'none';
  static ɵfac: i0.ɵɵFactoryDeclaration<ItCardComponent, never>;
  static ɵcmp: i0.ɵɵComponentDeclaration<ItCardComponent, "it-card", never, {
    "inline": {
      "alias": "inline";
      "required": false;
    };
    "mini": {
      "alias": "mini";
      "required": false;
    };
    "border": {
      "alias": "border";
      "required": false;
    };
    "banner": {
      "alias": "banner";
      "required": false;
    };
    "profile": {
      "alias": "profile";
      "required": false;
    };
    "rounded": {
      "alias": "rounded";
      "required": false;
    };
    "reverse": {
      "alias": "reverse";
      "required": false;
    };
    "fullHeight": {
      "alias": "fullHeight";
      "required": false;
    };
    "hasImage": {
      "alias": "hasImage";
      "required": false;
    };
    "borderTop": {
      "alias": "borderTop";
      "required": false;
    };
    "cardClass": {
      "alias": "cardClass";
      "required": false;
    };
    "bodyClass": {
      "alias": "bodyClass";
      "required": false;
    };
    "noPadding": {
      "alias": "noPadding";
      "required": false;
    };
    "shadow": {
      "alias": "shadow";
      "required": false;
    };
  }, {}, never, ["[beforeBody]", "*"], true, never>;
  static ngAcceptInputType_inline: BooleanInput;
  static ngAcceptInputType_mini: BooleanInput;
  static ngAcceptInputType_border: BooleanInput;
  static ngAcceptInputType_banner: BooleanInput;
  static ngAcceptInputType_profile: BooleanInput;
  static ngAcceptInputType_rounded: BooleanInput;
  static ngAcceptInputType_reverse: BooleanInput;
  static ngAcceptInputType_fullHeight: BooleanInput;
  static ngAcceptInputType_hasImage: BooleanInput;
  static ngAcceptInputType_borderTop: BooleanInput;
  static ngAcceptInputType_noPadding: BooleanInput;
}
declare namespace carousel_item_component_d_exports {
  export { ItCarouselItemComponent };
}
/**
 * Carousel Item
 * @description element, image or text slide of carousel
 */
export declare class ItCarouselItemComponent extends ItAbstractComponent {
  /**
   * The content of item
   */
  htmlContent: TemplateRef<any>;
  static ɵfac: i0.ɵɵFactoryDeclaration<ItCarouselItemComponent, never>;
  static ɵcmp: i0.ɵɵComponentDeclaration<ItCarouselItemComponent, "it-carousel-item", never, {}, {}, never, ["*"], true, never>;
}
declare namespace carousel_component_d_exports {
  export { ItCarouselComponent };
}
/**
 * Carousel
 * @description A presentation component for scrolling through elements, images or text slides.
 */
export declare class ItCarouselComponent implements AfterViewInit, OnDestroy {
  private readonly _changeDetectorRef;
  /**
   * The callout title
   * @default undefined
   */
  title: string | undefined;
  /**
   * The carousel type
   * @default default
   */
  type: CarouselType;
  /**
   * Custom class in splide__track element
   * @default ''
   */
  trackClass: string;
  /**
   * True for full screen (landscape) viewing
   * @default false
   */
  fullCarousel?: boolean;
  /**
   * To indicate that the contained image is of a large type
   * @default false
   */
  bigImg?: boolean;
  /**
   * To indicate that the contained image is of a standard type
   * @default false
   */
  standardImage?: boolean;
  /**
   * Card line style
   * @default false
   */
  lined?: boolean;
  protected items?: QueryList<ItCarouselItemComponent>;
  private carousel?;
  private carouselDiv;
  private itemSubscriptions?;
  protected get typeClass(): string;
  ngAfterViewInit(): void;
  ngOnDestroy(): void;
  /**
   * Removes Carousel features
   */
  dispose(): void;
  static ɵfac: i0.ɵɵFactoryDeclaration<ItCarouselComponent, never>;
  static ɵcmp: i0.ɵɵComponentDeclaration<ItCarouselComponent, "it-carousel", ["itCarousel"], {
    "title": {
      "alias": "title";
      "required": false;
    };
    "type": {
      "alias": "type";
      "required": false;
    };
    "trackClass": {
      "alias": "trackClass";
      "required": false;
    };
    "fullCarousel": {
      "alias": "fullCarousel";
      "required": false;
    };
    "bigImg": {
      "alias": "bigImg";
      "required": false;
    };
    "standardImage": {
      "alias": "standardImage";
      "required": false;
    };
    "lined": {
      "alias": "lined";
      "required": false;
    };
  }, {}, ["items"], never, true, never>;
  static ngAcceptInputType_fullCarousel: BooleanInput;
  static ngAcceptInputType_bigImg: BooleanInput;
  static ngAcceptInputType_standardImage: BooleanInput;
  static ngAcceptInputType_lined: BooleanInput;
}
declare namespace carousel_module_d_exports {
  export { ItCarouselModule };
}
export declare class ItCarouselModule {
  static ɵfac: i0.ɵɵFactoryDeclaration<ItCarouselModule, never>;
  static ɵmod: i0.ɵɵNgModuleDeclaration<ItCarouselModule, never, [typeof ItCarouselComponent, typeof ItCarouselItemComponent], [typeof ItCarouselComponent, typeof ItCarouselItemComponent]>;
  static ɵinj: i0.ɵɵInjectorDeclaration<ItCarouselModule>;
}
declare namespace chip_component_d_exports {
  export { ItChipComponent };
}
export declare class ItChipComponent {
  /**
   * Indica la label
   */
  set label(value: string);
  get label(): string;
  private _label;
  /**
   * Indica se mostrate il pulante di chisura
   */
  set showCloseButton(value: boolean);
  get showCloseButton(): boolean;
  private _showCloseButton;
  /**
   * Indica il size
   */
  set size(value: '' | 'lg');
  get size(): '' | 'lg';
  private _size;
  /**
   * Indica il colore della chip
   */
  set color(value: ChipColor | undefined);
  get color(): ChipColor | undefined;
  private _color;
  /**
   * Indica se la chip è disabilitata
   */
  set disabled(value: boolean);
  get disabled(): boolean;
  private _disabled;
  /**
   * Indica il nome dell'icona, se valorizzata viene mostrata
   */
  set icon(value: IconName | undefined);
  get icon(): IconName | undefined;
  private _icon;
  /**
   * Indica l'url dell'avatar, se valorizzata viene mostrata
   */
  set avatar(value: string | undefined);
  get avatar(): string | undefined;
  private _avatar;
  /**
   * Indica il valore da aggiungere al parametro alt, di default ''
   */
  set altAvatar(value: string);
  get altAvatar(): string;
  private _altAvatar;
  /**
   * Evento emesso al click sul bottone di chiusura
   */
  closeEvent: EventEmitter<any>;
  /**
   * Return the icon href
   */
  protected get iconHref(): string;
  private iconClose;
  /**
   * Return the close icon href
   */
  protected get iconCloseHref(): string;
  /**
   * The bootstrap-italia asset folder path
   * @default ./bootstrap-italia
   */
  protected assetBasePath: string;
  constructor();
  clickToClose(): void;
  static ɵfac: i0.ɵɵFactoryDeclaration<ItChipComponent, never>;
  static ɵcmp: i0.ɵɵComponentDeclaration<ItChipComponent, "it-chip", never, {
    "label": {
      "alias": "label";
      "required": false;
    };
    "showCloseButton": {
      "alias": "showCloseButton";
      "required": false;
    };
    "size": {
      "alias": "size";
      "required": false;
    };
    "color": {
      "alias": "color";
      "required": false;
    };
    "disabled": {
      "alias": "disabled";
      "required": false;
    };
    "icon": {
      "alias": "icon";
      "required": false;
    };
    "avatar": {
      "alias": "avatar";
      "required": false;
    };
    "altAvatar": {
      "alias": "altAvatar";
      "required": false;
    };
  }, {
    "closeEvent": "closeEvent";
  }, never, never, true, never>;
}
declare namespace dimmer_component_d_exports {
  export { DimmerColor, ItDimmerComponent };
}
export type DimmerColor = '' | 'dimmer-primary';
export declare class ItDimmerComponent implements OnInit {
  private elementRef;
  /**
   * Dimmer status
   * @default false
   */
  set active(value: boolean);
  get active(): boolean;
  private _active;
  /**
   * Colore del dimmer
   * @default ''
   */
  set color(value: DimmerColor);
  get color(): DimmerColor;
  private _color;
  ngOnInit(): void;
  static ɵfac: i0.ɵɵFactoryDeclaration<ItDimmerComponent, never>;
  static ɵcmp: i0.ɵɵComponentDeclaration<ItDimmerComponent, "it-dimmer", never, {
    "active": {
      "alias": "active";
      "required": false;
    };
    "color": {
      "alias": "color";
      "required": false;
    };
  }, {}, never, ["*"], true, never>;
}
declare namespace dimmer_icon_component_d_exports {
  export { ItDimmerIconComponent };
}
export declare class ItDimmerIconComponent {
  static ɵfac: i0.ɵɵFactoryDeclaration<ItDimmerIconComponent, never>;
  static ɵcmp: i0.ɵɵComponentDeclaration<ItDimmerIconComponent, "it-dimmer-icon", never, {}, {}, never, ["*"], true, never>;
}
declare namespace dimmer_buttons_component_d_exports {
  export { ItDimmerButtonsComponent };
}
export declare class ItDimmerButtonsComponent {
  /**
   * Indica se abbiamo 1 solo bottone
   * @default false
   */
  set hasOneButton(value: boolean);
  get hasOneButton(): boolean;
  private _hasOneButton;
  static ɵfac: i0.ɵɵFactoryDeclaration<ItDimmerButtonsComponent, never>;
  static ɵcmp: i0.ɵɵComponentDeclaration<ItDimmerButtonsComponent, "it-dimmer-buttons", never, {
    "hasOneButton": {
      "alias": "hasOneButton";
      "required": false;
    };
  }, {}, never, ["*"], true, never>;
}
declare namespace dimmer_module_d_exports {
  export { ItDimmerModule };
}
export declare class ItDimmerModule {
  static ɵfac: i0.ɵɵFactoryDeclaration<ItDimmerModule, never>;
  static ɵmod: i0.ɵɵNgModuleDeclaration<ItDimmerModule, never, [typeof ItDimmerComponent, typeof ItDimmerIconComponent, typeof ItDimmerButtonsComponent], [typeof ItDimmerComponent, typeof ItDimmerIconComponent, typeof ItDimmerButtonsComponent]>;
  static ɵinj: i0.ɵɵInjectorDeclaration<ItDimmerModule>;
}
declare namespace link_component_d_exports {
  export { ItLinkComponent };
}
export declare class ItLinkComponent extends ItAbstractComponent implements AfterViewInit, OnChanges {
  /**
   * The router link action
   *
   * Commands to pass to Router#createUrlTree.
   * - array: commands to pass to Router#createUrlTree.
   * - string: shorthand for array of commands with just the string, i.e. ['/route']
   * - null|undefined: Disables the link by removing the href
   */
  href: any[] | string | null | undefined;
  /**
   * Is an external link (false to not use Angular router link)
   * @default false
   */
  externalLink?: boolean;
  /**
   * Is disabled link
   * @default false
   */
  disabled?: boolean;
  /**
   * Custom class
   */
  class: string;
  ngAfterViewInit(): void;
  ngOnChanges(changes: SimpleChanges): void;
  static ɵfac: i0.ɵɵFactoryDeclaration<ItLinkComponent, never>;
  static ɵcmp: i0.ɵɵComponentDeclaration<ItLinkComponent, "it-link", never, {
    "href": {
      "alias": "href";
      "required": false;
    };
    "externalLink": {
      "alias": "externalLink";
      "required": false;
    };
    "disabled": {
      "alias": "disabled";
      "required": false;
    };
    "class": {
      "alias": "class";
      "required": false;
    };
  }, {}, never, ["*"], true, never>;
  static ngAcceptInputType_externalLink: BooleanInput;
  static ngAcceptInputType_disabled: BooleanInput;
}
declare namespace dropdown_item_component_d_exports {
  export { ItDropdownItemComponent };
}
export declare class ItDropdownItemComponent extends ItLinkComponent implements OnInit {
  /**
   * Show divider
   * @default false
   */
  divider?: boolean;
  /**
   * Active item
   * @default false
   */
  active?: boolean;
  /**
   * To increase the size of links
   * @default false
   */
  large?: boolean;
  /**
   * The name of icon to show
   */
  iconName: IconName | undefined;
  /**
   * The icon position
   * @default right
   */
  iconPosition: 'left' | 'right';
  /**
   * Dropdown mode
   */
  mode?: 'button' | 'link' | 'nav';
  /**
   * Change icon color if menu is dark
   * @default false
   */
  isDark: boolean;
  private elRef;
  protected isHostElement: boolean;
  get linkClass(): string;
  ngOnInit(): void;
  setDark(dark: boolean): void;
  static ɵfac: i0.ɵɵFactoryDeclaration<ItDropdownItemComponent, never>;
  static ɵcmp: i0.ɵɵComponentDeclaration<ItDropdownItemComponent, "it-dropdown-item, li[itDropdownItem]", never, {
    "divider": {
      "alias": "divider";
      "required": false;
    };
    "active": {
      "alias": "active";
      "required": false;
    };
    "large": {
      "alias": "large";
      "required": false;
    };
    "iconName": {
      "alias": "iconName";
      "required": false;
    };
    "iconPosition": {
      "alias": "iconPosition";
      "required": false;
    };
    "mode": {
      "alias": "mode";
      "required": false;
    };
  }, {}, never, ["*"], true, never>;
  static ngAcceptInputType_divider: BooleanInput;
  static ngAcceptInputType_active: BooleanInput;
  static ngAcceptInputType_large: BooleanInput;
}
declare namespace dropdown_component_d_exports {
  export { ItDropdownComponent };
}
export declare class ItDropdownComponent extends ItAbstractComponent implements AfterViewInit, OnChanges {
  /**
   * Dropdown mode
   */
  mode: 'button' | 'link' | 'nav';
  /**
   * Button color
   */
  color?: ButtonColor;
  /**
   * To open menu items to:
   * - <strong>dropup</strong>: up
   * - <strong>dropend</strong>: right
   * - <strong>dropstart</strong>: left
   */
  direction: DropdownDirection | undefined;
  /**
   * To get a dropdown menu as wide as the element containing the dropdown button
   * @default false
   */
  fullWidth?: boolean;
  /**
   * Contains a Megamenu element
   * @default false
   */
  megamenu?: boolean;
  /**
   * Dark menu style
   * @default false
   */
  dark?: boolean;
  /**
   * The dropdown items
   */
  items?: QueryList<ItDropdownItemComponent>;
  /**
   * Fires immediately when the show instance method is called.
   */
  showEvent: EventEmitter<Event>;
  /**
   * Fired when the dropdown has been made visible to the user and CSS transitions have completed.
   */
  shownEvent: EventEmitter<Event>;
  /**
   * Fires immediately when the hide instance method has been called.
   */
  hideEvent: EventEmitter<Event>;
  /**
   * Fired when the dropdown has finished being hidden from the user and CSS transitions have completed.
   */
  hiddenEvent: EventEmitter<Event>;
  private dropdown?;
  private dropdownButton?;
  get buttonClass(): string;
  ngOnChanges(changes: SimpleChanges): void;
  ngAfterViewInit(): void;
  /**
   * Set child items dark mode
   * @private
   */
  private setDarkItems;
  private updateListeners;
  /**
   * Toggles the dropdown menu of a given navbar or tabbed navigation.
   */
  toggle(): void;
  /**
   * Shows the dropdown menu of a given navbar or tabbed navigation.
   */
  show(): void;
  /**
   * Hides the dropdown menu of a given navbar or tabbed navigation.
   */
  hide(): void;
  /**
   * Updates the position of an element's dropdown.
   */
  update(): void;
  /**
   * Destroys an element's dropdown. (Removes stored data on the DOM element)
   */
  dispose(): void;
  static ɵfac: i0.ɵɵFactoryDeclaration<ItDropdownComponent, never>;
  static ɵcmp: i0.ɵɵComponentDeclaration<ItDropdownComponent, "it-dropdown", ["itDropdown"], {
    "mode": {
      "alias": "mode";
      "required": false;
    };
    "color": {
      "alias": "color";
      "required": false;
    };
    "direction": {
      "alias": "direction";
      "required": false;
    };
    "fullWidth": {
      "alias": "fullWidth";
      "required": false;
    };
    "megamenu": {
      "alias": "megamenu";
      "required": false;
    };
    "dark": {
      "alias": "dark";
      "required": false;
    };
  }, {
    "showEvent": "showEvent";
    "shownEvent": "shownEvent";
    "hideEvent": "hideEvent";
    "hiddenEvent": "hiddenEvent";
  }, ["items"], ["[listHeading]", "[list]", "[button]"], true, never>;
  static ngAcceptInputType_fullWidth: BooleanInput;
  static ngAcceptInputType_megamenu: BooleanInput;
  static ngAcceptInputType_dark: BooleanInput;
}
declare namespace dropdown_module_d_exports {
  export { ItDropdownModule };
}
export declare class ItDropdownModule {
  static ɵfac: i0.ɵɵFactoryDeclaration<ItDropdownModule, never>;
  static ɵmod: i0.ɵɵNgModuleDeclaration<ItDropdownModule, never, [typeof ItDropdownComponent, typeof ItDropdownItemComponent], [typeof ItDropdownComponent, typeof ItDropdownItemComponent]>;
  static ɵinj: i0.ɵɵInjectorDeclaration<ItDropdownModule>;
}
declare namespace forward_directive_d_exports {
  export { ItForwardDirective };
}
export declare class ItForwardDirective {
  private document;
  /**
   * Indica, se HTMLElement, l'elemento a cui navigare, o se stringa, il selettore che selezionerà l'elemento a cui navigare.
   */
  set itForward(value: HTMLElement | string | undefined);
  get itForward(): HTMLElement | string | undefined;
  private _itForward;
  onClick(event: any): void;
  static ɵfac: i0.ɵɵFactoryDeclaration<ItForwardDirective, never>;
  static ɵdir: i0.ɵɵDirectiveDeclaration<ItForwardDirective, "[itForward]", never, {
    "itForward": {
      "alias": "itForward";
      "required": false;
    };
  }, {}, never, never, true, never>;
}
declare namespace list_component_d_exports {
  export { ItListComponent };
}
export declare class ItListComponent {
  /**
   * Add 'link-list' class for navigation menu
   * @default false
   */
  linkList?: boolean;
  /**
   * Add 'link-sublist' class for navigation menu
   * @default false
   */
  linkSubList?: boolean;
  /**
   * Add 'multiline' class for wrapper
   * @default false
   */
  multiline?: boolean;
  static ɵfac: i0.ɵɵFactoryDeclaration<ItListComponent, never>;
  static ɵcmp: i0.ɵɵComponentDeclaration<ItListComponent, "it-list", never, {
    "linkList": {
      "alias": "linkList";
      "required": false;
    };
    "linkSubList": {
      "alias": "linkSubList";
      "required": false;
    };
    "multiline": {
      "alias": "multiline";
      "required": false;
    };
  }, {}, never, ["*"], true, never>;
  static ngAcceptInputType_linkList: BooleanInput;
  static ngAcceptInputType_linkSubList: BooleanInput;
  static ngAcceptInputType_multiline: BooleanInput;
}
declare namespace list_item_component_d_exports {
  export { ItListItemComponent };
}
export declare class ItListItemComponent extends ItLinkComponent implements OnInit {
  private elRef;
  protected isHostElement: boolean;
  /**
   * Add active class
   * @default false
   */
  active?: boolean;
  /**
   * Add large class
   */
  size?: 'large' | 'medium';
  /**
   * Add icon-left class
   * @default false
   */
  iconLeft?: boolean;
  /**
   * Add icon-right class
   * @default false
   */
  iconRight?: boolean;
  private _avatar;
  /**
   * The avatar url
   * @deprecated L'input 'avatar' è deprecato. Usa la documentazione del component Avatar per questo caso d'uso, facendo riferimento all'esempio Avatar con lista. Sarà rimosso nelle prossime versioni.
   */
  get avatar(): URL | undefined;
  set avatar(value: URL | undefined);
  /**
   * The thumb image url
   */
  image: URL | undefined;
  get itemClass(): string;
  ngOnInit(): void;
  static ɵfac: i0.ɵɵFactoryDeclaration<ItListItemComponent, never>;
  static ɵcmp: i0.ɵɵComponentDeclaration<ItListItemComponent, "it-list-item, li[itListItem]", never, {
    "active": {
      "alias": "active";
      "required": false;
    };
    "size": {
      "alias": "size";
      "required": false;
    };
    "iconLeft": {
      "alias": "iconLeft";
      "required": false;
    };
    "iconRight": {
      "alias": "iconRight";
      "required": false;
    };
    "avatar": {
      "alias": "avatar";
      "required": false;
    };
    "image": {
      "alias": "image";
      "required": false;
    };
  }, {}, never, ["[icon]", "*", "[action]", "[metadata]", "[multiple]"], true, never>;
  static ngAcceptInputType_active: BooleanInput;
  static ngAcceptInputType_iconLeft: BooleanInput;
  static ngAcceptInputType_iconRight: BooleanInput;
}
declare namespace list_module_d_exports {
  export { ItListModule };
}
export declare class ItListModule {
  static ɵfac: i0.ɵɵFactoryDeclaration<ItListModule, never>;
  static ɵmod: i0.ɵɵNgModuleDeclaration<ItListModule, never, [typeof ItListComponent, typeof ItListItemComponent], [typeof ItListComponent, typeof ItListItemComponent]>;
  static ɵinj: i0.ɵɵInjectorDeclaration<ItListModule>;
}
declare namespace modal_component_d_exports {
  export { ItModalComponent };
}
/**
 * Modal windows
 * @description To show featured content, notifications to users, or personalized content.
 */
export declare class ItModalComponent extends ItAbstractComponent implements AfterViewInit {
  /**
   * Show/Hide close button on header
   * @default true
   */
  closeButton: boolean;
  /**
   * To correctly format the contents of the modal with icon
   * @default false
   */
  alertModal?: boolean;
  /**
   * To correctly format the contents of the modal with Link List
   * @default false
   */
  dialogLinkList?: boolean;
  /**
   * Modal type Popconfirm can be used for short confirmation messages.
   * @default false
   */
  popconfirm?: boolean;
  /**
   * You can choose to use a scroll inside the modal, keeping the header and footer of the modal always visible
   * @default false
   */
  scrollable?: boolean;
  /**
   * To have modals that appear with fades
   * @default true
   */
  fade?: boolean;
  /**
   * Modal alignment
   * - <b>centered</b>: to vertically center the modal
   * - <b>left</b>: to left-align the modal
   * - <b>right</b>: to right-align the modal
   * @default undefined
   */
  alignment: 'centered' | 'left' | 'right' | undefined;
  /**
   * The modal size
   * @default undefined
   */
  size: 'sm' | 'lg' | 'xl' | undefined;
  /**
   * Includes a modal-backdrop element. Alternatively, specify static for a backdrop which doesn’t close the modal when clicked.
   * @default true
   */
  backdrop: 'static' | boolean;
  /**
   * Puts the focus on the modal when initialized.
   * @default true
   */
  focus: boolean;
  /**
   * Closes the modal when escape key is pressed.
   * @default true
   */
  keyboard: boolean;
  /**
   * To better distinguish the footer element with a shadow
   * @default false
   */
  footerShadow?: boolean;
  /**
   * Modal options
   */
  options?: Partial<Modal.Options>;
  /**
   * This event fires immediately when the instance method show is called.
   */
  showEvent: EventEmitter<Event>;
  /**
   * This event fires when the modal has been made visible to the user (it will wait for CSS transitions to complete).
   */
  shownEvent: EventEmitter<Event>;
  /**
   * This event is raised immediately when the instance method hide has been called.
   */
  hideEvent: EventEmitter<Event>;
  /**
   * This event fires when the modal has finished hiding from the user (it will wait for CSS transitions to complete).
   */
  hiddenEvent: EventEmitter<Event>;
  /**
   * This event is fired when the modal is displayed, its background is static and a click outside the modal or a press
   * of the esc key occurs and data-bs-keyboard is set to false.
   */
  hidePreventedEvent: EventEmitter<Event>;
  private modal?;
  private modalElement?;
  ngAfterViewInit(): void;
  protected get modalClass(): string;
  protected get dialogClass(): string;
  /**
   * Manually activate/deactivate a modal. Returns to the caller before the modal has actually been shown or hidden
   */
  toggle(): void;
  /**
   * Manually open a modal. Returns to the caller before the modal has actually been displayed
   */
  show(): void;
  /**
   * Manually hide a modal. Returns to the caller before the modal has actually been hidden
   */
  hide(): void;
  /**
   * Manually reposition the modal if the height of the modal changes when it is opened (in case a scroll bar appears).
   */
  handleUpdate(): void;
  /**
   * Destroys the modal of an element.
   */
  dispose(): void;
  static ɵfac: i0.ɵɵFactoryDeclaration<ItModalComponent, never>;
  static ɵcmp: i0.ɵɵComponentDeclaration<ItModalComponent, "it-modal", ["itModal"], {
    "closeButton": {
      "alias": "closeButton";
      "required": false;
    };
    "alertModal": {
      "alias": "alertModal";
      "required": false;
    };
    "dialogLinkList": {
      "alias": "dialogLinkList";
      "required": false;
    };
    "popconfirm": {
      "alias": "popconfirm";
      "required": false;
    };
    "scrollable": {
      "alias": "scrollable";
      "required": false;
    };
    "fade": {
      "alias": "fade";
      "required": false;
    };
    "alignment": {
      "alias": "alignment";
      "required": false;
    };
    "size": {
      "alias": "size";
      "required": false;
    };
    "backdrop": {
      "alias": "backdrop";
      "required": false;
    };
    "focus": {
      "alias": "focus";
      "required": false;
    };
    "keyboard": {
      "alias": "keyboard";
      "required": false;
    };
    "footerShadow": {
      "alias": "footerShadow";
      "required": false;
    };
    "options": {
      "alias": "options";
      "required": false;
    };
  }, {
    "showEvent": "showEvent";
    "shownEvent": "shownEvent";
    "hideEvent": "hideEvent";
    "hiddenEvent": "hiddenEvent";
    "hidePreventedEvent": "hidePreventedEvent";
  }, never, ["[beforeTitle]", "[modalTitle]", "[description]", "*", "[footer]"], true, never>;
  static ngAcceptInputType_closeButton: BooleanInput;
  static ngAcceptInputType_alertModal: BooleanInput;
  static ngAcceptInputType_dialogLinkList: BooleanInput;
  static ngAcceptInputType_popconfirm: BooleanInput;
  static ngAcceptInputType_scrollable: BooleanInput;
  static ngAcceptInputType_fade: BooleanInput;
  static ngAcceptInputType_focus: BooleanInput;
  static ngAcceptInputType_keyboard: BooleanInput;
  static ngAcceptInputType_footerShadow: BooleanInput;
}
declare namespace notifications_component_d_exports {
  export { ItNotificationsComponent };
}
export declare class ItNotificationsComponent implements OnDestroy {
  private readonly _changeDetectorRef;
  private readonly _notificationService;
  /**
   * Default notifications duration (milliseconds)
   * @default 8000
   */
  duration: number;
  /**
   * Default notifications position
   */
  position: NotificationPosition | undefined;
  /**
   * Default notifications is dismissible
   * @default true
   */
  dismissible: boolean;
  private subscription;
  private notificationCount;
  protected notifications: Array<Notification & {
    id: string;
  }>;
  constructor();
  ngOnDestroy(): void;
  protected get NotificationType(): typeof NotificationType;
  /**
   * Hide the notification
   * @param id
   */
  protected hideNotification(id: string): void;
  /**
   * Retrieve the icon name by notification type
   * @param notification the notification
   * @protected
   */
  private getNotificationIcon;
  static ɵfac: i0.ɵɵFactoryDeclaration<ItNotificationsComponent, never>;
  static ɵcmp: i0.ɵɵComponentDeclaration<ItNotificationsComponent, "it-notifications", never, {
    "duration": {
      "alias": "duration";
      "required": false;
    };
    "position": {
      "alias": "position";
      "required": false;
    };
    "dismissible": {
      "alias": "dismissible";
      "required": false;
    };
  }, {}, never, never, true, never>;
  static ngAcceptInputType_dismissible: BooleanInput;
}
declare namespace pagination_component_d_exports {
  export { ItPaginationComponent };
}
export declare class ItPaginationComponent implements OnChanges {
  /**
   * Index of page (start 0)
   */
  currentPage: number;
  /**
   * Max number of page (counter)
   */
  pageNumbers: number;
  /**
   * Number of pages closest to the current one to display
   * @default 5
   */
  visiblePages: number;
  /**
   * Pagination alignment (justify-content)
   */
  alignment: 'center' | 'end' | undefined;
  /**
   * Enable/Disable simple mode
   * Pagination in the "Simple mode" version is optimized for mobile devices.
   * @default false - disabled
   */
  simpleMode?: boolean;
  /**
   * Enable/Disable text links
   * Chevron icons used as navigation links are replaced by text links such as “previous” and “next”.
   * @default false - disabled
   */
  textLinks?: boolean;
  /**
   * Current value of Changer
   * If is set show the Changer
   * @default undefined - hide the Changer
   */
  currentChanger: number | undefined;
  /**
   * Available Changer values
   * @default [10, 25, 50, 100]
   */
  changerValues: Array<number>;
  /**
   * Hide/Show "Jump to page" input
   * @default false - hidden
   */
  showJumpToPage?: boolean;
  /**
   * Fired when page is changed. Emit the new index of page
   */
  pageEvent: EventEmitter<number>;
  /**
   * Fired when changer is changed. Emit the new changer value
   */
  changerEvent: EventEmitter<number>;
  /**
   * The pages
   * @protected
   */
  protected pages: Array<number>;
  /**
   * Jump to page input
   * @protected
   */
  protected jumpToPage: FormControl<number | null>;
  constructor();
  ngOnChanges(changes: SimpleChanges): void;
  /**
   * Create array to generate pagination of `visiblePages` element
   */
  private calculatePages;
  /**
   * On click page change
   * @param event click event
   * @param newPage the new page of table
   */
  protected pageChange(event: Event, newPage: number): void;
  /**
   * On click changer
   * @param event click event
   * @param value the new changer value
   */
  protected changerChange(event: Event, value: number): void;
  static ɵfac: i0.ɵɵFactoryDeclaration<ItPaginationComponent, never>;
  static ɵcmp: i0.ɵɵComponentDeclaration<ItPaginationComponent, "it-pagination", never, {
    "currentPage": {
      "alias": "currentPage";
      "required": true;
    };
    "pageNumbers": {
      "alias": "pageNumbers";
      "required": true;
    };
    "visiblePages": {
      "alias": "visiblePages";
      "required": false;
    };
    "alignment": {
      "alias": "alignment";
      "required": false;
    };
    "simpleMode": {
      "alias": "simpleMode";
      "required": false;
    };
    "textLinks": {
      "alias": "textLinks";
      "required": false;
    };
    "currentChanger": {
      "alias": "currentChanger";
      "required": false;
    };
    "changerValues": {
      "alias": "changerValues";
      "required": false;
    };
    "showJumpToPage": {
      "alias": "showJumpToPage";
      "required": false;
    };
  }, {
    "pageEvent": "pageEvent";
    "changerEvent": "changerEvent";
  }, never, ["*"], true, never>;
  static ngAcceptInputType_simpleMode: BooleanInput;
  static ngAcceptInputType_textLinks: BooleanInput;
  static ngAcceptInputType_showJumpToPage: BooleanInput;
}
declare namespace popover_directive_d_exports {
  export { ItPopoverDirective };
}
export declare class ItPopoverDirective implements AfterViewInit, OnDestroy {
  private readonly _elementRef;
  /**
   * Define the popover content
   * @param content the popover content
   */
  set content(content: string);
  /**
   * Define the popover title
   * @param title the popover title
   */
  set popoverTitle(title: string | undefined);
  /**
   * Define the popover placement
   * @param placement
   */
  set popoverPlacement(placement: ElementPlacement);
  /**
   * Appends the popover to a specific element.
   * @param container
   */
  set popoverContainer(container: 'body' | string | undefined);
  /**
   * Indicates whether the title contains html
   * @param html true if contain html
   */
  set popoverHtml(html: boolean);
  /**
   * How popover is triggered
   * - 'hover': To open the Popover on hover of the mouse over the element
   * - 'focus': To ignore popovers on the user's next click of an element other than the toggle element.
   * @param trigger
   */
  set popoverTrigger(trigger: 'click' | 'hover' | 'focus' | 'manual' | undefined);
  /**
   * This event fires immediately when the show method is called.
   */
  showEvent: EventEmitter<Event>;
  /**
   * This event is triggered when the tooltip has been made visible to the user (it will wait for the CSS transitions to complete).
   */
  shownEvent: EventEmitter<Event>;
  /**
   * This event fires immediately when the hide method is called.
   */
  hideEvent: EventEmitter<Event>;
  /**
   * This event is raised when the tooltip has finished being hidden from the user (it will wait for the CSS transitions to complete).
   */
  hiddenEvent: EventEmitter<Event>;
  /**
   * This event fires after the show event when the tooltip template has been added to the DOM.
   */
  insertedEvent: EventEmitter<Event>;
  private readonly element;
  private popover?;
  constructor();
  ngAfterViewInit(): void;
  ngOnDestroy(): void;
  /**
   * Shows the popover of an item.
   */
  show(): void;
  /**
   * Hide the popover of an element.
   */
  hide(): void;
  /**
   * Activate / Deactivate the popover of an element
   */
  toggle(): void;
  /**
   * Hides and destroys the popover of an element.
   */
  dispose(): void;
  /**
   * Gives the popover of an element a chance to be shown.
   */
  enable(): void;
  /**
   * Removes the ability to show the popover of an element.
   */
  disable(): void;
  /**
   * Toggles the possibility that the popover of an element is shown or hidden.
   */
  toggleEnabled(): void;
  /**
   * Updates the position of an element's popover.
   */
  update(): void;
  static ɵfac: i0.ɵɵFactoryDeclaration<ItPopoverDirective, never>;
  static ɵdir: i0.ɵɵDirectiveDeclaration<ItPopoverDirective, "[itPopover]", ["itPopover"], {
    "content": {
      "alias": "itPopover";
      "required": false;
    };
    "popoverTitle": {
      "alias": "popoverTitle";
      "required": false;
    };
    "popoverPlacement": {
      "alias": "popoverPlacement";
      "required": false;
    };
    "popoverContainer": {
      "alias": "popoverContainer";
      "required": false;
    };
    "popoverHtml": {
      "alias": "popoverHtml";
      "required": false;
    };
    "popoverTrigger": {
      "alias": "popoverTrigger";
      "required": false;
    };
  }, {
    "showEvent": "showEvent";
    "shownEvent": "shownEvent";
    "hideEvent": "hideEvent";
    "hiddenEvent": "hiddenEvent";
    "insertedEvent": "insertedEvent";
  }, never, never, true, never>;
  static ngAcceptInputType_popoverHtml: BooleanInput;
}
declare namespace progress_bar_component_d_exports {
  export { ItProgressBarComponent };
}
export declare class ItProgressBarComponent {
  /**
   * The progress bar value [0, 100]
   */
  value: number;
  /**
   * Show the progress label
   * @default false
   */
  showLabel?: boolean;
  /**
   * Show the progress as indeterminate
   * @default false
   */
  indeterminate?: boolean;
  /**
   * The progress bar color
   */
  color: ProgressBarColor | undefined;
  /**
   * Return the background color
   */
  get bgColor(): string;
  static ɵfac: i0.ɵɵFactoryDeclaration<ItProgressBarComponent, never>;
  static ɵcmp: i0.ɵɵComponentDeclaration<ItProgressBarComponent, "it-progress-bar", never, {
    "value": {
      "alias": "value";
      "required": true;
    };
    "showLabel": {
      "alias": "showLabel";
      "required": false;
    };
    "indeterminate": {
      "alias": "indeterminate";
      "required": false;
    };
    "color": {
      "alias": "color";
      "required": false;
    };
  }, {}, never, never, true, never>;
  static ngAcceptInputType_showLabel: BooleanInput;
  static ngAcceptInputType_indeterminate: BooleanInput;
}
declare namespace progress_button_component_d_exports {
  export { ItProgressButtonComponent };
}
export declare class ItProgressButtonComponent {
  /**
   * Behavior of the progress bar
   * - <b>true</b>: Show indeterminate progress bar
   * - <b>false</b> or <b>undefined</b>: Hide progress bar
   * - <b>number</b> [0, 100]: Assign a specific value to the progress bar
   * @default undefined
   */
  progress: number | boolean | undefined;
  /**
   * The progress bar color
   */
  progressColor: ProgressBarColor | undefined;
  get isProgress(): boolean;
  get progressValue(): number;
  get isIndeterminate(): boolean;
  static ɵfac: i0.ɵɵFactoryDeclaration<ItProgressButtonComponent, never>;
  static ɵcmp: i0.ɵɵComponentDeclaration<ItProgressButtonComponent, "button[itButton][progress]", never, {
    "progress": {
      "alias": "progress";
      "required": false;
    };
    "progressColor": {
      "alias": "progressColor";
      "required": false;
    };
  }, {}, never, ["*"], true, never>;
}
declare namespace spinner_component_d_exports {
  export { ItSpinnerComponent };
}
export declare class ItSpinnerComponent {
  /**
   * The spinner is active
   * @default true
   */
  active: boolean;
  /**
   * Show a small spinner
   * @default false
   */
  small?: boolean;
  /**
   * Show the double animation
   * @default false
   */
  double?: boolean;
  static ɵfac: i0.ɵɵFactoryDeclaration<ItSpinnerComponent, never>;
  static ɵcmp: i0.ɵɵComponentDeclaration<ItSpinnerComponent, "it-spinner", never, {
    "active": {
      "alias": "active";
      "required": false;
    };
    "small": {
      "alias": "small";
      "required": false;
    };
    "double": {
      "alias": "double";
      "required": false;
    };
  }, {}, never, never, true, never>;
  static ngAcceptInputType_active: BooleanInput;
  static ngAcceptInputType_small: BooleanInput;
  static ngAcceptInputType_double: BooleanInput;
}
declare namespace steppers_item_component_d_exports {
  export { ItSteppersItemComponent };
}
export declare class ItSteppersItemComponent extends ItAbstractComponent {
  /**
   * The labels present in the header steps
   */
  label: string;
  /**
   * The labels present in the header steps can be preceded by an icon.
   */
  icon: IconName | undefined;
  /**
   * The title for the icon.
   */
  iconTitle: string | undefined;
  /**
   * The content of step
   */
  htmlContent: TemplateRef<any>;
  static ɵfac: i0.ɵɵFactoryDeclaration<ItSteppersItemComponent, never>;
  static ɵcmp: i0.ɵɵComponentDeclaration<ItSteppersItemComponent, "it-steppers-item", never, {
    "label": {
      "alias": "label";
      "required": true;
    };
    "icon": {
      "alias": "icon";
      "required": false;
    };
    "iconTitle": {
      "alias": "iconTitle";
      "required": false;
    };
  }, {}, never, ["*"], true, never>;
}
declare namespace steppers_container_component_d_exports {
  export { ItSteppersContainerComponent };
}
export declare class ItSteppersContainerComponent implements AfterViewInit, OnDestroy {
  private readonly _changeDetectorRef;
  /**
   * The confirmed label if different from default
   * @default null
   */
  confirmedLabel: string | null;
  /**
   * The active step index
   * @param index the step index
   */
  activeStep: number;
  /**
   * Show the stepper header
   * @default true
   */
  showHeader: boolean;
  /**
   * Dark style
   * @default false
   */
  dark?: boolean;
  /**
   * The labels present in the header steps can be anticipated by the relative ordinal number.
   * @efualt false
   */
  steppersNumber?: boolean;
  /**
   * The progress style
   * -<b>progress</b>: Show progress bar - You can change the color with the `progressColor` attribute
   * -<b>dots</b>: Show progress dots
   * @default undefined - don't show progress
   */
  progressStyle: 'progress' | 'dots' | undefined;
  /**
   * Customize progress color
   */
  progressColor: ProgressBarColor | undefined;
  /**
   * Show the back button
   * @default true
   */
  showBackButton: boolean;
  /**
   * Disable the back button
   * @default false
   */
  disableBackButton?: boolean;
  /**
   * Show the forward button
   * @default true
   */
  showForwardButton: boolean;
  /**
   * Disable the forward button
   * @default false
   */
  disableForwardButton?: boolean;
  /**
   * Show the confirm button
   * @default false
   */
  showConfirmButton?: boolean;
  /**
   * Disable the confirm button
   * @default false
   */
  disableConfirmButton?: boolean;
  /**
   * Show the confirm button as indeterminate progress button
   */
  confirmLoading?: boolean;
  /**
   * Show the save button
   * @default false
   */
  showSaveButton?: boolean;
  /**
   * Disable the save button
   * @default false
   */
  disableSaveButton?: boolean;
  /**
   * Show the save button as indeterminate progress button
   */
  saveLoading?: boolean;
  /**
   * The stepper items
   */
  steps?: QueryList<ItSteppersItemComponent>;
  /**
   * On back button click
   * @event activeStep the current step index
   */
  backClick: EventEmitter<number>;
  /**
   * On forward button click
   * @event activeStep the current step index
   */
  forwardClick: EventEmitter<number>;
  /**
   * On confirm button click
   * @event activeStep the current step index
   */
  confirmClick: EventEmitter<number>;
  /**
   * On save button click
   * @event activeStep the current step index
   */
  saveClick: EventEmitter<number>;
  private stepsSubscriptions?;
  constructor();
  ngAfterViewInit(): void;
  ngOnDestroy(): void;
  static ɵfac: i0.ɵɵFactoryDeclaration<ItSteppersContainerComponent, never>;
  static ɵcmp: i0.ɵɵComponentDeclaration<ItSteppersContainerComponent, "it-steppers-container", never, {
    "confirmedLabel": {
      "alias": "confirmedLabel";
      "required": false;
    };
    "activeStep": {
      "alias": "activeStep";
      "required": true;
    };
    "showHeader": {
      "alias": "showHeader";
      "required": false;
    };
    "dark": {
      "alias": "dark";
      "required": false;
    };
    "steppersNumber": {
      "alias": "steppersNumber";
      "required": false;
    };
    "progressStyle": {
      "alias": "progressStyle";
      "required": false;
    };
    "progressColor": {
      "alias": "progressColor";
      "required": false;
    };
    "showBackButton": {
      "alias": "showBackButton";
      "required": false;
    };
    "disableBackButton": {
      "alias": "disableBackButton";
      "required": false;
    };
    "showForwardButton": {
      "alias": "showForwardButton";
      "required": false;
    };
    "disableForwardButton": {
      "alias": "disableForwardButton";
      "required": false;
    };
    "showConfirmButton": {
      "alias": "showConfirmButton";
      "required": false;
    };
    "disableConfirmButton": {
      "alias": "disableConfirmButton";
      "required": false;
    };
    "confirmLoading": {
      "alias": "confirmLoading";
      "required": false;
    };
    "showSaveButton": {
      "alias": "showSaveButton";
      "required": false;
    };
    "disableSaveButton": {
      "alias": "disableSaveButton";
      "required": false;
    };
    "saveLoading": {
      "alias": "saveLoading";
      "required": false;
    };
  }, {
    "backClick": "backClick";
    "forwardClick": "forwardClick";
    "confirmClick": "confirmClick";
    "saveClick": "saveClick";
  }, ["steps"], never, true, never>;
  static ngAcceptInputType_showHeader: BooleanInput;
  static ngAcceptInputType_dark: BooleanInput;
  static ngAcceptInputType_steppersNumber: BooleanInput;
  static ngAcceptInputType_showBackButton: BooleanInput;
  static ngAcceptInputType_disableBackButton: BooleanInput;
  static ngAcceptInputType_showForwardButton: BooleanInput;
  static ngAcceptInputType_disableForwardButton: BooleanInput;
  static ngAcceptInputType_showConfirmButton: BooleanInput;
  static ngAcceptInputType_disableConfirmButton: BooleanInput;
  static ngAcceptInputType_confirmLoading: BooleanInput;
  static ngAcceptInputType_showSaveButton: BooleanInput;
  static ngAcceptInputType_disableSaveButton: BooleanInput;
  static ngAcceptInputType_saveLoading: BooleanInput;
}
declare namespace steppers_module_d_exports {
  export { ItSteppersModule };
}
export declare class ItSteppersModule {
  static ɵfac: i0.ɵɵFactoryDeclaration<ItSteppersModule, never>;
  static ɵmod: i0.ɵɵNgModuleDeclaration<ItSteppersModule, never, [typeof ItSteppersContainerComponent, typeof ItSteppersItemComponent], [typeof ItSteppersContainerComponent, typeof ItSteppersItemComponent]>;
  static ɵinj: i0.ɵɵInjectorDeclaration<ItSteppersModule>;
}
declare namespace tab_item_component_d_exports {
  export { ItTabItemComponent };
}
export declare class ItTabItemComponent extends ItAbstractComponent implements AfterViewInit {
  /**
   * The tab label
   */
  label: string | undefined;
  /**
   * The icon name
   */
  icon: IconName | undefined;
  /**
   * Default active tab
   * @default false
   */
  active?: boolean;
  /**
   * Default disabled tab
   * @default false
   */
  disabled?: boolean;
  /**
   * Custom class
   */
  class: string;
  /**
   * The content of tab
   */
  htmlContent: TemplateRef<any>;
  ngAfterViewInit(): void;
  static ɵfac: i0.ɵɵFactoryDeclaration<ItTabItemComponent, never>;
  static ɵcmp: i0.ɵɵComponentDeclaration<ItTabItemComponent, "it-tab-item", never, {
    "label": {
      "alias": "label";
      "required": false;
    };
    "icon": {
      "alias": "icon";
      "required": false;
    };
    "active": {
      "alias": "active";
      "required": false;
    };
    "disabled": {
      "alias": "disabled";
      "required": false;
    };
    "class": {
      "alias": "class";
      "required": false;
    };
  }, {}, never, ["*"], true, never>;
  static ngAcceptInputType_active: BooleanInput;
  static ngAcceptInputType_disabled: BooleanInput;
}
declare namespace tab_container_component_d_exports {
  export { ItTabContainerComponent };
}
export declare class ItTabContainerComponent extends ItAbstractComponent implements OnDestroy, AfterViewInit {
  /**
   * Tabs automatically occupy the entire available width
   * @default false
   */
  auto?: boolean;
  /**
   * To obtain the correct margin between text and icon in the horizontally developed tab
   */
  iconText?: boolean;
  /**
   * Dark style
   */
  dark?: boolean;
  /**
   * Show items as cards
   */
  cards?: boolean;
  /**
   * Show vertical navigation
   */
  vertical?: boolean;
  /**
   * The tab position
   */
  inverted?: boolean;
  /**
   * If tabs are editable
   */
  editable?: boolean;
  /**
   * The tab items
   */
  tabs?: QueryList<ItTabItemComponent>;
  private tabNavLinks?;
  tabSelected: EventEmitter<ItTabItemComponent>;
  tabClosed: EventEmitter<any>;
  tabAdded: EventEmitter<any>;
  private tabSubscriptions?;
  constructor();
  ngAfterViewInit(): void;
  ngOnDestroy(): void;
  onTab(tab: ItTabItemComponent): void;
  clickToClose(index: number): void;
  clickToAdd($event: Event): void;
  static ɵfac: i0.ɵɵFactoryDeclaration<ItTabContainerComponent, never>;
  static ɵcmp: i0.ɵɵComponentDeclaration<ItTabContainerComponent, "it-tab-container", never, {
    "auto": {
      "alias": "auto";
      "required": false;
    };
    "iconText": {
      "alias": "iconText";
      "required": false;
    };
    "dark": {
      "alias": "dark";
      "required": false;
    };
    "cards": {
      "alias": "cards";
      "required": false;
    };
    "vertical": {
      "alias": "vertical";
      "required": false;
    };
    "inverted": {
      "alias": "inverted";
      "required": false;
    };
    "editable": {
      "alias": "editable";
      "required": false;
    };
  }, {
    "tabSelected": "tabSelected";
    "tabClosed": "tabClosed";
    "tabAdded": "tabAdded";
  }, ["tabs"], never, true, never>;
  static ngAcceptInputType_auto: BooleanInput;
  static ngAcceptInputType_iconText: BooleanInput;
  static ngAcceptInputType_dark: BooleanInput;
  static ngAcceptInputType_cards: BooleanInput;
  static ngAcceptInputType_vertical: BooleanInput;
  static ngAcceptInputType_inverted: BooleanInput;
  static ngAcceptInputType_editable: BooleanInput;
}
declare namespace tab_module_d_exports {
  export { ItTabModule };
}
export declare class ItTabModule {
  static ɵfac: i0.ɵɵFactoryDeclaration<ItTabModule, never>;
  static ɵmod: i0.ɵɵNgModuleDeclaration<ItTabModule, never, [typeof ItTabContainerComponent, typeof ItTabItemComponent], [typeof ItTabContainerComponent, typeof ItTabItemComponent]>;
  static ɵinj: i0.ɵɵInjectorDeclaration<ItTabModule>;
}
declare namespace table_component_d_exports {
  export { ItTableComponent };
}
export declare class ItTableComponent {
  /**
   * Table color
   */
  color: TableColor | undefined;
  /**
   * Head table color
   */
  headColor: TableHeadColor | undefined;
  /**
   * Use vertical alignment classes to realign where needed.
   */
  alignment: VerticalAlignment | undefined;
  /**
   * Use .table-striped to add zebra stripes to each table row contained in <tbody>.
   * @default false
   */
  striped?: boolean;
  /**
   * Add .table-hover to enable hover state on table rows contained in <tbody>.
   * @default false
   */
  hover?: boolean;
  /**
   * Add .table-bordered to have borders on all sides of the table and on all cells.
   * @default false
   */
  bordered?: boolean;
  /**
   * Add the .table-borderless class for a borderless table.
   * @default false
   */
  borderless?: boolean;
  /**
   * Add .table-sm to make tables more compact by halving the cell padding.
   * @efault false
   */
  compact?: boolean;
  /**
   * To render the <caption> on top of the table
   * @default false
   */
  captionTop?: boolean;
  /**
   * Responsive tables allow you to scroll tables horizontally with ease.
   * @default responsive
   */
  responsive: TableResponsive;
  static ɵfac: i0.ɵɵFactoryDeclaration<ItTableComponent, never>;
  static ɵcmp: i0.ɵɵComponentDeclaration<ItTableComponent, "it-table", never, {
    "color": {
      "alias": "color";
      "required": false;
    };
    "headColor": {
      "alias": "headColor";
      "required": false;
    };
    "alignment": {
      "alias": "alignment";
      "required": false;
    };
    "striped": {
      "alias": "striped";
      "required": false;
    };
    "hover": {
      "alias": "hover";
      "required": false;
    };
    "bordered": {
      "alias": "bordered";
      "required": false;
    };
    "borderless": {
      "alias": "borderless";
      "required": false;
    };
    "compact": {
      "alias": "compact";
      "required": false;
    };
    "captionTop": {
      "alias": "captionTop";
      "required": false;
    };
    "responsive": {
      "alias": "responsive";
      "required": false;
    };
  }, {}, never, ["[caption]", "[thead]", "[tbody]", "[tfoot]"], true, never>;
  static ngAcceptInputType_striped: BooleanInput;
  static ngAcceptInputType_hover: BooleanInput;
  static ngAcceptInputType_bordered: BooleanInput;
  static ngAcceptInputType_borderless: BooleanInput;
  static ngAcceptInputType_compact: BooleanInput;
  static ngAcceptInputType_captionTop: BooleanInput;
}
export type SortDirection = 'asc' | 'desc' | undefined;
/** Position of the arrow that displays when sorted. */
export type SortHeaderArrowPosition = 'before' | 'after';
/** Interface for a directive that holds sorting state consumed by `ItSortHeader`. */
export interface ItSortable {
  /** The id of the column being sorted. */
  id: string;
  /** Starting sort direction. */
  start?: SortDirection;
  /** Whether to disable clearing the sorting state. */
  disableSortClear?: boolean;
}
/** The current sort state. */
export interface ItSortEvent {
  /** The id of the column being sorted. */
  active: string;
  /** The sort direction. */
  direction: SortDirection;
}
/**
 * Default options for `it-sort`.
 */
export interface ItSortDefaultOptions {
  /** Whether to disable clearing the sorting state. */
  disableClear?: boolean;
  /** Position of the arrow that displays when sorted. */
  arrowPosition?: SortHeaderArrowPosition;
}
/**
 * Injection token to be used to override the default options for `it-sort`.
 */
export declare const IT_SORT_DEFAULT_OPTIONS: InjectionToken<ItSortDefaultOptions>;
declare namespace sort_directive_d_exports {
  export { ItSortDirective };
}
export declare class ItSortDirective implements OnChanges, OnDestroy {
  private _defaultOptions;
  /** The id of the most recently sorted ItSortable. */
  active?: string;
  /**
   * The direction to set when an MatSortable is initially sorted.
   * May be overridden by the MatSortable's sort start.
   */
  start: SortDirection;
  /** The sort direction of the currently active ItSortable. */
  get direction(): SortDirection;
  set direction(direction: SortDirection);
  private _direction;
  /**
   * Whether to disable the user from clearing the sort by finishing the sort direction cycle.
   * May be overridden by the ItSortable's disable clear input.
   */
  disableSortClear?: boolean;
  /** Whether the sortable is disabled. */
  sortDisabled: boolean;
  /** Event emitted when the user changes either the active sort or sort direction. */
  readonly sortChange: EventEmitter<ItSortEvent>;
  readonly sortDirectiveClass = "it-sort";
  /** Collection of all registered sortables that this directive manages. */
  protected sortables: Map<string, ItSortable>;
  /** Used to notify any child components listening to state changes. */
  readonly _stateChanges: Subject<void>;
  /**
   * Register function to be used by the contained ItSortables. Adds the ItSortable to the
   * collection of ItSortables.
   */
  register(sortable: ItSortable): void;
  /**
   * Unregister function to be used by the contained ItSortables. Removes the ItSortable from the
   * collection of contained ItSortables.
   */
  deregister(sortable: ItSortable): void;
  /** Sets the active sort id and determines the new sort direction. */
  sort(sortable: ItSortable): void;
  /** Returns the next sort direction of the active sortable, checking for potential overrides. */
  getNextSortDirection(sortable: ItSortable): SortDirection;
  ngOnChanges(): void;
  ngOnDestroy(): void;
  static ɵfac: i0.ɵɵFactoryDeclaration<ItSortDirective, never>;
  static ɵdir: i0.ɵɵDirectiveDeclaration<ItSortDirective, "[itSort]", ["itSort"], {
    "active": {
      "alias": "itSortActive";
      "required": false;
    };
    "start": {
      "alias": "itSortStart";
      "required": false;
    };
    "direction": {
      "alias": "itSortDirection";
      "required": false;
    };
    "disableSortClear": {
      "alias": "disableSortClear";
      "required": false;
    };
    "sortDisabled": {
      "alias": "sortDisabled";
      "required": false;
    };
  }, {
    "sortChange": "sortChange";
  }, never, never, true, never>;
  static ngAcceptInputType_disableSortClear: unknown;
  static ngAcceptInputType_sortDisabled: unknown;
}
declare namespace sort_header_component_d_exports {
  export { ItSortHeaderComponent };
}
/**
 * Applies sorting behavior (click to change sort) and styles to an element, including an
 * arrow to display the current sort direction.
 *
 * Must be provided with an id and contained within a parent ItSort directive.
 *
 * If used on header cells in a CdkTable, it will automatically default its id from its containing
 * column definition.
 */
export declare class ItSortHeaderComponent implements ItSortable, OnDestroy, OnInit {
  private readonly _changeDetectorRef;
  readonly _sort: ItSortDirective;
  /**
   * ID of this sort header. If used within the context of a CdkColumnDef, this will default to
   * the column's name.
   */
  id: string;
  /** Sets the position of the arrow that displays when sorted. */
  arrowPosition: SortHeaderArrowPosition;
  /** Overrides the sort start value of the containing MatSort for this SortHeaderComponent. */
  start?: SortDirection;
  /** whether the sort header is disabled. */
  sortDisabled: boolean;
  /** Overrides the disable clear value of the containing SortDirective for this MatSortable. */
  disableSortClear?: boolean;
  readonly sortHeaderClass = "it-sort-header";
  private _rerenderSubscription?;
  /** The direction the arrow should be facing according to the current state. */
  private _arrowDirection?;
  constructor();
  ngOnInit(): void;
  ngOnDestroy(): void;
  _handleClick(): void;
  /**
   * Whether this MatSortHeader is currently sorted in either ascending or descending order.
   */
  protected get isSorted(): boolean;
  /**
   * Returns the icon class by the arrow direction
   */
  protected get arrowIconClass(): IconName;
  /**
   * Updates the direction the arrow should be pointing. If it is not sorted, the arrow should be
   * facing the start direction. Otherwise if it is sorted, the arrow should point in the currently
   * active sorted direction. The reason this is updated through a function is because the direction
   * should only be changed at specific times - when deactivated but the hint is displayed and when
   * the sort is active and the direction changes. Otherwise the arrow's direction should linger
   * in cases such as the sort becoming deactivated but we want to animate the arrow away while
   * preserving its direction, even though the next sort direction is actually different and should
   * only be changed once the arrow displays again (hint or activation).
   */
  private updateArrowDirection;
  get isDisabled(): boolean;
  /**
   * Gets the aria-sort attribute that should be applied to this sort header. If this header
   * is not sorted, returns null so that the attribute is removed from the host element. Aria spec
   * says that the aria-sort property should only be present on one header at a time, so removing
   * ensures this is true.
   */
  get ariaSortAttribute(): "none" | "ascending" | "descending";
  /** Handles changes in the sorting state. */
  private _handleStateChanges;
  static ɵfac: i0.ɵɵFactoryDeclaration<ItSortHeaderComponent, never>;
  static ɵcmp: i0.ɵɵComponentDeclaration<ItSortHeaderComponent, "[it-sort-header]", ["itSortHeader"], {
    "id": {
      "alias": "it-sort-header";
      "required": false;
    };
    "arrowPosition": {
      "alias": "arrowPosition";
      "required": false;
    };
    "start": {
      "alias": "start";
      "required": false;
    };
    "sortDisabled": {
      "alias": "sortDisabled";
      "required": false;
    };
    "disableSortClear": {
      "alias": "disableSortClear";
      "required": false;
    };
  }, {}, never, ["*"], true, never>;
  static ngAcceptInputType_sortDisabled: unknown;
  static ngAcceptInputType_disableSortClear: unknown;
}
declare namespace table_module_d_exports {
  export { ItTableModule };
}
export declare class ItTableModule {
  static ɵfac: i0.ɵɵFactoryDeclaration<ItTableModule, never>;
  static ɵmod: i0.ɵɵNgModuleDeclaration<ItTableModule, never, [typeof ItTableComponent, typeof ItSortDirective, typeof ItSortHeaderComponent], [typeof ItTableComponent, typeof ItSortDirective, typeof ItSortHeaderComponent]>;
  static ɵinj: i0.ɵɵInjectorDeclaration<ItTableModule>;
}
declare namespace tooltip_directive_d_exports {
  export { ItTooltipDirective };
}
export declare class ItTooltipDirective implements AfterViewInit, OnDestroy {
  private readonly _elementRef;
  /**
   * Define the tooltip title
   * @param title the tooltip title
   */
  set title(title: string | undefined);
  /**
   * Define the tooltip placement
   * @param placement
   */
  set tooltipPlacement(placement: ElementPlacement);
  /**
   * Indicates whether the title contains html
   * @param html true if contain html
   */
  set tooltipHtml(html: boolean);
  /**
   * This event fires immediately when the show method is called.
   */
  showEvent: EventEmitter<Event>;
  /**
   * This event is triggered when the tooltip has been made visible to the user (it will wait for the CSS transitions to complete).
   */
  shownEvent: EventEmitter<Event>;
  /**
   * This event fires immediately when the hide method is called.
   */
  hideEvent: EventEmitter<Event>;
  /**
   * This event is raised when the tooltip has finished being hidden from the user (it will wait for the CSS transitions to complete).
   */
  hiddenEvent: EventEmitter<Event>;
  /**
   * This event fires after the show event when the tooltip template has been added to the DOM.
   */
  insertedEvent: EventEmitter<Event>;
  private readonly element;
  private tooltip?;
  constructor();
  ngAfterViewInit(): void;
  ngOnDestroy(): void;
  /**
   * Shows the tooltip of an item.
   */
  show(): void;
  /**
   * Hide the tooltip of an element.
   */
  hide(): void;
  /**
   * Activate / Deactivate the tooltip of an element
   */
  toggle(): void;
  /**
   * Hides and destroys the tooltip of an element.
   */
  dispose(): void;
  /**
   * Gives the tooltip of an element a chance to be shown.
   */
  enable(): void;
  /**
   * Removes the ability to show the tooltip of an element.
   */
  disable(): void;
  /**
   * Toggles the possibility that the tooltip of an element is shown or hidden.
   */
  toggleEnabled(): void;
  /**
   * Updates the position of an element's tooltip.
   */
  update(): void;
  static ɵfac: i0.ɵɵFactoryDeclaration<ItTooltipDirective, never>;
  static ɵdir: i0.ɵɵDirectiveDeclaration<ItTooltipDirective, "[itTooltip]", ["itTooltip"], {
    "title": {
      "alias": "itTooltip";
      "required": false;
    };
    "tooltipPlacement": {
      "alias": "tooltipPlacement";
      "required": false;
    };
    "tooltipHtml": {
      "alias": "tooltipHtml";
      "required": false;
    };
  }, {
    "showEvent": "showEvent";
    "shownEvent": "shownEvent";
    "hideEvent": "hideEvent";
    "hiddenEvent": "hiddenEvent";
    "insertedEvent": "insertedEvent";
  }, never, never, true, never>;
  static ngAcceptInputType_tooltipHtml: BooleanInput;
}
declare namespace timeline_component_d_exports {
  export { ItTimelineComponent };
}
/**
 * Timeline
 * @description Build timeline for chronological representation of events.
 */
export declare class ItTimelineComponent extends ItAbstractComponent {
  /**
   * Timeline elements array
   * @default []
   */
  timelineElements: TimelineElement[];
  /**
   * Default date format for timeline element reference date
   * @default dd/MM/yyyy
   */
  dateFormat: string;
  static ɵfac: i0.ɵɵFactoryDeclaration<ItTimelineComponent, never>;
  static ɵcmp: i0.ɵɵComponentDeclaration<ItTimelineComponent, "it-timeline", never, {
    "timelineElements": {
      "alias": "timelineElements";
      "required": false;
    };
    "dateFormat": {
      "alias": "dateFormat";
      "required": false;
    };
  }, {}, never, never, true, never>;
}
declare namespace timeline_item_component_d_exports {
  export { ItTimelineItemComponent };
}
/**
 * Timeline Item
 * @description Represents a single event for Timeline component.
 */
export declare class ItTimelineItemComponent extends ItAbstractComponent {
  /**
   * Timeline element title
   */
  title: string;
  /**
   * Timeline element text
   */
  text: string;
  /**
   * Timeline element signature
   */
  signature: string | undefined;
  /**
   * Timeline element reference date
   */
  eventDate: Date | undefined;
  /**
   * Timeline element reference date format
   * @default dd/MM/yyyy
   */
  dateFormat: string;
  /**
   * Timeline element PIN text
   */
  pinText: string | undefined;
  /**
   * Timeline element PIN type
   * @default none
   */
  pinType: TimelinePINType | undefined;
  /**
   * Timeline element PIN icon
   * @default code-circle
   */
  pinIcon: IconName | undefined;
  /**
   * Timeline element PIN icon
   * @default code-circle
   */
  pinIconTitle: string | undefined;
  /**
   * Timeline element category label
   */
  categoryLabel: string | undefined;
  /**
   * Timeline element date label
   */
  dateLabel: string | undefined;
  /**
   * Timeline element category title
   */
  categoryTitle: string | undefined;
  /**
   * Timeline element category link
   */
  categoryLink: string | undefined;
  /**
   * Timeline element show detail link
   * @default false
   */
  showReadMore: boolean;
  /** Timeline element detail link
   * @default #
   */
  readMoreLink: string | undefined;
  static ɵfac: i0.ɵɵFactoryDeclaration<ItTimelineItemComponent, never>;
  static ɵcmp: i0.ɵɵComponentDeclaration<ItTimelineItemComponent, "it-timeline-item", never, {
    "title": {
      "alias": "title";
      "required": true;
    };
    "text": {
      "alias": "text";
      "required": true;
    };
    "signature": {
      "alias": "signature";
      "required": false;
    };
    "eventDate": {
      "alias": "eventDate";
      "required": false;
    };
    "dateFormat": {
      "alias": "dateFormat";
      "required": false;
    };
    "pinText": {
      "alias": "pinText";
      "required": true;
    };
    "pinType": {
      "alias": "pinType";
      "required": false;
    };
    "pinIcon": {
      "alias": "pinIcon";
      "required": false;
    };
    "pinIconTitle": {
      "alias": "pinIconTitle";
      "required": false;
    };
    "categoryLabel": {
      "alias": "categoryLabel";
      "required": false;
    };
    "dateLabel": {
      "alias": "dateLabel";
      "required": false;
    };
    "categoryTitle": {
      "alias": "categoryTitle";
      "required": false;
    };
    "categoryLink": {
      "alias": "categoryLink";
      "required": false;
    };
    "showReadMore": {
      "alias": "showReadMore";
      "required": false;
    };
    "readMoreLink": {
      "alias": "readMoreLink";
      "required": false;
    };
  }, {}, never, never, true, never>;
  static ngAcceptInputType_showReadMore: BooleanInput;
}
declare namespace timeline_module_d_exports {
  export { ItTimelineModule };
}
export declare class ItTimelineModule {
  static ɵfac: i0.ɵɵFactoryDeclaration<ItTimelineModule, never>;
  static ɵmod: i0.ɵɵNgModuleDeclaration<ItTimelineModule, never, [typeof ItTimelineComponent, typeof ItTimelineItemComponent], [typeof ItTimelineComponent, typeof ItTimelineItemComponent]>;
  static ɵinj: i0.ɵɵInjectorDeclaration<ItTimelineModule>;
}
interface VideoJsTranslation {
  'Audio Player': string;
  'Video Player': string;
  Play: string;
  Pause: string;
  Replay: string;
  'Current Time': string;
  Duration: string;
  'Remaining Time': string;
  'Stream Type': string;
  LIVE: string;
  Loaded: string;
  Progress: string;
  'Progress Bar': string;
  'progress bar timing: currentTime={1} duration={2}': string;
  Fullscreen: string;
  'Exit Fullscreen': string;
  Mute: string;
  Unmute: string;
  'Playback Rate': string;
  Subtitles: string;
  'subtitles off': string;
  Captions: string;
  'captions off': string;
  Chapters: string;
  Descriptions: string;
  'descriptions off': string;
  'Audio Track': string;
  'Volume Level': string;
  'You aborted the media playback': string;
  'A network error caused the media download to fail part-way.': string;
  'The media could not be loaded, either because the server or network failed or because the format is not supported.': string;
  'The media playback was aborted due to a corruption problem or because the media used features your browser did not support.': string;
  'No compatible source was found for this media.': string;
  'The media is encrypted and we do not have the keys to decrypt it.': string;
  'Play Video': string;
  Close: string;
  'Close Modal Dialog': string;
  'Modal Window': string;
  'This is a modal window': string;
  'This modal can be closed by pressing the Escape key or activating the close button.': string;
  ', opens captions settings dialog': string;
  ', opens subtitles settings dialog': string;
  ', opens descriptions settings dialog': string;
  ', selected': string;
  'captions settings': string;
  'subtitles settings': string;
  'descriptions settings': string;
  Text: string;
  White: string;
  Black: string;
  Red: string;
  Green: string;
  Blue: string;
  Yellow: string;
  Magenta: string;
  Cyan: string;
  Background: string;
  Window: string;
  Transparent: string;
  'Semi-Transparent': string;
  Opaque: string;
  'Font Size': string;
  'Text Edge Style': string;
  None: string;
  Uniform: string;
  'Drop shadow': string;
  'Font Family': string;
  'Proportional Sans-Serif': string;
  'Monospace Sans-Serif': string;
  'Proportional Serif': string;
  'Monospace Serif': string;
  'Small Caps': string;
  Reset: string;
  'restore all settings to the default values': string;
  Done: string;
  'Caption Settings Dialog': string;
  'Beginning of dialog window. Escape will cancel and close the window.': string;
  'End of dialog window.': string;
  '{1} is loading.': string;
  'Exit Picture-in-Picture': string;
  'Picture-in-Picture': string;
  Color: string;
  Opacity: string;
  'Text Background': string;
  'Caption Area Background': string;
  'Skip forward {1} seconds': string;
  'Skip backward {1} seconds': string;
}
interface VideoPlayerTranslations {
  'audio-player': string;
  'video-player': string;
  play: string;
  pause: string;
  replay: string;
  'current-time': string;
  duration: string;
  'remaining-time': string;
  'stream-type': string;
  live: string;
  loaded: string;
  progress: string;
  'progress-bar': string;
  'progress-bar-timing:-currenttime={1}-duration={2}': string;
  fullscreen: string;
  'exit-fullscreen': string;
  mute: string;
  unmute: string;
  'playback-rate': string;
  subtitles: string;
  'subtitles-off': string;
  captions: string;
  'captions-off': string;
  chapters: string;
  descriptions: string;
  'descriptions-off': string;
  'audio-track': string;
  'volume-level': string;
  'you-aborted-the-media-playback': string;
  'a-network-error-caused-the-media-download-to-fail-part-way.': string;
  'the-media-could-not-be-loaded,-either-because-the-server-or-network-failed-or-because-the-format-is-not-supported.': string;
  'the-media-playback-was-aborted-due-to-a-corruption-problem-or-because-the-media-used-features-your-browser-did-not-support.': string;
  'no-compatible-source-was-found-for-this-media.': string;
  'the-media-is-encrypted-and-we-do-not-have-the-keys-to-decrypt-it.': string;
  'play-video': string;
  close: string;
  'close-modal-dialog': string;
  'modal-window': string;
  'this-is-a-modal-window': string;
  'this-modal-can-be-closed-by-pressing-the-escape-key-or-activating-the-close-button.': string;
  ',-opens-captions-settings-dialog': string;
  ',-opens-subtitles-settings-dialog': string;
  ',-opens-descriptions-settings-dialog': string;
  ',-selected': string;
  'captions-settings': string;
  'subtitles-settings': string;
  'descriptions-settings': string;
  text: string;
  white: string;
  black: string;
  red: string;
  green: string;
  blue: string;
  yellow: string;
  magenta: string;
  cyan: string;
  background: string;
  window: string;
  transparent: string;
  'semi-transparent': string;
  opaque: string;
  'font-size': string;
  'text-edge-style': string;
  none: string;
  uniform: string;
  'drop-shadow': string;
  'font-family': string;
  'proportional-sans-serif': string;
  'monospace-sans-serif': string;
  'proportional-serif': string;
  'monospace-serif': string;
  'small-caps': string;
  reset: string;
  'restore-all-settings-to-the-default-values': string;
  done: string;
  'caption-settings-dialog': string;
  'beginning-of-dialog-window.-escape-will-cancel-and-close-the-window.': string;
  'end-of-dialog-window.': string;
  '{1}-is-loading.': string;
  'exit-picture-in-picture': string;
  'picture-in-picture': string;
  color: string;
  opacity: string;
  'text-background': string;
  'caption-area-background': string;
  'skip-forward-{1}-seconds': string;
  'skip-backward-{1}-seconds': string;
}
declare class VideoPlayerI18nService {
  #private;
  init(player: Player, destroyRef: DestroyRef): void;
  getLanguage(): {
    languages: {
      [x: string]: VideoJsTranslation;
    };
    language: string;
  };
  private getTranslations;
  static ɵfac: i0.ɵɵFactoryDeclaration<VideoPlayerI18nService, never>;
  static ɵprov: i0.ɵɵInjectableDeclaration<any>;
}
interface Source {
  src: string;
  type: string;
}
interface Caption {
  lang: string;
  src: string;
  label: string;
  default?: true;
}
interface Chapter {
  lang: string;
  src: string;
  label: string;
  default?: true;
}
type Sources = Array<Source>;
type Captions = Array<Caption>;
type Chapters = Array<Chapter>;
type Preload = 'auto' | 'none' | 'metadata' | '';
type EmbedSourceType = 'video/youtube';
type TAutoplay = 'muted' | 'play' | 'any';
type ItNativeVideoPlayerOptions = {
  autoplay?: boolean | TAutoplay;
  controls?: boolean;
  fluid?: boolean;
  loop?: boolean;
  muted?: boolean;
  poster?: string;
  preload?: Preload;
  sources: Sources;
  captions?: Captions;
  chapters?: Chapters;
};
type ItEmbedVideoPlayerOptions = Omit<ItNativeVideoPlayerOptions, 'sources' | 'captions' | 'chapters'> & {
  source: Source & {
    type: EmbedSourceType;
  };
};
type ItVideoPlayerOptions = ItNativeVideoPlayerOptions | ItEmbedVideoPlayerOptions;
type ItVideoPlayerConfig = ItVideoPlayerOptions & {
  tech: string;
};
declare namespace video_player_component_d_exports {
  export { ItVideoPlayerComponent };
}
declare enum ViewType {
  Default = "DEFAULT",
  Overlay = "OVERLAY"
}
/**
 * Video Player
 * @description Component that allows playing a video.
 */
export declare class ItVideoPlayerComponent extends ItAbstractComponent implements OnInit {
  #private;
  private config;
  /**
   * Options for video player configuration
   */
  options: ItVideoPlayerOptions;
  videoPlayerRef?: ElementRef<HTMLVideoElement>;
  acceptOveralyRef?: ElementRef<HTMLDivElement>;
  acceptOverlayableRef?: ElementRef<HTMLDivElement>;
  chrRememberRef?: ElementRef<HTMLInputElement>;
  player: Player | null;
  readonly viewTypes: typeof ViewType;
  readonly viewType: import("@angular/core").WritableSignal<ViewType | undefined>;
  readonly cookieAccepted: import("@angular/core").WritableSignal<boolean>;
  protected readonly i18nService: VideoPlayerI18nService;
  private ngZone;
  private injector;
  constructor();
  ngOnInit(): Promise<void>;
  acceptCookieHandler(): void;
  private initVideoPlayer;
  private setVideoPlayer;
  private setViewType;
  private hideOverlay;
  private rememberHandler;
  private setVideoAttributes;
  static ɵfac: i0.ɵɵFactoryDeclaration<ItVideoPlayerComponent, never>;
  static ɵcmp: i0.ɵɵComponentDeclaration<ItVideoPlayerComponent, "it-video-player", never, {
    "options": {
      "alias": "options";
      "required": false;
    };
  }, {}, never, ["[transcriptionTitle]", "[transcriptionText]"], true, never>;
}
declare abstract class ItAbstractFormComponent<T = any> extends ItAbstractComponent implements OnInit, ControlValueAccessor, DoCheck {
  protected readonly _translateService: TranslateService;
  protected readonly _ngControl: NgControl | null;
  protected fgd?: ControlContainer | null | undefined;
  /**
   * The label of form control
   */
  label?: string;
  /**
   * Validation color display mode (validation triggered if field is touched or not pristine)
   * - <b>true</b>: Always show the validation color
   * - <b>false</b>: Never show validation color
   * - <b>only-valid</b>: Show only valid validation color
   * - <b>only-invalid</b>: Show only invalid validation color
   * @default <b>false</b>: Do not show the validation color by default
   */
  validationMode: boolean | 'only-valid' | 'only-invalid';
  /**
   * Set the disabled state
   */
  set disabled(isDisabled: boolean);
  /**
   * Internal form control
   */
  protected control: FormControl<T>;
  constructor();
  /**
   * Check if field is invalid (Validation failed)
   */
  get isInvalid(): boolean | undefined;
  /**
   * Check if field is valid (Validation successful)
   */
  get isValid(): boolean | undefined;
  /**
   * Return the invalid message string from TranslateService
   */
  get invalidMessage(): Observable<string>;
  ngOnInit(): void;
  onChange: (_: T) => void;
  onTouched: () => void;
  registerOnChange(fn: any): void;
  registerOnTouched(fn: any): void;
  setDisabledState(isDisabled: boolean): void;
  writeValue(value: T): void;
  /**
   * Mark the control as touched
   */
  markAsTouched(): void;
  /**
   * Fired to check if form control is touched
   */
  ngDoCheck(): void;
  /**
   * Add the validators in control and parent control
   * @param validators the validators
   * @protected
   */
  protected addValidators(validators: ValidatorFn | ValidatorFn[]): void;
  /**
   * Reports whether the control with the given path has the error specified. <br/>
   * If the control is not present, false is returned.
   * @param errorCode The code of the error to check
   * @param path A list of control names that designates how to move from the current control
   * to the control that should be queried for errors.
   * @returns whether the given error is present in the control at the given path.
   */
  hasError(errorCode: string, path?: Array<string | number> | string): boolean;
  /**
   * Reports error data for the control with the given path.
   * @param errorCode The code of the error to check
   * @param path A list of control names that designates how to move from the current control
   * to the control that should be queried for errors.
   * @returns error data for that particular error. If the control or error is not present,
   * null is returned.
   */
  getError(errorCode: string, path?: Array<string | number> | string): any;
  private setValidationModeWhenInAForm;
  static ɵfac: i0.ɵɵFactoryDeclaration<ItAbstractFormComponent<any>, never>;
  static ɵcmp: i0.ɵɵComponentDeclaration<ItAbstractFormComponent<any>, "ng-component", never, {
    "label": {
      "alias": "label";
      "required": false;
    };
    "validationMode": {
      "alias": "validationMode";
      "required": false;
    };
    "disabled": {
      "alias": "disabled";
      "required": false;
    };
  }, {}, never, never, false, never>;
  static ngAcceptInputType_disabled: BooleanInput;
}
declare namespace autocomplete_component_d_exports {
  export { ItAutocompleteComponent };
}
type functionSource = (query: string, populateResults: (results: string[]) => void) => void;
export declare class ItAutocompleteComponent extends ItAbstractFormComponent<string | null | undefined> {
  /**
   * Autocomplete elements.
   * @default []
   */
  source: string[] | functionSource;
  /**
   * Autocomplete if required.
   * @default false
   */
  required: boolean;
  /**
   * Input field name
   */
  name: string | undefined;
  /**
   * The input description
   */
  description: string | undefined;
  /**
   * Prevents suggestions from appearing if fewer than N characters are typed
   * @default 0
   */
  minLength: number;
  /**
   * Default value
   */
  defaultValue: string | null;
  /**
   * Function to set assistive hint label. For more information https://github.com/alphagov/accessible-autocomplete?tab=readme-ov-file#internationalization
   */
  assistiveHintLabel: () => string;
  /**
   * Function to set label in case of no result. For more information https://github.com/alphagov/accessible-autocomplete?tab=readme-ov-file#internationalization
   */
  noResultsLabel: () => string;
  /**
   * Function to set label that alerts you that query's too short. For more information https://github.com/alphagov/accessible-autocomplete?tab=readme-ov-file#internationalization
   */
  statusQueryTooShortLabel: (minQueryLength: number) => string;
  /**
   * Function to set no results label. For more information https://github.com/alphagov/accessible-autocomplete?tab=readme-ov-file#internationalization
   */
  statusNoResultsLabel: () => string;
  /**
   * Function to set selected option label. For more information https://github.com/alphagov/accessible-autocomplete?tab=readme-ov-file#internationalization
   */
  statusSelectedOptionLabel: (selectedOption: string, length: number, index: number) => string;
  /**
   * Function to set status results label. For more information https://github.com/alphagov/accessible-autocomplete?tab=readme-ov-file#internationalization
   */
  statusResultsLabel: (length: number, contentSelectedOption: string) => string;
  /**
   * Fired when value changes
   */
  selected: EventEmitter<any>;
  private selectAutocompleteEl?;
  private selectAutocomplete?;
  private value;
  private _interval;
  private _inputEl;
  ngOnInit(): void;
  writeValue(value: string | null | undefined): void;
  clear(): void;
  _findInput(): void;
  private _setAndCheck;
  private _initInputEl;
  ngAfterViewInit(): void;
  static ɵfac: i0.ɵɵFactoryDeclaration<ItAutocompleteComponent, never>;
  static ɵcmp: i0.ɵɵComponentDeclaration<ItAutocompleteComponent, "it-autocomplete", never, {
    "source": {
      "alias": "source";
      "required": false;
    };
    "required": {
      "alias": "required";
      "required": false;
    };
    "name": {
      "alias": "name";
      "required": false;
    };
    "description": {
      "alias": "description";
      "required": false;
    };
    "minLength": {
      "alias": "minLength";
      "required": false;
    };
    "defaultValue": {
      "alias": "defaultValue";
      "required": false;
    };
    "assistiveHintLabel": {
      "alias": "assistiveHintLabel";
      "required": false;
    };
    "noResultsLabel": {
      "alias": "noResultsLabel";
      "required": false;
    };
    "statusQueryTooShortLabel": {
      "alias": "statusQueryTooShortLabel";
      "required": false;
    };
    "statusNoResultsLabel": {
      "alias": "statusNoResultsLabel";
      "required": false;
    };
    "statusSelectedOptionLabel": {
      "alias": "statusSelectedOptionLabel";
      "required": false;
    };
    "statusResultsLabel": {
      "alias": "statusResultsLabel";
      "required": false;
    };
  }, {
    "selected": "selected";
  }, never, ["[error]"], true, never>;
}
export type InputControlType = 'text' | 'email' | 'number' | 'date' | 'time' | 'tel' | 'color' | 'url';
export interface SelectControlOption<T = any> {
  value: T;
  text?: string;
  selected?: boolean | ((value: T) => boolean);
  disabled?: boolean | ((value: T) => boolean);
}
export interface SelectControlGroup<T = any> {
  label: string;
  options: Array<SelectControlOption<T>>;
  dragdrop?: boolean;
}
export interface UploadFileListItem {
  /**
   * The item id
   */
  id: number;
  /**
   * The uploaded file
   */
  file: File;
  /**
   * Show progress bar
   *
   * The status of the item changes based on the value:
   * - <b>uploading</b>: if value is between 0 and 100 (exclusive 0 < value < 100)
   * - <b>success</b>: if value is greater than 100
   */
  progress?: number;
  /**
   * Show the ability to delete item
   * @default false
   */
  removable?: boolean;
  /**
   * Set the status of the item as 'error'
   */
  error?: boolean;
  /**
   * Add tooltip on file item name
   * @example It can be used to show the error message or additional information about the file
   */
  tooltip?: string;
}
/**
 * Elemento disponibile per l'autocompletamento del it-form-input
 */
export interface SearchItem<T = any> {
  /** Valore voce di autocompletamento */
  value: string;
  /** Opzionale. Path in cui ricercare l'immagine dell'avatar da posizionare a sinistra della voce di autocompletamento */
  avatarSrcPath?: string;
  /** Opzionale. Testo in alternativa dell'avatar per accessibilità */
  avatarAltText?: string;
  /** Opzionale. Icona posizionata a sinistra della voce di autocompletamento */
  icon?: IconName;
  /** Opzionale. Label posizionata a destra della voce di autocompletamento */
  label?: string;
  /** Opzionale. Link relativo all'elemento */
  link?: string;
  /**
   * Attribute not used for Search rendering.
   * It can be useful to retrieve some extra information when selecting the Search item
   */
  additionalData?: T;
}
declare namespace search_component_d_exports {
  export { ItSearchComponent };
}
export declare class ItSearchComponent extends ItAbstractFormComponent<string | null | undefined> implements OnInit {
  /**
   * Indicates the list of searchable elements on which to base the input search system
   * If you need to retrieve items via API, can pass a function of Observable
   * @default undefined
   */
  searchData: Array<SearchItem> | ((search?: string | null) => Observable<Array<SearchItem>>);
  /**
   * To get a large version of Search
   */
  big?: boolean;
  /**
   * Time span [ms] has passed without another source emission, to delay data filtering.
   * Useful when the user is typing multiple letters
   * @default 300 [ms]
   */
  debounceTime: number;
  /**
   * The input placeholder
   */
  placeholder: string;
  /**
   * The input label even get labelWaria icon
   */
  labelWaria: string | undefined;
  /**
   * Show the label
   */
  forceShowLabel: boolean;
  /**
   * Fired when the Search Item has been selected
   */
  searchSelectedEvent: EventEmitter<SearchItem>;
  protected showAutocompletion: boolean;
  /** Observable da cui vengono emessi i risultati dell'auto completamento */
  protected searchResults$: Observable<{
    searchedValue: string | undefined | null;
    relatedEntries: Array<SearchItem>;
  }>;
  ngOnInit(): void;
  /**
   * Create the search list
   */
  private getSearchResults$;
  protected onEntryClick(entry: SearchItem, event: Event): void;
  protected searchItemTrackByValueFn(index: number, item: SearchItem): string;
  protected onKeyDown(): void;
  static ɵfac: i0.ɵɵFactoryDeclaration<ItSearchComponent, never>;
  static ɵcmp: i0.ɵɵComponentDeclaration<ItSearchComponent, "it-search", never, {
    "searchData": {
      "alias": "searchData";
      "required": true;
    };
    "big": {
      "alias": "big";
      "required": false;
    };
    "debounceTime": {
      "alias": "debounceTime";
      "required": false;
    };
    "placeholder": {
      "alias": "placeholder";
      "required": false;
    };
    "labelWaria": {
      "alias": "labelWaria";
      "required": false;
    };
    "forceShowLabel": {
      "alias": "forceShowLabel";
      "required": false;
    };
  }, {
    "searchSelectedEvent": "searchSelectedEvent";
  }, never, ["[error]"], true, never>;
  static ngAcceptInputType_big: BooleanInput;
  static ngAcceptInputType_forceShowLabel: BooleanInput;
}
declare namespace checkbox_component_d_exports {
  export { ItCheckboxComponent };
}
export declare class ItCheckboxComponent extends ItAbstractFormComponent<boolean | null | undefined> implements OnInit, OnChanges {
  /**
   * If show checkbox as toggle
   * @default false
   */
  toggle?: boolean;
  /**
   * If show checkbox inline
   * @default false
   */
  inline?: boolean;
  /**
   * If is checkbox group
   * @default false
   */
  group?: boolean;
  /**
   * If checkbox is checked
   * @default false
   */
  checked?: boolean;
  /**
   * If checkbox is indeterminate
   * @default false
   */
  indeterminate?: boolean;
  ngOnInit(): void;
  ngOnChanges(changes: SimpleChanges): void;
  private markAsChecked;
  static ɵfac: i0.ɵɵFactoryDeclaration<ItCheckboxComponent, never>;
  static ɵcmp: i0.ɵɵComponentDeclaration<ItCheckboxComponent, "it-checkbox", never, {
    "toggle": {
      "alias": "toggle";
      "required": false;
    };
    "inline": {
      "alias": "inline";
      "required": false;
    };
    "group": {
      "alias": "group";
      "required": false;
    };
    "checked": {
      "alias": "checked";
      "required": false;
    };
    "indeterminate": {
      "alias": "indeterminate";
      "required": false;
    };
  }, {}, never, ["*", "[error]", "[label]"], true, never>;
  static ngAcceptInputType_toggle: BooleanInput;
  static ngAcceptInputType_inline: BooleanInput;
  static ngAcceptInputType_group: BooleanInput;
  static ngAcceptInputType_checked: BooleanInput;
  static ngAcceptInputType_indeterminate: BooleanInput;
}
declare namespace input_component_d_exports {
  export { ItInputComponent };
}
export declare class ItInputComponent extends ItAbstractFormComponent<string | number | null | undefined> implements OnInit {
  /**
   * The input type
   * @default text
   */
  type: InputControlType;
  /**
   * The input placeholder
   */
  placeholder: string;
  /**
   * The input description
   */
  description: string | undefined;
  /**
   * To prevent modification of the contained value.
   * - <b>plaintext</b>: Readonly field in the form stylized as plain text
   * @default undefined
   */
  readonly: boolean | 'plaintext' | undefined;
  /**
   * The max date value [Used only in type = 'date']
   * @default '9999-12-31'
   * @example 'yyyy-mm-dd'
   */
  maxDate?: string;
  /**
   * The min date value [Used only in type = 'date']
   * @example 'yyyy-mm-dd'
   */
  minDate: string | undefined;
  /**
   * The max value [Used only in type = 'number']
   */
  max: number | undefined;
  /**
   * The min value [Used only in type = 'number']
   */
  min: number | undefined;
  /**
   * The step value [Used only in type = 'number']
   */
  step: number | 'any' | undefined;
  /**
   * If is a currency number [Used only in type = 'number']
   * @default false
   */
  currency?: boolean;
  /**
   * If is a percentage number [Used only in type = 'number']
   * @default false
   */
  percentage?: boolean;
  /**
   * The currency or percentage symbol [Used only if percentage or currency]
   * @example '$'
   */
  symbol: string | undefined;
  /**
   * To make the numeric field automatically resize according to the value contained in it. [Used only in type = 'number']
   * @default false
   */
  adaptive?: boolean;
  /**
   * Input autocomplete attribute (Browser autocomplete)
   * @default undefined
   */
  autocomplete: string | undefined;
  get isActiveLabel(): boolean;
  /**
   * Check is readonly field
   */
  protected get isReadonly(): boolean;
  /**
   * Return the invalid message string from TranslateService
   */
  get invalidMessage(): Observable<string>;
  ngOnInit(): void;
  /**
   * Increment or decrease the input number value of step
   * @param decrease true to decrease value
   */
  protected incrementNumber(decrease?: boolean): void;
  static ɵfac: i0.ɵɵFactoryDeclaration<ItInputComponent, never>;
  static ɵcmp: i0.ɵɵComponentDeclaration<ItInputComponent, "it-input", never, {
    "type": {
      "alias": "type";
      "required": false;
    };
    "placeholder": {
      "alias": "placeholder";
      "required": false;
    };
    "description": {
      "alias": "description";
      "required": false;
    };
    "readonly": {
      "alias": "readonly";
      "required": false;
    };
    "maxDate": {
      "alias": "maxDate";
      "required": false;
    };
    "minDate": {
      "alias": "minDate";
      "required": false;
    };
    "max": {
      "alias": "max";
      "required": false;
    };
    "min": {
      "alias": "min";
      "required": false;
    };
    "step": {
      "alias": "step";
      "required": false;
    };
    "currency": {
      "alias": "currency";
      "required": false;
    };
    "percentage": {
      "alias": "percentage";
      "required": false;
    };
    "symbol": {
      "alias": "symbol";
      "required": false;
    };
    "adaptive": {
      "alias": "adaptive";
      "required": false;
    };
    "autocomplete": {
      "alias": "autocomplete";
      "required": false;
    };
  }, {}, never, ["[prependText]", "[append]", "[appendText]", "[error]"], true, never>;
  static ngAcceptInputType_currency: BooleanInput;
  static ngAcceptInputType_percentage: BooleanInput;
  static ngAcceptInputType_adaptive: BooleanInput;
}
declare namespace password_input_component_d_exports {
  export { ItPasswordInputComponent };
}
export declare class ItPasswordInputComponent extends ItAbstractFormComponent<string | null | undefined> implements OnInit, AfterViewInit {
  /**
   * The field is required
   * @default true
   */
  required: boolean;
  /**
   * The password minimum length
   * @default 10
   */
  minLength: number;
  /**
   * The password must contain at least one number
   * @default true
   */
  useNumber: boolean;
  /**
   * The password must contain at least one uppercase character
   * @default true
   */
  useCapitalCase: boolean;
  /**
   * The password must contain at least one lowercase character
   * @default true
   */
  useSmallCase: boolean;
  /**
   * The password must contain at least one special character
   * @default true
   */
  useSpecialCharacters: boolean;
  /**
   * The input placeholder
   */
  placeholder: string;
  /**
   * The input description
   * - <b>true</b>: show the StrengthMeter description message
   * - <b>string</b>: show custom description
   * @default true for StrengthMeter mode else is undefined
   */
  description: string | true | undefined;
  /**
   * Enable to show the strength meter
   * @default false
   */
  showStrengthMeter?: boolean;
  /**
   * Is the confirmation password field
   * @default false
   */
  confirmPasswordField?: boolean;
  /**
   * Input autocomplete attribute (Browser autocomplete)
   * @default undefined
   */
  autocomplete: string | undefined;
  private inputPasswordBs?;
  private inputElement?;
  ngOnInit(): void;
  ngAfterViewInit(): void;
  protected get isStrengthMeter(): boolean;
  /**
   * Return the invalid message string from TranslateService
   */
  get invalidMessage(): Observable<string>;
  /**
   * Retrieve the default StrengthMeter description message from TranslateService
   */
  protected get strengthMeterDescription(): Observable<string>;
  static ɵfac: i0.ɵɵFactoryDeclaration<ItPasswordInputComponent, never>;
  static ɵcmp: i0.ɵɵComponentDeclaration<ItPasswordInputComponent, "it-password-input", never, {
    "required": {
      "alias": "required";
      "required": false;
    };
    "minLength": {
      "alias": "minLength";
      "required": false;
    };
    "useNumber": {
      "alias": "useNumber";
      "required": false;
    };
    "useCapitalCase": {
      "alias": "useCapitalCase";
      "required": false;
    };
    "useSmallCase": {
      "alias": "useSmallCase";
      "required": false;
    };
    "useSpecialCharacters": {
      "alias": "useSpecialCharacters";
      "required": false;
    };
    "placeholder": {
      "alias": "placeholder";
      "required": false;
    };
    "description": {
      "alias": "description";
      "required": false;
    };
    "showStrengthMeter": {
      "alias": "showStrengthMeter";
      "required": false;
    };
    "confirmPasswordField": {
      "alias": "confirmPasswordField";
      "required": false;
    };
    "autocomplete": {
      "alias": "autocomplete";
      "required": false;
    };
  }, {}, never, ["[error]"], true, never>;
  static ngAcceptInputType_showStrengthMeter: BooleanInput;
  static ngAcceptInputType_confirmPasswordField: BooleanInput;
}
declare namespace radio_button_component_d_exports {
  export { ItRadioButtonComponent };
}
export declare class ItRadioButtonComponent extends ItAbstractFormComponent<string | number | null | undefined> implements OnInit {
  /**
   * The radio value
   */
  value: string | number | undefined | null;
  /**
   * If show radio inline
   * @default false
   */
  inline?: boolean;
  /**
   * If is radio group
   * @default false
   */
  group?: boolean;
  /**
   * If is radio is checked
   * @default false
   */
  checked?: boolean;
  /**
   * Set the radio name manually.
   * For example when the radio button name is duplicated inside page
   * @default by default the radio name is calculated from form field name
   */
  forceRadioName?: string;
  get name(): string;
  ngOnInit(): void;
  static ɵfac: i0.ɵɵFactoryDeclaration<ItRadioButtonComponent, never>;
  static ɵcmp: i0.ɵɵComponentDeclaration<ItRadioButtonComponent, "it-radio-button", never, {
    "value": {
      "alias": "value";
      "required": true;
    };
    "inline": {
      "alias": "inline";
      "required": false;
    };
    "group": {
      "alias": "group";
      "required": false;
    };
    "checked": {
      "alias": "checked";
      "required": false;
    };
    "forceRadioName": {
      "alias": "forceRadioName";
      "required": false;
    };
  }, {}, never, ["[label]", "*", "[error]", "[error]"], true, never>;
  static ngAcceptInputType_inline: BooleanInput;
  static ngAcceptInputType_group: BooleanInput;
  static ngAcceptInputType_checked: BooleanInput;
}
declare namespace range_component_d_exports {
  export { ItRangeComponent };
}
export declare class ItRangeComponent extends ItAbstractFormComponent<number | null | undefined> implements OnInit, OnChanges, OnDestroy {
  /**
   * The max value
   */
  max?: number;
  /**
   * The min value
   */
  min?: number;
  /**
   * The step value
   */
  step?: number | 'any';
  /**
   * The color on left of thumb [Require rightColor]
   * @example '#0d6efd' or 'var(--bs-primary)'
   * @default undefined ('var(--bs-gray-300)')
   */
  leftColor?: string;
  /**
   * The color on right of thumb [Require leftColor]
   * @example '#0d6efd' or 'var(--bs-primary)'
   * @default undefined ('var(--bs-gray-300)')
   */
  rightColor?: string;
  slider: ElementRef<HTMLInputElement>;
  private subscription?;
  ngOnInit(): void;
  ngOnChanges(changes: SimpleChanges): void;
  ngOnDestroy(): void;
  writeValue(value: number | null | undefined): void;
  /**
   * Update the percentage of slider color
   * @private
   */
  private updateSliderColor;
  static ɵfac: i0.ɵɵFactoryDeclaration<ItRangeComponent, never>;
  static ɵcmp: i0.ɵɵComponentDeclaration<ItRangeComponent, "it-range", never, {
    "max": {
      "alias": "max";
      "required": false;
    };
    "min": {
      "alias": "min";
      "required": false;
    };
    "step": {
      "alias": "step";
      "required": false;
    };
    "leftColor": {
      "alias": "leftColor";
      "required": false;
    };
    "rightColor": {
      "alias": "rightColor";
      "required": false;
    };
  }, {}, never, ["*"], true, never>;
}
declare namespace rating_component_d_exports {
  export { ItRatingComponent };
}
export declare class ItRatingComponent extends ItAbstractFormComponent<number | null | undefined> implements OnInit, OnChanges {
  /**
   * The rating value
   */
  value: number | undefined;
  /**
   * Number of stars to show
   * @default 5
   */
  starCount: number;
  protected stars: Array<number>;
  ngOnChanges(changes: SimpleChanges): void;
  ngOnInit(): void;
  /**
   * Generate the array of stars
   * @private
   */
  private generateStars;
  static ɵfac: i0.ɵɵFactoryDeclaration<ItRatingComponent, never>;
  static ɵcmp: i0.ɵɵComponentDeclaration<ItRatingComponent, "it-rating", never, {
    "value": {
      "alias": "value";
      "required": false;
    };
    "starCount": {
      "alias": "starCount";
      "required": false;
    };
  }, {}, never, never, true, never>;
}
declare namespace select_component_d_exports {
  export { ItSelectComponent };
}
export declare class ItSelectComponent extends ItAbstractFormComponent implements OnInit {
  /**
   * The select options
   */
  options: Array<SelectControlOption> | undefined;
  /**
   * The select group options
   */
  groups: Array<SelectControlGroup> | undefined;
  /**
   * The select description
   */
  description?: string;
  /**
   * If set, add a `disabled selected` option with value `null` and as text the value of the attribute
   * @example 'Select an option'
   */
  defaultOption?: string;
  ngOnInit(): void;
  /**
   * Check if the option is selected
   * @param option the option
   */
  optionIsSelected(option: SelectControlOption): boolean;
  /**
   * Check if the option is disabled
   * @param option the option
   */
  optionIsDisabled(option: SelectControlOption): boolean;
  static ɵfac: i0.ɵɵFactoryDeclaration<ItSelectComponent, never>;
  static ɵcmp: i0.ɵɵComponentDeclaration<ItSelectComponent, "it-select", never, {
    "options": {
      "alias": "options";
      "required": false;
    };
    "groups": {
      "alias": "groups";
      "required": false;
    };
    "description": {
      "alias": "description";
      "required": false;
    };
    "defaultOption": {
      "alias": "defaultOption";
      "required": false;
    };
  }, {}, never, ["*", "[error]"], true, never>;
}
declare namespace textarea_component_d_exports {
  export { ItTextareaComponent };
}
export declare class ItTextareaComponent extends ItAbstractFormComponent<string | null | undefined> {
  /**
   * Textarea Rows
   * @default 3
   */
  rows?: number;
  /**
   * The textarea placeholder
   */
  placeholder: string;
  /**
   * The input description
   */
  description: string | undefined;
  /**
   * To prevent modification of the contained value.
   * - <b>plaintext</b>: Readonly field in the form stylized as plain text
   * @default undefined
   */
  readonly: boolean | 'plaintext' | undefined;
  /**
   * Return the invalid message string from TranslateService
   */
  get invalidMessage(): Observable<string>;
  /**
   * Check is readonly field
   */
  protected get isReadonly(): boolean;
  static ɵfac: i0.ɵɵFactoryDeclaration<ItTextareaComponent, never>;
  static ɵcmp: i0.ɵɵComponentDeclaration<ItTextareaComponent, "it-textarea", never, {
    "rows": {
      "alias": "rows";
      "required": false;
    };
    "placeholder": {
      "alias": "placeholder";
      "required": false;
    };
    "description": {
      "alias": "description";
      "required": false;
    };
    "readonly": {
      "alias": "readonly";
      "required": false;
    };
  }, {}, never, ["[error]"], true, never>;
}
export interface TransferItem<ValueType> {
  text: string;
  value: ValueType;
}
export type TransferItemSelection<ValueType> = Array<TransferItem<ValueType>>;
export type SourceType = 'source' | 'target';
declare namespace transfer_component_d_exports {
  export { ItTransferComponent };
}
/**
 * Transfer
 * @description Component that allows the creation of checkbox lists.
 */
export declare class ItTransferComponent<T = any> extends ItAbstractFormComponent<T> implements OnInit {
  protected _ngControl: NgControl | null;
  protected _translateService: TranslateService;
  private readonly store;
  /**
   * The select options (left side)
   */
  options: never[];
  /**
   * The selected options (right side)
   */
  selected: never[];
  /**
   * Fired when there is a transfer, a backtransfer or a reset event
   */
  readonly transferChanges: EventEmitter<TransferItem<T>[]>;
  /**
   * Enable transfer button
   * @default false
   */
  readonly transferEnabled: import("rxjs").Observable<boolean>;
  /**
   * Enable backtransfer button
   * @default false
   */
  readonly backtransferEnabled: import("rxjs").Observable<boolean>;
  /**
   * Enable reset button
   * @default false
   */
  readonly resetEnabled: import("rxjs").Observable<boolean>;
  private readonly destroyRef;
  ngOnInit(): void;
  /**
   * Transfer button click handler
   */
  transferClickHandler(event: MouseEvent): void;
  /**
   * Transfer button keypress handler
   */
  transferKeyPressHandler(event: KeyboardEvent): void;
  /**
   * Backtransfer button click handler
   */
  backtransferClickHandler(event: MouseEvent): void;
  /**
   * Backtransfer button keypress handler
   */
  backtransferKeyPressHandler(event: KeyboardEvent): void;
  /**
   * Reset button click handler
   */
  resetClickHandler(event: MouseEvent): void;
  /**
   * Reset button keypress handler
   */
  resetKeyPressHandler(event: KeyboardEvent): void;
  private buttonEventHandler;
  private storeInit;
  private onStoreValueChanged;
  static ɵfac: i0.ɵɵFactoryDeclaration<ItTransferComponent<any>, never>;
  static ɵcmp: i0.ɵɵComponentDeclaration<ItTransferComponent<any>, "it-transfer", never, {
    "options": {
      "alias": "options";
      "required": false;
    };
    "selected": {
      "alias": "selected";
      "required": false;
    };
  }, {
    "transferChanges": "transferChanges";
  }, never, never, true, never>;
}
declare namespace upload_drag_drop_component_d_exports {
  export { ItUploadDragDropComponent };
}
export declare class ItUploadDragDropComponent extends ItAbstractComponent implements AfterViewInit {
  /**
   * The accepted file type to upload <br>
   * Possible values: <a href="https://developer.mozilla.org/en-US/docs/Web/HTTP/Basics_of_HTTP/MIME_types/Common_types">MIME Types</a> separated by comma
   * @example application/pdf,image/png
   * @default *
   */
  accept: string;
  /**
   * Fired when file start to upload
   */
  fileStartUpload: EventEmitter<File>;
  protected isDragover: boolean;
  protected isLoading: boolean;
  protected isSuccess: boolean;
  protected donut?: ProgressDonut;
  private donutElement?;
  protected filename?: string;
  protected extension?: string;
  protected fileSize?: string;
  /**
   * The bootstrap-italia asset folder path
   * @default ./bootstrap-italia
   */
  protected assetBasePath: string;
  constructor();
  ngAfterViewInit(): void;
  onDragOver(evt: DragEvent): void;
  onDragLeave(evt: DragEvent): void;
  onDrop(evt: DragEvent): void;
  /**
   * On load file from input
   * @param event
   */
  onLoadFile(event: Event): void;
  /**
   * Start the upload file
   * @param file
   */
  start(file: File): void;
  /**
   * Percentage of upload
   * @param value the percentage [0 - 100]
   */
  progress(value: number): void;
  /**
   * Upload success
   */
  success(): void;
  /**
   * Reset file uploader
   */
  reset(): void;
  static ɵfac: i0.ɵɵFactoryDeclaration<ItUploadDragDropComponent, never>;
  static ɵcmp: i0.ɵɵComponentDeclaration<ItUploadDragDropComponent, "it-upload-drag-drop", ["itUploadDragDrop"], {
    "accept": {
      "alias": "accept";
      "required": false;
    };
  }, {
    "fileStartUpload": "fileStartUpload";
  }, never, never, true, never>;
}
declare namespace upload_file_list_component_d_exports {
  export { ItUploadFileListComponent };
}
export declare class ItUploadFileListComponent extends ItAbstractComponent implements OnInit, OnChanges {
  /**
   * The list of files to show in list
   */
  fileList: Array<UploadFileListItem>;
  /**
   * The accepted file type to upload <br>
   * Possible values: <a href="https://developer.mozilla.org/en-US/docs/Web/HTTP/Basics_of_HTTP/MIME_types/Common_types">MIME Types</a> separated by comma
   * @example application/pdf,image/png
   * @default *
   */
  accept: string;
  /**
   * A label for the upload button
   */
  label?: string;
  /**
   * If upload multiple files
   * @default true
   */
  multiple: boolean;
  /**
   * If is file list image
   * @default false
   */
  images?: boolean;
  /**
   * Hide the load button
   * @default false
   */
  hideLoadButton?: boolean;
  /**
   * Fired when upload new files
   */
  uploadFiles: EventEmitter<FileList>;
  /**
   * Fired on delete item button click
   */
  deleteItem: EventEmitter<UploadFileListItem>;
  /**
   * Cache to preview image
   */
  previewImages: Map<number, string>;
  ngOnInit(): void;
  ngOnChanges(changes: SimpleChanges): void;
  /**
   * On load file from input
   * @param event
   */
  onLoadFiles(event: Event): void;
  /**
   * Get the file size string
   * @param file
   */
  getFileSize(file: File): string;
  static ɵfac: i0.ɵɵFactoryDeclaration<ItUploadFileListComponent, never>;
  static ɵcmp: i0.ɵɵComponentDeclaration<ItUploadFileListComponent, "it-upload-file-list", never, {
    "fileList": {
      "alias": "fileList";
      "required": true;
    };
    "accept": {
      "alias": "accept";
      "required": false;
    };
    "label": {
      "alias": "label";
      "required": false;
    };
    "multiple": {
      "alias": "multiple";
      "required": false;
    };
    "images": {
      "alias": "images";
      "required": false;
    };
    "hideLoadButton": {
      "alias": "hideLoadButton";
      "required": false;
    };
  }, {
    "uploadFiles": "uploadFiles";
    "deleteItem": "deleteItem";
  }, never, never, true, never>;
  static ngAcceptInputType_multiple: BooleanInput;
  static ngAcceptInputType_images: BooleanInput;
  static ngAcceptInputType_hideLoadButton: BooleanInput;
}
declare namespace form_module_d_exports {
  export { ItFormModule };
}
export declare class ItFormModule {
  static ɵfac: i0.ɵɵFactoryDeclaration<ItFormModule, never>;
  static ɵmod: i0.ɵɵNgModuleDeclaration<ItFormModule, never, [typeof ItAutocompleteComponent, typeof ItSearchComponent, typeof ItCheckboxComponent, typeof ItInputComponent, typeof ItPasswordInputComponent, typeof ItRadioButtonComponent, typeof ItRangeComponent, typeof ItRatingComponent, typeof ItSelectComponent, typeof ItTextareaComponent, typeof ItTransferComponent, typeof ItUploadDragDropComponent, typeof ItUploadFileListComponent], [typeof ItAutocompleteComponent, typeof ItSearchComponent, typeof ItCheckboxComponent, typeof ItInputComponent, typeof ItPasswordInputComponent, typeof ItRadioButtonComponent, typeof ItRangeComponent, typeof ItRatingComponent, typeof ItSelectComponent, typeof ItTextareaComponent, typeof ItTransferComponent, typeof ItUploadDragDropComponent, typeof ItUploadFileListComponent]>;
  static ɵinj: i0.ɵɵInjectorDeclaration<ItFormModule>;
}
declare namespace back_button_component_d_exports {
  export { ItBackButtonComponent };
}
export declare class ItBackButtonComponent {
  readonly _location: Location;
  /**
   * Back button style
   * - <b>link</b>: use a link with icon and text
   * - <b>button</b>: use a button with icon and text
   * @default button
   */
  buttonStyle: 'link' | 'button';
  /**
   * Button direction
   * - <b>left</b>: Back direction
   * - <b>up</b>: Upper direction
   * @default left
   */
  direction: 'left' | 'up';
  /**
   * Show/Hide icon
   * @default true
   */
  showIcon: boolean;
  /**
   * Show/Hide text
   * @default true
   */
  showText: boolean;
  /**
   * Custom back logic <br/>
   *
   * NOTE: to use 'this' need bind function  <br/>
   * @example backCbFn = this.errorCallback.bind(this);
   * (errorCallback is your function, pass backCbFn to the component)
   */
  backFn?: (location: Location) => void;
  /**
   * Go back function
   */
  goBack(event: Event): void;
  static ɵfac: i0.ɵɵFactoryDeclaration<ItBackButtonComponent, never>;
  static ɵcmp: i0.ɵɵComponentDeclaration<ItBackButtonComponent, "it-back-button", ["itBackButton"], {
    "buttonStyle": {
      "alias": "buttonStyle";
      "required": false;
    };
    "direction": {
      "alias": "direction";
      "required": false;
    };
    "showIcon": {
      "alias": "showIcon";
      "required": false;
    };
    "showText": {
      "alias": "showText";
      "required": false;
    };
    "backFn": {
      "alias": "backFn";
      "required": false;
    };
  }, {}, never, never, true, never>;
  static ngAcceptInputType_showIcon: BooleanInput;
  static ngAcceptInputType_showText: BooleanInput;
}
declare namespace back_to_top_component_d_exports {
  export { ItBackToTopComponent };
}
export declare class ItBackToTopComponent extends ItAbstractComponent implements AfterViewInit {
  /**
   * Aria label for the component
   * @default 'Torna su'
   */
  ariaLabel: string;
  /**
   * Show small button
   * @default false
   */
  small?: boolean;
  /**
   * Show shadow
   * @default false
   */
  shadow?: boolean;
  /**
   * Button usable button on a dark background
   * @default false
   */
  dark?: boolean;
  private backToTop?;
  private backToTopElement?;
  ngAfterViewInit(): void;
  /**
   * Show button
   */
  show(): void;
  /**
   * Hide the button
   */
  hide(): void;
  /**
   * Activates the scroll animation towards the Y coordinate indicated by the positionTop option
   */
  scrollToTop(): void;
  /**
   * Eliminate component features
   */
  dispose(): void;
  static ɵfac: i0.ɵɵFactoryDeclaration<ItBackToTopComponent, never>;
  static ɵcmp: i0.ɵɵComponentDeclaration<ItBackToTopComponent, "it-back-to-top", ["itBackToTop"], {
    "ariaLabel": {
      "alias": "ariaLabel";
      "required": false;
    };
    "small": {
      "alias": "small";
      "required": false;
    };
    "shadow": {
      "alias": "shadow";
      "required": false;
    };
    "dark": {
      "alias": "dark";
      "required": false;
    };
  }, {}, never, never, true, never>;
  static ngAcceptInputType_small: BooleanInput;
  static ngAcceptInputType_shadow: BooleanInput;
  static ngAcceptInputType_dark: BooleanInput;
}
declare namespace breadcrumb_item_component_d_exports {
  export { ItBreadcrumbItemComponent };
}
export declare class ItBreadcrumbItemComponent extends ItLinkComponent {
  /**
   * Is active breadcrumb item
   * @default false
   */
  active?: boolean;
  /**
   * The name of icon to show
   */
  iconName: IconName | undefined;
  /**
   * The content of item
   */
  htmlContent: TemplateRef<any>;
  static ɵfac: i0.ɵɵFactoryDeclaration<ItBreadcrumbItemComponent, never>;
  static ɵcmp: i0.ɵɵComponentDeclaration<ItBreadcrumbItemComponent, "it-breadcrumb-item", never, {
    "active": {
      "alias": "active";
      "required": false;
    };
    "iconName": {
      "alias": "iconName";
      "required": false;
    };
  }, {}, never, ["*"], true, never>;
  static ngAcceptInputType_active: BooleanInput;
}
declare namespace breadcrumb_component_d_exports {
  export { ItBreadcrumbComponent };
}
export declare class ItBreadcrumbComponent implements AfterViewInit, OnDestroy {
  private readonly _changeDetectorRef;
  /**
   * The character to use as separator
   * @default /
   */
  separator: string;
  /**
   * Dark style
   * @default false
   */
  dark?: boolean;
  /**
   * The tab items
   */
  items?: QueryList<ItBreadcrumbItemComponent>;
  private itemSubscriptions?;
  ngAfterViewInit(): void;
  ngOnDestroy(): void;
  static ɵfac: i0.ɵɵFactoryDeclaration<ItBreadcrumbComponent, never>;
  static ɵcmp: i0.ɵɵComponentDeclaration<ItBreadcrumbComponent, "it-breadcrumb", never, {
    "separator": {
      "alias": "separator";
      "required": false;
    };
    "dark": {
      "alias": "dark";
      "required": false;
    };
  }, {}, ["items"], never, true, never>;
  static ngAcceptInputType_dark: BooleanInput;
}
declare namespace breadcrumbs_module_d_exports {
  export { ItBreadcrumbsModule };
}
export declare class ItBreadcrumbsModule {
  static ɵfac: i0.ɵɵFactoryDeclaration<ItBreadcrumbsModule, never>;
  static ɵmod: i0.ɵɵNgModuleDeclaration<ItBreadcrumbsModule, never, [typeof ItBreadcrumbComponent, typeof ItBreadcrumbItemComponent], [typeof ItBreadcrumbComponent, typeof ItBreadcrumbItemComponent]>;
  static ɵinj: i0.ɵɵInjectorDeclaration<ItBreadcrumbsModule>;
}
declare namespace header_component_d_exports {
  export { ItHeaderComponent };
}
export declare class ItHeaderComponent implements AfterViewInit, OnChanges {
  light?: boolean;
  sticky?: boolean;
  showSlim?: boolean;
  smallHeader?: boolean;
  showSearch?: boolean;
  idCollapsable: string;
  slimTitle: string | undefined;
  slimTitleLink: string | undefined;
  loginStyle: 'none' | 'default' | 'full';
  loginClick: EventEmitter<Event>;
  searchClick: EventEmitter<Event>;
  private headerWrapper?;
  private itNavBarComponent?;
  megamenu?: boolean;
  expand?: boolean;
  private stickyHeader?;
  private readonly router;
  private readonly cdr;
  constructor();
  ngAfterViewInit(): void;
  ngOnChanges(changes: SimpleChanges): void;
  updateListeners(): void;
  openNavBar(): void;
  closeNavBar(): void;
  protected emitLoginClick(event: Event): void;
  protected emitSearchClick(event: Event): void;
  toggleCollapse(): void;
  static ɵfac: i0.ɵɵFactoryDeclaration<ItHeaderComponent, never>;
  static ɵcmp: i0.ɵɵComponentDeclaration<ItHeaderComponent, "it-header", never, {
    "light": {
      "alias": "light";
      "required": false;
    };
    "sticky": {
      "alias": "sticky";
      "required": false;
    };
    "showSlim": {
      "alias": "showSlim";
      "required": false;
    };
    "smallHeader": {
      "alias": "smallHeader";
      "required": false;
    };
    "showSearch": {
      "alias": "showSearch";
      "required": false;
    };
    "idCollapsable": {
      "alias": "idCollapsable";
      "required": false;
    };
    "slimTitle": {
      "alias": "slimTitle";
      "required": false;
    };
    "slimTitleLink": {
      "alias": "slimTitleLink";
      "required": false;
    };
    "loginStyle": {
      "alias": "loginStyle";
      "required": false;
    };
    "megamenu": {
      "alias": "megamenu";
      "required": false;
    };
    "expand": {
      "alias": "expand";
      "required": false;
    };
  }, {
    "loginClick": "loginClick";
    "searchClick": "searchClick";
  }, never, ["[slimLinkList]", "[slimRightZone]", "[brand]", "[rightZone]", "[navItems]"], true, never>;
  static ngAcceptInputType_light: BooleanInput;
  static ngAcceptInputType_sticky: BooleanInput;
  static ngAcceptInputType_showSlim: BooleanInput;
  static ngAcceptInputType_smallHeader: BooleanInput;
  static ngAcceptInputType_showSearch: BooleanInput;
  static ngAcceptInputType_megamenu: BooleanInput;
  static ngAcceptInputType_expand: BooleanInput;
}
declare namespace footer_component_d_exports {
  export { ItFooterComponent };
}
export declare class ItFooterComponent extends ItAbstractComponent {
  static ɵfac: i0.ɵɵFactoryDeclaration<ItFooterComponent, never>;
  static ɵcmp: i0.ɵɵComponentDeclaration<ItFooterComponent, "it-footer", ["itFooter"], {}, {}, never, ["[header]", "[links]", "[contacts]", "[small-links]"], true, never>;
}
declare namespace navbar_component_d_exports {
  export { ItNavBarComponent };
}
export declare class ItNavBarComponent implements AfterViewInit {
  megamenu?: boolean;
  expand?: boolean;
  private collapseButton?;
  private collapseView?;
  private navbar?;
  ngAfterViewInit(): void;
  get isOpen(): boolean | undefined;
  open(): void;
  close(): void;
  toggleCollapse(): void;
  static ɵfac: i0.ɵɵFactoryDeclaration<ItNavBarComponent, never>;
  static ɵcmp: i0.ɵɵComponentDeclaration<ItNavBarComponent, "it-navbar", never, {
    "megamenu": {
      "alias": "megamenu";
      "required": false;
    };
    "expand": {
      "alias": "expand";
      "required": false;
    };
  }, {}, never, ["[navItems]"], true, never>;
  static ngAcceptInputType_megamenu: BooleanInput;
  static ngAcceptInputType_expand: BooleanInput;
}
declare namespace navbar_item_component_d_exports {
  export { ItNavBarItemComponent };
}
export declare class ItNavBarItemComponent {
  static ɵfac: i0.ɵɵFactoryDeclaration<ItNavBarItemComponent, never>;
  static ɵcmp: i0.ɵɵComponentDeclaration<ItNavBarItemComponent, "it-navbar-item", never, {}, {}, never, ["*"], true, never>;
}
declare namespace navbar_module_d_exports {
  export { ItNavBarModule };
}
export declare class ItNavBarModule {
  static ɵfac: i0.ɵɵFactoryDeclaration<ItNavBarModule, never>;
  static ɵmod: i0.ɵɵNgModuleDeclaration<ItNavBarModule, never, [typeof ItNavBarComponent, typeof ItNavBarItemComponent], [typeof ItNavBarComponent, typeof ItNavBarItemComponent]>;
  static ɵinj: i0.ɵɵInjectorDeclaration<ItNavBarModule>;
}
declare namespace sidebar_component_d_exports {
  export { ItSidebarComponent };
}
export declare class ItSidebarComponent {
  /**
   * Per creare una sidebar con linea separatrice a destra è sufficiente aggiungere la classe
   */
  withRightLine: boolean;
  /**
   * Per creare una sidebar con linea separatrice a sinistra è sufficiente aggiungere la classe
   */
  withLeftLine: boolean;
  /**
   * Per cambiare il tema della sidebar e renderla scura
   */
  dark: boolean;
  /**
   * L'intestazione della sidebar
   */
  header?: string;
  componentClass: string;
  static ɵfac: i0.ɵɵFactoryDeclaration<ItSidebarComponent, never>;
  static ɵcmp: i0.ɵɵComponentDeclaration<ItSidebarComponent, "it-sidebar", never, {
    "withRightLine": {
      "alias": "withRightLine";
      "required": false;
    };
    "withLeftLine": {
      "alias": "withLeftLine";
      "required": false;
    };
    "dark": {
      "alias": "dark";
      "required": false;
    };
    "header": {
      "alias": "header";
      "required": false;
    };
  }, {}, never, ["*", "[secondary]"], true, never>;
  static ngAcceptInputType_withRightLine: BooleanInput;
  static ngAcceptInputType_withLeftLine: BooleanInput;
  static ngAcceptInputType_dark: BooleanInput;
}
declare namespace megamenu_component_d_exports {
  export { ItMegamenuComponent };
}
export declare class ItMegamenuComponent {
  /**
   * Megamenu mode
   */
  mode: 'right-section' | 'left-section' | 'normal';
  /**
   * To show Megamenu header
   * @default false
   */
  header?: boolean;
  /**
   * To show Megamenu footer
   * @default false
   */
  footer?: boolean;
  static ɵfac: i0.ɵɵFactoryDeclaration<ItMegamenuComponent, never>;
  static ɵcmp: i0.ɵɵComponentDeclaration<ItMegamenuComponent, "it-megamenu", never, {
    "mode": {
      "alias": "mode";
      "required": false;
    };
    "header": {
      "alias": "header";
      "required": false;
    };
    "footer": {
      "alias": "footer";
      "required": false;
    };
  }, {}, never, ["[megamenuLeftZone]", "[megamenuHeadingLink]", "[megamenuLinkList]", "[megamenuFooter]"], true, never>;
  static ngAcceptInputType_header: BooleanInput;
  static ngAcceptInputType_footer: BooleanInput;
}
declare namespace skiplink_component_d_exports {
  export { ItSkiplinkComponent };
}
export declare class ItSkiplinkComponent {
  /**
   * Aria label for `nav` mode
   * @default 'Scorciatoie di navigazione'
   */
  ariaLabel: string;
  /**
   * If `true` nav mode is enabled
   * @default false
   */
  nav?: boolean;
  static ɵfac: i0.ɵɵFactoryDeclaration<ItSkiplinkComponent, never>;
  static ɵcmp: i0.ɵɵComponentDeclaration<ItSkiplinkComponent, "it-skiplink", ["itSkipLink"], {
    "ariaLabel": {
      "alias": "ariaLabel";
      "required": false;
    };
    "nav": {
      "alias": "nav";
      "required": false;
    };
  }, {}, never, ["*"], true, never>;
  static ngAcceptInputType_nav: BooleanInput;
}
declare namespace skiplink_item_component_d_exports {
  export { ItSkiplinkItemComponent };
}
export declare class ItSkiplinkItemComponent {
  /**
   * The router link action
   *
   * Commands to pass to Router#createUrlTree.
   * - array: commands to pass to Router#createUrlTree.
   * - string: shorthand for array of commands with just the string, i.e. ['/route']
   * - null|undefined: Disables the link by removing the href
   */
  href: any[] | string | null | undefined;
  /**
   * Is an external link (false to not use Angular router link)
   * @default false
   */
  externalLink?: boolean;
  inNav: boolean;
  constructor();
  static ɵfac: i0.ɵɵFactoryDeclaration<ItSkiplinkItemComponent, never>;
  static ɵcmp: i0.ɵɵComponentDeclaration<ItSkiplinkItemComponent, "it-skiplink-item", ["itSkipLinkItem"], {
    "href": {
      "alias": "href";
      "required": false;
    };
    "externalLink": {
      "alias": "externalLink";
      "required": false;
    };
  }, {}, never, ["*"], true, never>;
  static ngAcceptInputType_externalLink: BooleanInput;
}
declare namespace skiplink_module_d_exports {
  export { ItSkiplinkModule };
}
export declare class ItSkiplinkModule {
  static ɵfac: i0.ɵɵFactoryDeclaration<ItSkiplinkModule, never>;
  static ɵmod: i0.ɵɵNgModuleDeclaration<ItSkiplinkModule, never, [typeof ItSkiplinkComponent, typeof ItSkiplinkItemComponent], [typeof ItSkiplinkComponent, typeof ItSkiplinkItemComponent]>;
  static ɵinj: i0.ɵɵInjectorDeclaration<ItSkiplinkModule>;
}
export type NavscrollItem = ({
  text: string;
  html?: never;
} | {
  html: string;
  text?: never;
}) & {
  title: string;
  href: string;
  childs: NavscrollItems;
};
export type NavscrollItems = Array<NavscrollItem>;
export interface NavscrollItemActive {
  active: boolean;
}
declare namespace navscroll_component_d_exports {
  export { ItNavscrollComponent };
}
/**
 * Navscroll
 * @description Show a list of links to anchor of the document.
 */
export declare class ItNavscrollComponent implements OnInit {
  #private;
  static _nextId: number;
  readonly accordionId: string;
  /**
   * Header of the Navscroll
   */
  header: string;
  /**
   * Render the header as a collapsible accordion toggle,
   * allowing users to show/hide the navigation links.
   * @default false
   */
  headerAsAccordion?: boolean;
  /**
   * Hide the navigation bar when in mobile mode (viewport < 992px).
   * Mandatory when navscroll is used in a mobile context or in combination with a sticky header.
   * @default false
   */
  hideNavigationOnMobile?: boolean;
  /**
   * Whether the accordion starts expanded.
   * Only applies when headerAsAccordion is true.
   * @default true
   */
  accordionExpanded: boolean;
  /**
   * A list of links
   */
  items: Array<NavscrollItem>;
  /**
   * Border position
   * @default left
   */
  borderPosition: 'left' | 'right';
  /**
   * Alignment
   * @default top
   */
  alignment: 'top' | 'bottom';
  /**
   * Theme
   * @default light
   */
  theme: 'light' | 'dark';
  /**
   * Custom template for the content section
   */
  pageSectionsTemplate?: TemplateRef<any>;
  onScroll(): void;
  onResize(): void;
  readonly toggleButtonRef: ElementRef<HTMLButtonElement>;
  readonly selectedTitle: import("rxjs").Observable<string>;
  readonly progressBarValue: import("rxjs").Observable<number>;
  readonly isMobile: import("rxjs").Observable<boolean>;
  readonly isNotMobile: import("rxjs").Observable<boolean>;
  constructor();
  ngOnInit(): void;
  static ɵfac: i0.ɵɵFactoryDeclaration<ItNavscrollComponent, never>;
  static ɵcmp: i0.ɵɵComponentDeclaration<ItNavscrollComponent, "it-navscroll", never, {
    "header": {
      "alias": "header";
      "required": false;
    };
    "headerAsAccordion": {
      "alias": "headerAsAccordion";
      "required": false;
    };
    "hideNavigationOnMobile": {
      "alias": "hideNavigationOnMobile";
      "required": false;
    };
    "accordionExpanded": {
      "alias": "accordionExpanded";
      "required": false;
    };
    "items": {
      "alias": "items";
      "required": false;
    };
    "borderPosition": {
      "alias": "borderPosition";
      "required": false;
    };
    "alignment": {
      "alias": "alignment";
      "required": false;
    };
    "theme": {
      "alias": "theme";
      "required": false;
    };
    "pageSectionsTemplate": {
      "alias": "pageSectionsTemplate";
      "required": false;
    };
  }, {}, never, never, true, never>;
  static ngAcceptInputType_headerAsAccordion: BooleanInput;
  static ngAcceptInputType_hideNavigationOnMobile: BooleanInput;
  static ngAcceptInputType_accordionExpanded: BooleanInput;
}
declare namespace error_page_component_d_exports {
  export { ItErrorPageComponent };
}
export declare class ItErrorPageComponent {
  private readonly route;
  /**
   * The error code to show
   */
  errorCode: number | 404 | 403 | 500 | undefined;
  /**
   * Show/Hide error code
   * @default true - show
   */
  showErrorCode?: boolean;
  /**
   * Custom error title
   * - If set it will be displayed instead of the default title.
   * - It is possible to use i18n keys
   */
  errorTitle: string | undefined;
  /**
   * Custom error description
   * - If set it will be displayed instead of the default description.
   * - It is possible to use i18n keys
   */
  errorDescription: string | undefined;
  /**
   * Show/Hide back button
   * @default true - show
   */
  showBackButton?: boolean;
  /**
   * Show/Hide home button
   * @default true - show
   */
  showHomeButton?: boolean;
  constructor();
  get isDefaultErrorCode(): boolean;
  static ɵfac: i0.ɵɵFactoryDeclaration<ItErrorPageComponent, never>;
  static ɵcmp: i0.ɵɵComponentDeclaration<ItErrorPageComponent, "it-error-page", never, {
    "errorCode": {
      "alias": "errorCode";
      "required": false;
    };
    "showErrorCode": {
      "alias": "showErrorCode";
      "required": false;
    };
    "errorTitle": {
      "alias": "errorTitle";
      "required": false;
    };
    "errorDescription": {
      "alias": "errorDescription";
      "required": false;
    };
    "showBackButton": {
      "alias": "showBackButton";
      "required": false;
    };
    "showHomeButton": {
      "alias": "showHomeButton";
      "required": false;
    };
  }, {}, never, never, true, never>;
  static ngAcceptInputType_showErrorCode: BooleanInput;
  static ngAcceptInputType_showBackButton: BooleanInput;
  static ngAcceptInputType_showHomeButton: BooleanInput;
}
export interface AvailableLanguage {
  /**
   * The language code
   */
  code: string;
  /**
   * Label to show
   */
  label: string;
}
declare namespace language_switcher_component_d_exports {
  export { ItLanguageSwitcherComponent };
}
export declare class ItLanguageSwitcherComponent implements OnInit {
  private readonly translateService;
  /**
   * The available languages
   * @default The languages available through TranslateService (ngx-translate)
   */
  availableLanguages: Array<AvailableLanguage> | undefined;
  /**
   * Dropdown mode
   */
  mode: 'button' | 'link' | 'nav';
  protected currentLang$: Observable<AvailableLanguage | undefined>;
  constructor();
  ngOnInit(): void;
  /**
   * Change the current language
   * @param lang the language code
   */
  changeLanguage(lang: string): void;
  static ɵfac: i0.ɵɵFactoryDeclaration<ItLanguageSwitcherComponent, never>;
  static ɵcmp: i0.ɵɵComponentDeclaration<ItLanguageSwitcherComponent, "it-language-switcher", never, {
    "availableLanguages": {
      "alias": "availableLanguages";
      "required": false;
    };
    "mode": {
      "alias": "mode";
      "required": false;
    };
  }, {}, never, never, true, never>;
}
declare namespace date_ago_pipe_d_exports {
  export { ItDateAgoPipe };
}
/**
 * Indicates in a textual way how much time has passed since the indicated date
 * @example 2 hours ago
 */
export declare class ItDateAgoPipe extends TranslatePipe implements PipeTransform {
  /**
   * Indicates in a textual way how much time has passed since the indicated date
   * @example 2 hours ago
   * @param value the Date or date string
   */
  transform(value: string | Date | null | undefined): string;
  static ɵfac: i0.ɵɵFactoryDeclaration<ItDateAgoPipe, never>;
  static ɵpipe: i0.ɵɵPipeDeclaration<ItDateAgoPipe, "itDateAgo", true>;
}
declare namespace duration_pipe_d_exports {
  export { ItDurationPipe, ItDurationPipeType };
}
export type ItDurationPipeType = 'year' | 'month' | 'week' | 'day' | 'hour' | 'minute' | 'second';
/**
 * Transform a number into a duration.
 * Is necessary indicate the value expressed by the number, for example 'day'.
 * @example
 *  - 1, 'day' -> 1 day
 *  - 5, 'day' -> 5 days
 *  - 7, 'day' -> 1 week
 *  - 365, 'day' -> 1 year
 *  - 2, 'week' -> 2 weeks
 *  ...
 */
export declare class ItDurationPipe extends TranslatePipe implements PipeTransform {
  /**
   * Transform a number into a duration.
   * Is necessary indicate the value expressed by the number, for example 'day'.
   * @example
   *  - 1, 'day' -> 1 day
   *  - 5, 'day' -> 5 days
   *  - 7, 'day' -> 1 week
   *  - 8, 'day' -> 1 week
   *  - 365, 'day' -> 1 year
   *  - 2, 'week' -> 2 weeks
   *  - 24, 'month' -> 1 year
   *  ...
   * @param value the number
   * @param type the number expressed type
   */
  transform(value: string | number | undefined | null, type: ItDurationPipeType): string;
  static ɵfac: i0.ɵɵFactoryDeclaration<ItDurationPipe, never>;
  static ɵpipe: i0.ɵɵPipeDeclaration<ItDurationPipe, "itDuration", true>;
}
declare namespace mark_matching_text_pipe_d_exports {
  export { ItMarkMatchingTextPipe };
}
/**
 * Allows you to highlight text with the <mark> tag
 */
export declare class ItMarkMatchingTextPipe implements PipeTransform {
  private readonly domSanitizer;
  /**
   * Allows you to highlight text with the <mark> tag
   * @param allString the full text to search from
   * @param searchString the string to search
   */
  transform(allString: string | undefined, searchString: string | number | null | undefined): SafeHtml | string | undefined;
  static ɵfac: i0.ɵɵFactoryDeclaration<ItMarkMatchingTextPipe, never>;
  static ɵpipe: i0.ɵɵPipeDeclaration<ItMarkMatchingTextPipe, "itMarkMatchingText", true>;
}
export declare class DesignAngularKitModule {
  static forRoot(config?: DesignAngularKitConfig): ModuleWithProviders<DesignAngularKitModule>;
  static forChild(): ModuleWithProviders<DesignAngularKitModule>;
  static ɵfac: i0.ɵɵFactoryDeclaration<DesignAngularKitModule, never>;
  static ɵmod: i0.ɵɵNgModuleDeclaration<DesignAngularKitModule, never, [typeof ItAccordionComponent, typeof ItAlertComponent, typeof ItAvatarModule, typeof ItBadgeDirective, typeof ItButtonDirective, typeof ItCalloutComponent, typeof ItCardComponent, typeof ItCarouselModule, typeof ItChipComponent, typeof ItCollapseComponent, typeof ItDimmerModule, typeof ItDropdownModule, typeof ItForwardDirective, typeof ItLinkComponent, typeof ItListModule, typeof ItModalComponent, typeof ItNotificationsComponent, typeof ItPaginationComponent, typeof ItPopoverDirective, typeof ItProgressBarComponent, typeof ItProgressButtonComponent, typeof ItSpinnerComponent, typeof ItSteppersModule, typeof ItTabModule, typeof ItTableModule, typeof ItTooltipDirective, typeof ItTimelineModule, typeof ItVideoPlayerComponent, typeof ItFormModule, typeof ItBackButtonComponent, typeof ItBackToTopComponent, typeof ItBreadcrumbsModule, typeof ItHeaderComponent, typeof ItFooterComponent, typeof ItNavBarModule, typeof ItSidebarComponent, typeof ItMegamenuComponent, typeof ItSkiplinkModule, typeof ItNavscrollComponent, typeof ItErrorPageComponent, typeof ItIconComponent, typeof ItLanguageSwitcherComponent, typeof ItDateAgoPipe, typeof ItDurationPipe, typeof ItMarkMatchingTextPipe], [typeof ItAccordionComponent, typeof ItAlertComponent, typeof ItAvatarModule, typeof ItBadgeDirective, typeof ItButtonDirective, typeof ItCalloutComponent, typeof ItCardComponent, typeof ItCarouselModule, typeof ItChipComponent, typeof ItCollapseComponent, typeof ItDimmerModule, typeof ItDropdownModule, typeof ItForwardDirective, typeof ItLinkComponent, typeof ItListModule, typeof ItModalComponent, typeof ItNotificationsComponent, typeof ItPaginationComponent, typeof ItPopoverDirective, typeof ItProgressBarComponent, typeof ItProgressButtonComponent, typeof ItSpinnerComponent, typeof ItSteppersModule, typeof ItTabModule, typeof ItTableModule, typeof ItTooltipDirective, typeof ItTimelineModule, typeof ItVideoPlayerComponent, typeof ItFormModule, typeof ItBackButtonComponent, typeof ItBackToTopComponent, typeof ItBreadcrumbsModule, typeof ItHeaderComponent, typeof ItFooterComponent, typeof ItNavBarModule, typeof ItSidebarComponent, typeof ItMegamenuComponent, typeof ItSkiplinkModule, typeof ItNavscrollComponent, typeof ItErrorPageComponent, typeof ItIconComponent, typeof ItLanguageSwitcherComponent, typeof ItDateAgoPipe, typeof ItDurationPipe, typeof ItMarkMatchingTextPipe]>;
  static ɵinj: i0.ɵɵInjectorDeclaration<DesignAngularKitModule>;
}
/**
 * Configures DesignAngularKit library
 * @param config the DesignAngularKit config
 */
export declare function provideDesignAngularKit(config?: DesignAngularKitConfig): EnvironmentProviders;
export declare class ItVideoPlayerModule {
  static ɵfac: i0.ɵɵFactoryDeclaration<ItVideoPlayerModule, never>;
  static ɵmod: i0.ɵɵNgModuleDeclaration<ItVideoPlayerModule, never, [typeof ItVideoPlayerComponent], [typeof ItVideoPlayerComponent]>;
  static ɵinj: i0.ɵɵInjectorDeclaration<ItVideoPlayerModule>;
}
export declare class ItNotificationService {
  private subject;
  /**
   * Listen on notification arrived
   * @param filterType filter type of notification
   */
  onNotification(filterType?: NotificationType): Observable<Notification>;
  /**
   * Show new notification
   * @param notification notification
   */
  addNotification(notification: Notification): void;
  /**
   * Create new Standard notification
   * @param title notification title
   * @param message notification message
   * @param dismissible notification dismissible
   * @param duration notification duration (milliseconds)
   * @param position notification position
   */
  standard(title: string, message?: string, dismissible?: boolean, duration?: number, position?: NotificationPosition): void;
  /**
   * Create new Success notification
   * @param title notification title
   * @param message notification message
   * @param dismissible notification dismissible
   * @param duration notification duration (milliseconds)
   * @param position notification position
   */
  success(title: string, message?: string, dismissible?: boolean, duration?: number, position?: NotificationPosition): void;
  /**
   * Create new Error notification
   * @param title notification title
   * @param message notification message
   * @param dismissible notification dismissible
   * @param duration notification duration (milliseconds)
   * @param position notification position
   */
  error(title: string, message?: string, dismissible?: boolean, duration?: number, position?: NotificationPosition): void;
  /**
   * Create new Warning notification
   * @param title notification title
   * @param message notification message
   * @param dismissible notification dismissible
   * @param duration notification duration (milliseconds)
   * @param position notification position
   */
  warning(title: string, message?: string, dismissible?: boolean, duration?: number, position?: NotificationPosition): void;
  /**
   * Create new Info notification
   * @param title notification title
   * @param message notification message
   * @param dismissible notification dismissible
   * @param duration notification duration (milliseconds)
   * @param position notification position
   */
  info(title: string, message?: string, dismissible?: boolean, duration?: number, position?: NotificationPosition): void;
  static ɵfac: i0.ɵɵFactoryDeclaration<ItNotificationService, never>;
  static ɵprov: i0.ɵɵInjectableDeclaration<any>;
}
export declare class ItDateUtils {
  /**
   * Add seconds to date
   * @param date the date
   * @param seconds seconds to add
   */
  static addSeconds(date: Date, seconds: number): Date;
  /**
   * Add minutes to date
   * @param date the date
   * @param minutes minutes to add
   */
  static addMinutes(date: Date, minutes: number): Date;
  /**
   * Add hours to date
   * @param date the date
   * @param hours hours to add
   */
  static addHours(date: Date, hours: number): Date;
  /**
   * Add days to date
   * @param date the date
   * @param days days to add
   */
  static addDays(date: Date, days: number): Date;
  /**
   * Add years to date
   * @param date the date
   * @param months months to add
   */
  static addMonths(date: Date, months: number): Date;
  /**
   * Add years to date
   * @param date the date
   * @param years years to add
   */
  static addYears(date: Date, years: number): Date;
  /**
   * Calculate number of days between two date
   * @param startDate
   * @param endDate
   * @param absolute return unsigned result
   */
  static countDays(startDate: Date, endDate: Date, absolute?: boolean): number;
  /**
   * Check if string is a date with iso format
   * @param value the string
   */
  static isIsoString(value: string | null): boolean;
  /**
   * Convert iso string to Date
   * @param isoString the iso string
   */
  static isoStringToDate(isoString: string | null): Date | null;
  /**
   * Remove time from an iso date string
   * @param isoString the iso string
   */
  static isoStringRemoveTime(isoString: string): string;
  /**
   * Set iso string hours to 0 and format correctly the date (consider timezone offset)
   * @example '2024-03-04T23:00:00.000Z' -> '2024-03-05T00:00:00.000Z'
   * @param isoString the iso string
   */
  static isoStringSetZeroTime(isoString: string): string;
  /**
   * Calculate the date time left and return the string format [d h m s]
   * @param endDate
   */
  static timeLeftString(endDate: Date): Observable<string>;
  /**
   * Calculate the next day of week
   * @param dayOfWeek Day of week 0=Sunday, 1=Monday...4=Thursday...
   * @param hour the specif hour
   * @param minute the specific minute
   */
  static nextWeekDayAndTime(dayOfWeek: number, hour?: number, minute?: number): Date;
}
export declare class ItFileUtils {
  /**
   * Return the file size string
   * @param file the file
   * @param decimals decimal to show
   */
  static getFileSizeString(file: File, decimals?: number): string;
  /**
   * Convert a file to base64 string
   * @param file the base64 string
   */
  static fileToBase64(file: File): Observable<string>;
  /**
   * Convert base64 to Blob
   * @param base64 the base64 string
   * @param mimeType the <a href="https://developer.mozilla.org/en-US/docs/Web/HTTP/Basics_of_HTTP/MIME_types/Common_types">MIME type</a> (example 'application/pdf')
   */
  static base64ToBlob(base64: string, mimeType: string): Blob;
  /**
   * Convert base64 to File
   * @param base64 the base64 string
   * @param mimeType the <a href="https://developer.mozilla.org/en-US/docs/Web/HTTP/Basics_of_HTTP/MIME_types/Common_types">MIME type</a> (example 'application/pdf')
   * @param filename the file name
   */
  static base64ToFile(base64: string, mimeType: string, filename: string): File;
  /**
   * Extract the MIME type from base64 string
   * @param base64 the base64 string
   */
  static getMimeTypeFromBase64(base64: string): string | undefined;
}
/**
 * General Email Regex (RFC 5322 Official Standard)
 * http://emailregex.com/
 */
export declare const EMAIL_REGEX: RegExp;
/**
 * Phone number Regex
 */
export declare const PHONE_NUMBER_REGEX: RegExp;
/**
 * URL Regex
 */
export declare const URL_REGEX: RegExp;
/**
 * The italian tax code Regex (Codice Fiscale)
 */
export declare const ITALIAN_TAX_CODE_REGEX: RegExp;
/**
 * The VAT number Regex (Partita iva)
 */
export declare const VAT_NUMBER_REGEX: RegExp;
/**
 * Italian CAP Regex
 */
export declare const CAP_REGEX: RegExp;
/**
 * Italian Plate Regex
 */
export declare const PLATE_REGEX: RegExp;
/**
 * IBAN Regex
 * https://blog.marketto.it/en/2018/06/validate-any-country-iban/
 */
export declare const IBAN_REGEX: RegExp;
export declare class ItValidators {
  static SpecialCharacterPattern: string;
  /**
   * Static pattern validator with custom error
   * @param regex
   * @param error
   */
  static customPattern(regex: RegExp, error: ValidationErrors): ValidatorFn;
  /**
   * Set Validator if the condition is satisfied
   * @param validator the validator to apply if the condition is true
   * @param condition the condition
   */
  static conditional(validator: ValidatorFn, condition: (control: AbstractControl) => boolean): ValidatorFn;
  /**
   * Check whether our password and confirm password are a match
   * @param control
   * @param passwordControlName the password formControlName
   * @param confirmControlName the confirmPassword formControlName
   */
  static passwordMatch(control: AbstractControl, passwordControlName?: string, confirmControlName?: string): AbstractControl | null;
  /**
   * Password validator
   * @param minLength minimum password length - default 10
   * @param hasNumber check whether the entered password has a number - default true
   * @param hasCapitalCase check whether the entered password has upper case letter - default true
   * @param hasSmallCase check whether the entered password has a lower-case letter - default true
   * @param hasSpecialCharacters check whether the entered password has a special character - default true
   * @param required the field is required - default true
   */
  static password(minLength?: number, hasNumber?: boolean, hasCapitalCase?: boolean, hasSmallCase?: boolean, hasSpecialCharacters?: boolean, required?: boolean): ValidatorFn;
  /**
   * Email validator
   */
  static get email(): ValidatorFn;
  /**
   * Phone number validator
   */
  static get tel(): ValidatorFn;
  static includes(possibleValues: string[]): ValidatorFn;
  /**
   * URL validator
   */
  static get url(): ValidatorFn;
  /**
   * Italian Tax Code validator
   */
  static get taxCode(): ValidatorFn;
  /**
   * VAT Number validator
   */
  static get vatNumber(): ValidatorFn;
  /**
   * Italian Postal Code validator (CAP)
   */
  static get cap(): ValidatorFn;
  /**
   * IBAN validator
   */
  static get iban(): ValidatorFn;
  /**
   * Italian plate validator
   */
  static get plate(): ValidatorFn;
  /**
   * Check if value is a valid RegExp
   */
  static get regExp(): ValidatorFn;
}
export type { Caption, Chapter, ItEmbedVideoPlayerOptions, ItNativeVideoPlayerOptions, ItVideoPlayerConfig, ItVideoPlayerOptions, Source };