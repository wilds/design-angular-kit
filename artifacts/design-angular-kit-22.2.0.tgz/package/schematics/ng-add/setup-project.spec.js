"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || (function () {
    var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function (o) {
            var ar = [];
            for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
            return ar;
        };
        return ownKeys(o);
    };
    return function (mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
        __setModuleDefault(result, mod);
        return result;
    };
})();
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
const testing_1 = require("@angular-devkit/schematics/testing");
const path = __importStar(require("path"));
const createApp = (runner_1, options_1, _a) => __awaiter(void 0, [runner_1, options_1, _a], void 0, function* (runner, options, { standalone, style }) {
    let tree = yield runner.runExternalSchematic('@schematics/angular', 'workspace', {
        name: 'workspace',
        version: '18.0.0',
        newProjectRoot: 'projects',
    });
    tree = yield runner.runExternalSchematic('@schematics/angular', 'application', {
        name: options.project,
        standalone,
        style,
    }, tree);
    return { tree };
});
describe(`ng add design-angular-kit | setup-project - library providing`, () => {
    const collectionPath = path.join(__dirname, '../collection.json');
    const runner = new testing_1.SchematicTestRunner('schematics', collectionPath);
    const defaultOptions = {
        project: 'test-project', // Set your default project name
    };
    it('should add DesignAngularKitModule to the root module - NgModule app', () => __awaiter(void 0, void 0, void 0, function* () {
        const { tree: appTree } = yield createApp(runner, defaultOptions, { standalone: false, style: 'scss' });
        const tree = yield runner.runSchematic('ng-add-setup-project', defaultOptions, appTree);
        // Check if the app.module.ts file exists
        const modulePath = '/projects/test-project/src/app/app-module.ts';
        expect(tree.files).toContain(modulePath);
        // Check if the correct import statement was added
        const content = tree.readContent(modulePath);
        expect(content).toContain(`import { DesignAngularKitModule } from 'design-angular-kit';`);
        expect(content).toContain(`DesignAngularKitModule.forRoot()`);
    }));
    it('should add provideDesignAngularKit() to the app config - Standalone app', () => __awaiter(void 0, void 0, void 0, function* () {
        const { tree: appTree } = yield createApp(runner, defaultOptions, { standalone: true, style: 'scss' });
        const tree = yield runner.runSchematic('ng-add-setup-project', defaultOptions, appTree);
        // Check if the app.module.ts file exists
        const appConfigPath = '/projects/test-project/src/app/app.config.ts';
        expect(tree.files).toContain(appConfigPath);
        // Check if the correct import statement was added
        const content = tree.readContent(appConfigPath);
        expect(content).toContain(`import { provideDesignAngularKit } from 'design-angular-kit';`);
        expect(content).toContain(`provideDesignAngularKit()`);
    }));
});
for (const standalone of [true, false]) {
    describe(`ng add design-angular-kit | setup-project for ${standalone ? 'standalone' : 'NgModule'} app - styles`, () => {
        const collectionPath = path.join(__dirname, '../collection.json');
        const runner = new testing_1.SchematicTestRunner('schematics', collectionPath);
        const defaultOptions = {
            project: 'test-project', // Set your default project name
        };
        it('should add .scss import to project style file', () => __awaiter(void 0, void 0, void 0, function* () {
            const { tree: appTree } = yield createApp(runner, defaultOptions, { standalone, style: 'scss' });
            const tree = yield runner.runSchematic('ng-add-setup-project', defaultOptions, appTree);
            // Check if the styles.scss file exists
            const styleFilePath = '/projects/test-project/src/styles.scss';
            expect(tree.files).toContain(styleFilePath);
            // Check if the correct import statement was added
            const content = tree.readContent(styleFilePath);
            expect(content).toContain(`@import '../node_modules/bootstrap-italia/src/scss/bootstrap-italia.scss';`);
        }));
        it('should add .sass import to project style file', () => __awaiter(void 0, void 0, void 0, function* () {
            const { tree: appTree } = yield createApp(runner, defaultOptions, { standalone, style: 'sass' });
            const tree = yield runner.runSchematic('ng-add-setup-project', defaultOptions, appTree);
            // Check if the styles.sass file exists
            const styleFilePath = '/projects/test-project/src/styles.sass';
            expect(tree.files).toContain(styleFilePath);
            // Check if the correct import statement was added
            const content = tree.readContent(styleFilePath);
            expect(content).toContain(`@import 'bootstrap-italia/scss/bootstrap-italia'`);
        }));
        it('should add .css import to angular.json', () => __awaiter(void 0, void 0, void 0, function* () {
            const { tree: appTree } = yield createApp(runner, defaultOptions, { standalone, style: 'css' });
            const tree = yield runner.runSchematic('ng-add-setup-project', defaultOptions, appTree);
            // Check if the angular.json file exists
            const angularJsonPath = '/angular.json';
            expect(tree.files).toContain(angularJsonPath);
            // Check if the correct import statement was added
            const content = tree.readContent(angularJsonPath);
            expect(content).toContain(`node_modules/bootstrap-italia/dist/css/bootstrap-italia.min.css`);
        }));
    });
    describe(`ng add design-angular-kit | setup-project for ${standalone ? 'standalone' : 'NgModule'} app - assets`, () => {
        const collectionPath = path.join(__dirname, '../collection.json');
        const runner = new testing_1.SchematicTestRunner('schematics', collectionPath);
        const defaultOptions = {
            project: 'test-project', // Set your default project name
        };
        it('should add bootstrap italia assets to angular.json', () => __awaiter(void 0, void 0, void 0, function* () {
            var _a, _b, _c, _d, _e;
            const { tree: appTree } = yield createApp(runner, defaultOptions, { standalone, style: 'css' });
            const tree = yield runner.runSchematic('ng-add-setup-project', defaultOptions, appTree);
            // Check if the angular.json file exists
            const angularJsonPath = '/angular.json';
            expect(tree.files).toContain(angularJsonPath);
            // Check if the correct import statement was added
            const content = tree.readContent(angularJsonPath);
            //"./node_modules/bootstrap-italia/"
            expect(content).toContain(`./node_modules/bootstrap-italia/`);
            const angularJson = JSON.parse(content);
            const assetsConfig = (_e = (_d = (_c = (_b = (_a = angularJson.projects[defaultOptions.project]) === null || _a === void 0 ? void 0 : _a.architect) === null || _b === void 0 ? void 0 : _b.build) === null || _c === void 0 ? void 0 : _c.options) === null || _d === void 0 ? void 0 : _d.assets) === null || _e === void 0 ? void 0 : _e.find((item) => item.input === `./node_modules/bootstrap-italia/`);
            expect(assetsConfig).toBeDefined(assetsConfig);
        }));
    });
    describe(`ng add design-angular-kit | setup-project for ${standalone ? 'standalone' : 'NgModule'} app - localisation`, () => {
        const collectionPath = path.join(__dirname, '../collection.json');
        const runner = new testing_1.SchematicTestRunner('schematics', collectionPath);
        const defaultOptions = {
            project: 'test-project', // Set your default project name
        };
        it('should add bootstrap italia localisation to angular.json', () => __awaiter(void 0, void 0, void 0, function* () {
            var _a, _b, _c, _d, _e;
            const { tree: appTree } = yield createApp(runner, defaultOptions, { standalone, style: 'css' });
            const tree = yield runner.runSchematic('ng-add-setup-project', defaultOptions, appTree);
            // Check if the angular.json file exists
            const angularJsonPath = '/angular.json';
            expect(tree.files).toContain(angularJsonPath);
            // Check if the correct import statement was added
            const content = tree.readContent(angularJsonPath);
            //"./node_modules/bootstrap-italia/"
            expect(content).toContain(`/node_modules/design-angular-kit/assets/i18n`);
            const angularJson = JSON.parse(content);
            const assetsConfig = (_e = (_d = (_c = (_b = (_a = angularJson.projects[defaultOptions.project]) === null || _a === void 0 ? void 0 : _a.architect) === null || _b === void 0 ? void 0 : _b.build) === null || _c === void 0 ? void 0 : _c.options) === null || _d === void 0 ? void 0 : _d.assets) === null || _e === void 0 ? void 0 : _e.find((item) => item.input === `./node_modules/design-angular-kit/assets/i18n`);
            expect(assetsConfig).toBeDefined(assetsConfig);
        }));
    });
}
//# sourceMappingURL=setup-project.spec.js.map