export declare function getPackageVersion({ angularMajorVersion }: {
    angularMajorVersion: string;
}): string;
