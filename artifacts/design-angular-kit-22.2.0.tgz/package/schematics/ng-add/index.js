"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.default = default_1;
const tasks_1 = require("@angular-devkit/schematics/tasks");
const utils_1 = require("./utils");
const versions_helper_1 = require("./versions-helper");
const DESIGN_ANGULAR_KIT_PACKAGE_NAME = 'design-angular-kit';
const NG_LATEST_VERSION = '22.0.0';
function default_1(options) {
    return (host, context) => {
        // Get the version of `@angular/core`
        // This tag should be preferred because all Angular dependencies should  have the same version tag if possible.
        const ngCoreVersionTag = (0, utils_1.getPackageVersionFromPackageJson)(host, '@angular/core');
        const designAngularKitVersionRange = (0, utils_1.getPackageVersionFromPackageJson)(host, DESIGN_ANGULAR_KIT_PACKAGE_NAME);
        const angularDependencyVersion = ngCoreVersionTag || NG_LATEST_VERSION;
        const { major: angularMajorVersion } = (0, utils_1.toSemVerObject)(angularDependencyVersion);
        const designAngularKitPackageVersion = (0, versions_helper_1.getPackageVersion)({ angularMajorVersion });
        // The CLI inserts `design-angular-kit` into the `package.json` before this schematic runs.
        // This means that we do not need to insert Design Angular Kit into `package.json` files again.
        if (designAngularKitVersionRange === null) {
            (0, utils_1.addPackageToPackageJson)(host, DESIGN_ANGULAR_KIT_PACKAGE_NAME, designAngularKitPackageVersion);
        }
        (0, utils_1.addPackageToPackageJson)(host, '@angular/cdk', angularDependencyVersion);
        (0, utils_1.addPackageToPackageJson)(host, '@angular/animations', angularDependencyVersion);
        const installTaskId = context.addTask(new tasks_1.NodePackageInstallTask());
        context.addTask(new tasks_1.RunSchematicTask('ng-add-setup-project', options), [installTaskId]);
    };
}
//# sourceMappingURL=index.js.map