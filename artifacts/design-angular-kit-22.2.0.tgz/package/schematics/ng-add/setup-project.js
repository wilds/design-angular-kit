"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.default = default_1;
const schematics_1 = require("@angular-devkit/schematics");
const setup_project_1 = require("./rules/setup-project");
const schematics_2 = require("@angular/cdk/schematics");
const workspace_1 = require("@schematics/angular/utility/workspace");
const workspace_models_1 = require("@schematics/angular/utility/workspace-models");
function default_1(options) {
    return (host, context) => __awaiter(this, void 0, void 0, function* () {
        const workspace = yield (0, workspace_1.getWorkspace)(host);
        const project = (0, schematics_2.getProjectFromWorkspace)(workspace, options.project);
        const isAProject = project.extensions['projectType'] === workspace_models_1.ProjectType.Application;
        if (isAProject) {
            return (0, schematics_1.chain)([
                (0, setup_project_1.addAnimations)(),
                (0, setup_project_1.addHttpClient)(),
                (0, setup_project_1.addDesignAngularKit)(options),
                (0, setup_project_1.addImportToStyleFile)(options),
                (0, setup_project_1.addAssets)(options),
                (0, setup_project_1.addLocalisation)(options),
            ]);
        }
        context.logger.warn(`Design Angular Kit has been set in your workspace. No additional setup required.\nIf you intend to run the schematics on a specific project, please use -- project option `);
        return;
    });
}
//# sourceMappingURL=setup-project.js.map