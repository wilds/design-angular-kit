import { SchematicsException } from '@angular-devkit/schematics';
export declare class NoProjectException extends SchematicsException {
    constructor(project: string);
}
export declare class NoMainFileException extends SchematicsException {
    constructor(project: string);
}
