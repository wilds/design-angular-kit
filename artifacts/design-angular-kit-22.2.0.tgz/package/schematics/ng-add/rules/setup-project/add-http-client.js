"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.addHttpClient = addHttpClient;
const schematics_1 = require("@angular-devkit/schematics");
function addHttpClient() {
    //this dependency should be provided at application level instead of lib level. ref: provideDesignAngularKit
    //provideHttpClient(),
    return (host, context) => (0, schematics_1.callRule)((0, schematics_1.noop)(), host, context);
}
//# sourceMappingURL=add-http-client.js.map