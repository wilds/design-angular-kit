"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || (function () {
    var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function (o) {
            var ar = [];
            for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
            return ar;
        };
        return ownKeys(o);
    };
    return function (mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
        __setModuleDefault(result, mod);
        return result;
    };
})();
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.addImportToStyleFile = addImportToStyleFile;
const core_1 = require("@angular-devkit/core");
const utility_1 = require("@schematics/angular/utility");
const path = __importStar(require("path"));
const angular_json_helper_1 = require("./angular-json-helper");
const exceptions_1 = require("./exceptions");
const BOOTSTRAP_ITALIA_CSS_FILEPATH = 'node_modules/bootstrap-italia/dist/css/bootstrap-italia.min.css';
const SUPPORTED_BOOTSTRAP_ITALIA_STYLE_MAP = {
    '.sass': `
  /* Importazione libreria SCSS di bootstrap-italia */
  @import 'bootstrap-italia/scss/bootstrap-italia'
  `,
    '.scss': `
  /* Importazione libreria SCSS di bootstrap-italia */
  @import '../node_modules/bootstrap-italia/src/scss/bootstrap-italia.scss';
  `,
};
/**
 * if supported
 *    add to styles.scss or to style.sass
 * else
 *  add css to assets in angular.json
 * @param options
 * @returns Rule
 */
function addImportToStyleFile(options) {
    return (host, context) => __awaiter(this, void 0, void 0, function* () {
        const workspace = yield (0, utility_1.readWorkspace)(host);
        const projectName = options.project || workspace.extensions.defaultProject.toString();
        const project = workspace.projects.get(projectName);
        if (!project) {
            throw new exceptions_1.NoProjectException(projectName);
        }
        const styleFilePath = getProjectStyleFile(project) || '';
        const styleFileExtension = path.extname(styleFilePath);
        const styleFilePatch = SUPPORTED_BOOTSTRAP_ITALIA_STYLE_MAP[styleFileExtension];
        // found supported styles
        if (styleFilePatch) {
            return addBootstrapItaliaToStylesFile(styleFilePath, styleFilePatch);
        }
        else {
            // found some styles, but unsupported
            if (styleFileExtension !== '.css' && styleFileExtension !== '') {
                context.logger.warn('messages.unsupportedStyles(styleFilePath)');
            }
            // just patching 'angular.json'
            addBootstrapItaliaToAngularJson(project);
            yield (0, utility_1.writeWorkspace)(host, workspace);
        }
    });
}
function addBootstrapItaliaToStylesFile(styleFilePath, styleFilePatch) {
    return (host) => __awaiter(this, void 0, void 0, function* () {
        const styleContent = host.read(styleFilePath).toString('utf-8');
        const recorder = host.beginUpdate(styleFilePath);
        recorder.insertRight(styleContent.length, styleFilePatch);
        host.commitUpdate(recorder);
    });
}
function addBootstrapItaliaToAngularJson(project) {
    const targetOptions = (0, angular_json_helper_1.getProjectTargetOptions)(project, 'build');
    const styles = targetOptions.styles;
    if (!styles) {
        targetOptions.styles = [BOOTSTRAP_ITALIA_CSS_FILEPATH];
    }
    else {
        const existingStyles = styles.map(s => (typeof s === 'string' ? s : s['input']));
        for (const [, stylePath] of existingStyles.entries()) {
            if (stylePath === BOOTSTRAP_ITALIA_CSS_FILEPATH) {
                return;
            }
        }
        styles.unshift(BOOTSTRAP_ITALIA_CSS_FILEPATH);
    }
}
// Regular expression that matches all possible Angular CLI default style files
const defaultStyleFileRegex = /styles\.(c|le|sc|sa)ss/;
// Regular expression that matches all files that have a proper stylesheet extension
const validStyleFileRegex = /\.(c|le|sc|sa)ss/;
function getProjectStyleFile(project, extension) {
    const buildOptions = (0, angular_json_helper_1.getProjectTargetOptions)(project, 'build');
    if (buildOptions.styles && Array.isArray(buildOptions.styles) && buildOptions.styles.length) {
        const styles = buildOptions.styles.map(s => (typeof s === 'string' ? s : s['input']));
        // Look for the default style file that is generated for new projects by the Angular CLI. This
        // default style file is usually called `styles.ext` unless it has been changed explicitly.
        const defaultMainStylePath = styles.find(file => (extension ? file === `styles.${extension}` : defaultStyleFileRegex.test(file)));
        if (defaultMainStylePath) {
            return (0, core_1.normalize)(defaultMainStylePath);
        }
        // If no default style file could be found, use the first style file that matches the given
        // extension. If no extension specified explicitly, we look for any file with a valid style
        // file extension.
        const fallbackStylePath = styles.find(file => (extension ? file.endsWith(`.${extension}`) : validStyleFileRegex.test(file)));
        if (fallbackStylePath) {
            return (0, core_1.normalize)(fallbackStylePath);
        }
    }
    return null;
}
//# sourceMappingURL=add-import-to-style-file.js.map