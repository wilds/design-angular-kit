"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.NoMainFileException = exports.NoProjectException = void 0;
const schematics_1 = require("@angular-devkit/schematics");
class NoProjectException extends schematics_1.SchematicsException {
    constructor(project) {
        super(`Unable to find project '${project}' in the workspace`);
    }
}
exports.NoProjectException = NoProjectException;
class NoMainFileException extends schematics_1.SchematicsException {
    constructor(project) {
        super(`Unable to find 'build.options.main' file path for project "${project}`);
    }
}
exports.NoMainFileException = NoMainFileException;
//# sourceMappingURL=exceptions.js.map