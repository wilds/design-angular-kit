import { Rule } from '@angular-devkit/schematics';
import { Schema } from '../../schema';
/**
 * if supported
 *    add to styles.scss or to style.sass
 * else
 *  add css to assets in angular.json
 * @param options
 * @returns Rule
 */
export declare function addImportToStyleFile(options: Schema): Rule;
