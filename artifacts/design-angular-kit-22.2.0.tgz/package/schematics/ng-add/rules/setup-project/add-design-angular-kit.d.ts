import { Rule } from '@angular-devkit/schematics';
import { Schema } from '../../schema';
export declare function addDesignAngularKit(options: Schema): Rule;
