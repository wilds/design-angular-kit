import { workspaces } from '@angular-devkit/core';
export declare function getProjectTargetOptions(project: workspaces.ProjectDefinition, buildTarget: string): Record<string, import("@angular-devkit/core").JsonValue | undefined>;
