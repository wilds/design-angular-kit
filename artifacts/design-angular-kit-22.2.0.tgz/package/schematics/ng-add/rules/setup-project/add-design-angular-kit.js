"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.addDesignAngularKit = addDesignAngularKit;
const schematics_1 = require("@angular-devkit/schematics");
const schematics_2 = require("@angular/cdk/schematics");
const utility_1 = require("@schematics/angular/utility");
const util_1 = require("@schematics/angular/utility/standalone/util");
const rxjs_1 = require("rxjs");
const exceptions_1 = require("./exceptions");
function addDesignAngularKit(options) {
    return (host, context) => __awaiter(this, void 0, void 0, function* () {
        const workspace = yield (0, utility_1.readWorkspace)(host);
        const projectName = options.project || workspace.extensions.defaultProject;
        // 1. getting project by name
        const project = workspace.projects.get(projectName);
        if (!project) {
            throw new exceptions_1.NoProjectException(projectName);
        }
        // 2. getting main file for project
        const mainFilePath = yield (0, util_1.getMainFilePath)(host, projectName);
        if (!mainFilePath || !host.read(mainFilePath)) {
            throw new exceptions_1.NoMainFileException(projectName);
        }
        const isNotStandaloneApp = !(0, schematics_2.isStandaloneApp)(host, mainFilePath);
        const rule = isNotStandaloneApp
            ? (0, utility_1.addRootImport)(projectName, ({ code, external }) => code `${external('DesignAngularKitModule', 'design-angular-kit')}.forRoot()\n`)
            : (0, utility_1.addRootProvider)(projectName, ({ code, external }) => code `${external('provideDesignAngularKit', 'design-angular-kit')}()`);
        return (0, rxjs_1.firstValueFrom)((0, schematics_1.callRule)(rule, host, context).pipe((0, rxjs_1.map)(() => {
            return () => () => { };
        })));
    });
}
//# sourceMappingURL=add-design-angular-kit.js.map