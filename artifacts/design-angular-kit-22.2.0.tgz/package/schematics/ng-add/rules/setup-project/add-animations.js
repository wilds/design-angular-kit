"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.addAnimations = addAnimations;
const schematics_1 = require("@angular-devkit/schematics");
function addAnimations() {
    //this dependency should be provided at application level instead of lib level. ref: provideDesignAngularKit
    //provideAnimationsAsync(),
    return (host, context) => (0, schematics_1.callRule)((0, schematics_1.noop)(), host, context);
}
//# sourceMappingURL=add-animations.js.map