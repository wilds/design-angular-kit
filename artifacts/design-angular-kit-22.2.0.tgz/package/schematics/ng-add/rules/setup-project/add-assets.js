"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.addAssets = addAssets;
const utility_1 = require("@schematics/angular/utility");
const angular_json_helper_1 = require("./angular-json-helper");
const exceptions_1 = require("./exceptions");
const ASSETS_CONFIG = {
    glob: '**/*',
    input: './node_modules/bootstrap-italia/',
    output: '/bootstrap-italia/',
};
function addAssets(options) {
    return (host) => __awaiter(this, void 0, void 0, function* () {
        const workspace = yield (0, utility_1.readWorkspace)(host);
        const projectName = options.project || workspace.extensions.defaultProject.toString();
        const project = workspace.projects.get(projectName);
        if (!project) {
            throw new exceptions_1.NoProjectException(projectName);
        }
        addAssetsToAngularJson(project);
        yield (0, utility_1.writeWorkspace)(host, workspace);
    });
}
function addAssetsToAngularJson(project) {
    const targetOptions = (0, angular_json_helper_1.getProjectTargetOptions)(project, 'build');
    const assets = targetOptions.assets;
    if (!assets) {
        targetOptions.assets = [ASSETS_CONFIG];
    }
    else {
        const existingAssets = assets.map(s => (typeof s === 'string' ? s : s['input']));
        for (const [, input] of existingAssets.entries()) {
            if (input === ASSETS_CONFIG.input) {
                return;
            }
        }
        assets.push(ASSETS_CONFIG);
    }
}
//# sourceMappingURL=add-assets.js.map