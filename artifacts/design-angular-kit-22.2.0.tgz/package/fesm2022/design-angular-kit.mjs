import * as i0 from "@angular/core";
import { ChangeDetectionStrategy, ChangeDetectorRef, Component, ContentChildren, DOCUMENT, DestroyRef, Directive, ElementRef, EventEmitter, HostAttributeToken, HostBinding, HostListener, Injectable, InjectionToken, Injector, Input, NgModule, NgZone, Output, Pipe, Renderer2, TemplateRef, ViewChild, ViewChildren, ViewEncapsulation, afterNextRender, booleanAttribute, inject, makeEnvironmentProviders, provideAppInitializer, signal } from "@angular/core";
import { AsyncPipe, DatePipe, Location, LowerCasePipe, NgClass, NgOptimizedImage, NgTemplateOutlet, TitleCasePipe, ViewportScroller } from "@angular/common";
import { takeUntilDestroyed, toObservable } from "@angular/core/rxjs-interop";
import { AsyncSubject, BehaviorSubject, Observable, Subject, combineLatest, debounceTime, delay, distinctUntilChanged, filter, forkJoin, map, merge, of, shareReplay, skip, startWith, switchMap, take, takeWhile, tap, timer, withLatestFrom } from "rxjs";
import videojs from "video.js";
import * as i1$1 from "@ngx-translate/core";
import { TranslateModule, TranslatePipe, TranslateService, provideTranslateService } from "@ngx-translate/core";
import { initYoutubePlugin } from "bootstrap-italia/dist/plugins/util/youtube-video.js";
import { Alert, BackToTop, Carousel, Collapse, Dropdown, HeaderSticky, InputPassword, Modal, NavBarCollapsible, Notification, Popover, ProgressDonut, SelectAutocomplete, Tab, Tooltip, loadFonts } from "bootstrap-italia";
import { ActivatedRoute, NavigationEnd, Router, RouterLink, RouterLinkActive, RouterLinkWithHref, Scroll } from "@angular/router";
import { animate, style, transition, trigger } from "@angular/animations";
import * as i1 from "@angular/forms";
import { ControlContainer, FormControl, FormControlName, FormGroup, NgControl, NgModel, ReactiveFormsModule, Validators } from "@angular/forms";
import { DomSanitizer } from "@angular/platform-browser";
import { provideHttpClient, withXhr } from "@angular/common/http";
import { provideAnimationsAsync } from "@angular/platform-browser/animations/async";
import { provideTranslateHttpLoader } from "@ngx-translate/http-loader";
import { map as map$1 } from "rxjs/operators";
var ItAbstractComponent = class ItAbstractComponent {
	static {
		this.instances = 0;
	}
	constructor() {
		this.id = this.getDefaultId();
		this._renderer = inject(Renderer2);
		this._elementRef = inject(ElementRef);
		this._changeDetectorRef = inject(ChangeDetectorRef);
		this.valueChanges = new EventEmitter();
	}
	ngAfterViewInit() {
		this._renderer.removeAttribute(this._elementRef.nativeElement, "id");
	}
	ngOnChanges(changes) {
		this.valueChanges.next();
	}
	getDefaultId() {
		return `${this.constructor.name.replace("Component", "").replace(/[A-Z]+(?![a-z])|[A-Z]/g, ($, ofs) => (ofs ? "-" : "") + $.toLowerCase())}-${ItAbstractComponent.instances++}`;
	}
	static {
		this.ɵfac = i0.ɵɵngDeclareFactory({
			minVersion: "12.0.0",
			version: "22.2.1",
			ngImport: i0,
			type: ItAbstractComponent,
			deps: [],
			target: i0.ɵɵFactoryTarget.Component
		});
	}
	static {
		this.ɵcmp = i0.ɵɵngDeclareComponent({
			minVersion: "14.0.0",
			version: "22.2.1",
			type: ItAbstractComponent,
			isStandalone: false,
			selector: "ng-component",
			inputs: { id: "id" },
			outputs: { valueChanges: "valueChanges" },
			usesOnChanges: true,
			ngImport: i0,
			template: "",
			isInline: true,
			changeDetection: i0.ChangeDetectionStrategy.Eager
		});
	}
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.1",
	ngImport: i0,
	type: ItAbstractComponent,
	decorators: [{
		type: Component,
		args: [{
			template: "",
			changeDetection: ChangeDetectionStrategy.Eager,
			standalone: false
		}]
	}],
	ctorParameters: () => [],
	propDecorators: {
		id: [{ type: Input }],
		valueChanges: [{ type: Output }]
	}
});
var VideoPlayerI18nService = class VideoPlayerI18nService {
	#translate = inject(TranslateService);
	init(player, destroyRef) {
		this.#translate.onLangChange.pipe(takeUntilDestroyed(destroyRef), tap({ next: (e) => {
			const language = e.lang;
			videojs.addLanguage(language, this.getTranslations());
			player.language(language);
		} })).subscribe((x) => {
			console.log("onLangChange", x);
		});
	}
	getLanguage() {
		const language = this.#translate.currentLang ?? "it";
		return {
			languages: { [language]: mapToVideoJsTranslation(this.#translate.instant("it.video-player")) },
			language
		};
	}
	getTranslations() {
		return mapToVideoJsTranslation(this.#translate.instant("it.video-player"));
	}
	static {
		this.ɵfac = i0.ɵɵngDeclareFactory({
			minVersion: "12.0.0",
			version: "22.2.1",
			ngImport: i0,
			type: VideoPlayerI18nService,
			deps: [],
			target: i0.ɵɵFactoryTarget.Injectable
		});
	}
	static {
		this.ɵprov = i0.ɵɵngDeclareInjectable({
			minVersion: "12.0.0",
			version: "22.2.1",
			ngImport: i0,
			type: VideoPlayerI18nService,
			providedIn: "root"
		});
	}
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.1",
	ngImport: i0,
	type: VideoPlayerI18nService,
	decorators: [{
		type: Injectable,
		args: [{ providedIn: "root" }]
	}]
});
function mapToVideoJsTranslation(translations) {
	return {
		"Audio Player": translations["audio-player"],
		"Video Player": translations["video-player"],
		Play: translations.play,
		Pause: translations.pause,
		Replay: translations.replay,
		"Current Time": translations["current-time"],
		Duration: translations.duration,
		"Remaining Time": translations["remaining-time"],
		"Stream Type": translations["stream-type"],
		LIVE: translations.live,
		Loaded: translations.loaded,
		Progress: translations.progress,
		"Progress Bar": translations["progress-bar"],
		"progress bar timing: currentTime={1} duration={2}": translations["progress-bar-timing:-currenttime={1}-duration={2}"],
		Fullscreen: translations.fullscreen,
		"Exit Fullscreen": translations["exit-fullscreen"],
		Mute: translations.mute,
		Unmute: translations.unmute,
		"Playback Rate": translations["playback-rate"],
		Subtitles: translations.subtitles,
		"subtitles off": translations["subtitles-off"],
		Captions: translations.captions,
		"captions off": translations["captions-off"],
		Chapters: translations.chapters,
		Descriptions: translations.descriptions,
		"descriptions off": translations["descriptions-off"],
		"Audio Track": translations["audio-track"],
		"Volume Level": translations["volume-level"],
		"You aborted the media playback": translations["you-aborted-the-media-playback"],
		"A network error caused the media download to fail part-way.": translations["a-network-error-caused-the-media-download-to-fail-part-way."],
		"The media could not be loaded, either because the server or network failed or because the format is not supported.": translations["the-media-could-not-be-loaded,-either-because-the-server-or-network-failed-or-because-the-format-is-not-supported."],
		"The media playback was aborted due to a corruption problem or because the media used features your browser did not support.": translations["the-media-playback-was-aborted-due-to-a-corruption-problem-or-because-the-media-used-features-your-browser-did-not-support."],
		"No compatible source was found for this media.": translations["no-compatible-source-was-found-for-this-media."],
		"The media is encrypted and we do not have the keys to decrypt it.": translations["the-media-is-encrypted-and-we-do-not-have-the-keys-to-decrypt-it."],
		"Play Video": translations["play-video"],
		Close: translations.close,
		"Close Modal Dialog": translations["close-modal-dialog"],
		"Modal Window": translations["modal-window"],
		"This is a modal window": translations["this-is-a-modal-window"],
		"This modal can be closed by pressing the Escape key or activating the close button.": translations["this-modal-can-be-closed-by-pressing-the-escape-key-or-activating-the-close-button."],
		", opens captions settings dialog": translations[",-opens-captions-settings-dialog"],
		", opens subtitles settings dialog": translations[",-opens-subtitles-settings-dialog"],
		", opens descriptions settings dialog": translations[",-opens-descriptions-settings-dialog"],
		", selected": translations[",-selected"],
		"captions settings": translations["captions-settings"],
		"subtitles settings": translations["subtitles-settings"],
		"descriptions settings": translations["descriptions-settings"],
		Text: translations.text,
		White: translations.white,
		Black: translations.black,
		Red: translations.red,
		Green: translations.green,
		Blue: translations.blue,
		Yellow: translations.yellow,
		Magenta: translations.magenta,
		Cyan: translations.cyan,
		Background: translations.background,
		Window: translations.window,
		Transparent: translations.transparent,
		"Semi-Transparent": translations["semi-transparent"],
		Opaque: translations.opaque,
		"Font Size": translations["font-size"],
		"Text Edge Style": translations["text-edge-style"],
		None: translations.none,
		Uniform: translations.uniform,
		"Drop shadow": translations["drop-shadow"],
		"Font Family": translations["font-family"],
		"Proportional Sans-Serif": translations["proportional-sans-serif"],
		"Monospace Sans-Serif": translations["monospace-sans-serif"],
		"Proportional Serif": translations["proportional-serif"],
		"Monospace Serif": translations["monospace-serif"],
		"Small Caps": translations["small-caps"],
		Reset: translations.reset,
		"restore all settings to the default values": translations["restore-all-settings-to-the-default-values"],
		Done: translations.done,
		"Caption Settings Dialog": translations["caption-settings-dialog"],
		"Beginning of dialog window. Escape will cancel and close the window.": translations["beginning-of-dialog-window.-escape-will-cancel-and-close-the-window."],
		"End of dialog window.": translations["end-of-dialog-window."],
		"{1} is loading.": translations["{1}-is-loading."],
		"Exit Picture-in-Picture": translations["exit-picture-in-picture"],
		"Picture-in-Picture": translations["picture-in-picture"],
		Color: translations.color,
		Opacity: translations.opacity,
		"Text Background": translations["text-background"],
		"Caption Area Background": translations["caption-area-background"],
		"Skip forward {1} seconds": translations["skip-forward-{1}-seconds"],
		"Skip backward {1} seconds": translations["skip-backward-{1}-seconds"]
	};
}
const hasYoutubeVideo = (options) => options.source?.type === "video/youtube";
var VideoPlayerConfigService = class VideoPlayerConfigService {
	#languageService = inject(VideoPlayerI18nService);
	async configureTech({ tech }) {
		if (tech === "youtube") initYoutubePlugin(videojs);
	}
	mergeConfig(o) {
		const options = o;
		const captions = options.captions ? options.captions.map((c) => ({
			...c,
			kind: "captions"
		})) : [];
		const chapters = options.chapters ? options.chapters.map((c) => ({
			...c,
			kind: "chapters"
		})) : [];
		const isYoutubeVideo = hasYoutubeVideo(options);
		const DEFAULT_CONFIG = this.#languageService.getLanguage();
		const techOrder = [isYoutubeVideo ? "youtube" : "html5"];
		const preload = options.preload ?? "metadata";
		const config = {
			...DEFAULT_CONFIG,
			...options,
			preload,
			techOrder,
			tracks: [...captions, ...chapters],
			tech: "html5"
		};
		return isYoutubeVideo ? {
			...config,
			sources: [o.source],
			tech: "youtube",
			youtube: {
				ytControls: 2,
				rel: 0,
				fs: 0,
				modestbranding: 1
			}
		} : config;
	}
	static {
		this.ɵfac = i0.ɵɵngDeclareFactory({
			minVersion: "12.0.0",
			version: "22.2.1",
			ngImport: i0,
			type: VideoPlayerConfigService,
			deps: [],
			target: i0.ɵɵFactoryTarget.Injectable
		});
	}
	static {
		this.ɵprov = i0.ɵɵngDeclareInjectable({
			minVersion: "12.0.0",
			version: "22.2.1",
			ngImport: i0,
			type: VideoPlayerConfigService,
			providedIn: "root"
		});
	}
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.1",
	ngImport: i0,
	type: VideoPlayerConfigService,
	decorators: [{
		type: Injectable,
		args: [{ providedIn: "root" }]
	}]
});
const preferencesMap = { ck3: {} };
const STORAGE_KEY = "bs-ck3";
const rememberChoice = (service, remember) => {
	preferencesMap.ck3[service] = remember;
	localStorage.setItem(STORAGE_KEY, JSON.stringify(preferencesMap.ck3));
};
const isChoiceRemembered = (service) => {
	preferencesMap.ck3 = JSON.parse(localStorage.getItem(STORAGE_KEY) || "{}");
	return Boolean(preferencesMap.ck3[service]) || false;
};
const clearAllRememberedChoices = () => {
	localStorage.removeItem(STORAGE_KEY);
};
const cookies = {
	rememberChoice,
	isChoiceRemembered,
	clearAllRememberedChoices
};
var ViewType;
(function(ViewType) {
	ViewType["Default"] = "DEFAULT";
	ViewType["Overlay"] = "OVERLAY";
})(ViewType || (ViewType = {}));
var ItVideoPlayerComponent = class ItVideoPlayerComponent extends ItAbstractComponent {
	#destroyRef;
	constructor() {
		super();
		this.config = inject(VideoPlayerConfigService);
		this.player = null;
		this.viewTypes = ViewType;
		this.viewType = signal(void 0, ...ngDevMode ? [{ debugName: "viewType" }] : /* istanbul ignore next */ []);
		this.cookieAccepted = signal(false, ...ngDevMode ? [{ debugName: "cookieAccepted" }] : /* istanbul ignore next */ []);
		this.i18nService = inject(VideoPlayerI18nService);
		this.#destroyRef = inject(DestroyRef);
		this.ngZone = inject(NgZone);
		this.injector = inject(Injector);
		afterNextRender(() => {
			if (this.viewType() === ViewType.Overlay && cookies.isChoiceRemembered("youtube.com")) this.hideOverlay();
		});
		this.#destroyRef.onDestroy(() => this.player?.dispose());
	}
	async ngOnInit() {
		const config = this.config.mergeConfig(this.options);
		this.setViewType(config);
		await this.ngZone.runOutsideAngular(() => this.config.configureTech(config));
		if (!this.videoPlayerRef) {
			toObservable(this.cookieAccepted, { injector: this.injector }).pipe(delay(0)).subscribe((value) => {
				if (value && !this.player) this.initVideoPlayer();
			});
			return;
		}
		this.initVideoPlayer();
	}
	acceptCookieHandler() {
		this.rememberHandler();
		this.hideOverlay();
		this.cookieAccepted.set(true);
	}
	initVideoPlayer() {
		const config = this.config.mergeConfig(this.options);
		this.setVideoAttributes(config);
		this.setVideoPlayer();
	}
	setVideoPlayer() {
		const config = this.config.mergeConfig(this.options);
		const onPlayerReadyCb = () => {
			if (!this.player) return;
			this.i18nService.init(this.player, this.#destroyRef);
		};
		const element = this.videoPlayerRef?.nativeElement;
		if (!element) throw Error("videoPlayerRef is undefined");
		this.player = this.ngZone.runOutsideAngular(() => videojs(element, config, onPlayerReadyCb));
	}
	setViewType(config) {
		this.viewType.set(config.tech === "youtube" ? ViewType.Overlay : ViewType.Default);
		this.cookieAccepted.set(this.viewType() === ViewType.Overlay && cookies.isChoiceRemembered("youtube.com"));
	}
	hideOverlay() {
		if (!this.acceptOverlayableRef) return;
		const classes = ["show"];
		this.acceptOverlayableRef.nativeElement.classList.remove(...classes);
		if (!this.acceptOveralyRef) return;
		this.acceptOveralyRef.nativeElement.classList.remove(...classes);
		this.acceptOveralyRef.nativeElement.setAttribute("aria-hidden", "true");
	}
	rememberHandler() {
		if (!this.chrRememberRef) return;
		const remember = this.chrRememberRef.nativeElement.checked;
		cookies.rememberChoice("youtube.com", remember);
	}
	setVideoAttributes(options) {
		if (!this.videoPlayerRef) return;
		const v = this.videoPlayerRef.nativeElement;
		const { autoplay, controls, loop, muted, poster, fluid } = options;
		if (autoplay) v.setAttribute("autoplay", autoplay.toString());
		if (controls) v.setAttribute("controls", "");
		if (loop) v.setAttribute("loop", "");
		if (muted) v.setAttribute("muted", "");
		if (poster) v.setAttribute("poster", poster);
		if (fluid) v.setAttribute("fluid", "");
		v.setAttribute("preload", "none");
		v.setAttribute("playsinline", "");
	}
	static {
		this.ɵfac = i0.ɵɵngDeclareFactory({
			minVersion: "12.0.0",
			version: "22.2.1",
			ngImport: i0,
			type: ItVideoPlayerComponent,
			deps: [],
			target: i0.ɵɵFactoryTarget.Component
		});
	}
	static {
		this.ɵcmp = i0.ɵɵngDeclareComponent({
			minVersion: "17.0.0",
			version: "22.2.1",
			type: ItVideoPlayerComponent,
			isStandalone: true,
			selector: "it-video-player",
			inputs: { options: "options" },
			viewQueries: [
				{
					propertyName: "videoPlayerRef",
					first: true,
					predicate: ["videoPlayer"],
					descendants: true
				},
				{
					propertyName: "acceptOveralyRef",
					first: true,
					predicate: ["acceptOveraly"],
					descendants: true
				},
				{
					propertyName: "acceptOverlayableRef",
					first: true,
					predicate: ["acceptOverlayable"],
					descendants: true
				},
				{
					propertyName: "chrRememberRef",
					first: true,
					predicate: ["chkRemember"],
					descendants: true
				}
			],
			usesInheritance: true,
			ngImport: i0,
			template: `@switch (viewType()) {
      @case (viewTypes.Default) {
        <div class="row">
          <ng-container *ngTemplateOutlet="videoTemplate"></ng-container>
          <ng-container *ngTemplateOutlet="transcriptionTemplate"></ng-container>
        </div>
      }
      @case (viewTypes.Overlay) {
        <div #acceptOverlayable class="acceptoverlayable show">
          <div #acceptOveraly class="acceptoverlay acceptoverlay-primary fade show">
            <div class="acceptoverlay-inner">
              <div class="acceptoverlay-icon">
                <svg class="icon icon-xl"><use href="/bootstrap-italia/dist/svg/sprites.svg#it-video"></use></svg>
              </div>
              <p>
                Accetta i cookie di YouTube per vedere il video. Puoi gestire le preferenze nella
                <a href="#" class="text-white">cookie policy</a>.
              </p>
              <div class="acceptoverlay-buttons bg-dark">
                <button type="button" class="btn btn-primary" (click)="acceptCookieHandler()">Accetta</button>
                <div class="form-check">
                  <input id="chk-remember{{ id }}" type="checkbox" #chkRemember />
                  <label for="chk-remember{{ id }}">Ricorda per tutti i video</label>
                </div>
              </div>
            </div>
          </div>
          @if (cookieAccepted()) {
            <div>
              <ng-container *ngTemplateOutlet="videoTemplate"></ng-container>
              <ng-container *ngTemplateOutlet="transcriptionTemplate"></ng-container>
            </div>
          }
        </div>
      }
      @default {
        <h1>No video provider</h1>
      }
    }
    <ng-template #videoTemplate>
      <div>
        <video #videoPlayer class="video-js vjs-theme-bootstrap-italia vjs-fluid vjs-big-play-centered"></video>
      </div>
    </ng-template>

    <ng-template #transcriptionTemplate>
      <div class="vjs-transcription accordion">
        <div class="accordion-item">
          <h2 class="accordion-header " id="transcription-{{ id }}-head">
            <button
              class="accordion-button collapsed"
              type="button"
              data-bs-toggle="collapse"
              [attr.data-bs-target]="'#transcription-' + id"
              [attr.aria-controls]="'transcription-' + id"
              aria-expanded="true">
              <ng-content select="[transcriptionTitle]">Trascrizione</ng-content>
            </button>
          </h2>
          <div
            id="transcription-{{ id }}"
            class="accordion-collapse collapse"
            role="region"
            [attr.aria-labelledby]="'transcription-' + id + '-head'">
            <div class="accordion-body">
              <ng-content select="[transcriptionText]">-</ng-content>
            </div>
          </div>
        </div>
      </div>
    </ng-template> `,
			isInline: true,
			dependencies: [{
				kind: "directive",
				type: NgTemplateOutlet,
				selector: "[ngTemplateOutlet]",
				inputs: [
					"ngTemplateOutletContext",
					"ngTemplateOutlet",
					"ngTemplateOutletInjector"
				]
			}],
			changeDetection: i0.ChangeDetectionStrategy.OnPush,
			encapsulation: i0.ViewEncapsulation.None
		});
	}
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.1",
	ngImport: i0,
	type: ItVideoPlayerComponent,
	decorators: [{
		type: Component,
		args: [{
			standalone: true,
			selector: "it-video-player",
			template: `@switch (viewType()) {
      @case (viewTypes.Default) {
        <div class="row">
          <ng-container *ngTemplateOutlet="videoTemplate"></ng-container>
          <ng-container *ngTemplateOutlet="transcriptionTemplate"></ng-container>
        </div>
      }
      @case (viewTypes.Overlay) {
        <div #acceptOverlayable class="acceptoverlayable show">
          <div #acceptOveraly class="acceptoverlay acceptoverlay-primary fade show">
            <div class="acceptoverlay-inner">
              <div class="acceptoverlay-icon">
                <svg class="icon icon-xl"><use href="/bootstrap-italia/dist/svg/sprites.svg#it-video"></use></svg>
              </div>
              <p>
                Accetta i cookie di YouTube per vedere il video. Puoi gestire le preferenze nella
                <a href="#" class="text-white">cookie policy</a>.
              </p>
              <div class="acceptoverlay-buttons bg-dark">
                <button type="button" class="btn btn-primary" (click)="acceptCookieHandler()">Accetta</button>
                <div class="form-check">
                  <input id="chk-remember{{ id }}" type="checkbox" #chkRemember />
                  <label for="chk-remember{{ id }}">Ricorda per tutti i video</label>
                </div>
              </div>
            </div>
          </div>
          @if (cookieAccepted()) {
            <div>
              <ng-container *ngTemplateOutlet="videoTemplate"></ng-container>
              <ng-container *ngTemplateOutlet="transcriptionTemplate"></ng-container>
            </div>
          }
        </div>
      }
      @default {
        <h1>No video provider</h1>
      }
    }
    <ng-template #videoTemplate>
      <div>
        <video #videoPlayer class="video-js vjs-theme-bootstrap-italia vjs-fluid vjs-big-play-centered"></video>
      </div>
    </ng-template>

    <ng-template #transcriptionTemplate>
      <div class="vjs-transcription accordion">
        <div class="accordion-item">
          <h2 class="accordion-header " id="transcription-{{ id }}-head">
            <button
              class="accordion-button collapsed"
              type="button"
              data-bs-toggle="collapse"
              [attr.data-bs-target]="'#transcription-' + id"
              [attr.aria-controls]="'transcription-' + id"
              aria-expanded="true">
              <ng-content select="[transcriptionTitle]">Trascrizione</ng-content>
            </button>
          </h2>
          <div
            id="transcription-{{ id }}"
            class="accordion-collapse collapse"
            role="region"
            [attr.aria-labelledby]="'transcription-' + id + '-head'">
            <div class="accordion-body">
              <ng-content select="[transcriptionText]">-</ng-content>
            </div>
          </div>
        </div>
      </div>
    </ng-template> `,
			imports: [NgTemplateOutlet],
			encapsulation: ViewEncapsulation.None,
			changeDetection: ChangeDetectionStrategy.OnPush
		}]
	}],
	ctorParameters: () => [],
	propDecorators: {
		options: [{ type: Input }],
		videoPlayerRef: [{
			type: ViewChild,
			args: ["videoPlayer", { static: false }]
		}],
		acceptOveralyRef: [{
			type: ViewChild,
			args: ["acceptOveraly", { static: false }]
		}],
		acceptOverlayableRef: [{
			type: ViewChild,
			args: ["acceptOverlayable", { static: false }]
		}],
		chrRememberRef: [{
			type: ViewChild,
			args: ["chkRemember", { static: false }]
		}]
	}
});
function inputToBoolean(value) {
	return booleanAttribute(value);
}
var ItCollapseComponent = class ItCollapseComponent extends ItAbstractComponent {
	constructor() {
		super(...arguments);
		this.class = "";
		this.showEvent = new EventEmitter();
		this.shownEvent = new EventEmitter();
		this.hideEvent = new EventEmitter();
		this.hiddenEvent = new EventEmitter();
		this.open = false;
	}
	ngAfterViewInit() {
		super.ngAfterViewInit();
		this._renderer.removeAttribute(this._elementRef.nativeElement, "class");
		if (this.collapseDiv) {
			const element = this.collapseDiv.nativeElement;
			this.collapse = Collapse.getOrCreateInstance(element, { toggle: this.opened });
			element.addEventListener("show.bs.collapse", (event) => {
				this.open = true;
				this.showEvent.emit(event);
			});
			element.addEventListener("shown.bs.collapse", (event) => {
				this.open = true;
				this.shownEvent.emit(event);
			});
			element.addEventListener("hide.bs.collapse", (event) => {
				this.open = false;
				this.hideEvent.emit(event);
			});
			element.addEventListener("hidden.bs.collapse", (event) => {
				this.open = false;
				this.hiddenEvent.emit(event);
			});
		}
	}
	isOpen() {
		return this.open;
	}
	show() {
		this.collapse?.show();
	}
	hide() {
		this.collapse?.hide();
	}
	toggle() {
		this.collapse?.toggle();
	}
	dispose() {
		this.collapse?.dispose();
	}
	static {
		this.ɵfac = i0.ɵɵngDeclareFactory({
			minVersion: "12.0.0",
			version: "22.2.1",
			ngImport: i0,
			type: ItCollapseComponent,
			deps: null,
			target: i0.ɵɵFactoryTarget.Component
		});
	}
	static {
		this.ɵcmp = i0.ɵɵngDeclareComponent({
			minVersion: "16.1.0",
			version: "22.2.1",
			type: ItCollapseComponent,
			isStandalone: true,
			selector: "it-collapse",
			inputs: {
				multi: [
					"multi",
					"multi",
					inputToBoolean
				],
				opened: [
					"opened",
					"opened",
					inputToBoolean
				],
				class: "class"
			},
			outputs: {
				showEvent: "showEvent",
				shownEvent: "shownEvent",
				hideEvent: "hideEvent",
				hiddenEvent: "hiddenEvent"
			},
			viewQueries: [{
				propertyName: "collapseDiv",
				first: true,
				predicate: ["collapse"],
				descendants: true
			}],
			exportAs: ["itCollapse"],
			usesInheritance: true,
			ngImport: i0,
			template: "<div [id]=\"id\" class=\"collapse {{ class }}\" [class.multi-collapse]=\"multi\" #collapse>\r\n  <ng-content></ng-content>\r\n</div>\r\n",
			changeDetection: i0.ChangeDetectionStrategy.OnPush
		});
	}
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.1",
	ngImport: i0,
	type: ItCollapseComponent,
	decorators: [{
		type: Component,
		args: [{
			selector: "it-collapse",
			exportAs: "itCollapse",
			changeDetection: ChangeDetectionStrategy.OnPush,
			imports: [],
			template: "<div [id]=\"id\" class=\"collapse {{ class }}\" [class.multi-collapse]=\"multi\" #collapse>\r\n  <ng-content></ng-content>\r\n</div>\r\n"
		}]
	}],
	propDecorators: {
		multi: [{
			type: Input,
			args: [{ transform: inputToBoolean }]
		}],
		opened: [{
			type: Input,
			args: [{ transform: inputToBoolean }]
		}],
		class: [{ type: Input }],
		showEvent: [{ type: Output }],
		shownEvent: [{ type: Output }],
		hideEvent: [{ type: Output }],
		hiddenEvent: [{ type: Output }],
		collapseDiv: [{
			type: ViewChild,
			args: ["collapse"]
		}]
	}
});
var ItAccordionComponent = class ItAccordionComponent extends ItCollapseComponent {
	constructor() {
		super(...arguments);
		this.isCollapsed = true;
	}
	ngAfterViewInit() {
		super.ngAfterViewInit();
		this._renderer.removeAttribute(this._elementRef.nativeElement, "title");
		this.isCollapsed = !this.opened;
		this.hideEvent.subscribe(() => {
			this.isCollapsed = true;
			this._changeDetectorRef.detectChanges();
		});
		this.showEvent.subscribe(() => {
			this.isCollapsed = false;
			this._changeDetectorRef.detectChanges();
		});
	}
	static {
		this.ɵfac = i0.ɵɵngDeclareFactory({
			minVersion: "12.0.0",
			version: "22.2.1",
			ngImport: i0,
			type: ItAccordionComponent,
			deps: null,
			target: i0.ɵɵFactoryTarget.Component
		});
	}
	static {
		this.ɵcmp = i0.ɵɵngDeclareComponent({
			minVersion: "14.0.0",
			version: "22.2.1",
			type: ItAccordionComponent,
			isStandalone: true,
			selector: "it-accordion",
			inputs: { title: "title" },
			viewQueries: [{
				propertyName: "collapseDiv",
				first: true,
				predicate: ["collapse"],
				descendants: true
			}],
			exportAs: ["itAccordion"],
			usesInheritance: true,
			ngImport: i0,
			template: "<div class=\"accordion\">\r\n  <div class=\"accordion-item\">\r\n    <h2 class=\"accordion-header\" id=\"collapse-{{ id }}-heading\">\r\n      <button\r\n        class=\"accordion-button\"\r\n        type=\"button\"\r\n        data-bs-toggle=\"collapse\"\r\n        [class.collapsed]=\"isCollapsed\"\r\n        [attr.data-bs-target]=\"'#collapse-' + id\"\r\n        [attr.aria-controls]=\"'collapse-' + id\"\r\n        [attr.aria-expanded]=\"opened ? 'true' : 'false'\">\r\n        {{ title }}\r\n      </button>\r\n    </h2>\r\n\r\n    <div\r\n      #collapse\r\n      id=\"collapse-{{ id }}\"\r\n      role=\"region\"\r\n      class=\"accordion-collapse collapse {{ class }}\"\r\n      [attr.aria-labelledby]=\"'collapse-' + id + '-heading'\">\r\n      <div class=\"accordion-body\">\r\n        <ng-content></ng-content>\r\n      </div>\r\n    </div>\r\n  </div>\r\n</div>\r\n",
			changeDetection: i0.ChangeDetectionStrategy.OnPush
		});
	}
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.1",
	ngImport: i0,
	type: ItAccordionComponent,
	decorators: [{
		type: Component,
		args: [{
			selector: "it-accordion",
			exportAs: "itAccordion",
			changeDetection: ChangeDetectionStrategy.OnPush,
			imports: [],
			template: "<div class=\"accordion\">\r\n  <div class=\"accordion-item\">\r\n    <h2 class=\"accordion-header\" id=\"collapse-{{ id }}-heading\">\r\n      <button\r\n        class=\"accordion-button\"\r\n        type=\"button\"\r\n        data-bs-toggle=\"collapse\"\r\n        [class.collapsed]=\"isCollapsed\"\r\n        [attr.data-bs-target]=\"'#collapse-' + id\"\r\n        [attr.aria-controls]=\"'collapse-' + id\"\r\n        [attr.aria-expanded]=\"opened ? 'true' : 'false'\">\r\n        {{ title }}\r\n      </button>\r\n    </h2>\r\n\r\n    <div\r\n      #collapse\r\n      id=\"collapse-{{ id }}\"\r\n      role=\"region\"\r\n      class=\"accordion-collapse collapse {{ class }}\"\r\n      [attr.aria-labelledby]=\"'collapse-' + id + '-heading'\">\r\n      <div class=\"accordion-body\">\r\n        <ng-content></ng-content>\r\n      </div>\r\n    </div>\r\n  </div>\r\n</div>\r\n"
		}]
	}],
	propDecorators: {
		title: [{
			type: Input,
			args: [{ required: true }]
		}],
		collapseDiv: [{
			type: ViewChild,
			args: ["collapse"]
		}]
	}
});
const IT_ASSET_BASE_PATH = new InjectionToken("it-asset-base-path");
var ItIconComponent = class ItIconComponent {
	get iconHref() {
		return `${this.assetBasePath}/dist/svg/sprites.svg#it-${this.name}`;
	}
	get iconClass() {
		let iconClass = "icon";
		if (this.size) iconClass += ` icon-${this.size}`;
		if (this.color) iconClass += ` icon-${this.color}`;
		else iconClass += " icon-current-color";
		if (this.padded) iconClass += ` icon-padded`;
		if (this.svgClass) iconClass += ` ${this.svgClass}`;
		return iconClass;
	}
	get isAriaHidden() {
		return this.labelWaria == void 0 && this.title == void 0;
	}
	get role() {
		return this.labelWaria == void 0 && this.title == void 0 ? null : "img";
	}
	constructor() {
		this.assetBasePath = inject(IT_ASSET_BASE_PATH);
	}
	static {
		this.ɵfac = i0.ɵɵngDeclareFactory({
			minVersion: "12.0.0",
			version: "22.2.1",
			ngImport: i0,
			type: ItIconComponent,
			deps: [],
			target: i0.ɵɵFactoryTarget.Component
		});
	}
	static {
		this.ɵcmp = i0.ɵɵngDeclareComponent({
			minVersion: "17.0.0",
			version: "22.2.1",
			type: ItIconComponent,
			isStandalone: true,
			selector: "it-icon",
			inputs: {
				name: "name",
				size: "size",
				color: "color",
				padded: [
					"padded",
					"padded",
					inputToBoolean
				],
				svgClass: "svgClass",
				title: "title",
				labelWaria: "labelWaria"
			},
			ngImport: i0,
			template: "<svg [attr.role]=\"role\" [attr.aria-hidden]=\"isAriaHidden\" [attr.aria-label]=\"title || labelWaria\" [class]=\"iconClass\">\r\n  @if (title || labelWaria) {\r\n    <title>{{ title || labelWaria }}</title>\r\n  }\r\n  <use [attr.href]=\"iconHref\" [attr.xlink:href]=\"iconHref\"></use>\r\n</svg>\r\n",
			styles: [":host{display:contents}.icon-current-color{fill:currentColor}\n"],
			changeDetection: i0.ChangeDetectionStrategy.OnPush
		});
	}
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.1",
	ngImport: i0,
	type: ItIconComponent,
	decorators: [{
		type: Component,
		args: [{
			selector: "it-icon",
			changeDetection: ChangeDetectionStrategy.OnPush,
			imports: [],
			template: "<svg [attr.role]=\"role\" [attr.aria-hidden]=\"isAriaHidden\" [attr.aria-label]=\"title || labelWaria\" [class]=\"iconClass\">\r\n  @if (title || labelWaria) {\r\n    <title>{{ title || labelWaria }}</title>\r\n  }\r\n  <use [attr.href]=\"iconHref\" [attr.xlink:href]=\"iconHref\"></use>\r\n</svg>\r\n",
			styles: [":host{display:contents}.icon-current-color{fill:currentColor}\n"]
		}]
	}],
	ctorParameters: () => [],
	propDecorators: {
		name: [{
			type: Input,
			args: [{ required: true }]
		}],
		size: [{ type: Input }],
		color: [{ type: Input }],
		padded: [{
			type: Input,
			args: [{ transform: inputToBoolean }]
		}],
		svgClass: [{ type: Input }],
		title: [{ type: Input }],
		labelWaria: [{ type: Input }]
	}
});
var ItAlertComponent = class ItAlertComponent extends ItAbstractComponent {
	constructor() {
		super(...arguments);
		this.color = "info";
		this.closeEvent = new EventEmitter();
		this.closedEvent = new EventEmitter();
	}
	ngAfterViewInit() {
		super.ngAfterViewInit();
		if (this.headingEl?.nativeElement) {
			const el = this.headingEl.nativeElement;
			if (el.textContent?.trim() === "") el.hidden = true;
		}
		if (this.alertElement) {
			const element = this.alertElement.nativeElement;
			this.alert = Alert.getOrCreateInstance(element);
			element.addEventListener("close.bs.alert", (event) => this.closeEvent.emit(event));
			element.addEventListener("closed.bs.alert", (event) => this.closedEvent.emit(event));
		}
	}
	close() {
		this.alert?.close();
	}
	dispose() {
		this.alert?.dispose();
	}
	static {
		this.ɵfac = i0.ɵɵngDeclareFactory({
			minVersion: "12.0.0",
			version: "22.2.1",
			ngImport: i0,
			type: ItAlertComponent,
			deps: null,
			target: i0.ɵɵFactoryTarget.Component
		});
	}
	static {
		this.ɵcmp = i0.ɵɵngDeclareComponent({
			minVersion: "17.0.0",
			version: "22.2.1",
			type: ItAlertComponent,
			isStandalone: true,
			selector: "it-alert",
			inputs: {
				color: "color",
				dismissible: [
					"dismissible",
					"dismissible",
					inputToBoolean
				]
			},
			outputs: {
				closeEvent: "closeEvent",
				closedEvent: "closedEvent"
			},
			viewQueries: [{
				propertyName: "alertElement",
				first: true,
				predicate: ["alertElement"],
				descendants: true
			}, {
				propertyName: "headingEl",
				first: true,
				predicate: ["headingEl"],
				descendants: true
			}],
			exportAs: ["itAlert"],
			usesInheritance: true,
			ngImport: i0,
			template: "<div\r\n  #alertElement\r\n  class=\"alert alert-{{ color }}\"\r\n  [class.alert-dismissible]=\"dismissible\"\r\n  [class.fade]=\"dismissible\"\r\n  [class.show]=\"dismissible\"\r\n  role=\"alert\">\r\n  <h4 #headingEl class=\"alert-heading\">\r\n    <ng-content select=\"[heading]\"></ng-content>\r\n  </h4>\r\n\r\n  <ng-content></ng-content>\r\n\r\n  @if (dismissible) {\r\n    <button type=\"button\" class=\"btn-close\" data-bs-dismiss=\"alert\" [attr.aria-label]=\"'it.core.close-alert' | translate\">\r\n      <it-icon name=\"close\"></it-icon>\r\n    </button>\r\n  }\r\n</div>\r\n",
			styles: [".alert-heading:empty{display:none}\n"],
			dependencies: [
				{
					kind: "ngmodule",
					type: TranslateModule
				},
				{
					kind: "component",
					type: ItIconComponent,
					selector: "it-icon",
					inputs: [
						"name",
						"size",
						"color",
						"padded",
						"svgClass",
						"title",
						"labelWaria"
					]
				},
				{
					kind: "pipe",
					type: i1$1.TranslatePipe,
					name: "translate"
				}
			],
			changeDetection: i0.ChangeDetectionStrategy.OnPush
		});
	}
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.1",
	ngImport: i0,
	type: ItAlertComponent,
	decorators: [{
		type: Component,
		args: [{
			selector: "it-alert",
			exportAs: "itAlert",
			changeDetection: ChangeDetectionStrategy.OnPush,
			imports: [TranslateModule, ItIconComponent],
			template: "<div\r\n  #alertElement\r\n  class=\"alert alert-{{ color }}\"\r\n  [class.alert-dismissible]=\"dismissible\"\r\n  [class.fade]=\"dismissible\"\r\n  [class.show]=\"dismissible\"\r\n  role=\"alert\">\r\n  <h4 #headingEl class=\"alert-heading\">\r\n    <ng-content select=\"[heading]\"></ng-content>\r\n  </h4>\r\n\r\n  <ng-content></ng-content>\r\n\r\n  @if (dismissible) {\r\n    <button type=\"button\" class=\"btn-close\" data-bs-dismiss=\"alert\" [attr.aria-label]=\"'it.core.close-alert' | translate\">\r\n      <it-icon name=\"close\"></it-icon>\r\n    </button>\r\n  }\r\n</div>\r\n",
			styles: [".alert-heading:empty{display:none}\n"]
		}]
	}],
	propDecorators: {
		color: [{ type: Input }],
		dismissible: [{
			type: Input,
			args: [{ transform: inputToBoolean }]
		}],
		closeEvent: [{ type: Output }],
		closedEvent: [{ type: Output }],
		alertElement: [{
			type: ViewChild,
			args: ["alertElement"]
		}],
		headingEl: [{
			type: ViewChild,
			args: ["headingEl"]
		}]
	}
});
var ItLinkComponent = class ItLinkComponent extends ItAbstractComponent {
	constructor() {
		super(...arguments);
		this.class = "";
	}
	ngAfterViewInit() {
		super.ngAfterViewInit();
		this._renderer.removeAttribute(this._elementRef.nativeElement, "class");
	}
	ngOnChanges(changes) {
		super.ngOnChanges(changes);
		if (changes["class"]) this._changeDetectorRef.markForCheck();
	}
	static {
		this.ɵfac = i0.ɵɵngDeclareFactory({
			minVersion: "12.0.0",
			version: "22.2.1",
			ngImport: i0,
			type: ItLinkComponent,
			deps: null,
			target: i0.ɵɵFactoryTarget.Component
		});
	}
	static {
		this.ɵcmp = i0.ɵɵngDeclareComponent({
			minVersion: "17.0.0",
			version: "22.2.1",
			type: ItLinkComponent,
			isStandalone: true,
			selector: "it-link",
			inputs: {
				href: "href",
				externalLink: [
					"externalLink",
					"externalLink",
					inputToBoolean
				],
				disabled: [
					"disabled",
					"disabled",
					inputToBoolean
				],
				class: "class"
			},
			usesInheritance: true,
			usesOnChanges: true,
			ngImport: i0,
			template: "@if (!externalLink) {\r\n  <a [id]=\"id\" [class]=\"class\" [routerLinkActive]=\"'active'\" [routerLink]=\"(disabled ? null : href)!\" style=\"cursor: pointer\">\r\n    <ng-container *ngTemplateOutlet=\"linkContent\"></ng-container>\r\n  </a>\r\n} @else {\r\n  <a [id]=\"id\" [class]=\"class\" [attr.href]=\"disabled ? null : href\" style=\"cursor: pointer\">\r\n    <ng-container *ngTemplateOutlet=\"linkContent\"></ng-container>\r\n  </a>\r\n}\r\n\r\n<ng-template #linkContent>\r\n  <ng-content></ng-content>\r\n</ng-template>\r\n",
			dependencies: [
				{
					kind: "directive",
					type: RouterLink,
					selector: "[routerLink]",
					inputs: [
						"target",
						"queryParams",
						"fragment",
						"queryParamsHandling",
						"state",
						"info",
						"relativeTo",
						"preserveFragment",
						"skipLocationChange",
						"replaceUrl",
						"browserUrl",
						"routerLink"
					]
				},
				{
					kind: "directive",
					type: RouterLinkActive,
					selector: "[routerLinkActive]",
					inputs: [
						"routerLinkActiveOptions",
						"ariaCurrentWhenActive",
						"routerLinkActive"
					],
					outputs: ["isActiveChange"],
					exportAs: ["routerLinkActive"]
				},
				{
					kind: "directive",
					type: NgTemplateOutlet,
					selector: "[ngTemplateOutlet]",
					inputs: [
						"ngTemplateOutletContext",
						"ngTemplateOutlet",
						"ngTemplateOutletInjector"
					]
				}
			],
			changeDetection: i0.ChangeDetectionStrategy.OnPush
		});
	}
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.1",
	ngImport: i0,
	type: ItLinkComponent,
	decorators: [{
		type: Component,
		args: [{
			selector: "it-link",
			changeDetection: ChangeDetectionStrategy.OnPush,
			imports: [
				RouterLink,
				RouterLinkActive,
				NgTemplateOutlet
			],
			template: "@if (!externalLink) {\r\n  <a [id]=\"id\" [class]=\"class\" [routerLinkActive]=\"'active'\" [routerLink]=\"(disabled ? null : href)!\" style=\"cursor: pointer\">\r\n    <ng-container *ngTemplateOutlet=\"linkContent\"></ng-container>\r\n  </a>\r\n} @else {\r\n  <a [id]=\"id\" [class]=\"class\" [attr.href]=\"disabled ? null : href\" style=\"cursor: pointer\">\r\n    <ng-container *ngTemplateOutlet=\"linkContent\"></ng-container>\r\n  </a>\r\n}\r\n\r\n<ng-template #linkContent>\r\n  <ng-content></ng-content>\r\n</ng-template>\r\n"
		}]
	}],
	propDecorators: {
		href: [{ type: Input }],
		externalLink: [{
			type: Input,
			args: [{ transform: inputToBoolean }]
		}],
		disabled: [{
			type: Input,
			args: [{ transform: inputToBoolean }]
		}],
		class: [{ type: Input }]
	}
});
var ItDropdownItemComponent = class ItDropdownItemComponent extends ItLinkComponent {
	constructor() {
		super(...arguments);
		this.iconPosition = "right";
		this.mode = "button";
		this.isDark = false;
		this.elRef = inject(ElementRef);
		this.isHostElement = false;
	}
	get linkClass() {
		let linkClass = `list-item ${this.active ? "active" : "dropdown-item"}`;
		if (this.mode === "nav") linkClass += " nav-link";
		if (this.disabled) linkClass += " disabled";
		if (this.large) linkClass += " large";
		if (this.iconName) linkClass += ` ${this.iconPosition === "right" ? "right-icon" : "left-icon"}`;
		return linkClass;
	}
	ngOnInit() {
		this.isHostElement = this.elRef.nativeElement.tagName.toLowerCase() === "li";
		if (!this.isHostElement) console.warn(`L'utilizzo del componente attraverso il selettore it-dropdown-item verrà deprecato in quanto non accessibile. Usa il selettore itDropdownItem invece. Consulta la documentazione del component Dropdown.`);
	}
	setDark(dark) {
		if (this.isDark !== dark) {
			this.isDark = dark;
			this._changeDetectorRef.detectChanges();
		}
	}
	static {
		this.ɵfac = i0.ɵɵngDeclareFactory({
			minVersion: "12.0.0",
			version: "22.2.1",
			ngImport: i0,
			type: ItDropdownItemComponent,
			deps: null,
			target: i0.ɵɵFactoryTarget.Component
		});
	}
	static {
		this.ɵcmp = i0.ɵɵngDeclareComponent({
			minVersion: "17.0.0",
			version: "22.2.1",
			type: ItDropdownItemComponent,
			isStandalone: true,
			selector: "it-dropdown-item, li[itDropdownItem]",
			inputs: {
				divider: [
					"divider",
					"divider",
					inputToBoolean
				],
				active: [
					"active",
					"active",
					inputToBoolean
				],
				large: [
					"large",
					"large",
					inputToBoolean
				],
				iconName: "iconName",
				iconPosition: "iconPosition",
				mode: "mode"
			},
			usesInheritance: true,
			ngImport: i0,
			template: "@if (isHostElement) {\r\n  <ng-container *ngTemplateOutlet=\"content\"></ng-container>\r\n} @else {\r\n  <li>\r\n    <ng-container *ngTemplateOutlet=\"content\"></ng-container>\r\n  </li>\r\n}\r\n\r\n<ng-template #content>\r\n  @if (divider) {\r\n    <span class=\"divider\"></span>\r\n  } @else {\r\n    <it-link [class]=\"linkClass\" [id]=\"id\" [href]=\"href\" [externalLink]=\"externalLink\" [disabled]=\"disabled\">\r\n      @if (iconName && iconPosition === 'left') {\r\n        <it-icon size=\"sm\" [name]=\"iconName\" [color]=\"isDark ? 'light' : 'primary'\" [svgClass]=\"iconPosition\"></it-icon>\r\n      }\r\n      <span><ng-content></ng-content></span>\r\n      @if (iconName && iconPosition === 'right') {\r\n        <it-icon size=\"sm\" [name]=\"iconName\" [color]=\"isDark ? 'light' : 'primary'\" [svgClass]=\"iconPosition\"></it-icon>\r\n      }\r\n      @if (active) {\r\n        <span class=\"visually-hidden\">{{ 'it.core.active' | translate }}</span>\r\n      }\r\n    </it-link>\r\n  }\r\n</ng-template>\r\n",
			styles: [".list-item.disabled{pointer-events:none;cursor:default}:host ::ng-deep svg.left{margin-right:8px}:host ::ng-deep svg.right{margin-left:8px}\n"],
			dependencies: [
				{
					kind: "component",
					type: ItIconComponent,
					selector: "it-icon",
					inputs: [
						"name",
						"size",
						"color",
						"padded",
						"svgClass",
						"title",
						"labelWaria"
					]
				},
				{
					kind: "ngmodule",
					type: TranslateModule
				},
				{
					kind: "component",
					type: ItLinkComponent,
					selector: "it-link",
					inputs: [
						"href",
						"externalLink",
						"disabled",
						"class"
					]
				},
				{
					kind: "directive",
					type: NgTemplateOutlet,
					selector: "[ngTemplateOutlet]",
					inputs: [
						"ngTemplateOutletContext",
						"ngTemplateOutlet",
						"ngTemplateOutletInjector"
					]
				},
				{
					kind: "pipe",
					type: i1$1.TranslatePipe,
					name: "translate"
				}
			],
			changeDetection: i0.ChangeDetectionStrategy.OnPush
		});
	}
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.1",
	ngImport: i0,
	type: ItDropdownItemComponent,
	decorators: [{
		type: Component,
		args: [{
			selector: "it-dropdown-item, li[itDropdownItem]",
			changeDetection: ChangeDetectionStrategy.OnPush,
			imports: [
				ItIconComponent,
				TranslateModule,
				ItLinkComponent,
				NgTemplateOutlet
			],
			template: "@if (isHostElement) {\r\n  <ng-container *ngTemplateOutlet=\"content\"></ng-container>\r\n} @else {\r\n  <li>\r\n    <ng-container *ngTemplateOutlet=\"content\"></ng-container>\r\n  </li>\r\n}\r\n\r\n<ng-template #content>\r\n  @if (divider) {\r\n    <span class=\"divider\"></span>\r\n  } @else {\r\n    <it-link [class]=\"linkClass\" [id]=\"id\" [href]=\"href\" [externalLink]=\"externalLink\" [disabled]=\"disabled\">\r\n      @if (iconName && iconPosition === 'left') {\r\n        <it-icon size=\"sm\" [name]=\"iconName\" [color]=\"isDark ? 'light' : 'primary'\" [svgClass]=\"iconPosition\"></it-icon>\r\n      }\r\n      <span><ng-content></ng-content></span>\r\n      @if (iconName && iconPosition === 'right') {\r\n        <it-icon size=\"sm\" [name]=\"iconName\" [color]=\"isDark ? 'light' : 'primary'\" [svgClass]=\"iconPosition\"></it-icon>\r\n      }\r\n      @if (active) {\r\n        <span class=\"visually-hidden\">{{ 'it.core.active' | translate }}</span>\r\n      }\r\n    </it-link>\r\n  }\r\n</ng-template>\r\n",
			styles: [".list-item.disabled{pointer-events:none;cursor:default}:host ::ng-deep svg.left{margin-right:8px}:host ::ng-deep svg.right{margin-left:8px}\n"]
		}]
	}],
	propDecorators: {
		divider: [{
			type: Input,
			args: [{ transform: inputToBoolean }]
		}],
		active: [{
			type: Input,
			args: [{ transform: inputToBoolean }]
		}],
		large: [{
			type: Input,
			args: [{ transform: inputToBoolean }]
		}],
		iconName: [{ type: Input }],
		iconPosition: [{ type: Input }],
		mode: [{ type: Input }]
	}
});
var ItDropdownComponent = class ItDropdownComponent extends ItAbstractComponent {
	constructor() {
		super(...arguments);
		this.mode = "button";
		this.showEvent = new EventEmitter();
		this.shownEvent = new EventEmitter();
		this.hideEvent = new EventEmitter();
		this.hiddenEvent = new EventEmitter();
	}
	get buttonClass() {
		let btnClass = "btn dropdown-toggle";
		if (this.color) btnClass += ` btn-${this.color}`;
		else btnClass += ` btn-dropdown`;
		return btnClass;
	}
	ngOnChanges(changes) {
		if (changes["dark"] && !changes["dark"].firstChange) this.setDarkItems();
		if (changes["mode"] && !changes["mode"].firstChange) this.updateListeners();
		super.ngOnChanges(changes);
	}
	ngAfterViewInit() {
		super.ngAfterViewInit();
		this.setDarkItems();
		this.updateListeners();
		this.items?.forEach((item) => {
			item.mode = this.mode;
		});
	}
	setDarkItems() {
		if (this.dark !== void 0) this.items?.forEach((item) => {
			item.setDark(!!this.dark);
		});
	}
	updateListeners() {
		if (this.dropdownButton) {
			const element = this.dropdownButton.nativeElement;
			this.dropdown = Dropdown.getOrCreateInstance(element);
			element.addEventListener("show.bs.dropdown", (event) => this.showEvent.emit(event));
			element.addEventListener("shown.bs.dropdown", (event) => this.shownEvent.emit(event));
			element.addEventListener("hide.bs.dropdown", (event) => this.hideEvent.emit(event));
			element.addEventListener("hidden.bs.dropdown", (event) => this.hiddenEvent.emit(event));
		}
	}
	toggle() {
		this.dropdown?.toggle();
	}
	show() {
		this.dropdown?.show();
	}
	hide() {
		this.dropdown?.hide();
	}
	update() {
		this.dropdown?.update();
	}
	dispose() {
		this.dropdown?.dispose();
	}
	static {
		this.ɵfac = i0.ɵɵngDeclareFactory({
			minVersion: "12.0.0",
			version: "22.2.1",
			ngImport: i0,
			type: ItDropdownComponent,
			deps: null,
			target: i0.ɵɵFactoryTarget.Component
		});
	}
	static {
		this.ɵcmp = i0.ɵɵngDeclareComponent({
			minVersion: "17.0.0",
			version: "22.2.1",
			type: ItDropdownComponent,
			isStandalone: true,
			selector: "it-dropdown",
			inputs: {
				mode: "mode",
				color: "color",
				direction: "direction",
				fullWidth: [
					"fullWidth",
					"fullWidth",
					inputToBoolean
				],
				megamenu: [
					"megamenu",
					"megamenu",
					inputToBoolean
				],
				dark: [
					"dark",
					"dark",
					inputToBoolean
				]
			},
			outputs: {
				showEvent: "showEvent",
				shownEvent: "shownEvent",
				hideEvent: "hideEvent",
				hiddenEvent: "hiddenEvent"
			},
			queries: [{
				propertyName: "items",
				predicate: ItDropdownItemComponent
			}],
			viewQueries: [{
				propertyName: "dropdownButton",
				first: true,
				predicate: ["dropdownButton"],
				descendants: true
			}],
			exportAs: ["itDropdown"],
			usesInheritance: true,
			usesOnChanges: true,
			ngImport: i0,
			template: "<div class=\"dropdown {{ direction }}\" [class.nav-item]=\"mode === 'nav'\" [class.megamenu]=\"megamenu\">\r\n  @if (mode === 'button') {\r\n    <button\r\n      #dropdownButton\r\n      [id]=\"id\"\r\n      [class]=\"buttonClass\"\r\n      type=\"button\"\r\n      data-bs-toggle=\"dropdown\"\r\n      aria-haspopup=\"true\"\r\n      aria-expanded=\"false\">\r\n      <ng-container *ngTemplateOutlet=\"buttonContent\"></ng-container>\r\n      <it-icon svgClass=\"icon-expand\" name=\"expand\" size=\"sm\" [color]=\"this.color ? 'light' : 'primary'\"></it-icon>\r\n    </button>\r\n  } @else {\r\n    <a\r\n      #dropdownButton\r\n      [id]=\"id\"\r\n      [class.btn]=\"mode === 'link'\"\r\n      [class.btn-dropdown]=\"mode === 'link'\"\r\n      [class.nav-link]=\"mode === 'nav'\"\r\n      href=\"#\"\r\n      class=\"dropdown-toggle\"\r\n      role=\"button\"\r\n      data-bs-toggle=\"dropdown\"\r\n      aria-haspopup=\"true\"\r\n      aria-expanded=\"false\">\r\n      <ng-container *ngTemplateOutlet=\"buttonContent\"></ng-container>\r\n      <it-icon svgClass=\"icon-expand\" name=\"expand\" size=\"sm\"></it-icon>\r\n    </a>\r\n  }\r\n\r\n  <div class=\"dropdown-menu\" [class.full-width]=\"fullWidth\" [class.dark]=\"dark\" [attr.aria-labelledby]=\"id\">\r\n    <div class=\"link-list-wrapper\">\r\n      <div class=\"link-list-heading\">\r\n        <ng-content select=\"[listHeading]\"></ng-content>\r\n      </div>\r\n      <ul class=\"link-list\">\r\n        <ng-content select=\"[list]\"></ng-content>\r\n      </ul>\r\n    </div>\r\n  </div>\r\n</div>\r\n\r\n<ng-template #buttonContent>\r\n  <ng-content select=\"[button]\"></ng-content>\r\n</ng-template>\r\n",
			styles: [".link-list-heading:empty{display:none}\n"],
			dependencies: [{
				kind: "component",
				type: ItIconComponent,
				selector: "it-icon",
				inputs: [
					"name",
					"size",
					"color",
					"padded",
					"svgClass",
					"title",
					"labelWaria"
				]
			}, {
				kind: "directive",
				type: NgTemplateOutlet,
				selector: "[ngTemplateOutlet]",
				inputs: [
					"ngTemplateOutletContext",
					"ngTemplateOutlet",
					"ngTemplateOutletInjector"
				]
			}],
			changeDetection: i0.ChangeDetectionStrategy.OnPush
		});
	}
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.1",
	ngImport: i0,
	type: ItDropdownComponent,
	decorators: [{
		type: Component,
		args: [{
			selector: "it-dropdown",
			exportAs: "itDropdown",
			changeDetection: ChangeDetectionStrategy.OnPush,
			imports: [ItIconComponent, NgTemplateOutlet],
			template: "<div class=\"dropdown {{ direction }}\" [class.nav-item]=\"mode === 'nav'\" [class.megamenu]=\"megamenu\">\r\n  @if (mode === 'button') {\r\n    <button\r\n      #dropdownButton\r\n      [id]=\"id\"\r\n      [class]=\"buttonClass\"\r\n      type=\"button\"\r\n      data-bs-toggle=\"dropdown\"\r\n      aria-haspopup=\"true\"\r\n      aria-expanded=\"false\">\r\n      <ng-container *ngTemplateOutlet=\"buttonContent\"></ng-container>\r\n      <it-icon svgClass=\"icon-expand\" name=\"expand\" size=\"sm\" [color]=\"this.color ? 'light' : 'primary'\"></it-icon>\r\n    </button>\r\n  } @else {\r\n    <a\r\n      #dropdownButton\r\n      [id]=\"id\"\r\n      [class.btn]=\"mode === 'link'\"\r\n      [class.btn-dropdown]=\"mode === 'link'\"\r\n      [class.nav-link]=\"mode === 'nav'\"\r\n      href=\"#\"\r\n      class=\"dropdown-toggle\"\r\n      role=\"button\"\r\n      data-bs-toggle=\"dropdown\"\r\n      aria-haspopup=\"true\"\r\n      aria-expanded=\"false\">\r\n      <ng-container *ngTemplateOutlet=\"buttonContent\"></ng-container>\r\n      <it-icon svgClass=\"icon-expand\" name=\"expand\" size=\"sm\"></it-icon>\r\n    </a>\r\n  }\r\n\r\n  <div class=\"dropdown-menu\" [class.full-width]=\"fullWidth\" [class.dark]=\"dark\" [attr.aria-labelledby]=\"id\">\r\n    <div class=\"link-list-wrapper\">\r\n      <div class=\"link-list-heading\">\r\n        <ng-content select=\"[listHeading]\"></ng-content>\r\n      </div>\r\n      <ul class=\"link-list\">\r\n        <ng-content select=\"[list]\"></ng-content>\r\n      </ul>\r\n    </div>\r\n  </div>\r\n</div>\r\n\r\n<ng-template #buttonContent>\r\n  <ng-content select=\"[button]\"></ng-content>\r\n</ng-template>\r\n",
			styles: [".link-list-heading:empty{display:none}\n"]
		}]
	}],
	propDecorators: {
		mode: [{ type: Input }],
		color: [{ type: Input }],
		direction: [{ type: Input }],
		fullWidth: [{
			type: Input,
			args: [{ transform: inputToBoolean }]
		}],
		megamenu: [{
			type: Input,
			args: [{ transform: inputToBoolean }]
		}],
		dark: [{
			type: Input,
			args: [{ transform: inputToBoolean }]
		}],
		items: [{
			type: ContentChildren,
			args: [ItDropdownItemComponent]
		}],
		showEvent: [{ type: Output }],
		shownEvent: [{ type: Output }],
		hideEvent: [{ type: Output }],
		hiddenEvent: [{ type: Output }],
		dropdownButton: [{
			type: ViewChild,
			args: ["dropdownButton"]
		}]
	}
});
const dropdownComponents = [ItDropdownComponent, ItDropdownItemComponent];
var ItDropdownModule = class ItDropdownModule {
	static {
		this.ɵfac = i0.ɵɵngDeclareFactory({
			minVersion: "12.0.0",
			version: "22.2.1",
			ngImport: i0,
			type: ItDropdownModule,
			deps: [],
			target: i0.ɵɵFactoryTarget.NgModule
		});
	}
	static {
		this.ɵmod = i0.ɵɵngDeclareNgModule({
			minVersion: "14.0.0",
			version: "22.2.1",
			ngImport: i0,
			type: ItDropdownModule,
			imports: [ItDropdownComponent, ItDropdownItemComponent],
			exports: [ItDropdownComponent, ItDropdownItemComponent]
		});
	}
	static {
		this.ɵinj = i0.ɵɵngDeclareInjector({
			minVersion: "12.0.0",
			version: "22.2.1",
			ngImport: i0,
			type: ItDropdownModule,
			imports: [ItDropdownItemComponent]
		});
	}
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.1",
	ngImport: i0,
	type: ItDropdownModule,
	decorators: [{
		type: NgModule,
		args: [{
			imports: dropdownComponents,
			exports: dropdownComponents
		}]
	}]
});
var ItAvatarDropdownItemComponent = class ItAvatarDropdownItemComponent {
	static {
		this.ɵfac = i0.ɵɵngDeclareFactory({
			minVersion: "12.0.0",
			version: "22.2.1",
			ngImport: i0,
			type: ItAvatarDropdownItemComponent,
			deps: [],
			target: i0.ɵɵFactoryTarget.Component
		});
	}
	static {
		this.ɵcmp = i0.ɵɵngDeclareComponent({
			minVersion: "14.0.0",
			version: "22.2.1",
			type: ItAvatarDropdownItemComponent,
			isStandalone: true,
			selector: "it-avatar-dropdown-item",
			inputs: {
				link: "link",
				title: "title",
				accesskey: "accesskey",
				tabindex: "tabindex"
			},
			viewQueries: [{
				propertyName: "_implicitContent",
				first: true,
				predicate: TemplateRef,
				descendants: true,
				static: true
			}],
			ngImport: i0,
			template: "<ng-template><ng-content></ng-content></ng-template>",
			isInline: true,
			styles: [".link-list-wrapper{z-index:2;position:relative}a{cursor:pointer}:host ::ng-deep .dropdown-toggle{width:100%;height:100%}:host ::ng-deep .dropdown-toggle .icon{display:none}\n"],
			changeDetection: i0.ChangeDetectionStrategy.Eager
		});
	}
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.1",
	ngImport: i0,
	type: ItAvatarDropdownItemComponent,
	decorators: [{
		type: Component,
		args: [{
			selector: "it-avatar-dropdown-item",
			template: "<ng-template><ng-content></ng-content></ng-template>",
			changeDetection: ChangeDetectionStrategy.Eager,
			styles: [".link-list-wrapper{z-index:2;position:relative}a{cursor:pointer}:host ::ng-deep .dropdown-toggle{width:100%;height:100%}:host ::ng-deep .dropdown-toggle .icon{display:none}\n"]
		}]
	}],
	propDecorators: {
		_implicitContent: [{
			type: ViewChild,
			args: [TemplateRef, { static: true }]
		}],
		link: [{ type: Input }],
		title: [{ type: Input }],
		accesskey: [{ type: Input }],
		tabindex: [{ type: Input }]
	}
});
var ItAvatarDropdownComponent = class ItAvatarDropdownComponent {
	constructor() {
		this.componentClass = "avatar avatar-dropdown";
	}
	static {
		this.ɵfac = i0.ɵɵngDeclareFactory({
			minVersion: "12.0.0",
			version: "22.2.1",
			ngImport: i0,
			type: ItAvatarDropdownComponent,
			deps: [],
			target: i0.ɵɵFactoryTarget.Component
		});
	}
	static {
		this.ɵcmp = i0.ɵɵngDeclareComponent({
			minVersion: "17.0.0",
			version: "22.2.1",
			type: ItAvatarDropdownComponent,
			isStandalone: true,
			selector: "it-avatar-dropdown",
			host: { properties: { "class": "this.componentClass" } },
			queries: [{
				propertyName: "items",
				predicate: ItAvatarDropdownItemComponent
			}],
			ngImport: i0,
			template: "<it-dropdown id=\"dropdown\" class=\"dropdown\">\r\n  <ng-content button select=\"[it-avatar-dropdown-toggle]\"></ng-content>\r\n  <ng-container list class=\"dropdown-menu\">\r\n    @for (item of items; track item) {\r\n      <li>\r\n        @if (item.link) {\r\n          <a\r\n            [routerLink]=\"item.link\"\r\n            class=\"dropdown-item list-item\"\r\n            title=\"item.title\"\r\n            accesskey=\"item.accesskey\"\r\n            tabindex=\"item.tabindex\">\r\n            <ng-template *ngTemplateOutlet=\"item._implicitContent\"></ng-template>\r\n          </a>\r\n        } @else {\r\n          <div class=\"dropdown-item list-item\">\r\n            <ng-template *ngTemplateOutlet=\"item._implicitContent\"></ng-template>\r\n          </div>\r\n        }\r\n      </li>\r\n    }\r\n  </ng-container>\r\n</it-dropdown>\r\n",
			styles: [".link-list-wrapper{z-index:2;position:relative}a{cursor:pointer}:host ::ng-deep .dropdown-toggle{width:100%;height:100%}:host ::ng-deep .dropdown-toggle .icon{display:none}\n"],
			dependencies: [
				{
					kind: "ngmodule",
					type: ItDropdownModule
				},
				{
					kind: "component",
					type: ItDropdownComponent,
					selector: "it-dropdown",
					inputs: [
						"mode",
						"color",
						"direction",
						"fullWidth",
						"megamenu",
						"dark"
					],
					outputs: [
						"showEvent",
						"shownEvent",
						"hideEvent",
						"hiddenEvent"
					],
					exportAs: ["itDropdown"]
				},
				{
					kind: "directive",
					type: NgTemplateOutlet,
					selector: "[ngTemplateOutlet]",
					inputs: [
						"ngTemplateOutletContext",
						"ngTemplateOutlet",
						"ngTemplateOutletInjector"
					]
				},
				{
					kind: "directive",
					type: RouterLink,
					selector: "[routerLink]",
					inputs: [
						"target",
						"queryParams",
						"fragment",
						"queryParamsHandling",
						"state",
						"info",
						"relativeTo",
						"preserveFragment",
						"skipLocationChange",
						"replaceUrl",
						"browserUrl",
						"routerLink"
					]
				}
			],
			changeDetection: i0.ChangeDetectionStrategy.Eager
		});
	}
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.1",
	ngImport: i0,
	type: ItAvatarDropdownComponent,
	decorators: [{
		type: Component,
		args: [{
			selector: "it-avatar-dropdown",
			changeDetection: ChangeDetectionStrategy.Eager,
			imports: [
				ItDropdownModule,
				NgTemplateOutlet,
				RouterLink
			],
			template: "<it-dropdown id=\"dropdown\" class=\"dropdown\">\r\n  <ng-content button select=\"[it-avatar-dropdown-toggle]\"></ng-content>\r\n  <ng-container list class=\"dropdown-menu\">\r\n    @for (item of items; track item) {\r\n      <li>\r\n        @if (item.link) {\r\n          <a\r\n            [routerLink]=\"item.link\"\r\n            class=\"dropdown-item list-item\"\r\n            title=\"item.title\"\r\n            accesskey=\"item.accesskey\"\r\n            tabindex=\"item.tabindex\">\r\n            <ng-template *ngTemplateOutlet=\"item._implicitContent\"></ng-template>\r\n          </a>\r\n        } @else {\r\n          <div class=\"dropdown-item list-item\">\r\n            <ng-template *ngTemplateOutlet=\"item._implicitContent\"></ng-template>\r\n          </div>\r\n        }\r\n      </li>\r\n    }\r\n  </ng-container>\r\n</it-dropdown>\r\n",
			styles: [".link-list-wrapper{z-index:2;position:relative}a{cursor:pointer}:host ::ng-deep .dropdown-toggle{width:100%;height:100%}:host ::ng-deep .dropdown-toggle .icon{display:none}\n"]
		}]
	}],
	propDecorators: {
		componentClass: [{
			type: HostBinding,
			args: ["class"]
		}],
		items: [{
			type: ContentChildren,
			args: [ItAvatarDropdownItemComponent]
		}]
	}
});
var ItAvatarExtraTextDirective = class ItAvatarExtraTextDirective {
	get hostClasses() {
		return "extra-text";
	}
	static {
		this.ɵfac = i0.ɵɵngDeclareFactory({
			minVersion: "12.0.0",
			version: "22.2.1",
			ngImport: i0,
			type: ItAvatarExtraTextDirective,
			deps: [],
			target: i0.ɵɵFactoryTarget.Directive
		});
	}
	static {
		this.ɵdir = i0.ɵɵngDeclareDirective({
			minVersion: "14.0.0",
			version: "22.2.1",
			type: ItAvatarExtraTextDirective,
			isStandalone: true,
			selector: "[itAvatarExtraText]",
			host: { properties: { "class": "this.hostClasses" } },
			exportAs: ["itAvatarExtraText"],
			ngImport: i0
		});
	}
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.1",
	ngImport: i0,
	type: ItAvatarExtraTextDirective,
	decorators: [{
		type: Directive,
		args: [{
			standalone: true,
			selector: "[itAvatarExtraText]",
			exportAs: "itAvatarExtraText"
		}]
	}],
	propDecorators: { hostClasses: [{
		type: HostBinding,
		args: ["class"]
	}] }
});
var ItAvatarListItemDirective = class ItAvatarListItemDirective {
	get hostClasses() {
		return `list-item`;
	}
	static {
		this.ɵfac = i0.ɵɵngDeclareFactory({
			minVersion: "12.0.0",
			version: "22.2.1",
			ngImport: i0,
			type: ItAvatarListItemDirective,
			deps: [],
			target: i0.ɵɵFactoryTarget.Directive
		});
	}
	static {
		this.ɵdir = i0.ɵɵngDeclareDirective({
			minVersion: "14.0.0",
			version: "22.2.1",
			type: ItAvatarListItemDirective,
			isStandalone: true,
			selector: "[itAvatarListItem]",
			host: { properties: { "class": "this.hostClasses" } },
			exportAs: ["itAvatarListItem"],
			ngImport: i0
		});
	}
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.1",
	ngImport: i0,
	type: ItAvatarListItemDirective,
	decorators: [{
		type: Directive,
		args: [{
			standalone: true,
			selector: "[itAvatarListItem]",
			exportAs: "itAvatarListItem"
		}]
	}],
	propDecorators: { hostClasses: [{
		type: HostBinding,
		args: ["class"]
	}] }
});
var ItAvatarGroupItemComponent = class ItAvatarGroupItemComponent {
	static {
		this.ɵfac = i0.ɵɵngDeclareFactory({
			minVersion: "12.0.0",
			version: "22.2.1",
			ngImport: i0,
			type: ItAvatarGroupItemComponent,
			deps: [],
			target: i0.ɵɵFactoryTarget.Component
		});
	}
	static {
		this.ɵcmp = i0.ɵɵngDeclareComponent({
			minVersion: "14.0.0",
			version: "22.2.1",
			type: ItAvatarGroupItemComponent,
			isStandalone: true,
			selector: "it-avatar-item",
			viewQueries: [{
				propertyName: "_implicitContent",
				first: true,
				predicate: TemplateRef,
				descendants: true,
				static: true
			}],
			ngImport: i0,
			template: `<ng-template let-linkListItem="linkList">
    <ng-content></ng-content>
  </ng-template>`,
			isInline: true,
			changeDetection: i0.ChangeDetectionStrategy.Eager
		});
	}
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.1",
	ngImport: i0,
	type: ItAvatarGroupItemComponent,
	decorators: [{
		type: Component,
		args: [{
			standalone: true,
			selector: "it-avatar-item",
			changeDetection: ChangeDetectionStrategy.Eager,
			template: `<ng-template let-linkListItem="linkList">
    <ng-content></ng-content>
  </ng-template>`
		}]
	}],
	propDecorators: { _implicitContent: [{
		type: ViewChild,
		args: [TemplateRef, { static: true }]
	}] }
});
var ItAvatarGroupComponent = class ItAvatarGroupComponent {
	constructor() {
		this.linkList = false;
	}
	static {
		this.ɵfac = i0.ɵɵngDeclareFactory({
			minVersion: "12.0.0",
			version: "22.2.1",
			ngImport: i0,
			type: ItAvatarGroupComponent,
			deps: [],
			target: i0.ɵɵFactoryTarget.Component
		});
	}
	static {
		this.ɵcmp = i0.ɵɵngDeclareComponent({
			minVersion: "17.0.0",
			version: "22.2.1",
			type: ItAvatarGroupComponent,
			isStandalone: true,
			selector: "it-avatar-group",
			inputs: { linkList: [
				"linkList",
				"linkList",
				inputToBoolean
			] },
			host: { properties: { "class.link-list-wrapper": "this.linkList" } },
			queries: [{
				propertyName: "avatars",
				predicate: ItAvatarGroupItemComponent
			}],
			ngImport: i0,
			template: `
    <ul [class]="linkList ? 'link-list avatar-group' : 'avatar-group-stacked'">
      @for (avatar of avatars; track avatar) {
        <li>
          <ng-container *ngTemplateOutlet="avatar._implicitContent; context: { linkList: linkList }"></ng-container>
        </li>
      }
    </ul>
  `,
			isInline: true,
			dependencies: [{
				kind: "directive",
				type: NgTemplateOutlet,
				selector: "[ngTemplateOutlet]",
				inputs: [
					"ngTemplateOutletContext",
					"ngTemplateOutlet",
					"ngTemplateOutletInjector"
				]
			}],
			changeDetection: i0.ChangeDetectionStrategy.Eager
		});
	}
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.1",
	ngImport: i0,
	type: ItAvatarGroupComponent,
	decorators: [{
		type: Component,
		args: [{
			selector: "it-avatar-group",
			imports: [NgTemplateOutlet],
			changeDetection: ChangeDetectionStrategy.Eager,
			template: `
    <ul [class]="linkList ? 'link-list avatar-group' : 'avatar-group-stacked'">
      @for (avatar of avatars; track avatar) {
        <li>
          <ng-container *ngTemplateOutlet="avatar._implicitContent; context: { linkList: linkList }"></ng-container>
        </li>
      }
    </ul>
  `
		}]
	}],
	propDecorators: {
		linkList: [{
			type: Input,
			args: [{ transform: inputToBoolean }]
		}, {
			type: HostBinding,
			args: ["class.link-list-wrapper"]
		}],
		avatars: [{
			type: ContentChildren,
			args: [ItAvatarGroupItemComponent]
		}]
	}
});
var ItAvatarPresenceDirective = class ItAvatarPresenceDirective {
	get presence() {
		return this._presence;
	}
	set presence(value) {
		this._presence = value;
	}
	get hostClasses() {
		return `avatar-presence ${this._presence}`;
	}
	static {
		this.ɵfac = i0.ɵɵngDeclareFactory({
			minVersion: "12.0.0",
			version: "22.2.1",
			ngImport: i0,
			type: ItAvatarPresenceDirective,
			deps: [],
			target: i0.ɵɵFactoryTarget.Directive
		});
	}
	static {
		this.ɵdir = i0.ɵɵngDeclareDirective({
			minVersion: "14.0.0",
			version: "22.2.1",
			type: ItAvatarPresenceDirective,
			isStandalone: true,
			selector: "[itAvatarPresence]",
			inputs: { presence: "presence" },
			host: { properties: { "class": "this.hostClasses" } },
			exportAs: ["itAvatarPresence"],
			ngImport: i0
		});
	}
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.1",
	ngImport: i0,
	type: ItAvatarPresenceDirective,
	decorators: [{
		type: Directive,
		args: [{
			standalone: true,
			selector: "[itAvatarPresence]",
			exportAs: "itAvatarPresence"
		}]
	}],
	propDecorators: {
		presence: [{ type: Input }],
		hostClasses: [{
			type: HostBinding,
			args: ["class"]
		}]
	}
});
var ItAvatarStatusDirective = class ItAvatarStatusDirective {
	get status() {
		return this._status;
	}
	set status(value) {
		this._status = value;
	}
	get hostClasses() {
		return `avatar-status ${this._status}`;
	}
	static {
		this.ɵfac = i0.ɵɵngDeclareFactory({
			minVersion: "12.0.0",
			version: "22.2.1",
			ngImport: i0,
			type: ItAvatarStatusDirective,
			deps: [],
			target: i0.ɵɵFactoryTarget.Directive
		});
	}
	static {
		this.ɵdir = i0.ɵɵngDeclareDirective({
			minVersion: "14.0.0",
			version: "22.2.1",
			type: ItAvatarStatusDirective,
			isStandalone: true,
			selector: "[itAvatarStatus]",
			inputs: { status: "status" },
			host: { properties: { "class": "this.hostClasses" } },
			exportAs: ["itAvatarStatus"],
			ngImport: i0
		});
	}
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.1",
	ngImport: i0,
	type: ItAvatarStatusDirective,
	decorators: [{
		type: Directive,
		args: [{
			standalone: true,
			selector: "[itAvatarStatus]",
			exportAs: "itAvatarStatus"
		}]
	}],
	propDecorators: {
		status: [{ type: Input }],
		hostClasses: [{
			type: HostBinding,
			args: ["class"]
		}]
	}
});
var ItAvatarWrapperDirective = class ItAvatarWrapperDirective {
	constructor() {
		this.extraText = false;
	}
	get hostClasses() {
		let cssClass = "avatar-wrapper";
		if (this.extraText) cssClass += " avatar-extra-text";
		return cssClass;
	}
	static {
		this.ɵfac = i0.ɵɵngDeclareFactory({
			minVersion: "12.0.0",
			version: "22.2.1",
			ngImport: i0,
			type: ItAvatarWrapperDirective,
			deps: [],
			target: i0.ɵɵFactoryTarget.Directive
		});
	}
	static {
		this.ɵdir = i0.ɵɵngDeclareDirective({
			minVersion: "16.1.0",
			version: "22.2.1",
			type: ItAvatarWrapperDirective,
			isStandalone: true,
			selector: "[itAvatarWrapper]",
			inputs: { extraText: [
				"extraText",
				"extraText",
				inputToBoolean
			] },
			host: { properties: { "class": "this.hostClasses" } },
			exportAs: ["itAvatarWrapper"],
			ngImport: i0
		});
	}
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.1",
	ngImport: i0,
	type: ItAvatarWrapperDirective,
	decorators: [{
		type: Directive,
		args: [{
			standalone: true,
			selector: "[itAvatarWrapper]",
			exportAs: "itAvatarWrapper"
		}]
	}],
	propDecorators: {
		extraText: [{
			type: Input,
			args: [{ transform: inputToBoolean }]
		}],
		hostClasses: [{
			type: HostBinding,
			args: ["class"]
		}]
	}
});
var ColorsEnum;
(function(ColorsEnum) {
	ColorsEnum["primary"] = "primary";
	ColorsEnum["secondary"] = "secondary";
	ColorsEnum["success"] = "success";
	ColorsEnum["danger"] = "danger";
	ColorsEnum["warning"] = "warning";
	ColorsEnum["green"] = "green";
	ColorsEnum["orange"] = "orange";
	ColorsEnum["red"] = "red";
})(ColorsEnum || (ColorsEnum = {}));
var SizesEnum;
(function(SizesEnum) {
	SizesEnum["xs"] = "size-xs";
	SizesEnum["sm"] = "size-sm";
	SizesEnum["lg"] = "size-lg";
	SizesEnum["xl"] = "size-xl";
	SizesEnum["xxl"] = "size-xxl";
})(SizesEnum || (SizesEnum = {}));
var ItAvatarDirective = class ItAvatarDirective {
	get color() {
		return this._color;
	}
	set color(value) {
		const colorsKey = value;
		if (ColorsEnum[colorsKey]) this._color = ColorsEnum[colorsKey];
		else this._color = void 0;
	}
	get size() {
		return this._size;
	}
	set size(value) {
		const sizesKey = value;
		if (SizesEnum[sizesKey]) this._size = SizesEnum[sizesKey];
		else this._size = void 0;
	}
	get hostClasses() {
		let cssClass = "avatar";
		if (this.size) cssClass += ` ${this.size}`;
		if (this.color) cssClass += ` avatar-${this.color}`;
		return cssClass;
	}
	static {
		this.ɵfac = i0.ɵɵngDeclareFactory({
			minVersion: "12.0.0",
			version: "22.2.1",
			ngImport: i0,
			type: ItAvatarDirective,
			deps: [],
			target: i0.ɵɵFactoryTarget.Directive
		});
	}
	static {
		this.ɵdir = i0.ɵɵngDeclareDirective({
			minVersion: "14.0.0",
			version: "22.2.1",
			type: ItAvatarDirective,
			isStandalone: true,
			selector: "[itAvatar]",
			inputs: {
				color: "color",
				size: "size"
			},
			host: { properties: { "class": "this.hostClasses" } },
			exportAs: ["itAvatar"],
			ngImport: i0
		});
	}
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.1",
	ngImport: i0,
	type: ItAvatarDirective,
	decorators: [{
		type: Directive,
		args: [{
			standalone: true,
			selector: "[itAvatar]",
			exportAs: "itAvatar"
		}]
	}],
	propDecorators: {
		color: [{ type: Input }],
		size: [{ type: Input }],
		hostClasses: [{
			type: HostBinding,
			args: ["class"]
		}]
	}
});
const avatarComponents = [
	ItAvatarGroupItemComponent,
	ItAvatarGroupComponent,
	ItAvatarDropdownComponent,
	ItAvatarDropdownItemComponent,
	ItAvatarDirective,
	ItAvatarExtraTextDirective,
	ItAvatarWrapperDirective,
	ItAvatarStatusDirective,
	ItAvatarPresenceDirective,
	ItAvatarListItemDirective
];
var ItAvatarModule = class ItAvatarModule {
	static {
		this.ɵfac = i0.ɵɵngDeclareFactory({
			minVersion: "12.0.0",
			version: "22.2.1",
			ngImport: i0,
			type: ItAvatarModule,
			deps: [],
			target: i0.ɵɵFactoryTarget.NgModule
		});
	}
	static {
		this.ɵmod = i0.ɵɵngDeclareNgModule({
			minVersion: "14.0.0",
			version: "22.2.1",
			ngImport: i0,
			type: ItAvatarModule,
			imports: [
				ItAvatarGroupItemComponent,
				ItAvatarGroupComponent,
				ItAvatarDropdownComponent,
				ItAvatarDropdownItemComponent,
				ItAvatarDirective,
				ItAvatarExtraTextDirective,
				ItAvatarWrapperDirective,
				ItAvatarStatusDirective,
				ItAvatarPresenceDirective,
				ItAvatarListItemDirective
			],
			exports: [
				ItAvatarGroupItemComponent,
				ItAvatarGroupComponent,
				ItAvatarDropdownComponent,
				ItAvatarDropdownItemComponent,
				ItAvatarDirective,
				ItAvatarExtraTextDirective,
				ItAvatarWrapperDirective,
				ItAvatarStatusDirective,
				ItAvatarPresenceDirective,
				ItAvatarListItemDirective
			]
		});
	}
	static {
		this.ɵinj = i0.ɵɵngDeclareInjector({
			minVersion: "12.0.0",
			version: "22.2.1",
			ngImport: i0,
			type: ItAvatarModule,
			imports: [ItAvatarDropdownComponent]
		});
	}
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.1",
	ngImport: i0,
	type: ItAvatarModule,
	decorators: [{
		type: NgModule,
		args: [{
			imports: avatarComponents,
			exports: avatarComponents
		}]
	}]
});
var ItBadgeDirective = class ItBadgeDirective {
	get badgeClass() {
		let badgeClass = "badge";
		if (this.rounded) badgeClass += ` rounded-pill`;
		if (this.color) badgeClass += ` bg-${this.color}`;
		return badgeClass;
	}
	static {
		this.ɵfac = i0.ɵɵngDeclareFactory({
			minVersion: "12.0.0",
			version: "22.2.1",
			ngImport: i0,
			type: ItBadgeDirective,
			deps: [],
			target: i0.ɵɵFactoryTarget.Directive
		});
	}
	static {
		this.ɵdir = i0.ɵɵngDeclareDirective({
			minVersion: "16.1.0",
			version: "22.2.1",
			type: ItBadgeDirective,
			isStandalone: true,
			selector: "[itBadge]",
			inputs: {
				color: ["itBadge", "color"],
				rounded: [
					"rounded",
					"rounded",
					inputToBoolean
				]
			},
			host: { properties: { "class": "this.badgeClass" } },
			exportAs: ["itBadge"],
			ngImport: i0
		});
	}
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.1",
	ngImport: i0,
	type: ItBadgeDirective,
	decorators: [{
		type: Directive,
		args: [{
			standalone: true,
			selector: "[itBadge]",
			exportAs: "itBadge"
		}]
	}],
	propDecorators: {
		color: [{
			type: Input,
			args: ["itBadge"]
		}],
		rounded: [{
			type: Input,
			args: [{ transform: inputToBoolean }]
		}],
		badgeClass: [{
			type: HostBinding,
			args: ["class"]
		}]
	}
});
var ItProgressBarComponent = class ItProgressBarComponent {
	get bgColor() {
		if (!this.color) return "";
		return ` bg-${this.color}`;
	}
	static {
		this.ɵfac = i0.ɵɵngDeclareFactory({
			minVersion: "12.0.0",
			version: "22.2.1",
			ngImport: i0,
			type: ItProgressBarComponent,
			deps: [],
			target: i0.ɵɵFactoryTarget.Component
		});
	}
	static {
		this.ɵcmp = i0.ɵɵngDeclareComponent({
			minVersion: "17.0.0",
			version: "22.2.1",
			type: ItProgressBarComponent,
			isStandalone: true,
			selector: "it-progress-bar",
			inputs: {
				value: "value",
				showLabel: [
					"showLabel",
					"showLabel",
					inputToBoolean
				],
				indeterminate: [
					"indeterminate",
					"indeterminate",
					inputToBoolean
				],
				color: "color"
			},
			ngImport: i0,
			template: "<div class=\"progress-bar-wrapper\">\r\n  @if (showLabel) {\r\n    <div class=\"progress-bar-label\">\r\n      <span class=\"visually-hidden\">{{ 'it.core.progress' | translate }} </span>{{ value }}%\r\n    </div>\r\n  }\r\n  <div class=\"progress\" [class.progress-color]=\"!!color\" [class.progress-indeterminate]=\"indeterminate\">\r\n    @if (indeterminate) {\r\n      <div class=\"progress-bar{{ bgColor }}\" role=\"progressbar\"></div>\r\n    } @else {\r\n      <div\r\n        class=\"progress-bar{{ bgColor }}\"\r\n        role=\"progressbar\"\r\n        [style.width.%]=\"value\"\r\n        [attr.aria-valuenow]=\"value\"\r\n        aria-valuemin=\"0\"\r\n        aria-valuemax=\"100\"></div>\r\n    }\r\n  </div>\r\n</div>\r\n",
			dependencies: [{
				kind: "ngmodule",
				type: TranslateModule
			}, {
				kind: "pipe",
				type: i1$1.TranslatePipe,
				name: "translate"
			}],
			changeDetection: i0.ChangeDetectionStrategy.OnPush
		});
	}
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.1",
	ngImport: i0,
	type: ItProgressBarComponent,
	decorators: [{
		type: Component,
		args: [{
			selector: "it-progress-bar",
			changeDetection: ChangeDetectionStrategy.OnPush,
			imports: [TranslateModule],
			template: "<div class=\"progress-bar-wrapper\">\r\n  @if (showLabel) {\r\n    <div class=\"progress-bar-label\">\r\n      <span class=\"visually-hidden\">{{ 'it.core.progress' | translate }} </span>{{ value }}%\r\n    </div>\r\n  }\r\n  <div class=\"progress\" [class.progress-color]=\"!!color\" [class.progress-indeterminate]=\"indeterminate\">\r\n    @if (indeterminate) {\r\n      <div class=\"progress-bar{{ bgColor }}\" role=\"progressbar\"></div>\r\n    } @else {\r\n      <div\r\n        class=\"progress-bar{{ bgColor }}\"\r\n        role=\"progressbar\"\r\n        [style.width.%]=\"value\"\r\n        [attr.aria-valuenow]=\"value\"\r\n        aria-valuemin=\"0\"\r\n        aria-valuemax=\"100\"></div>\r\n    }\r\n  </div>\r\n</div>\r\n"
		}]
	}],
	propDecorators: {
		value: [{
			type: Input,
			args: [{ required: true }]
		}],
		showLabel: [{
			type: Input,
			args: [{ transform: inputToBoolean }]
		}],
		indeterminate: [{
			type: Input,
			args: [{ transform: inputToBoolean }]
		}],
		color: [{ type: Input }]
	}
});
var ItProgressButtonComponent = class ItProgressButtonComponent {
	get isProgress() {
		return typeof this.progress === "number" || !!this.progress;
	}
	get progressValue() {
		return typeof this.progress === "number" ? this.progress : 0;
	}
	get isIndeterminate() {
		return typeof this.progress !== "number" && !!this.progress;
	}
	static {
		this.ɵfac = i0.ɵɵngDeclareFactory({
			minVersion: "12.0.0",
			version: "22.2.1",
			ngImport: i0,
			type: ItProgressButtonComponent,
			deps: [],
			target: i0.ɵɵFactoryTarget.Component
		});
	}
	static {
		this.ɵcmp = i0.ɵɵngDeclareComponent({
			minVersion: "17.0.0",
			version: "22.2.1",
			type: ItProgressButtonComponent,
			isStandalone: true,
			selector: "button[itButton][progress]",
			inputs: {
				progress: "progress",
				progressColor: "progressColor"
			},
			ngImport: i0,
			template: "<ng-content></ng-content>\r\n\r\n@if (isProgress) {\r\n  <it-progress-bar [value]=\"progressValue\" [indeterminate]=\"isIndeterminate\" [color]=\"progressColor\"></it-progress-bar>\r\n}\r\n",
			dependencies: [{
				kind: "component",
				type: ItProgressBarComponent,
				selector: "it-progress-bar",
				inputs: [
					"value",
					"showLabel",
					"indeterminate",
					"color"
				]
			}],
			changeDetection: i0.ChangeDetectionStrategy.OnPush
		});
	}
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.1",
	ngImport: i0,
	type: ItProgressButtonComponent,
	decorators: [{
		type: Component,
		args: [{
			selector: "button[itButton][progress]",
			changeDetection: ChangeDetectionStrategy.OnPush,
			imports: [ItProgressBarComponent],
			template: "<ng-content></ng-content>\r\n\r\n@if (isProgress) {\r\n  <it-progress-bar [value]=\"progressValue\" [indeterminate]=\"isIndeterminate\" [color]=\"progressColor\"></it-progress-bar>\r\n}\r\n"
		}]
	}],
	propDecorators: {
		progress: [{ type: Input }],
		progressColor: [{ type: Input }]
	}
});
var ItButtonDirective = class ItButtonDirective {
	constructor() {
		this.progressButtonComponent = inject(ItProgressButtonComponent, {
			optional: true,
			host: true
		});
		this.type = "button";
	}
	get hostClasses() {
		let cssClass = "btn";
		if (this.color) cssClass += ` btn-${this.color}`;
		if (this.size) cssClass += ` btn-${this.size}`;
		if (this.block) cssClass += " btn-block";
		if (this.disabled) cssClass += " disabled";
		if (this.icons?.length && !this.progressButtonComponent) cssClass += " btn-icon";
		if (this.progressButtonComponent) cssClass += " btn-progress";
		return cssClass;
	}
	static {
		this.ɵfac = i0.ɵɵngDeclareFactory({
			minVersion: "12.0.0",
			version: "22.2.1",
			ngImport: i0,
			type: ItButtonDirective,
			deps: [],
			target: i0.ɵɵFactoryTarget.Directive
		});
	}
	static {
		this.ɵdir = i0.ɵɵngDeclareDirective({
			minVersion: "16.1.0",
			version: "22.2.1",
			type: ItButtonDirective,
			isStandalone: true,
			selector: "[itButton]",
			inputs: {
				color: ["itButton", "color"],
				size: "size",
				block: "block",
				disabled: [
					"disabled",
					"disabled",
					inputToBoolean
				],
				type: "type"
			},
			host: { properties: {
				"attr.aria-disabled": "this.disabled",
				"attr.type": "this.type",
				"class": "this.hostClasses"
			} },
			queries: [{
				propertyName: "icons",
				predicate: ItIconComponent
			}],
			exportAs: ["itButton"],
			ngImport: i0
		});
	}
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.1",
	ngImport: i0,
	type: ItButtonDirective,
	decorators: [{
		type: Directive,
		args: [{
			standalone: true,
			selector: "[itButton]",
			exportAs: "itButton"
		}]
	}],
	propDecorators: {
		color: [{
			type: Input,
			args: ["itButton"]
		}],
		size: [{ type: Input }],
		block: [{ type: Input }],
		disabled: [{
			type: Input,
			args: [{ transform: inputToBoolean }]
		}, {
			type: HostBinding,
			args: ["attr.aria-disabled"]
		}],
		type: [{ type: Input }, {
			type: HostBinding,
			args: ["attr.type"]
		}],
		icons: [{
			type: ContentChildren,
			args: [ItIconComponent]
		}],
		hostClasses: [{
			type: HostBinding,
			args: ["class"]
		}]
	}
});
var ItCalloutComponent = class ItCalloutComponent {
	constructor() {
		this.appearance = "default";
		this.labelWaria = void 0;
	}
	get iconName() {
		if (this.icon) return this.icon;
		if (this.appearance === "more") return "zoom-in";
		switch (this.color) {
			case "success": return "check-circle";
			case "warning": return "help-circle";
			case "danger": return "close-circle";
			default: return "info-circle";
		}
	}
	static {
		this.ɵfac = i0.ɵɵngDeclareFactory({
			minVersion: "12.0.0",
			version: "22.2.1",
			ngImport: i0,
			type: ItCalloutComponent,
			deps: [],
			target: i0.ɵɵFactoryTarget.Component
		});
	}
	static {
		this.ɵcmp = i0.ɵɵngDeclareComponent({
			minVersion: "17.0.0",
			version: "22.2.1",
			type: ItCalloutComponent,
			isStandalone: true,
			selector: "it-callout",
			inputs: {
				label: "label",
				hiddenLabel: "hiddenLabel",
				color: "color",
				appearance: "appearance",
				icon: "icon",
				labelWaria: "labelWaria"
			},
			ngImport: i0,
			template: "<div class=\"callout {{ color }}\" [class.callout-highlight]=\"appearance === 'highlight'\" [class.callout-more]=\"appearance === 'more'\">\r\n  @if (appearance === 'default') {\r\n    <div class=\"callout-inner\">\r\n      <ng-container *ngTemplateOutlet=\"inner\"></ng-container>\r\n    </div>\r\n  } @else {\r\n    <ng-container *ngTemplateOutlet=\"inner\"></ng-container>\r\n  }\r\n</div>\r\n\r\n<ng-template #inner>\r\n  @if (label) {\r\n    <div class=\"callout-title\">\r\n      <it-icon [labelWaria]=\"labelWaria\" [name]=\"iconName\"></it-icon>\r\n      @if (hiddenLabel) {\r\n        <span class=\"visually-hidden\">{{ hiddenLabel }}</span>\r\n      }\r\n      <span class=\"text\">{{ label }}</span>\r\n    </div>\r\n  }\r\n  <p class=\"callout-big-text\">\r\n    <ng-content select=\"[bigText]\"></ng-content>\r\n  </p>\r\n  <ng-content></ng-content>\r\n</ng-template>\r\n",
			styles: [".callout-big-text:empty{display:none}\n"],
			dependencies: [{
				kind: "directive",
				type: NgTemplateOutlet,
				selector: "[ngTemplateOutlet]",
				inputs: [
					"ngTemplateOutletContext",
					"ngTemplateOutlet",
					"ngTemplateOutletInjector"
				]
			}, {
				kind: "component",
				type: ItIconComponent,
				selector: "it-icon",
				inputs: [
					"name",
					"size",
					"color",
					"padded",
					"svgClass",
					"title",
					"labelWaria"
				]
			}],
			changeDetection: i0.ChangeDetectionStrategy.OnPush
		});
	}
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.1",
	ngImport: i0,
	type: ItCalloutComponent,
	decorators: [{
		type: Component,
		args: [{
			selector: "it-callout",
			changeDetection: ChangeDetectionStrategy.OnPush,
			imports: [NgTemplateOutlet, ItIconComponent],
			template: "<div class=\"callout {{ color }}\" [class.callout-highlight]=\"appearance === 'highlight'\" [class.callout-more]=\"appearance === 'more'\">\r\n  @if (appearance === 'default') {\r\n    <div class=\"callout-inner\">\r\n      <ng-container *ngTemplateOutlet=\"inner\"></ng-container>\r\n    </div>\r\n  } @else {\r\n    <ng-container *ngTemplateOutlet=\"inner\"></ng-container>\r\n  }\r\n</div>\r\n\r\n<ng-template #inner>\r\n  @if (label) {\r\n    <div class=\"callout-title\">\r\n      <it-icon [labelWaria]=\"labelWaria\" [name]=\"iconName\"></it-icon>\r\n      @if (hiddenLabel) {\r\n        <span class=\"visually-hidden\">{{ hiddenLabel }}</span>\r\n      }\r\n      <span class=\"text\">{{ label }}</span>\r\n    </div>\r\n  }\r\n  <p class=\"callout-big-text\">\r\n    <ng-content select=\"[bigText]\"></ng-content>\r\n  </p>\r\n  <ng-content></ng-content>\r\n</ng-template>\r\n",
			styles: [".callout-big-text:empty{display:none}\n"]
		}]
	}],
	propDecorators: {
		label: [{ type: Input }],
		hiddenLabel: [{ type: Input }],
		color: [{ type: Input }],
		appearance: [{ type: Input }],
		icon: [{ type: Input }],
		labelWaria: [{ type: Input }]
	}
});
var ItCardComponent = class ItCardComponent extends ItAbstractComponent {
	constructor() {
		super(...arguments);
		this.border = true;
		this.cardClass = "";
		this.bodyClass = "";
		this.shadow = "sm";
	}
	static {
		this.ɵfac = i0.ɵɵngDeclareFactory({
			minVersion: "12.0.0",
			version: "22.2.1",
			ngImport: i0,
			type: ItCardComponent,
			deps: null,
			target: i0.ɵɵFactoryTarget.Component
		});
	}
	static {
		this.ɵcmp = i0.ɵɵngDeclareComponent({
			minVersion: "16.1.0",
			version: "22.2.1",
			type: ItCardComponent,
			isStandalone: true,
			selector: "it-card",
			inputs: {
				inline: [
					"inline",
					"inline",
					inputToBoolean
				],
				mini: [
					"mini",
					"mini",
					inputToBoolean
				],
				border: [
					"border",
					"border",
					inputToBoolean
				],
				banner: [
					"banner",
					"banner",
					inputToBoolean
				],
				profile: [
					"profile",
					"profile",
					inputToBoolean
				],
				rounded: [
					"rounded",
					"rounded",
					inputToBoolean
				],
				reverse: [
					"reverse",
					"reverse",
					inputToBoolean
				],
				fullHeight: [
					"fullHeight",
					"fullHeight",
					inputToBoolean
				],
				hasImage: [
					"hasImage",
					"hasImage",
					inputToBoolean
				],
				borderTop: [
					"borderTop",
					"borderTop",
					inputToBoolean
				],
				cardClass: "cardClass",
				bodyClass: "bodyClass",
				noPadding: [
					"noPadding",
					"noPadding",
					inputToBoolean
				],
				shadow: "shadow"
			},
			usesInheritance: true,
			ngImport: i0,
			template: "<ng-template #cardContent>\r\n  <ng-content select=\"[beforeBody]\"></ng-content>\r\n  <ng-content></ng-content>\r\n</ng-template>\r\n\r\n<article\r\n  class=\"it-card rounded {{ cardClass }}\"\r\n  [class.border]=\"border\"\r\n  [class.rounded]=\"rounded\"\r\n  [class.shadow-sm]=\"shadow === 'sm'\"\r\n  [class.shadow-lg]=\"shadow === 'lg'\"\r\n  [class.shadow]=\"shadow === 'normal'\"\r\n  [class.it-card-image]=\"hasImage\"\r\n  [class.it-card-height-full]=\"fullHeight\"\r\n  [class.it-card-inline]=\"inline\"\r\n  [class.it-card-inline-reverse]=\"reverse\"\r\n  [class.it-card-inline-mini]=\"mini\"\r\n  [class.it-card-banner]=\"banner\"\r\n  [class.it-card-profile]=\"profile\"\r\n  [class.it-card-border-top]=\"borderTop\"\r\n  [class.it-card-border-top-secondary]=\"borderTop\"\r\n  [class.p-0]=\"noPadding\">\r\n  <ng-container *ngTemplateOutlet=\"cardContent\"></ng-container>\r\n</article>\r\n",
			styles: [".card-body:empty{display:none}::ng-deep .row [class*=col-] .card,::ng-deep .row [class*=col-] .card-wrapper{height:100%}::ng-deep .card-wrapper.card-teaser-wrapper it-card{flex-direction:row;align-items:flex-start;flex:0 0 100%;flex-wrap:wrap;margin:16px 0}@media(min-width:768px){::ng-deep .card-wrapper.card-teaser-wrapper it-card{flex:0 0 49%}}:host{width:100%}\n"],
			dependencies: [{
				kind: "directive",
				type: NgTemplateOutlet,
				selector: "[ngTemplateOutlet]",
				inputs: [
					"ngTemplateOutletContext",
					"ngTemplateOutlet",
					"ngTemplateOutletInjector"
				]
			}],
			changeDetection: i0.ChangeDetectionStrategy.OnPush
		});
	}
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.1",
	ngImport: i0,
	type: ItCardComponent,
	decorators: [{
		type: Component,
		args: [{
			selector: "it-card",
			changeDetection: ChangeDetectionStrategy.OnPush,
			imports: [NgTemplateOutlet],
			template: "<ng-template #cardContent>\r\n  <ng-content select=\"[beforeBody]\"></ng-content>\r\n  <ng-content></ng-content>\r\n</ng-template>\r\n\r\n<article\r\n  class=\"it-card rounded {{ cardClass }}\"\r\n  [class.border]=\"border\"\r\n  [class.rounded]=\"rounded\"\r\n  [class.shadow-sm]=\"shadow === 'sm'\"\r\n  [class.shadow-lg]=\"shadow === 'lg'\"\r\n  [class.shadow]=\"shadow === 'normal'\"\r\n  [class.it-card-image]=\"hasImage\"\r\n  [class.it-card-height-full]=\"fullHeight\"\r\n  [class.it-card-inline]=\"inline\"\r\n  [class.it-card-inline-reverse]=\"reverse\"\r\n  [class.it-card-inline-mini]=\"mini\"\r\n  [class.it-card-banner]=\"banner\"\r\n  [class.it-card-profile]=\"profile\"\r\n  [class.it-card-border-top]=\"borderTop\"\r\n  [class.it-card-border-top-secondary]=\"borderTop\"\r\n  [class.p-0]=\"noPadding\">\r\n  <ng-container *ngTemplateOutlet=\"cardContent\"></ng-container>\r\n</article>\r\n",
			styles: [".card-body:empty{display:none}::ng-deep .row [class*=col-] .card,::ng-deep .row [class*=col-] .card-wrapper{height:100%}::ng-deep .card-wrapper.card-teaser-wrapper it-card{flex-direction:row;align-items:flex-start;flex:0 0 100%;flex-wrap:wrap;margin:16px 0}@media(min-width:768px){::ng-deep .card-wrapper.card-teaser-wrapper it-card{flex:0 0 49%}}:host{width:100%}\n"]
		}]
	}],
	propDecorators: {
		inline: [{
			type: Input,
			args: [{ transform: inputToBoolean }]
		}],
		mini: [{
			type: Input,
			args: [{ transform: inputToBoolean }]
		}],
		border: [{
			type: Input,
			args: [{ transform: inputToBoolean }]
		}],
		banner: [{
			type: Input,
			args: [{ transform: inputToBoolean }]
		}],
		profile: [{
			type: Input,
			args: [{ transform: inputToBoolean }]
		}],
		rounded: [{
			type: Input,
			args: [{ transform: inputToBoolean }]
		}],
		reverse: [{
			type: Input,
			args: [{ transform: inputToBoolean }]
		}],
		fullHeight: [{
			type: Input,
			args: [{ transform: inputToBoolean }]
		}],
		hasImage: [{
			type: Input,
			args: [{ transform: inputToBoolean }]
		}],
		borderTop: [{
			type: Input,
			args: [{ transform: inputToBoolean }]
		}],
		cardClass: [{ type: Input }],
		bodyClass: [{ type: Input }],
		noPadding: [{
			type: Input,
			args: [{ transform: inputToBoolean }]
		}],
		shadow: [{ type: Input }]
	}
});
var ItCarouselItemComponent = class ItCarouselItemComponent extends ItAbstractComponent {
	static {
		this.ɵfac = i0.ɵɵngDeclareFactory({
			minVersion: "12.0.0",
			version: "22.2.1",
			ngImport: i0,
			type: ItCarouselItemComponent,
			deps: null,
			target: i0.ɵɵFactoryTarget.Component
		});
	}
	static {
		this.ɵcmp = i0.ɵɵngDeclareComponent({
			minVersion: "14.0.0",
			version: "22.2.1",
			type: ItCarouselItemComponent,
			isStandalone: true,
			selector: "it-carousel-item",
			viewQueries: [{
				propertyName: "htmlContent",
				first: true,
				predicate: TemplateRef,
				descendants: true
			}],
			usesInheritance: true,
			ngImport: i0,
			template: "<ng-template>\r\n  <ng-content></ng-content>\r\n</ng-template>\r\n",
			changeDetection: i0.ChangeDetectionStrategy.OnPush
		});
	}
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.1",
	ngImport: i0,
	type: ItCarouselItemComponent,
	decorators: [{
		type: Component,
		args: [{
			selector: "it-carousel-item",
			changeDetection: ChangeDetectionStrategy.OnPush,
			imports: [],
			template: "<ng-template>\r\n  <ng-content></ng-content>\r\n</ng-template>\r\n"
		}]
	}],
	propDecorators: { htmlContent: [{
		type: ViewChild,
		args: [TemplateRef]
	}] }
});
var ItCarouselComponent = class ItCarouselComponent {
	constructor() {
		this._changeDetectorRef = inject(ChangeDetectorRef);
		this.type = "default";
		this.trackClass = "";
	}
	get typeClass() {
		return this.type === "default" ? "it-carousel-landscape-abstract" : `it-carousel-landscape-abstract-${this.type}`;
	}
	ngAfterViewInit() {
		this.items?.changes.pipe(startWith(void 0)).subscribe(() => {
			this.itemSubscriptions?.forEach((sub) => sub.unsubscribe());
			this.itemSubscriptions = this.items?.map((item) => item.valueChanges.subscribe(() => {
				this._changeDetectorRef.detectChanges();
			}));
			this._changeDetectorRef.detectChanges();
		});
		setTimeout(() => {
			this.carousel = Carousel.getOrCreateInstance(this.carouselDiv.nativeElement);
		}, 100);
	}
	ngOnDestroy() {
		this.itemSubscriptions?.forEach((item) => item.unsubscribe());
	}
	dispose() {
		this.carousel?.dispose();
	}
	static {
		this.ɵfac = i0.ɵɵngDeclareFactory({
			minVersion: "12.0.0",
			version: "22.2.1",
			ngImport: i0,
			type: ItCarouselComponent,
			deps: [],
			target: i0.ɵɵFactoryTarget.Component
		});
	}
	static {
		this.ɵcmp = i0.ɵɵngDeclareComponent({
			minVersion: "17.0.0",
			version: "22.2.1",
			type: ItCarouselComponent,
			isStandalone: true,
			selector: "it-carousel",
			inputs: {
				title: "title",
				type: "type",
				trackClass: "trackClass",
				fullCarousel: [
					"fullCarousel",
					"fullCarousel",
					inputToBoolean
				],
				bigImg: [
					"bigImg",
					"bigImg",
					inputToBoolean
				],
				standardImage: [
					"standardImage",
					"standardImage",
					inputToBoolean
				],
				lined: [
					"lined",
					"lined",
					inputToBoolean
				]
			},
			queries: [{
				propertyName: "items",
				predicate: ItCarouselItemComponent
			}],
			viewQueries: [{
				propertyName: "carouselDiv",
				first: true,
				predicate: ["carousel"],
				descendants: true
			}],
			exportAs: ["itCarousel"],
			ngImport: i0,
			template: "<div\r\n  #carousel\r\n  class=\"it-carousel-wrapper splide {{ typeClass }}\"\r\n  [class.it-full-carousel]=\"fullCarousel\"\r\n  [class.it-big-img]=\"bigImg\"\r\n  [class.it-standard-image]=\"standardImage\">\r\n  @if (title) {\r\n    <div class=\"it-header-block\">\r\n      <div class=\"it-header-block-title\">\r\n        <h2>{{ title }}</h2>\r\n      </div>\r\n    </div>\r\n  }\r\n\r\n  <div class=\"splide__track {{ trackClass }}\">\r\n    @if (items) {\r\n      <ul class=\"splide__list\">\r\n        @for (item of items; track item) {\r\n          <li class=\"splide__slide\" [class.lined_slide]=\"lined\">\r\n            <div class=\"it-single-slide-wrapper\">\r\n              <ng-container *ngTemplateOutlet=\"item.htmlContent\"></ng-container>\r\n            </div>\r\n          </li>\r\n        }\r\n      </ul>\r\n    }\r\n  </div>\r\n</div>\r\n",
			dependencies: [{
				kind: "directive",
				type: NgTemplateOutlet,
				selector: "[ngTemplateOutlet]",
				inputs: [
					"ngTemplateOutletContext",
					"ngTemplateOutlet",
					"ngTemplateOutletInjector"
				]
			}],
			changeDetection: i0.ChangeDetectionStrategy.OnPush
		});
	}
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.1",
	ngImport: i0,
	type: ItCarouselComponent,
	decorators: [{
		type: Component,
		args: [{
			selector: "it-carousel",
			exportAs: "itCarousel",
			changeDetection: ChangeDetectionStrategy.OnPush,
			imports: [NgTemplateOutlet],
			template: "<div\r\n  #carousel\r\n  class=\"it-carousel-wrapper splide {{ typeClass }}\"\r\n  [class.it-full-carousel]=\"fullCarousel\"\r\n  [class.it-big-img]=\"bigImg\"\r\n  [class.it-standard-image]=\"standardImage\">\r\n  @if (title) {\r\n    <div class=\"it-header-block\">\r\n      <div class=\"it-header-block-title\">\r\n        <h2>{{ title }}</h2>\r\n      </div>\r\n    </div>\r\n  }\r\n\r\n  <div class=\"splide__track {{ trackClass }}\">\r\n    @if (items) {\r\n      <ul class=\"splide__list\">\r\n        @for (item of items; track item) {\r\n          <li class=\"splide__slide\" [class.lined_slide]=\"lined\">\r\n            <div class=\"it-single-slide-wrapper\">\r\n              <ng-container *ngTemplateOutlet=\"item.htmlContent\"></ng-container>\r\n            </div>\r\n          </li>\r\n        }\r\n      </ul>\r\n    }\r\n  </div>\r\n</div>\r\n"
		}]
	}],
	propDecorators: {
		title: [{ type: Input }],
		type: [{ type: Input }],
		trackClass: [{ type: Input }],
		fullCarousel: [{
			type: Input,
			args: [{ transform: inputToBoolean }]
		}],
		bigImg: [{
			type: Input,
			args: [{ transform: inputToBoolean }]
		}],
		standardImage: [{
			type: Input,
			args: [{ transform: inputToBoolean }]
		}],
		lined: [{
			type: Input,
			args: [{ transform: inputToBoolean }]
		}],
		items: [{
			type: ContentChildren,
			args: [ItCarouselItemComponent]
		}],
		carouselDiv: [{
			type: ViewChild,
			args: ["carousel"]
		}]
	}
});
const carouselComponents = [ItCarouselComponent, ItCarouselItemComponent];
var ItCarouselModule = class ItCarouselModule {
	static {
		this.ɵfac = i0.ɵɵngDeclareFactory({
			minVersion: "12.0.0",
			version: "22.2.1",
			ngImport: i0,
			type: ItCarouselModule,
			deps: [],
			target: i0.ɵɵFactoryTarget.NgModule
		});
	}
	static {
		this.ɵmod = i0.ɵɵngDeclareNgModule({
			minVersion: "14.0.0",
			version: "22.2.1",
			ngImport: i0,
			type: ItCarouselModule,
			imports: [ItCarouselComponent, ItCarouselItemComponent],
			exports: [ItCarouselComponent, ItCarouselItemComponent]
		});
	}
	static {
		this.ɵinj = i0.ɵɵngDeclareInjector({
			minVersion: "12.0.0",
			version: "22.2.1",
			ngImport: i0,
			type: ItCarouselModule
		});
	}
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.1",
	ngImport: i0,
	type: ItCarouselModule,
	decorators: [{
		type: NgModule,
		args: [{
			imports: carouselComponents,
			exports: carouselComponents
		}]
	}]
});
var ItChipComponent = class ItChipComponent {
	set label(value) {
		this._label = value;
	}
	get label() {
		return this._label;
	}
	set showCloseButton(value) {
		this._showCloseButton = value;
	}
	get showCloseButton() {
		return this._showCloseButton;
	}
	set size(value) {
		this._size = value;
	}
	get size() {
		return this._size;
	}
	set color(value) {
		this._color = value;
	}
	get color() {
		return this._color;
	}
	set disabled(value) {
		this._disabled = value;
	}
	get disabled() {
		return this._disabled;
	}
	set icon(value) {
		this._icon = value;
	}
	get icon() {
		return this._icon;
	}
	set avatar(value) {
		this._avatar = value;
	}
	get avatar() {
		return this._avatar;
	}
	set altAvatar(value) {
		this._altAvatar = value;
	}
	get altAvatar() {
		return this._altAvatar;
	}
	get iconHref() {
		return `${this.assetBasePath}/dist/svg/sprites.svg#it-${this._icon}`;
	}
	get iconCloseHref() {
		return `${this.assetBasePath}/dist/svg/sprites.svg#it-${this.iconClose}`;
	}
	constructor() {
		this._label = "";
		this._showCloseButton = false;
		this._size = "";
		this._color = void 0;
		this._disabled = false;
		this._icon = void 0;
		this._avatar = void 0;
		this._altAvatar = "";
		this.closeEvent = new EventEmitter();
		this.iconClose = "close";
		this.assetBasePath = inject(IT_ASSET_BASE_PATH);
	}
	clickToClose() {
		this.closeEvent.emit();
	}
	static {
		this.ɵfac = i0.ɵɵngDeclareFactory({
			minVersion: "12.0.0",
			version: "22.2.1",
			ngImport: i0,
			type: ItChipComponent,
			deps: [],
			target: i0.ɵɵFactoryTarget.Component
		});
	}
	static {
		this.ɵcmp = i0.ɵɵngDeclareComponent({
			minVersion: "17.0.0",
			version: "22.2.1",
			type: ItChipComponent,
			isStandalone: true,
			selector: "it-chip",
			inputs: {
				label: "label",
				showCloseButton: "showCloseButton",
				size: "size",
				color: "color",
				disabled: "disabled",
				icon: "icon",
				avatar: "avatar",
				altAvatar: "altAvatar"
			},
			outputs: { closeEvent: "closeEvent" },
			host: { styleAttribute: "display: inline-block; vertical-align: middle" },
			ngImport: i0,
			template: "<div\r\n  class=\"chip\"\r\n  [ngClass]=\"[\r\n    !showCloseButton ? 'chip-simple' : 'alert',\r\n    size === 'lg' ? 'chip-lg' : '',\r\n    color ? 'chip-' + color : '',\r\n    disabled ? 'chip-disabled' : '',\r\n  ]\">\r\n  @if (icon) {\r\n    <svg class=\"icon icon-xs\">\r\n      <use [attr.href]=\"iconHref\" [attr.xlink:href]=\"iconHref\"></use>\r\n    </svg>\r\n  }\r\n  @if (avatar) {\r\n    <div class=\"avatar size-xs\"><img [src]=\"avatar\" [alt]=\"altAvatar\" /></div>\r\n  }\r\n  <span class=\"chip-label\">{{ label }}</span>\r\n  @if (showCloseButton) {\r\n    <button (click)=\"clickToClose()\" [disabled]=\"disabled\">\r\n      <svg class=\"icon\">\r\n        <use [attr.href]=\"iconCloseHref\" [attr.xlink:href]=\"iconCloseHref\"></use>\r\n      </svg>\r\n      <span class=\"visually-hidden\">{{ 'it.core.remove' | translate }} {{ label }}</span>\r\n    </button>\r\n  }\r\n</div>\r\n",
			dependencies: [
				{
					kind: "directive",
					type: NgClass,
					selector: "[ngClass]",
					inputs: ["class", "ngClass"]
				},
				{
					kind: "ngmodule",
					type: TranslateModule
				},
				{
					kind: "pipe",
					type: i1$1.TranslatePipe,
					name: "translate"
				}
			],
			changeDetection: i0.ChangeDetectionStrategy.OnPush
		});
	}
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.1",
	ngImport: i0,
	type: ItChipComponent,
	decorators: [{
		type: Component,
		args: [{
			selector: "it-chip",
			changeDetection: ChangeDetectionStrategy.OnPush,
			imports: [NgClass, TranslateModule],
			host: { style: "display: inline-block; vertical-align: middle" },
			template: "<div\r\n  class=\"chip\"\r\n  [ngClass]=\"[\r\n    !showCloseButton ? 'chip-simple' : 'alert',\r\n    size === 'lg' ? 'chip-lg' : '',\r\n    color ? 'chip-' + color : '',\r\n    disabled ? 'chip-disabled' : '',\r\n  ]\">\r\n  @if (icon) {\r\n    <svg class=\"icon icon-xs\">\r\n      <use [attr.href]=\"iconHref\" [attr.xlink:href]=\"iconHref\"></use>\r\n    </svg>\r\n  }\r\n  @if (avatar) {\r\n    <div class=\"avatar size-xs\"><img [src]=\"avatar\" [alt]=\"altAvatar\" /></div>\r\n  }\r\n  <span class=\"chip-label\">{{ label }}</span>\r\n  @if (showCloseButton) {\r\n    <button (click)=\"clickToClose()\" [disabled]=\"disabled\">\r\n      <svg class=\"icon\">\r\n        <use [attr.href]=\"iconCloseHref\" [attr.xlink:href]=\"iconCloseHref\"></use>\r\n      </svg>\r\n      <span class=\"visually-hidden\">{{ 'it.core.remove' | translate }} {{ label }}</span>\r\n    </button>\r\n  }\r\n</div>\r\n"
		}]
	}],
	ctorParameters: () => [],
	propDecorators: {
		label: [{ type: Input }],
		showCloseButton: [{ type: Input }],
		size: [{ type: Input }],
		color: [{ type: Input }],
		disabled: [{ type: Input }],
		icon: [{ type: Input }],
		avatar: [{ type: Input }],
		altAvatar: [{ type: Input }],
		closeEvent: [{ type: Output }]
	}
});
var ItDimmerComponent = class ItDimmerComponent {
	constructor() {
		this.elementRef = inject(ElementRef);
		this._active = false;
		this._color = "";
	}
	set active(value) {
		this._active = value;
	}
	get active() {
		return this._active;
	}
	set color(value) {
		this._color = value;
	}
	get color() {
		return this._color;
	}
	ngOnInit() {
		this.elementRef?.nativeElement?.parentElement?.classList?.add("dimmable");
	}
	static {
		this.ɵfac = i0.ɵɵngDeclareFactory({
			minVersion: "12.0.0",
			version: "22.2.1",
			ngImport: i0,
			type: ItDimmerComponent,
			deps: [],
			target: i0.ɵɵFactoryTarget.Component
		});
	}
	static {
		this.ɵcmp = i0.ɵɵngDeclareComponent({
			minVersion: "17.0.0",
			version: "22.2.1",
			type: ItDimmerComponent,
			isStandalone: true,
			selector: "it-dimmer",
			inputs: {
				active: "active",
				color: "color"
			},
			ngImport: i0,
			template: "@if (active) {\r\n  <div class=\"dimmer\" @fade [ngClass]=\"[color, 'show']\">\r\n    <div class=\"dimmer-inner\">\r\n      <ng-content></ng-content>\r\n    </div>\r\n  </div>\r\n}\r\n",
			dependencies: [{
				kind: "directive",
				type: NgClass,
				selector: "[ngClass]",
				inputs: ["class", "ngClass"]
			}],
			animations: [trigger("fade", [transition(":enter", [style({ opacity: 0 }), animate("150ms", style({ opacity: .9 }))]), transition(":leave", [animate("150ms", style({ opacity: 0 }))])])],
			changeDetection: i0.ChangeDetectionStrategy.OnPush
		});
	}
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.1",
	ngImport: i0,
	type: ItDimmerComponent,
	decorators: [{
		type: Component,
		args: [{
			selector: "it-dimmer",
			changeDetection: ChangeDetectionStrategy.OnPush,
			animations: [trigger("fade", [transition(":enter", [style({ opacity: 0 }), animate("150ms", style({ opacity: .9 }))]), transition(":leave", [animate("150ms", style({ opacity: 0 }))])])],
			imports: [NgClass],
			template: "@if (active) {\r\n  <div class=\"dimmer\" @fade [ngClass]=\"[color, 'show']\">\r\n    <div class=\"dimmer-inner\">\r\n      <ng-content></ng-content>\r\n    </div>\r\n  </div>\r\n}\r\n"
		}]
	}],
	propDecorators: {
		active: [{ type: Input }],
		color: [{ type: Input }]
	}
});
var ItDimmerIconComponent = class ItDimmerIconComponent {
	static {
		this.ɵfac = i0.ɵɵngDeclareFactory({
			minVersion: "12.0.0",
			version: "22.2.1",
			ngImport: i0,
			type: ItDimmerIconComponent,
			deps: [],
			target: i0.ɵɵFactoryTarget.Component
		});
	}
	static {
		this.ɵcmp = i0.ɵɵngDeclareComponent({
			minVersion: "14.0.0",
			version: "22.2.1",
			type: ItDimmerIconComponent,
			isStandalone: true,
			selector: "it-dimmer-icon",
			ngImport: i0,
			template: "<div class=\"dimmer-icon\">\r\n  <ng-content></ng-content>\r\n</div>\r\n",
			changeDetection: i0.ChangeDetectionStrategy.OnPush
		});
	}
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.1",
	ngImport: i0,
	type: ItDimmerIconComponent,
	decorators: [{
		type: Component,
		args: [{
			selector: "it-dimmer-icon",
			changeDetection: ChangeDetectionStrategy.OnPush,
			imports: [],
			template: "<div class=\"dimmer-icon\">\r\n  <ng-content></ng-content>\r\n</div>\r\n"
		}]
	}]
});
var ItDimmerButtonsComponent = class ItDimmerButtonsComponent {
	constructor() {
		this._hasOneButton = false;
	}
	set hasOneButton(value) {
		this._hasOneButton = value;
	}
	get hasOneButton() {
		return this._hasOneButton;
	}
	static {
		this.ɵfac = i0.ɵɵngDeclareFactory({
			minVersion: "12.0.0",
			version: "22.2.1",
			ngImport: i0,
			type: ItDimmerButtonsComponent,
			deps: [],
			target: i0.ɵɵFactoryTarget.Component
		});
	}
	static {
		this.ɵcmp = i0.ɵɵngDeclareComponent({
			minVersion: "14.0.0",
			version: "22.2.1",
			type: ItDimmerButtonsComponent,
			isStandalone: true,
			selector: "it-dimmer-buttons",
			inputs: { hasOneButton: "hasOneButton" },
			ngImport: i0,
			template: "<div class=\"dimmer-buttons bg-dark\" [ngClass]=\"{ 'single-button': hasOneButton }\">\r\n  <ng-content></ng-content>\r\n</div>\r\n",
			dependencies: [{
				kind: "directive",
				type: NgClass,
				selector: "[ngClass]",
				inputs: ["class", "ngClass"]
			}],
			changeDetection: i0.ChangeDetectionStrategy.OnPush
		});
	}
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.1",
	ngImport: i0,
	type: ItDimmerButtonsComponent,
	decorators: [{
		type: Component,
		args: [{
			selector: "it-dimmer-buttons",
			changeDetection: ChangeDetectionStrategy.OnPush,
			imports: [NgClass],
			template: "<div class=\"dimmer-buttons bg-dark\" [ngClass]=\"{ 'single-button': hasOneButton }\">\r\n  <ng-content></ng-content>\r\n</div>\r\n"
		}]
	}],
	propDecorators: { hasOneButton: [{ type: Input }] }
});
const dimmerComponents = [
	ItDimmerComponent,
	ItDimmerIconComponent,
	ItDimmerButtonsComponent
];
var ItDimmerModule = class ItDimmerModule {
	static {
		this.ɵfac = i0.ɵɵngDeclareFactory({
			minVersion: "12.0.0",
			version: "22.2.1",
			ngImport: i0,
			type: ItDimmerModule,
			deps: [],
			target: i0.ɵɵFactoryTarget.NgModule
		});
	}
	static {
		this.ɵmod = i0.ɵɵngDeclareNgModule({
			minVersion: "14.0.0",
			version: "22.2.1",
			ngImport: i0,
			type: ItDimmerModule,
			imports: [
				ItDimmerComponent,
				ItDimmerIconComponent,
				ItDimmerButtonsComponent
			],
			exports: [
				ItDimmerComponent,
				ItDimmerIconComponent,
				ItDimmerButtonsComponent
			]
		});
	}
	static {
		this.ɵinj = i0.ɵɵngDeclareInjector({
			minVersion: "12.0.0",
			version: "22.2.1",
			ngImport: i0,
			type: ItDimmerModule
		});
	}
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.1",
	ngImport: i0,
	type: ItDimmerModule,
	decorators: [{
		type: NgModule,
		args: [{
			imports: dimmerComponents,
			exports: dimmerComponents
		}]
	}]
});
var ItForwardDirective = class ItForwardDirective {
	constructor() {
		this.document = inject(DOCUMENT);
		this._itForward = void 0;
	}
	set itForward(value) {
		this._itForward = value;
	}
	get itForward() {
		return this._itForward;
	}
	onClick(event) {
		event.preventDefault();
		if (this.itForward) {
			if (typeof this.itForward === "string") this.document?.querySelector(this.itForward)?.scrollIntoView({
				behavior: "smooth",
				block: "start",
				inline: "nearest"
			});
			else if (this.itForward instanceof HTMLElement) this.itForward.scrollIntoView({
				behavior: "smooth",
				block: "start",
				inline: "nearest"
			});
		}
	}
	static {
		this.ɵfac = i0.ɵɵngDeclareFactory({
			minVersion: "12.0.0",
			version: "22.2.1",
			ngImport: i0,
			type: ItForwardDirective,
			deps: [],
			target: i0.ɵɵFactoryTarget.Directive
		});
	}
	static {
		this.ɵdir = i0.ɵɵngDeclareDirective({
			minVersion: "14.0.0",
			version: "22.2.1",
			type: ItForwardDirective,
			isStandalone: true,
			selector: "[itForward]",
			inputs: { itForward: "itForward" },
			host: {
				listeners: { "click": "onClick($event)" },
				classAttribute: "forward"
			},
			ngImport: i0
		});
	}
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.1",
	ngImport: i0,
	type: ItForwardDirective,
	decorators: [{
		type: Directive,
		args: [{
			standalone: true,
			selector: "[itForward]",
			host: { class: "forward" }
		}]
	}],
	propDecorators: {
		itForward: [{ type: Input }],
		onClick: [{
			type: HostListener,
			args: ["click", ["$event"]]
		}]
	}
});
var ItListComponent = class ItListComponent {
	static {
		this.ɵfac = i0.ɵɵngDeclareFactory({
			minVersion: "12.0.0",
			version: "22.2.1",
			ngImport: i0,
			type: ItListComponent,
			deps: [],
			target: i0.ɵɵFactoryTarget.Component
		});
	}
	static {
		this.ɵcmp = i0.ɵɵngDeclareComponent({
			minVersion: "17.0.0",
			version: "22.2.1",
			type: ItListComponent,
			isStandalone: true,
			selector: "it-list",
			inputs: {
				linkList: [
					"linkList",
					"linkList",
					inputToBoolean
				],
				linkSubList: [
					"linkSubList",
					"linkSubList",
					inputToBoolean
				],
				multiline: [
					"multiline",
					"multiline",
					inputToBoolean
				]
			},
			ngImport: i0,
			template: "@if (!linkSubList) {\r\n  <div [class.multiline]=\"multiline\" [class]=\"linkList ? 'link-list-wrapper' : 'it-list-wrapper'\">\r\n    <ul [class]=\"linkList ? 'link-list' : 'it-list'\">\r\n      <ng-container *ngTemplateOutlet=\"contentTpl\"></ng-container>\r\n    </ul>\r\n  </div>\r\n}\r\n@if (linkSubList) {\r\n  <ul class=\"link-sublist\">\r\n    <ng-container *ngTemplateOutlet=\"contentTpl\"></ng-container>\r\n  </ul>\r\n}\r\n<ng-template #contentTpl><ng-content></ng-content></ng-template>\r\n",
			dependencies: [{
				kind: "directive",
				type: NgTemplateOutlet,
				selector: "[ngTemplateOutlet]",
				inputs: [
					"ngTemplateOutletContext",
					"ngTemplateOutlet",
					"ngTemplateOutletInjector"
				]
			}],
			changeDetection: i0.ChangeDetectionStrategy.OnPush
		});
	}
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.1",
	ngImport: i0,
	type: ItListComponent,
	decorators: [{
		type: Component,
		args: [{
			selector: "it-list",
			changeDetection: ChangeDetectionStrategy.OnPush,
			imports: [NgTemplateOutlet],
			template: "@if (!linkSubList) {\r\n  <div [class.multiline]=\"multiline\" [class]=\"linkList ? 'link-list-wrapper' : 'it-list-wrapper'\">\r\n    <ul [class]=\"linkList ? 'link-list' : 'it-list'\">\r\n      <ng-container *ngTemplateOutlet=\"contentTpl\"></ng-container>\r\n    </ul>\r\n  </div>\r\n}\r\n@if (linkSubList) {\r\n  <ul class=\"link-sublist\">\r\n    <ng-container *ngTemplateOutlet=\"contentTpl\"></ng-container>\r\n  </ul>\r\n}\r\n<ng-template #contentTpl><ng-content></ng-content></ng-template>\r\n"
		}]
	}],
	propDecorators: {
		linkList: [{
			type: Input,
			args: [{ transform: inputToBoolean }]
		}],
		linkSubList: [{
			type: Input,
			args: [{ transform: inputToBoolean }]
		}],
		multiline: [{
			type: Input,
			args: [{ transform: inputToBoolean }]
		}]
	}
});
var ItListItemComponent = class ItListItemComponent extends ItLinkComponent {
	constructor() {
		super(...arguments);
		this.elRef = inject(ElementRef);
		this.isHostElement = false;
	}
	get avatar() {
		console.warn(`L'input 'avatar' è deprecato. Usa la documentazione del component Avatar per questo caso d'uso, facendo riferimento all'esempio Avatar con lista. Sarà rimosso nelle prossime versioni.`);
		return this._avatar;
	}
	set avatar(value) {
		this._avatar = value;
	}
	get itemClass() {
		const inSidebar = this.elRef.nativeElement.closest(".sidebar-linklist-wrapper") ? true : false;
		let itemClass = "list-item";
		if (this.disabled) itemClass += ` disabled`;
		if (this.active) itemClass += ` active`;
		if (this.size) itemClass += ` ${this.size}`;
		if (this.iconLeft) itemClass += inSidebar ? ` left-icon` : ` icon-left`;
		if (this.iconRight) itemClass += inSidebar ? ` right-icon` : ` icon-right`;
		if (this.class) itemClass += ` ${this.class}`;
		return itemClass;
	}
	ngOnInit() {
		this.isHostElement = this.elRef.nativeElement.tagName.toLowerCase() === "li";
		if (!this.isHostElement) console.warn(`L'utilizzo del componente attraverso il selettore it-list-item verrà deprecato in quanto non accessibile. Usa il selettore itListItem invece. Consulta la documentazione del component Lista.`);
	}
	static {
		this.ɵfac = i0.ɵɵngDeclareFactory({
			minVersion: "12.0.0",
			version: "22.2.1",
			ngImport: i0,
			type: ItListItemComponent,
			deps: null,
			target: i0.ɵɵFactoryTarget.Component
		});
	}
	static {
		this.ɵcmp = i0.ɵɵngDeclareComponent({
			minVersion: "17.0.0",
			version: "22.2.1",
			type: ItListItemComponent,
			isStandalone: true,
			selector: "it-list-item, li[itListItem]",
			inputs: {
				active: [
					"active",
					"active",
					inputToBoolean
				],
				size: "size",
				iconLeft: [
					"iconLeft",
					"iconLeft",
					inputToBoolean
				],
				iconRight: [
					"iconRight",
					"iconRight",
					inputToBoolean
				],
				avatar: "avatar",
				image: "image"
			},
			usesInheritance: true,
			ngImport: i0,
			template: "@if (isHostElement) {\r\n  <ng-container *ngTemplateOutlet=\"structure\"></ng-container>\r\n} @else {\r\n  <li>\r\n    <ng-container *ngTemplateOutlet=\"structure\"></ng-container>\r\n  </li>\r\n}\r\n\r\n<ng-template #structure>\r\n  @if (!href) {\r\n    <div [class]=\"itemClass\">\r\n      <ng-container *ngTemplateOutlet=\"content\"></ng-container>\r\n    </div>\r\n  } @else {\r\n    <it-link [class]=\"itemClass\" [href]=\"href\" [externalLink]=\"!!externalLink\" [disabled]=\"!!disabled\">\r\n      <ng-container *ngTemplateOutlet=\"content\"></ng-container>\r\n    </it-link>\r\n  }\r\n</ng-template>\r\n\r\n<ng-template #content>\r\n  <div class=\"it-rounded-icon\">\r\n    <ng-content select=\"[icon]\"></ng-content>\r\n  </div>\r\n\r\n  @if (avatar) {\r\n    <div class=\"avatar size-lg\">\r\n      <img [attr.src]=\"avatar\" alt=\"avatar\" />\r\n    </div>\r\n  }\r\n\r\n  @if (image) {\r\n    <div class=\"it-thumb\">\r\n      <img [attr.src]=\"image\" alt=\"thumb\" />\r\n    </div>\r\n  }\r\n\r\n  <div class=\"it-right-zone\">\r\n    <ng-content></ng-content>\r\n    <ng-content select=\"[action]\"></ng-content>\r\n\r\n    <span class=\"it-multiple\">\r\n      <span class=\"metadata\">\r\n        <ng-content select=\"[metadata]\"></ng-content>\r\n      </span>\r\n\r\n      <ng-content select=\"[multiple]\"></ng-content>\r\n    </span>\r\n  </div>\r\n</ng-template>\r\n",
			styles: [".metadata:empty,.it-rounded-icon:empty{display:none}:host ::ng-deep it-icon+.it-multiple{display:none!important}:host ::ng-deep .list-item-title-icon-wrapper+.it-multiple{display:none!important}:host ::ng-deep p+.it-multiple{display:none!important}\n"],
			dependencies: [{
				kind: "directive",
				type: NgTemplateOutlet,
				selector: "[ngTemplateOutlet]",
				inputs: [
					"ngTemplateOutletContext",
					"ngTemplateOutlet",
					"ngTemplateOutletInjector"
				]
			}, {
				kind: "component",
				type: ItLinkComponent,
				selector: "it-link",
				inputs: [
					"href",
					"externalLink",
					"disabled",
					"class"
				]
			}],
			changeDetection: i0.ChangeDetectionStrategy.OnPush
		});
	}
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.1",
	ngImport: i0,
	type: ItListItemComponent,
	decorators: [{
		type: Component,
		args: [{
			selector: "it-list-item, li[itListItem]",
			changeDetection: ChangeDetectionStrategy.OnPush,
			imports: [NgTemplateOutlet, ItLinkComponent],
			template: "@if (isHostElement) {\r\n  <ng-container *ngTemplateOutlet=\"structure\"></ng-container>\r\n} @else {\r\n  <li>\r\n    <ng-container *ngTemplateOutlet=\"structure\"></ng-container>\r\n  </li>\r\n}\r\n\r\n<ng-template #structure>\r\n  @if (!href) {\r\n    <div [class]=\"itemClass\">\r\n      <ng-container *ngTemplateOutlet=\"content\"></ng-container>\r\n    </div>\r\n  } @else {\r\n    <it-link [class]=\"itemClass\" [href]=\"href\" [externalLink]=\"!!externalLink\" [disabled]=\"!!disabled\">\r\n      <ng-container *ngTemplateOutlet=\"content\"></ng-container>\r\n    </it-link>\r\n  }\r\n</ng-template>\r\n\r\n<ng-template #content>\r\n  <div class=\"it-rounded-icon\">\r\n    <ng-content select=\"[icon]\"></ng-content>\r\n  </div>\r\n\r\n  @if (avatar) {\r\n    <div class=\"avatar size-lg\">\r\n      <img [attr.src]=\"avatar\" alt=\"avatar\" />\r\n    </div>\r\n  }\r\n\r\n  @if (image) {\r\n    <div class=\"it-thumb\">\r\n      <img [attr.src]=\"image\" alt=\"thumb\" />\r\n    </div>\r\n  }\r\n\r\n  <div class=\"it-right-zone\">\r\n    <ng-content></ng-content>\r\n    <ng-content select=\"[action]\"></ng-content>\r\n\r\n    <span class=\"it-multiple\">\r\n      <span class=\"metadata\">\r\n        <ng-content select=\"[metadata]\"></ng-content>\r\n      </span>\r\n\r\n      <ng-content select=\"[multiple]\"></ng-content>\r\n    </span>\r\n  </div>\r\n</ng-template>\r\n",
			styles: [".metadata:empty,.it-rounded-icon:empty{display:none}:host ::ng-deep it-icon+.it-multiple{display:none!important}:host ::ng-deep .list-item-title-icon-wrapper+.it-multiple{display:none!important}:host ::ng-deep p+.it-multiple{display:none!important}\n"]
		}]
	}],
	propDecorators: {
		active: [{
			type: Input,
			args: [{ transform: inputToBoolean }]
		}],
		size: [{ type: Input }],
		iconLeft: [{
			type: Input,
			args: [{ transform: inputToBoolean }]
		}],
		iconRight: [{
			type: Input,
			args: [{ transform: inputToBoolean }]
		}],
		avatar: [{ type: Input }],
		image: [{ type: Input }]
	}
});
const listComponents = [ItListComponent, ItListItemComponent];
var ItListModule = class ItListModule {
	static {
		this.ɵfac = i0.ɵɵngDeclareFactory({
			minVersion: "12.0.0",
			version: "22.2.1",
			ngImport: i0,
			type: ItListModule,
			deps: [],
			target: i0.ɵɵFactoryTarget.NgModule
		});
	}
	static {
		this.ɵmod = i0.ɵɵngDeclareNgModule({
			minVersion: "14.0.0",
			version: "22.2.1",
			ngImport: i0,
			type: ItListModule,
			imports: [ItListComponent, ItListItemComponent],
			exports: [ItListComponent, ItListItemComponent]
		});
	}
	static {
		this.ɵinj = i0.ɵɵngDeclareInjector({
			minVersion: "12.0.0",
			version: "22.2.1",
			ngImport: i0,
			type: ItListModule
		});
	}
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.1",
	ngImport: i0,
	type: ItListModule,
	decorators: [{
		type: NgModule,
		args: [{
			imports: listComponents,
			exports: listComponents
		}]
	}]
});
var ItModalComponent = class ItModalComponent extends ItAbstractComponent {
	constructor() {
		super(...arguments);
		this.closeButton = true;
		this.fade = true;
		this.backdrop = true;
		this.focus = true;
		this.keyboard = true;
		this.showEvent = new EventEmitter();
		this.shownEvent = new EventEmitter();
		this.hideEvent = new EventEmitter();
		this.hiddenEvent = new EventEmitter();
		this.hidePreventedEvent = new EventEmitter();
	}
	ngAfterViewInit() {
		super.ngAfterViewInit();
		this._renderer.removeAttribute(this._elementRef.nativeElement, "title");
		if (this.modalElement) {
			const element = this.modalElement.nativeElement;
			this.modal = Modal.getOrCreateInstance(element, {
				...this.options,
				backdrop: this.backdrop === "static" ? "static" : this.backdrop,
				focus: this.focus,
				keyboard: this.keyboard
			});
			element.addEventListener("show.bs.modal", (event) => this.showEvent.emit(event));
			element.addEventListener("shown.bs.modal", (event) => this.shownEvent.emit(event));
			element.addEventListener("hide.bs.modal", (event) => this.hideEvent.emit(event));
			element.addEventListener("hidden.bs.modal", (event) => this.hiddenEvent.emit(event));
			element.addEventListener("hidePrevented.bs.modal", (event) => this.hidePreventedEvent.emit(event));
		}
	}
	get modalClass() {
		let modalClass = "modal";
		if (this.fade) modalClass += ` fade`;
		if (this.alertModal) modalClass += ` alert-modal`;
		if (this.dialogLinkList) modalClass += ` it-dialog-link-list`;
		if (this.popconfirm) modalClass += ` popconfirm-modal`;
		if (this.scrollable) modalClass += ` it-dialog-scrollable`;
		return modalClass;
	}
	get dialogClass() {
		let dialogClass = "modal-dialog";
		if (this.alignment) dialogClass += ` modal-dialog-${this.alignment}`;
		if (this.size) dialogClass += ` modal-${this.size}`;
		return dialogClass;
	}
	toggle() {
		this.modal?.toggle();
	}
	show() {
		this.modal?.show();
	}
	hide() {
		this.modal?.hide();
	}
	handleUpdate() {
		this.modal?.handleUpdate();
	}
	dispose() {
		this.modal?.dispose();
	}
	static {
		this.ɵfac = i0.ɵɵngDeclareFactory({
			minVersion: "12.0.0",
			version: "22.2.1",
			ngImport: i0,
			type: ItModalComponent,
			deps: null,
			target: i0.ɵɵFactoryTarget.Component
		});
	}
	static {
		this.ɵcmp = i0.ɵɵngDeclareComponent({
			minVersion: "17.0.0",
			version: "22.2.1",
			type: ItModalComponent,
			isStandalone: true,
			selector: "it-modal",
			inputs: {
				closeButton: [
					"closeButton",
					"closeButton",
					inputToBoolean
				],
				alertModal: [
					"alertModal",
					"alertModal",
					inputToBoolean
				],
				dialogLinkList: [
					"dialogLinkList",
					"dialogLinkList",
					inputToBoolean
				],
				popconfirm: [
					"popconfirm",
					"popconfirm",
					inputToBoolean
				],
				scrollable: [
					"scrollable",
					"scrollable",
					inputToBoolean
				],
				fade: [
					"fade",
					"fade",
					inputToBoolean
				],
				alignment: "alignment",
				size: "size",
				backdrop: "backdrop",
				focus: [
					"focus",
					"focus",
					inputToBoolean
				],
				keyboard: [
					"keyboard",
					"keyboard",
					inputToBoolean
				],
				footerShadow: [
					"footerShadow",
					"footerShadow",
					inputToBoolean
				],
				options: "options"
			},
			outputs: {
				showEvent: "showEvent",
				shownEvent: "shownEvent",
				hideEvent: "hideEvent",
				hiddenEvent: "hiddenEvent",
				hidePreventedEvent: "hidePreventedEvent"
			},
			viewQueries: [{
				propertyName: "modalElement",
				first: true,
				predicate: ["modalElement"],
				descendants: true
			}],
			exportAs: ["itModal"],
			usesInheritance: true,
			ngImport: i0,
			template: "<div\r\n  #modalElement\r\n  [id]=\"id\"\r\n  [class]=\"modalClass\"\r\n  tabindex=\"-1\"\r\n  role=\"dialog\"\r\n  aria-hidden=\"true\"\r\n  [attr.aria-labelledby]=\"id + '-title'\"\r\n  [attr.aria-describedby]=\"id + '-description'\">\r\n  <div [class]=\"dialogClass\">\r\n    <div class=\"modal-content\" role=\"document\">\r\n      <div class=\"modal-header\">\r\n        <ng-content select=\"[beforeTitle]\"></ng-content>\r\n\r\n        <h2 class=\"modal-title h5\" id=\"{{ id }}-title\">\r\n          <ng-content select=\"[modalTitle]\"></ng-content>\r\n        </h2>\r\n\r\n        @if (closeButton) {\r\n          <button type=\"button\" class=\"btn-close\" data-bs-dismiss=\"modal\" [attr.aria-label]=\"'it.core.close-modal' | translate\"></button>\r\n        }\r\n      </div>\r\n\r\n      <div class=\"modal-body\">\r\n        <div id=\"{{ id }}-description\">\r\n          <ng-content select=\"[description]\"></ng-content>\r\n        </div>\r\n        <ng-content></ng-content>\r\n      </div>\r\n\r\n      <div class=\"modal-footer\" [class.modal-footer-shadow]=\"footerShadow\">\r\n        <ng-content select=\"[footer]\"></ng-content>\r\n      </div>\r\n    </div>\r\n  </div>\r\n</div>\r\n",
			styles: [".modal-footer:empty{display:none}\n"],
			dependencies: [{
				kind: "ngmodule",
				type: TranslateModule
			}, {
				kind: "pipe",
				type: i1$1.TranslatePipe,
				name: "translate"
			}],
			changeDetection: i0.ChangeDetectionStrategy.OnPush
		});
	}
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.1",
	ngImport: i0,
	type: ItModalComponent,
	decorators: [{
		type: Component,
		args: [{
			selector: "it-modal",
			exportAs: "itModal",
			changeDetection: ChangeDetectionStrategy.OnPush,
			imports: [TranslateModule],
			template: "<div\r\n  #modalElement\r\n  [id]=\"id\"\r\n  [class]=\"modalClass\"\r\n  tabindex=\"-1\"\r\n  role=\"dialog\"\r\n  aria-hidden=\"true\"\r\n  [attr.aria-labelledby]=\"id + '-title'\"\r\n  [attr.aria-describedby]=\"id + '-description'\">\r\n  <div [class]=\"dialogClass\">\r\n    <div class=\"modal-content\" role=\"document\">\r\n      <div class=\"modal-header\">\r\n        <ng-content select=\"[beforeTitle]\"></ng-content>\r\n\r\n        <h2 class=\"modal-title h5\" id=\"{{ id }}-title\">\r\n          <ng-content select=\"[modalTitle]\"></ng-content>\r\n        </h2>\r\n\r\n        @if (closeButton) {\r\n          <button type=\"button\" class=\"btn-close\" data-bs-dismiss=\"modal\" [attr.aria-label]=\"'it.core.close-modal' | translate\"></button>\r\n        }\r\n      </div>\r\n\r\n      <div class=\"modal-body\">\r\n        <div id=\"{{ id }}-description\">\r\n          <ng-content select=\"[description]\"></ng-content>\r\n        </div>\r\n        <ng-content></ng-content>\r\n      </div>\r\n\r\n      <div class=\"modal-footer\" [class.modal-footer-shadow]=\"footerShadow\">\r\n        <ng-content select=\"[footer]\"></ng-content>\r\n      </div>\r\n    </div>\r\n  </div>\r\n</div>\r\n",
			styles: [".modal-footer:empty{display:none}\n"]
		}]
	}],
	propDecorators: {
		closeButton: [{
			type: Input,
			args: [{ transform: inputToBoolean }]
		}],
		alertModal: [{
			type: Input,
			args: [{ transform: inputToBoolean }]
		}],
		dialogLinkList: [{
			type: Input,
			args: [{ transform: inputToBoolean }]
		}],
		popconfirm: [{
			type: Input,
			args: [{ transform: inputToBoolean }]
		}],
		scrollable: [{
			type: Input,
			args: [{ transform: inputToBoolean }]
		}],
		fade: [{
			type: Input,
			args: [{ transform: inputToBoolean }]
		}],
		alignment: [{ type: Input }],
		size: [{ type: Input }],
		backdrop: [{ type: Input }],
		focus: [{
			type: Input,
			args: [{ transform: inputToBoolean }]
		}],
		keyboard: [{
			type: Input,
			args: [{ transform: inputToBoolean }]
		}],
		footerShadow: [{
			type: Input,
			args: [{ transform: inputToBoolean }]
		}],
		options: [{ type: Input }],
		showEvent: [{ type: Output }],
		shownEvent: [{ type: Output }],
		hideEvent: [{ type: Output }],
		hiddenEvent: [{ type: Output }],
		hidePreventedEvent: [{ type: Output }],
		modalElement: [{
			type: ViewChild,
			args: ["modalElement", { static: false }]
		}]
	}
});
var NotificationType;
(function(NotificationType) {
	NotificationType["Standard"] = "standard";
	NotificationType["Success"] = "success";
	NotificationType["Error"] = "error";
	NotificationType["Info"] = "info";
	NotificationType["Warning"] = "warning";
})(NotificationType || (NotificationType = {}));
var NotificationPosition;
(function(NotificationPosition) {
	NotificationPosition["Top"] = "top-fix mt-3";
	NotificationPosition["Bottom"] = "bottom-fix mb-3";
	NotificationPosition["Left"] = "left-fix ms-3";
	NotificationPosition["Right"] = "right-fix me-3";
})(NotificationPosition || (NotificationPosition = {}));
var ItNotificationService = class ItNotificationService {
	constructor() {
		this.subject = new Subject();
	}
	onNotification(filterType) {
		return this.subject.asObservable().pipe(filter((n) => n && (!filterType || n.type === filterType)));
	}
	addNotification(notification) {
		this.subject.next(notification);
	}
	standard(title, message, dismissible, duration, position) {
		this.addNotification({
			type: NotificationType.Standard,
			message,
			title,
			duration,
			dismissible,
			position
		});
	}
	success(title, message, dismissible, duration, position) {
		this.addNotification({
			type: NotificationType.Success,
			message,
			title,
			duration,
			dismissible,
			position
		});
	}
	error(title, message, dismissible, duration, position) {
		this.addNotification({
			type: NotificationType.Error,
			message,
			title,
			duration,
			dismissible,
			position
		});
	}
	warning(title, message, dismissible, duration, position) {
		this.addNotification({
			type: NotificationType.Warning,
			message,
			title,
			duration,
			dismissible,
			position
		});
	}
	info(title, message, dismissible, duration, position) {
		this.addNotification({
			type: NotificationType.Info,
			message,
			title,
			duration,
			dismissible,
			position
		});
	}
	static {
		this.ɵfac = i0.ɵɵngDeclareFactory({
			minVersion: "12.0.0",
			version: "22.2.1",
			ngImport: i0,
			type: ItNotificationService,
			deps: [],
			target: i0.ɵɵFactoryTarget.Injectable
		});
	}
	static {
		this.ɵprov = i0.ɵɵngDeclareInjectable({
			minVersion: "12.0.0",
			version: "22.2.1",
			ngImport: i0,
			type: ItNotificationService,
			providedIn: "root"
		});
	}
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.1",
	ngImport: i0,
	type: ItNotificationService,
	decorators: [{
		type: Injectable,
		args: [{ providedIn: "root" }]
	}]
});
var ItNotificationsComponent = class ItNotificationsComponent {
	constructor() {
		this._changeDetectorRef = inject(ChangeDetectorRef);
		this._notificationService = inject(ItNotificationService);
		this.duration = 8e3;
		this.dismissible = true;
		this.notificationCount = 0;
		this.notifications = [];
		this.subscription = this._notificationService.onNotification().subscribe((notification) => {
			if (!notification.duration) notification.duration = this.duration;
			if (!notification.position && this.position) notification.position = this.position;
			if (notification.dismissible === void 0 && this.dismissible) notification.dismissible = true;
			if (!notification.icon) notification.icon = this.getNotificationIcon(notification);
			const newNotification = {
				...notification,
				id: `${notification.type}-${this.notificationCount++}-notification`
			};
			this.notifications.push(newNotification);
			this._changeDetectorRef.detectChanges();
			setTimeout(() => {
				new Notification(document.getElementById(newNotification.id), { timeout: notification.duration }).show();
				setTimeout(() => {
					const index = this.notifications.findIndex((n) => n.id === newNotification.id);
					if (index > -1) {
						this.notifications.splice(index, 1);
						if (!this.notifications.length) this.notificationCount = 0;
						this._changeDetectorRef.detectChanges();
					}
				}, notification.duration);
			}, 200);
		});
	}
	ngOnDestroy() {
		this.subscription.unsubscribe();
	}
	get NotificationType() {
		return NotificationType;
	}
	hideNotification(id) {
		Notification.getInstance(document.getElementById(id))?.hide();
	}
	getNotificationIcon(notification) {
		switch (notification.type) {
			case NotificationType.Success: return "check-circle";
			case NotificationType.Error: return "close-circle";
			case NotificationType.Warning: return "error";
			case NotificationType.Info: return "info-circle";
			case NotificationType.Standard:
			default: return;
		}
	}
	static {
		this.ɵfac = i0.ɵɵngDeclareFactory({
			minVersion: "12.0.0",
			version: "22.2.1",
			ngImport: i0,
			type: ItNotificationsComponent,
			deps: [],
			target: i0.ɵɵFactoryTarget.Component
		});
	}
	static {
		this.ɵcmp = i0.ɵɵngDeclareComponent({
			minVersion: "17.0.0",
			version: "22.2.1",
			type: ItNotificationsComponent,
			isStandalone: true,
			selector: "it-notifications",
			inputs: {
				duration: "duration",
				position: "position",
				dismissible: [
					"dismissible",
					"dismissible",
					inputToBoolean
				]
			},
			ngImport: i0,
			template: "@for (notification of notifications; track notification.id) {\r\n  <div\r\n    [id]=\"notification.id\"\r\n    class=\"notification {{ notification.position }} {{ notification.type }}\"\r\n    [class.with-icon]=\"!!notification.icon\"\r\n    [class.dismissable]=\"notification.dismissible\"\r\n    role=\"alert\"\r\n    [attr.aria-labelledby]=\"notification.id + '-title'\">\r\n    <h2 [id]=\"notification.id + '-title'\" class=\"h5\">\r\n      @if (notification.icon) {\r\n        <it-icon [name]=\"notification.icon\"></it-icon>\r\n      }\r\n      <ng-container>{{ notification.title }}</ng-container>\r\n    </h2>\r\n    @if (notification.message) {\r\n      <p>{{ notification.message }}</p>\r\n    }\r\n    @if (notification.dismissible) {\r\n      <button type=\"button\" class=\"btn notification-close\" (click)=\"hideNotification(notification.id)\">\r\n        <it-icon name=\"close\"></it-icon>\r\n        <span class=\"visually-hidden\">{{ 'it.core.close-notification' | translate: { title: notification.title } }}</span>\r\n      </button>\r\n    }\r\n  </div>\r\n}\r\n",
			styles: [".notification{z-index:10000}\n"],
			dependencies: [
				{
					kind: "component",
					type: ItIconComponent,
					selector: "it-icon",
					inputs: [
						"name",
						"size",
						"color",
						"padded",
						"svgClass",
						"title",
						"labelWaria"
					]
				},
				{
					kind: "ngmodule",
					type: TranslateModule
				},
				{
					kind: "pipe",
					type: i1$1.TranslatePipe,
					name: "translate"
				}
			],
			changeDetection: i0.ChangeDetectionStrategy.OnPush
		});
	}
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.1",
	ngImport: i0,
	type: ItNotificationsComponent,
	decorators: [{
		type: Component,
		args: [{
			selector: "it-notifications",
			changeDetection: ChangeDetectionStrategy.OnPush,
			imports: [ItIconComponent, TranslateModule],
			template: "@for (notification of notifications; track notification.id) {\r\n  <div\r\n    [id]=\"notification.id\"\r\n    class=\"notification {{ notification.position }} {{ notification.type }}\"\r\n    [class.with-icon]=\"!!notification.icon\"\r\n    [class.dismissable]=\"notification.dismissible\"\r\n    role=\"alert\"\r\n    [attr.aria-labelledby]=\"notification.id + '-title'\">\r\n    <h2 [id]=\"notification.id + '-title'\" class=\"h5\">\r\n      @if (notification.icon) {\r\n        <it-icon [name]=\"notification.icon\"></it-icon>\r\n      }\r\n      <ng-container>{{ notification.title }}</ng-container>\r\n    </h2>\r\n    @if (notification.message) {\r\n      <p>{{ notification.message }}</p>\r\n    }\r\n    @if (notification.dismissible) {\r\n      <button type=\"button\" class=\"btn notification-close\" (click)=\"hideNotification(notification.id)\">\r\n        <it-icon name=\"close\"></it-icon>\r\n        <span class=\"visually-hidden\">{{ 'it.core.close-notification' | translate: { title: notification.title } }}</span>\r\n      </button>\r\n    }\r\n  </div>\r\n}\r\n",
			styles: [".notification{z-index:10000}\n"]
		}]
	}],
	ctorParameters: () => [],
	propDecorators: {
		duration: [{ type: Input }],
		position: [{ type: Input }],
		dismissible: [{
			type: Input,
			args: [{ transform: inputToBoolean }]
		}]
	}
});
var ItAbstractFormComponent = class ItAbstractFormComponent extends ItAbstractComponent {
	set disabled(isDisabled) {
		this.setDisabledState(isDisabled);
	}
	constructor() {
		super();
		this._translateService = inject(TranslateService);
		this._ngControl = inject(NgControl, {
			self: true,
			optional: true
		});
		this.fgd = inject(ControlContainer, { optional: true });
		this.validationMode = false;
		this.onChange = (_) => {};
		this.onTouched = () => {};
		this.control = new FormControl();
		this._ngControl && (this._ngControl.valueAccessor = this);
	}
	get isInvalid() {
		if (this.validationMode === "only-valid" || this.validationMode !== "only-invalid" && !this.validationMode) return;
		if (this._ngControl) return this._ngControl.invalid === true && this._ngControl.touched === true;
		return this.control.invalid && this.control.touched;
	}
	get isValid() {
		if (this.validationMode === "only-invalid" || this.validationMode !== "only-valid" && !this.validationMode) return;
		if (this._ngControl) return this._ngControl.valid === true && this._ngControl.touched === true;
		return this.control.valid && this.control.touched;
	}
	get invalidMessage() {
		if (this.hasError("required")) return this._translateService.get("it.errors.required-field");
		return this._translateService.get("it.errors.invalid-field");
	}
	ngOnInit() {
		if (this._ngControl?.control) {
			this.control.setValidators(this._ngControl.control.validator);
			this.setValidationModeWhenInAForm();
		}
	}
	registerOnChange(fn) {
		this.control.valueChanges.subscribe(fn);
		this.onChange = fn;
	}
	registerOnTouched(fn) {
		this.onTouched = fn;
	}
	setDisabledState(isDisabled) {
		if (isDisabled) return this.control.disable();
		this.control.enable();
	}
	writeValue(value) {
		this.control.setValue(value, { emitEvent: false });
		this._changeDetectorRef.detectChanges();
	}
	markAsTouched() {
		if (!this.control.touched) this.onTouched();
	}
	ngDoCheck() {
		if (this._ngControl?.control) {
			const ngControl = this._ngControl.control;
			if (this.control.touched !== ngControl.touched) {
				if (ngControl.touched) this.control.markAsTouched();
				else this.control.markAsUntouched();
			}
			if (this.control.pristine !== ngControl.pristine) {
				if (ngControl.pristine) this.control.markAsPristine();
				else this.control.markAsDirty();
			}
		}
		this._changeDetectorRef.detectChanges();
	}
	addValidators(validators) {
		if (!Array.isArray(validators)) validators = [validators];
		validators.forEach((validator) => {
			if (!this.control.hasValidator(validator)) this.control.addValidators(validator);
			if (this._ngControl?.control && !this._ngControl.control.hasValidator(validator)) this._ngControl.control.addValidators(validator);
		});
	}
	hasError(errorCode, path) {
		if (this._ngControl) return this._ngControl.hasError(errorCode, path);
		return this.control.hasError(errorCode, path);
	}
	getError(errorCode, path) {
		if (this._ngControl) return this._ngControl.getError(errorCode, path);
		return this.control.getError(errorCode, path);
	}
	setValidationModeWhenInAForm() {
		if (this.fgd?.control instanceof FormGroup && !this.validationMode) this.validationMode = true;
	}
	static {
		this.ɵfac = i0.ɵɵngDeclareFactory({
			minVersion: "12.0.0",
			version: "22.2.1",
			ngImport: i0,
			type: ItAbstractFormComponent,
			deps: [],
			target: i0.ɵɵFactoryTarget.Component
		});
	}
	static {
		this.ɵcmp = i0.ɵɵngDeclareComponent({
			minVersion: "16.1.0",
			version: "22.2.1",
			type: ItAbstractFormComponent,
			isStandalone: false,
			selector: "ng-component",
			inputs: {
				label: "label",
				validationMode: "validationMode",
				disabled: [
					"disabled",
					"disabled",
					inputToBoolean
				]
			},
			usesInheritance: true,
			ngImport: i0,
			template: "",
			isInline: true,
			changeDetection: i0.ChangeDetectionStrategy.Eager
		});
	}
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.1",
	ngImport: i0,
	type: ItAbstractFormComponent,
	decorators: [{
		type: Component,
		args: [{
			template: "",
			changeDetection: ChangeDetectionStrategy.Eager,
			standalone: false
		}]
	}],
	ctorParameters: () => [],
	propDecorators: {
		label: [{ type: Input }],
		validationMode: [{ type: Input }],
		disabled: [{
			type: Input,
			args: [{ transform: inputToBoolean }]
		}]
	}
});
const EMAIL_REGEX = /(?:[a-z0-9!#$%&'*+/=?^_`{|}~-]+(?:\.[a-z0-9!#$%&'*+/=?^_`{|}~-]+)*|"(?:[\x01-\x08\x0b\x0c\x0e-\x1f\x21\x23-\x5b\x5d-\x7f]|\\[\x01-\x09\x0b\x0c\x0e-\x7f])*")@(?:(?:[a-z0-9](?:[a-z0-9-]*[a-z0-9])?\.)+[a-z0-9](?:[a-z0-9-]*[a-z0-9])?|\[(?:(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.){3}(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?|[a-z0-9-]*[a-z0-9]:(?:[\x01-\x08\x0b\x0c\x0e-\x1f\x21-\x5a\x53-\x7f]|\\[\x01-\x09\x0b\x0c\x0e-\x7f])+)\])/;
const PHONE_NUMBER_REGEX = /^\s*(?:\+?(\d{1,3}))?[-. (]*(\d{3})[-. )]*(\d{3})[-. ]*(\d{3})(?: *x(\d+))?\s*$/;
const URL_REGEX = /(https?:\/\/(?:www\.|(?!www))[a-zA-Z0-9][a-zA-Z0-9-]+[a-zA-Z0-9]\.[^\s]{2,}|www\.[a-zA-Z0-9][a-zA-Z0-9-]+[a-zA-Z0-9]\.[^\s]{2,}|https?:\/\/(?:www\.|(?!www))[a-zA-Z0-9]+\.[^\s]{2,}|www\.[a-zA-Z0-9]+\.[^\s]{2,})/;
const ITALIAN_TAX_CODE_REGEX = /^[A-Za-z]{6}[0-9]{2}[A-Za-z]{1}[0-9]{2}[A-Za-z]{1}[0-9]{3}[A-Za-z]{1}$/i;
const VAT_NUMBER_REGEX = /^[0-9]{11}$/;
const CAP_REGEX = /^[0-9]{5}$/;
const PLATE_REGEX = /^[A-Za-z]{2}\d{3}[A-Za-z]{2}$/i;
const IBAN_REGEX = /^(?:(?:IT|SM)\d{2}[A-Z]\d{22}|CY\d{2}[A-Z]\d{23}|NL\d{2}[A-Z]{4}\d{10}|LV\d{2}[A-Z]{4}\d{13}|(?:BG|BH|GB|IE)\d{2}[A-Z]{4}\d{14}|GI\d{2}[A-Z]{4}\d{15}|RO\d{2}[A-Z]{4}\d{16}|KW\d{2}[A-Z]{4}\d{22}|MT\d{2}[A-Z]{4}\d{23}|NO\d{13}|(?:DK|FI|GL|FO)\d{16}|MK\d{17}|(?:AT|EE|KZ|LU|XK)\d{18}|(?:BA|HR|LI|CH|CR)\d{19}|(?:GE|DE|LT|ME|RS)\d{20}|IL\d{21}|(?:AD|CZ|ES|MD|SA)\d{22}|PT\d{23}|(?:BE|IS)\d{24}|(?:FR|MR|MC)\d{25}|(?:AL|DO|LB|PL)\d{26}|(?:AZ|HU)\d{27}|(?:GR|MU)\d{28})$/i;
var ItValidators = class ItValidators {
	static {
		this.SpecialCharacterPattern = "!@#$%&*_+=;:|,.";
	}
	static customPattern(regex, error) {
		return (control) => {
			if (!control.value) return null;
			return regex.test(control.value) ? null : error;
		};
	}
	static conditional(validator, condition) {
		return (formControl) => {
			if (!formControl.parent) return null;
			if (condition(formControl)) return validator(formControl);
			return null;
		};
	}
	static passwordMatch(control, passwordControlName = "password", confirmControlName = "confirmPassword") {
		const confirmControl = control.get(confirmControlName);
		if (!confirmControl) return null;
		const passwordControl = control.get(passwordControlName);
		const password = passwordControl?.value;
		if (password && !confirmControl.value || confirmControl.value && password !== confirmControl.value) {
			confirmControl?.setErrors({ noPasswordMatch: true });
			confirmControl?.markAsTouched();
			return control;
		}
		if (password && passwordControl?.touched) confirmControl?.markAsTouched();
		return null;
	}
	static password(minLength = 10, hasNumber = true, hasCapitalCase = true, hasSmallCase = true, hasSpecialCharacters = true, required = true) {
		const validators = [Validators.minLength(minLength)];
		if (hasNumber) validators.push(ItValidators.customPattern(/\d/, { hasNumber }));
		if (hasCapitalCase) validators.push(ItValidators.customPattern(/[A-Z]/, { hasCapitalCase }));
		if (hasSmallCase) validators.push(ItValidators.customPattern(/[a-z]/, { hasSmallCase }));
		if (hasSpecialCharacters) validators.push(ItValidators.customPattern(new RegExp(`[${ItValidators.SpecialCharacterPattern}]`), { hasSpecialCharacters }));
		if (required) validators.push(Validators.required);
		return Validators.compose(validators);
	}
	static get email() {
		return Validators.compose([Validators.email, ItValidators.customPattern(EMAIL_REGEX, { invalidEmail: true })]);
	}
	static get tel() {
		return ItValidators.customPattern(PHONE_NUMBER_REGEX, { invalidTel: true });
	}
	static includes(possibleValues) {
		return (formControl) => {
			return possibleValues?.includes(formControl.value) ? null : { invalidSelection: true };
		};
	}
	static get url() {
		return ItValidators.customPattern(URL_REGEX, { invalidUrl: true });
	}
	static get taxCode() {
		return ItValidators.customPattern(ITALIAN_TAX_CODE_REGEX, { invalidTaxCode: true });
	}
	static get vatNumber() {
		return ItValidators.customPattern(VAT_NUMBER_REGEX, { invalidVatNumber: true });
	}
	static get cap() {
		return ItValidators.customPattern(CAP_REGEX, { invalidCap: true });
	}
	static get iban() {
		return ItValidators.customPattern(IBAN_REGEX, { invalidIban: true });
	}
	static get plate() {
		return ItValidators.customPattern(PLATE_REGEX, { invalidPlate: true });
	}
	static get regExp() {
		return (control) => {
			try {
				if (control?.value) new RegExp(control.value);
			} catch {
				return { invalidRegex: true };
			}
			return null;
		};
	}
};
var ItInputComponent = class ItInputComponent extends ItAbstractFormComponent {
	constructor() {
		super(...arguments);
		this.type = "text";
		this.placeholder = "";
		this.maxDate = "9999-12-31";
	}
	get isActiveLabel() {
		const value = this.control.value;
		if (!!value && value !== 0 || value === 0 || !!this.placeholder) return true;
		return this.type === "date" || this.type === "time" || this.type === "color";
	}
	get isReadonly() {
		return this.readonly === "plaintext" || !!this.readonly;
	}
	get invalidMessage() {
		if (this.hasError("min") && this.min) return this._translateService.get("it.errors.min-invalid", { min: this.min });
		if (this.hasError("max") && this.max) return this._translateService.get("it.errors.max-invalid", { max: this.max });
		if (this.hasError("minlength")) {
			const error = this.getError("minlength");
			return this._translateService.get("it.errors.min-length-invalid", { min: error.requiredLength });
		}
		if (this.hasError("maxlength")) {
			const error = this.getError("maxlength");
			return this._translateService.get("it.errors.max-length-invalid", { max: error.requiredLength });
		}
		if (this.hasError("email") || this.hasError("invalidEmail")) return this._translateService.get("it.errors.email-invalid");
		if (this.hasError("invalidTel")) return this._translateService.get("it.errors.tel-invalid");
		if (this.hasError("invalidUrl")) return this._translateService.get("it.errors.url-invalid");
		if (this.hasError("invalidTaxCode")) return this._translateService.get("it.errors.tax-code-invalid");
		if (this.hasError("invalidVatNumber")) return this._translateService.get("it.errors.vat-number-invalid");
		if (this.hasError("invalidCap")) return this._translateService.get("it.errors.cap-invalid");
		if (this.hasError("invalidIban")) return this._translateService.get("it.errors.iban-invalid");
		if (this.hasError("invalidPlate")) return this._translateService.get("it.errors.plate-invalid");
		if (this.hasError("invalidRegex")) return this._translateService.get("it.errors.regex-invalid");
		if (this.hasError("pattern")) {
			const error = this.getError("pattern");
			return this._translateService.get("it.errors.pattern-invalid", { pattern: error.requiredPattern });
		}
		return super.invalidMessage;
	}
	ngOnInit() {
		super.ngOnInit();
		const validators = [];
		switch (this.type) {
			case "number":
				if (this.percentage) {
					this.min = this.min || 0;
					this.max = this.max || 100;
				}
				validators.push((control) => this.min ? Validators.min(this.min)(control) : null);
				validators.push((control) => this.max ? Validators.max(this.max)(control) : null);
				break;
			case "email":
				validators.push(ItValidators.email);
				break;
			case "tel":
				validators.push(ItValidators.tel);
				break;
			case "url": validators.push(ItValidators.url);
		}
		this.addValidators(validators);
	}
	incrementNumber(decrease = false) {
		if (this.type !== "number") return;
		const step = this.step === "any" ? 1 : this.step ?? 1;
		let value = Number(this.control.value);
		value = (isNaN(value) ? 0 : value) + (decrease ? -step : step);
		value = Math.round(value * 0xe8d4a51000) / 0xe8d4a51000;
		if (this.min !== void 0 && value < this.min) value = this.min;
		else if (this.max !== void 0 && value > this.max) value = this.max;
		this.control.setValue(value);
	}
	static {
		this.ɵfac = i0.ɵɵngDeclareFactory({
			minVersion: "12.0.0",
			version: "22.2.1",
			ngImport: i0,
			type: ItInputComponent,
			deps: null,
			target: i0.ɵɵFactoryTarget.Component
		});
	}
	static {
		this.ɵcmp = i0.ɵɵngDeclareComponent({
			minVersion: "17.0.0",
			version: "22.2.1",
			type: ItInputComponent,
			isStandalone: true,
			selector: "it-input",
			inputs: {
				type: "type",
				placeholder: "placeholder",
				description: "description",
				readonly: "readonly",
				maxDate: "maxDate",
				minDate: "minDate",
				max: "max",
				min: "min",
				step: "step",
				currency: [
					"currency",
					"currency",
					inputToBoolean
				],
				percentage: [
					"percentage",
					"percentage",
					inputToBoolean
				],
				symbol: "symbol",
				adaptive: [
					"adaptive",
					"adaptive",
					inputToBoolean
				],
				autocomplete: "autocomplete"
			},
			usesInheritance: true,
			ngImport: i0,
			template: "<div class=\"form-group\">\r\n  <div\r\n    class=\"input-group\"\r\n    [class.disabled]=\"!control.enabled\"\r\n    [class.input-number]=\"type === 'number'\"\r\n    [class.input-number-currency]=\"currency\"\r\n    [class.input-number-percentage]=\"percentage\"\r\n    [class.input-number-adaptive]=\"adaptive\">\r\n    <span class=\"input-group-text\" #prependText>\r\n      <ng-content select=\"[prependText]\"></ng-content>\r\n    </span>\r\n    @if (label) {\r\n      <label\r\n        [for]=\"id\"\r\n        [class.active]=\"isActiveLabel\"\r\n        [class.input-symbol-label]=\"percentage || currency\"\r\n        [class.input-number-label]=\"type === 'number'\"\r\n        [class.empty-prepend-label]=\"!(percentage || currency) && !prependText.clientWidth\">\r\n        {{ label }}\r\n      </label>\r\n    }\r\n\r\n    @if (type === 'number') {\r\n      @if (currency || percentage) {\r\n        <span class=\"input-group-text fw-semibold\">{{ symbol }}</span>\r\n      }\r\n      <input\r\n        type=\"number\"\r\n        [id]=\"id\"\r\n        [step]=\"step ?? null\"\r\n        [min]=\"min ?? ''\"\r\n        [max]=\"max ?? ''\"\r\n        [class.form-control]=\"readonly !== 'plaintext'\"\r\n        [class.form-control-plaintext]=\"readonly === 'plaintext'\"\r\n        [class.is-invalid]=\"isInvalid\"\r\n        [class.just-validate-success-field]=\"isValid\"\r\n        [formControl]=\"control\"\r\n        [placeholder]=\"placeholder\"\r\n        [readonly]=\"isReadonly\"\r\n        [autocomplete]=\"autocomplete\"\r\n        [attr.aria-describedby]=\"description ? id + '-description' : null\"\r\n        (blur)=\"markAsTouched()\" />\r\n      <span class=\"input-group-text align-buttons flex-column\">\r\n        <button type=\"button\" class=\"input-number-add\" [disabled]=\"!control.enabled\" (click)=\"incrementNumber()\">\r\n          <span class=\"visually-hidden\">{{ 'it.form.increase-value' | translate }}</span>\r\n        </button>\r\n        <button type=\"button\" class=\"input-number-sub\" [disabled]=\"!control.enabled\" (click)=\"incrementNumber(true)\">\r\n          <span class=\"visually-hidden\">{{ 'it.form.decrease-value' | translate }}</span>\r\n        </button>\r\n      </span>\r\n    } @else {\r\n      <input\r\n        [id]=\"id\"\r\n        [type]=\"type\"\r\n        [max]=\"type === 'date' ? maxDate : undefined\"\r\n        [min]=\"type === 'date' ? minDate : undefined\"\r\n        [class.form-control]=\"readonly !== 'plaintext'\"\r\n        [class.form-control-plaintext]=\"readonly === 'plaintext'\"\r\n        [class.is-invalid]=\"isInvalid\"\r\n        [class.just-validate-success-field]=\"isValid\"\r\n        [formControl]=\"control\"\r\n        [placeholder]=\"placeholder\"\r\n        [readonly]=\"isReadonly\"\r\n        [autocomplete]=\"autocomplete\"\r\n        [attr.aria-describedby]=\"description ? id + '-description' : null\"\r\n        (blur)=\"markAsTouched()\" />\r\n    }\r\n\r\n    <div class=\"input-group-append\">\r\n      <ng-content select=\"[append]\"></ng-content>\r\n\r\n      <div class=\"input-group-text\">\r\n        <ng-content select=\"[appendText]\"></ng-content>\r\n      </div>\r\n    </div>\r\n  </div>\r\n\r\n  @if (description) {\r\n    <small [id]=\"id + '-description'\" class=\"form-text\">{{ description }}</small>\r\n  }\r\n\r\n  @if (isInvalid) {\r\n    <div class=\"form-feedback just-validate-error-label\" [id]=\"id + '-error'\">\r\n      <div #customError>\r\n        <ng-content select=\"[error]\"></ng-content>\r\n      </div>\r\n      @if (!customError.hasChildNodes()) {\r\n        {{ invalidMessage | async }}\r\n      }\r\n    </div>\r\n  }\r\n</div>\r\n",
			styles: [".form-group label{z-index:1000}.form-group .input-number .align-buttons{height:100%}.form-group .input-group-text:empty{display:none}.form-group label.empty-prepend-label{left:auto!important;max-width:100%!important}.form-group label:not(.active):has(+input:-webkit-autofill){transform:translateY(-75%)}\n"],
			dependencies: [
				{
					kind: "ngmodule",
					type: ReactiveFormsModule
				},
				{
					kind: "directive",
					type: i1.DefaultValueAccessor,
					selector: "input:not([type=checkbox]):not([ngNoCva])[formControlName],textarea:not([ngNoCva])[formControlName],input:not([type=checkbox]):not([ngNoCva])[formControl],textarea:not([ngNoCva])[formControl],input:not([type=checkbox]):not([ngNoCva])[ngModel],textarea:not([ngNoCva])[ngModel],[ngDefaultControl]"
				},
				{
					kind: "directive",
					type: i1.NumberValueAccessor,
					selector: "input[type=number]:not([ngNoCva])[formControlName],input[type=number]:not([ngNoCva])[formControl],input[type=number]:not([ngNoCva])[ngModel]"
				},
				{
					kind: "directive",
					type: i1.NgControlStatus,
					selector: "[formControlName],[ngModel],[formControl]"
				},
				{
					kind: "directive",
					type: i1.MinValidator,
					selector: "input[type=number][min][formControlName],input[type=number][min][formControl],input[type=number][min][ngModel]",
					inputs: ["min"]
				},
				{
					kind: "directive",
					type: i1.MaxValidator,
					selector: "input[type=number][max][formControlName],input[type=number][max][formControl],input[type=number][max][ngModel]",
					inputs: ["max"]
				},
				{
					kind: "directive",
					type: i1.FormControlDirective,
					selector: "[formControl]",
					inputs: [
						"formControl",
						"disabled",
						"ngModel"
					],
					outputs: ["ngModelChange"],
					exportAs: ["ngForm"]
				},
				{
					kind: "ngmodule",
					type: TranslateModule
				},
				{
					kind: "pipe",
					type: i1$1.TranslatePipe,
					name: "translate"
				},
				{
					kind: "pipe",
					type: AsyncPipe,
					name: "async"
				}
			],
			changeDetection: i0.ChangeDetectionStrategy.OnPush
		});
	}
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.1",
	ngImport: i0,
	type: ItInputComponent,
	decorators: [{
		type: Component,
		args: [{
			selector: "it-input",
			changeDetection: ChangeDetectionStrategy.OnPush,
			imports: [
				ReactiveFormsModule,
				TranslateModule,
				AsyncPipe
			],
			template: "<div class=\"form-group\">\r\n  <div\r\n    class=\"input-group\"\r\n    [class.disabled]=\"!control.enabled\"\r\n    [class.input-number]=\"type === 'number'\"\r\n    [class.input-number-currency]=\"currency\"\r\n    [class.input-number-percentage]=\"percentage\"\r\n    [class.input-number-adaptive]=\"adaptive\">\r\n    <span class=\"input-group-text\" #prependText>\r\n      <ng-content select=\"[prependText]\"></ng-content>\r\n    </span>\r\n    @if (label) {\r\n      <label\r\n        [for]=\"id\"\r\n        [class.active]=\"isActiveLabel\"\r\n        [class.input-symbol-label]=\"percentage || currency\"\r\n        [class.input-number-label]=\"type === 'number'\"\r\n        [class.empty-prepend-label]=\"!(percentage || currency) && !prependText.clientWidth\">\r\n        {{ label }}\r\n      </label>\r\n    }\r\n\r\n    @if (type === 'number') {\r\n      @if (currency || percentage) {\r\n        <span class=\"input-group-text fw-semibold\">{{ symbol }}</span>\r\n      }\r\n      <input\r\n        type=\"number\"\r\n        [id]=\"id\"\r\n        [step]=\"step ?? null\"\r\n        [min]=\"min ?? ''\"\r\n        [max]=\"max ?? ''\"\r\n        [class.form-control]=\"readonly !== 'plaintext'\"\r\n        [class.form-control-plaintext]=\"readonly === 'plaintext'\"\r\n        [class.is-invalid]=\"isInvalid\"\r\n        [class.just-validate-success-field]=\"isValid\"\r\n        [formControl]=\"control\"\r\n        [placeholder]=\"placeholder\"\r\n        [readonly]=\"isReadonly\"\r\n        [autocomplete]=\"autocomplete\"\r\n        [attr.aria-describedby]=\"description ? id + '-description' : null\"\r\n        (blur)=\"markAsTouched()\" />\r\n      <span class=\"input-group-text align-buttons flex-column\">\r\n        <button type=\"button\" class=\"input-number-add\" [disabled]=\"!control.enabled\" (click)=\"incrementNumber()\">\r\n          <span class=\"visually-hidden\">{{ 'it.form.increase-value' | translate }}</span>\r\n        </button>\r\n        <button type=\"button\" class=\"input-number-sub\" [disabled]=\"!control.enabled\" (click)=\"incrementNumber(true)\">\r\n          <span class=\"visually-hidden\">{{ 'it.form.decrease-value' | translate }}</span>\r\n        </button>\r\n      </span>\r\n    } @else {\r\n      <input\r\n        [id]=\"id\"\r\n        [type]=\"type\"\r\n        [max]=\"type === 'date' ? maxDate : undefined\"\r\n        [min]=\"type === 'date' ? minDate : undefined\"\r\n        [class.form-control]=\"readonly !== 'plaintext'\"\r\n        [class.form-control-plaintext]=\"readonly === 'plaintext'\"\r\n        [class.is-invalid]=\"isInvalid\"\r\n        [class.just-validate-success-field]=\"isValid\"\r\n        [formControl]=\"control\"\r\n        [placeholder]=\"placeholder\"\r\n        [readonly]=\"isReadonly\"\r\n        [autocomplete]=\"autocomplete\"\r\n        [attr.aria-describedby]=\"description ? id + '-description' : null\"\r\n        (blur)=\"markAsTouched()\" />\r\n    }\r\n\r\n    <div class=\"input-group-append\">\r\n      <ng-content select=\"[append]\"></ng-content>\r\n\r\n      <div class=\"input-group-text\">\r\n        <ng-content select=\"[appendText]\"></ng-content>\r\n      </div>\r\n    </div>\r\n  </div>\r\n\r\n  @if (description) {\r\n    <small [id]=\"id + '-description'\" class=\"form-text\">{{ description }}</small>\r\n  }\r\n\r\n  @if (isInvalid) {\r\n    <div class=\"form-feedback just-validate-error-label\" [id]=\"id + '-error'\">\r\n      <div #customError>\r\n        <ng-content select=\"[error]\"></ng-content>\r\n      </div>\r\n      @if (!customError.hasChildNodes()) {\r\n        {{ invalidMessage | async }}\r\n      }\r\n    </div>\r\n  }\r\n</div>\r\n",
			styles: [".form-group label{z-index:1000}.form-group .input-number .align-buttons{height:100%}.form-group .input-group-text:empty{display:none}.form-group label.empty-prepend-label{left:auto!important;max-width:100%!important}.form-group label:not(.active):has(+input:-webkit-autofill){transform:translateY(-75%)}\n"]
		}]
	}],
	propDecorators: {
		type: [{ type: Input }],
		placeholder: [{ type: Input }],
		description: [{ type: Input }],
		readonly: [{ type: Input }],
		maxDate: [{ type: Input }],
		minDate: [{ type: Input }],
		max: [{ type: Input }],
		min: [{ type: Input }],
		step: [{ type: Input }],
		currency: [{
			type: Input,
			args: [{ transform: inputToBoolean }]
		}],
		percentage: [{
			type: Input,
			args: [{ transform: inputToBoolean }]
		}],
		symbol: [{ type: Input }],
		adaptive: [{
			type: Input,
			args: [{ transform: inputToBoolean }]
		}],
		autocomplete: [{ type: Input }]
	}
});
var ItPaginationComponent = class ItPaginationComponent {
	constructor() {
		this.visiblePages = 5;
		this.changerValues = [
			10,
			25,
			50,
			100
		];
		this.pageEvent = new EventEmitter();
		this.changerEvent = new EventEmitter();
		this.pages = [];
		this.jumpToPage = new FormControl(null);
		this.jumpToPage.valueChanges.pipe(debounceTime(300), distinctUntilChanged(), filter((value) => !!value && this.jumpToPage.valid)).subscribe((value) => {
			this.pageEvent.emit(value - 1);
		});
	}
	ngOnChanges(changes) {
		this.pages = this.calculatePages();
		if (changes["currentPage"]) this.jumpToPage.setValue(null, { emitEvent: false });
	}
	calculatePages() {
		if (this.simpleMode) return [this.currentPage];
		const length = this.pageNumbers > this.visiblePages ? this.visiblePages : this.pageNumbers;
		const halfVisiblePages = Math.floor(this.visiblePages / 2);
		let start = this.currentPage > halfVisiblePages && this.pageNumbers > this.visiblePages ? this.currentPage - halfVisiblePages + 1 : 1;
		if (this.pageNumbers > this.visiblePages) {
			if (this.currentPage + 1 >= this.pageNumbers) start -= halfVisiblePages;
			else if (this.currentPage >= this.pageNumbers - halfVisiblePages) start -= this.pageNumbers - (this.currentPage + 1);
		}
		return Array.from({ length }, (_, i) => i + start);
	}
	pageChange(event, newPage) {
		event.preventDefault();
		this.pageEvent.emit(newPage - 1);
	}
	changerChange(event, value) {
		event.preventDefault();
		this.changerEvent.emit(value);
	}
	static {
		this.ɵfac = i0.ɵɵngDeclareFactory({
			minVersion: "12.0.0",
			version: "22.2.1",
			ngImport: i0,
			type: ItPaginationComponent,
			deps: [],
			target: i0.ɵɵFactoryTarget.Component
		});
	}
	static {
		this.ɵcmp = i0.ɵɵngDeclareComponent({
			minVersion: "17.0.0",
			version: "22.2.1",
			type: ItPaginationComponent,
			isStandalone: true,
			selector: "it-pagination",
			inputs: {
				currentPage: "currentPage",
				pageNumbers: "pageNumbers",
				visiblePages: "visiblePages",
				alignment: "alignment",
				simpleMode: [
					"simpleMode",
					"simpleMode",
					inputToBoolean
				],
				textLinks: [
					"textLinks",
					"textLinks",
					inputToBoolean
				],
				currentChanger: "currentChanger",
				changerValues: "changerValues",
				showJumpToPage: [
					"showJumpToPage",
					"showJumpToPage",
					inputToBoolean
				]
			},
			outputs: {
				pageEvent: "pageEvent",
				changerEvent: "changerEvent"
			},
			usesOnChanges: true,
			ngImport: i0,
			template: "<nav\r\n  class=\"pagination-wrapper\"\r\n  [class.justify-content-center]=\"alignment === 'center'\"\r\n  [class.justify-content-end]=\"alignment === 'end'\"\r\n  [class.pagination-total]=\"totalNumberText.hasChildNodes()\">\r\n  @if (pages.length) {\r\n    <ul class=\"pagination\">\r\n      <li class=\"page-item\" [class.disabled]=\"currentPage < 1\">\r\n        <a class=\"page-link\" [class.text]=\"textLinks\" href=\"#\" (click)=\"!(currentPage < 1) && pageChange($event, currentPage)\">\r\n          @if (!textLinks) {\r\n            <it-icon name=\"chevron-left\" color=\"primary\"></it-icon>\r\n          }\r\n          <span class=\"visually-hidden\">\r\n            {{ (textLinks ? 'it.core.page' : 'it.core.previous-page') | translate }}\r\n          </span>\r\n          @if (textLinks) {\r\n            {{ 'it.core.previous' | translate }}\r\n          }\r\n        </a>\r\n      </li>\r\n      @if (simpleMode) {\r\n        <li class=\"page-item\">\r\n          <span class=\"page-link\" aria-current=\"page\">{{ currentPage + 1 }}</span>\r\n        </li>\r\n        <li class=\"page-item\"><span class=\"page-link\">/</span></li>\r\n        <li class=\"page-item\">\r\n          <span class=\"page-link\">{{ pageNumbers }}</span>\r\n        </li>\r\n        <li class=\"page-item visually-hidden\">\r\n          <a class=\"page-link\" href=\"#\" aria-current=\"page\">\r\n            {{ 'it.core.page-of-total' | translate: { page: currentPage + 1, total: pageNumbers } }}\r\n          </a>\r\n        </li>\r\n      } @else {\r\n        @if (pageNumbers > visiblePages && pages[0] >= 2) {\r\n          <li class=\"page-item\">\r\n            <a class=\"page-link\" href=\"#\" (click)=\"pageChange($event, 1)\">1</a>\r\n          </li>\r\n          @if (pages[0] >= 3) {\r\n            <li class=\"page-item\">\r\n              <span class=\"page-link\">...</span>\r\n            </li>\r\n          }\r\n        }\r\n        @for (page of pages; track page) {\r\n          <li class=\"page-item\">\r\n            @if (page === currentPage + 1) {\r\n              <a class=\"page-link\" href=\"#\" aria-current=\"page\">\r\n                <span class=\"d-inline-block d-sm-none\">{{ 'it.core.page' | translate }}</span> {{ page }}\r\n              </a>\r\n            } @else {\r\n              <a class=\"page-link\" href=\"#\" (click)=\"pageChange($event, page)\">{{ page }}</a>\r\n            }\r\n          </li>\r\n        }\r\n        @if (pageNumbers > visiblePages && pages[pages.length - 1] < pageNumbers) {\r\n          @if (pages[pages.length - 1] < pageNumbers - 1) {\r\n            <li class=\"page-item\">\r\n              <span class=\"page-link\">...</span>\r\n            </li>\r\n          }\r\n          <li class=\"page-item\">\r\n            <a class=\"page-link\" href=\"#\" (click)=\"pageChange($event, pageNumbers)\">{{ pageNumbers }}</a>\r\n          </li>\r\n        }\r\n      }\r\n      <li class=\"page-item\" [class.disabled]=\"currentPage >= pageNumbers - 1\">\r\n        <a\r\n          class=\"page-link\"\r\n          [class.text]=\"textLinks\"\r\n          href=\"#\"\r\n          (click)=\"!(currentPage >= pageNumbers - 1) && pageChange($event, currentPage + 2)\">\r\n          <span class=\"visually-hidden\">\r\n            {{ (textLinks ? 'it.core.page' : 'it.core.next-page') | translate }}\r\n          </span>\r\n          @if (textLinks) {\r\n            {{ 'it.core.next' | translate }}\r\n          } @else {\r\n            <it-icon name=\"chevron-right\" color=\"primary\"></it-icon>\r\n          }\r\n        </a>\r\n      </li>\r\n    </ul>\r\n  }\r\n\r\n  @if (currentChanger !== undefined) {\r\n    <it-dropdown>\r\n      <span button>{{ currentChanger }} / {{ 'it.core.page' | translate | lowercase }}</span>\r\n      <ng-container list>\r\n        @for (value of changerValues; track value) {\r\n          <li\r\n            itDropdownItem\r\n            href=\"#\"\r\n            externalLink=\"true\"\r\n            tabindex=\"-1\"\r\n            (click)=\"changerChange($event, value)\"\r\n            (keyup.enter)=\"changerChange($event, value)\">\r\n            {{ value }} / {{ 'it.core.page' | translate | lowercase }}\r\n          </li>\r\n        }\r\n      </ng-container>\r\n    </it-dropdown>\r\n  }\r\n\r\n  @if (showJumpToPage) {\r\n    <it-input\r\n      type=\"number\"\r\n      [min]=\"1\"\r\n      [max]=\"pageNumbers\"\r\n      [label]=\"('it.core.go-to' | translate) + '...'\"\r\n      [formControl]=\"jumpToPage\"></it-input>\r\n  }\r\n\r\n  <p [class.d-none]=\"!totalNumberText.hasChildNodes()\" #totalNumberText>\r\n    <ng-content></ng-content>\r\n  </p>\r\n</nav>\r\n",
			dependencies: [
				{
					kind: "component",
					type: ItIconComponent,
					selector: "it-icon",
					inputs: [
						"name",
						"size",
						"color",
						"padded",
						"svgClass",
						"title",
						"labelWaria"
					]
				},
				{
					kind: "ngmodule",
					type: TranslateModule
				},
				{
					kind: "ngmodule",
					type: ItDropdownModule
				},
				{
					kind: "component",
					type: ItDropdownComponent,
					selector: "it-dropdown",
					inputs: [
						"mode",
						"color",
						"direction",
						"fullWidth",
						"megamenu",
						"dark"
					],
					outputs: [
						"showEvent",
						"shownEvent",
						"hideEvent",
						"hiddenEvent"
					],
					exportAs: ["itDropdown"]
				},
				{
					kind: "component",
					type: ItDropdownItemComponent,
					selector: "it-dropdown-item, li[itDropdownItem]",
					inputs: [
						"divider",
						"active",
						"large",
						"iconName",
						"iconPosition",
						"mode"
					]
				},
				{
					kind: "component",
					type: ItInputComponent,
					selector: "it-input",
					inputs: [
						"type",
						"placeholder",
						"description",
						"readonly",
						"maxDate",
						"minDate",
						"max",
						"min",
						"step",
						"currency",
						"percentage",
						"symbol",
						"adaptive",
						"autocomplete"
					]
				},
				{
					kind: "ngmodule",
					type: ReactiveFormsModule
				},
				{
					kind: "directive",
					type: i1.NgControlStatus,
					selector: "[formControlName],[ngModel],[formControl]"
				},
				{
					kind: "directive",
					type: i1.FormControlDirective,
					selector: "[formControl]",
					inputs: [
						"formControl",
						"disabled",
						"ngModel"
					],
					outputs: ["ngModelChange"],
					exportAs: ["ngForm"]
				},
				{
					kind: "pipe",
					type: i1$1.TranslatePipe,
					name: "translate"
				},
				{
					kind: "pipe",
					type: LowerCasePipe,
					name: "lowercase"
				}
			],
			changeDetection: i0.ChangeDetectionStrategy.OnPush
		});
	}
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.1",
	ngImport: i0,
	type: ItPaginationComponent,
	decorators: [{
		type: Component,
		args: [{
			selector: "it-pagination",
			changeDetection: ChangeDetectionStrategy.OnPush,
			imports: [
				ItIconComponent,
				TranslateModule,
				LowerCasePipe,
				ItDropdownModule,
				ItInputComponent,
				ReactiveFormsModule
			],
			template: "<nav\r\n  class=\"pagination-wrapper\"\r\n  [class.justify-content-center]=\"alignment === 'center'\"\r\n  [class.justify-content-end]=\"alignment === 'end'\"\r\n  [class.pagination-total]=\"totalNumberText.hasChildNodes()\">\r\n  @if (pages.length) {\r\n    <ul class=\"pagination\">\r\n      <li class=\"page-item\" [class.disabled]=\"currentPage < 1\">\r\n        <a class=\"page-link\" [class.text]=\"textLinks\" href=\"#\" (click)=\"!(currentPage < 1) && pageChange($event, currentPage)\">\r\n          @if (!textLinks) {\r\n            <it-icon name=\"chevron-left\" color=\"primary\"></it-icon>\r\n          }\r\n          <span class=\"visually-hidden\">\r\n            {{ (textLinks ? 'it.core.page' : 'it.core.previous-page') | translate }}\r\n          </span>\r\n          @if (textLinks) {\r\n            {{ 'it.core.previous' | translate }}\r\n          }\r\n        </a>\r\n      </li>\r\n      @if (simpleMode) {\r\n        <li class=\"page-item\">\r\n          <span class=\"page-link\" aria-current=\"page\">{{ currentPage + 1 }}</span>\r\n        </li>\r\n        <li class=\"page-item\"><span class=\"page-link\">/</span></li>\r\n        <li class=\"page-item\">\r\n          <span class=\"page-link\">{{ pageNumbers }}</span>\r\n        </li>\r\n        <li class=\"page-item visually-hidden\">\r\n          <a class=\"page-link\" href=\"#\" aria-current=\"page\">\r\n            {{ 'it.core.page-of-total' | translate: { page: currentPage + 1, total: pageNumbers } }}\r\n          </a>\r\n        </li>\r\n      } @else {\r\n        @if (pageNumbers > visiblePages && pages[0] >= 2) {\r\n          <li class=\"page-item\">\r\n            <a class=\"page-link\" href=\"#\" (click)=\"pageChange($event, 1)\">1</a>\r\n          </li>\r\n          @if (pages[0] >= 3) {\r\n            <li class=\"page-item\">\r\n              <span class=\"page-link\">...</span>\r\n            </li>\r\n          }\r\n        }\r\n        @for (page of pages; track page) {\r\n          <li class=\"page-item\">\r\n            @if (page === currentPage + 1) {\r\n              <a class=\"page-link\" href=\"#\" aria-current=\"page\">\r\n                <span class=\"d-inline-block d-sm-none\">{{ 'it.core.page' | translate }}</span> {{ page }}\r\n              </a>\r\n            } @else {\r\n              <a class=\"page-link\" href=\"#\" (click)=\"pageChange($event, page)\">{{ page }}</a>\r\n            }\r\n          </li>\r\n        }\r\n        @if (pageNumbers > visiblePages && pages[pages.length - 1] < pageNumbers) {\r\n          @if (pages[pages.length - 1] < pageNumbers - 1) {\r\n            <li class=\"page-item\">\r\n              <span class=\"page-link\">...</span>\r\n            </li>\r\n          }\r\n          <li class=\"page-item\">\r\n            <a class=\"page-link\" href=\"#\" (click)=\"pageChange($event, pageNumbers)\">{{ pageNumbers }}</a>\r\n          </li>\r\n        }\r\n      }\r\n      <li class=\"page-item\" [class.disabled]=\"currentPage >= pageNumbers - 1\">\r\n        <a\r\n          class=\"page-link\"\r\n          [class.text]=\"textLinks\"\r\n          href=\"#\"\r\n          (click)=\"!(currentPage >= pageNumbers - 1) && pageChange($event, currentPage + 2)\">\r\n          <span class=\"visually-hidden\">\r\n            {{ (textLinks ? 'it.core.page' : 'it.core.next-page') | translate }}\r\n          </span>\r\n          @if (textLinks) {\r\n            {{ 'it.core.next' | translate }}\r\n          } @else {\r\n            <it-icon name=\"chevron-right\" color=\"primary\"></it-icon>\r\n          }\r\n        </a>\r\n      </li>\r\n    </ul>\r\n  }\r\n\r\n  @if (currentChanger !== undefined) {\r\n    <it-dropdown>\r\n      <span button>{{ currentChanger }} / {{ 'it.core.page' | translate | lowercase }}</span>\r\n      <ng-container list>\r\n        @for (value of changerValues; track value) {\r\n          <li\r\n            itDropdownItem\r\n            href=\"#\"\r\n            externalLink=\"true\"\r\n            tabindex=\"-1\"\r\n            (click)=\"changerChange($event, value)\"\r\n            (keyup.enter)=\"changerChange($event, value)\">\r\n            {{ value }} / {{ 'it.core.page' | translate | lowercase }}\r\n          </li>\r\n        }\r\n      </ng-container>\r\n    </it-dropdown>\r\n  }\r\n\r\n  @if (showJumpToPage) {\r\n    <it-input\r\n      type=\"number\"\r\n      [min]=\"1\"\r\n      [max]=\"pageNumbers\"\r\n      [label]=\"('it.core.go-to' | translate) + '...'\"\r\n      [formControl]=\"jumpToPage\"></it-input>\r\n  }\r\n\r\n  <p [class.d-none]=\"!totalNumberText.hasChildNodes()\" #totalNumberText>\r\n    <ng-content></ng-content>\r\n  </p>\r\n</nav>\r\n"
		}]
	}],
	ctorParameters: () => [],
	propDecorators: {
		currentPage: [{
			type: Input,
			args: [{ required: true }]
		}],
		pageNumbers: [{
			type: Input,
			args: [{ required: true }]
		}],
		visiblePages: [{ type: Input }],
		alignment: [{ type: Input }],
		simpleMode: [{
			type: Input,
			args: [{ transform: inputToBoolean }]
		}],
		textLinks: [{
			type: Input,
			args: [{ transform: inputToBoolean }]
		}],
		currentChanger: [{ type: Input }],
		changerValues: [{ type: Input }],
		showJumpToPage: [{
			type: Input,
			args: [{ transform: inputToBoolean }]
		}],
		pageEvent: [{ type: Output }],
		changerEvent: [{ type: Output }]
	}
});
var ItPopoverDirective = class ItPopoverDirective {
	set content(content) {
		this.element.setAttribute("data-bs-content", content);
	}
	set popoverTitle(title) {
		if (title) {
			this.element.setAttribute("title", title);
			this.element.setAttribute("data-bs-original-title", title);
		}
	}
	set popoverPlacement(placement) {
		this.element.setAttribute("data-bs-placement", placement);
	}
	set popoverContainer(container) {
		if (container) this.element.setAttribute("data-bs-container", container);
	}
	set popoverHtml(html) {
		this.element.setAttribute("data-bs-html", html ? "true" : "false");
	}
	set popoverTrigger(trigger) {
		if (trigger) this.element.setAttribute("data-bs-trigger", trigger);
	}
	constructor() {
		this._elementRef = inject(ElementRef);
		this.showEvent = new EventEmitter();
		this.shownEvent = new EventEmitter();
		this.hideEvent = new EventEmitter();
		this.hiddenEvent = new EventEmitter();
		this.insertedEvent = new EventEmitter();
		this.element = this._elementRef.nativeElement;
	}
	ngAfterViewInit() {
		this.element.setAttribute("data-bs-toggle", "popover");
		this.popover = Popover.getOrCreateInstance(this.element);
		this.element.addEventListener("show.bs.popover", (event) => this.showEvent.emit(event));
		this.element.addEventListener("shown.bs.popover", (event) => this.shownEvent.emit(event));
		this.element.addEventListener("hide.bs.popover", (event) => this.hideEvent.emit(event));
		this.element.addEventListener("hidden.bs.popover", (event) => this.hiddenEvent.emit(event));
		this.element.addEventListener("inserted.bs.popover", (event) => this.insertedEvent.emit(event));
	}
	ngOnDestroy() {
		this.dispose();
	}
	show() {
		this.popover?.show();
	}
	hide() {
		this.popover?.hide();
	}
	toggle() {
		this.popover?.toggle();
	}
	dispose() {
		this.popover?.dispose();
	}
	enable() {
		this.popover?.enable();
	}
	disable() {
		this.popover?.disable();
	}
	toggleEnabled() {
		this.popover?.disable();
	}
	update() {
		this.popover?.disable();
	}
	static {
		this.ɵfac = i0.ɵɵngDeclareFactory({
			minVersion: "12.0.0",
			version: "22.2.1",
			ngImport: i0,
			type: ItPopoverDirective,
			deps: [],
			target: i0.ɵɵFactoryTarget.Directive
		});
	}
	static {
		this.ɵdir = i0.ɵɵngDeclareDirective({
			minVersion: "16.1.0",
			version: "22.2.1",
			type: ItPopoverDirective,
			isStandalone: true,
			selector: "[itPopover]",
			inputs: {
				content: ["itPopover", "content"],
				popoverTitle: "popoverTitle",
				popoverPlacement: "popoverPlacement",
				popoverContainer: "popoverContainer",
				popoverHtml: [
					"popoverHtml",
					"popoverHtml",
					inputToBoolean
				],
				popoverTrigger: "popoverTrigger"
			},
			outputs: {
				showEvent: "showEvent",
				shownEvent: "shownEvent",
				hideEvent: "hideEvent",
				hiddenEvent: "hiddenEvent",
				insertedEvent: "insertedEvent"
			},
			exportAs: ["itPopover"],
			ngImport: i0
		});
	}
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.1",
	ngImport: i0,
	type: ItPopoverDirective,
	decorators: [{
		type: Directive,
		args: [{
			standalone: true,
			selector: "[itPopover]",
			exportAs: "itPopover"
		}]
	}],
	ctorParameters: () => [],
	propDecorators: {
		content: [{
			type: Input,
			args: ["itPopover"]
		}],
		popoverTitle: [{ type: Input }],
		popoverPlacement: [{ type: Input }],
		popoverContainer: [{ type: Input }],
		popoverHtml: [{
			type: Input,
			args: [{ transform: inputToBoolean }]
		}],
		popoverTrigger: [{ type: Input }],
		showEvent: [{ type: Output }],
		shownEvent: [{ type: Output }],
		hideEvent: [{ type: Output }],
		hiddenEvent: [{ type: Output }],
		insertedEvent: [{ type: Output }]
	}
});
var ItSpinnerComponent = class ItSpinnerComponent {
	constructor() {
		this.active = true;
	}
	static {
		this.ɵfac = i0.ɵɵngDeclareFactory({
			minVersion: "12.0.0",
			version: "22.2.1",
			ngImport: i0,
			type: ItSpinnerComponent,
			deps: [],
			target: i0.ɵɵFactoryTarget.Component
		});
	}
	static {
		this.ɵcmp = i0.ɵɵngDeclareComponent({
			minVersion: "17.0.0",
			version: "22.2.1",
			type: ItSpinnerComponent,
			isStandalone: true,
			selector: "it-spinner",
			inputs: {
				active: [
					"active",
					"active",
					inputToBoolean
				],
				small: [
					"small",
					"small",
					inputToBoolean
				],
				double: [
					"double",
					"double",
					inputToBoolean
				]
			},
			ngImport: i0,
			template: "<div class=\"progress-spinner\" [class.progress-spinner-double]=\"double\" [class.progress-spinner-active]=\"active\" [class.size-sm]=\"small\">\r\n  @if (double) {\r\n    <div class=\"progress-spinner-inner\"></div>\r\n    <div class=\"progress-spinner-inner\"></div>\r\n  }\r\n  <span class=\"visually-hidden\">{{ 'it.core.loading' | translate }}...</span>\r\n</div>\r\n",
			dependencies: [{
				kind: "ngmodule",
				type: TranslateModule
			}, {
				kind: "pipe",
				type: i1$1.TranslatePipe,
				name: "translate"
			}],
			changeDetection: i0.ChangeDetectionStrategy.OnPush
		});
	}
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.1",
	ngImport: i0,
	type: ItSpinnerComponent,
	decorators: [{
		type: Component,
		args: [{
			selector: "it-spinner",
			changeDetection: ChangeDetectionStrategy.OnPush,
			imports: [TranslateModule],
			template: "<div class=\"progress-spinner\" [class.progress-spinner-double]=\"double\" [class.progress-spinner-active]=\"active\" [class.size-sm]=\"small\">\r\n  @if (double) {\r\n    <div class=\"progress-spinner-inner\"></div>\r\n    <div class=\"progress-spinner-inner\"></div>\r\n  }\r\n  <span class=\"visually-hidden\">{{ 'it.core.loading' | translate }}...</span>\r\n</div>\r\n"
		}]
	}],
	propDecorators: {
		active: [{
			type: Input,
			args: [{ transform: inputToBoolean }]
		}],
		small: [{
			type: Input,
			args: [{ transform: inputToBoolean }]
		}],
		double: [{
			type: Input,
			args: [{ transform: inputToBoolean }]
		}]
	}
});
var ItSteppersItemComponent = class ItSteppersItemComponent extends ItAbstractComponent {
	static {
		this.ɵfac = i0.ɵɵngDeclareFactory({
			minVersion: "12.0.0",
			version: "22.2.1",
			ngImport: i0,
			type: ItSteppersItemComponent,
			deps: null,
			target: i0.ɵɵFactoryTarget.Component
		});
	}
	static {
		this.ɵcmp = i0.ɵɵngDeclareComponent({
			minVersion: "14.0.0",
			version: "22.2.1",
			type: ItSteppersItemComponent,
			isStandalone: true,
			selector: "it-steppers-item",
			inputs: {
				label: "label",
				icon: "icon",
				iconTitle: "iconTitle"
			},
			viewQueries: [{
				propertyName: "htmlContent",
				first: true,
				predicate: TemplateRef,
				descendants: true
			}],
			usesInheritance: true,
			ngImport: i0,
			template: "<ng-template>\r\n  <ng-content></ng-content>\r\n</ng-template>\r\n",
			changeDetection: i0.ChangeDetectionStrategy.OnPush
		});
	}
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.1",
	ngImport: i0,
	type: ItSteppersItemComponent,
	decorators: [{
		type: Component,
		args: [{
			selector: "it-steppers-item",
			changeDetection: ChangeDetectionStrategy.OnPush,
			imports: [],
			template: "<ng-template>\r\n  <ng-content></ng-content>\r\n</ng-template>\r\n"
		}]
	}],
	propDecorators: {
		label: [{
			type: Input,
			args: [{ required: true }]
		}],
		icon: [{ type: Input }],
		iconTitle: [{ type: Input }],
		htmlContent: [{
			type: ViewChild,
			args: [TemplateRef]
		}]
	}
});
var ItSteppersContainerComponent = class ItSteppersContainerComponent {
	constructor() {
		this._changeDetectorRef = inject(ChangeDetectorRef);
		this.confirmedLabel = null;
		this.showHeader = true;
		this.showBackButton = true;
		this.showForwardButton = true;
		this.backClick = new EventEmitter();
		this.forwardClick = new EventEmitter();
		this.confirmClick = new EventEmitter();
		this.saveClick = new EventEmitter();
	}
	ngAfterViewInit() {
		this.steps?.changes.pipe(startWith(void 0)).subscribe(() => {
			this.stepsSubscriptions?.forEach((sub) => sub.unsubscribe());
			this.stepsSubscriptions = this.steps?.map((step) => step.valueChanges.subscribe(() => {
				this._changeDetectorRef.detectChanges();
			}));
			this._changeDetectorRef.detectChanges();
		});
	}
	ngOnDestroy() {
		this.stepsSubscriptions?.forEach((step) => step.unsubscribe());
	}
	static {
		this.ɵfac = i0.ɵɵngDeclareFactory({
			minVersion: "12.0.0",
			version: "22.2.1",
			ngImport: i0,
			type: ItSteppersContainerComponent,
			deps: [],
			target: i0.ɵɵFactoryTarget.Component
		});
	}
	static {
		this.ɵcmp = i0.ɵɵngDeclareComponent({
			minVersion: "17.0.0",
			version: "22.2.1",
			type: ItSteppersContainerComponent,
			isStandalone: true,
			selector: "it-steppers-container",
			inputs: {
				confirmedLabel: "confirmedLabel",
				activeStep: "activeStep",
				showHeader: [
					"showHeader",
					"showHeader",
					inputToBoolean
				],
				dark: [
					"dark",
					"dark",
					inputToBoolean
				],
				steppersNumber: [
					"steppersNumber",
					"steppersNumber",
					inputToBoolean
				],
				progressStyle: "progressStyle",
				progressColor: "progressColor",
				showBackButton: [
					"showBackButton",
					"showBackButton",
					inputToBoolean
				],
				disableBackButton: [
					"disableBackButton",
					"disableBackButton",
					inputToBoolean
				],
				showForwardButton: [
					"showForwardButton",
					"showForwardButton",
					inputToBoolean
				],
				disableForwardButton: [
					"disableForwardButton",
					"disableForwardButton",
					inputToBoolean
				],
				showConfirmButton: [
					"showConfirmButton",
					"showConfirmButton",
					inputToBoolean
				],
				disableConfirmButton: [
					"disableConfirmButton",
					"disableConfirmButton",
					inputToBoolean
				],
				confirmLoading: [
					"confirmLoading",
					"confirmLoading",
					inputToBoolean
				],
				showSaveButton: [
					"showSaveButton",
					"showSaveButton",
					inputToBoolean
				],
				disableSaveButton: [
					"disableSaveButton",
					"disableSaveButton",
					inputToBoolean
				],
				saveLoading: [
					"saveLoading",
					"saveLoading",
					inputToBoolean
				]
			},
			outputs: {
				backClick: "backClick",
				forwardClick: "forwardClick",
				confirmClick: "confirmClick",
				saveClick: "saveClick"
			},
			queries: [{
				propertyName: "steps",
				predicate: ItSteppersItemComponent
			}],
			ngImport: i0,
			template: "<div class=\"steppers\" [class.bg-dark]=\"dark\">\r\n  @if (showHeader) {\r\n    <div class=\"steppers-header\">\r\n      @if (steps) {\r\n        <ul>\r\n          @for (step of steps; track step.id; let i = $index) {\r\n            <li [class.confirmed]=\"i < activeStep\" [class.active]=\"i === activeStep\" [class.no-line]=\"i === activeStep && steppersNumber\">\r\n              @if (step.icon && !steppersNumber) {\r\n                <it-icon [title]=\"step.iconTitle\" [name]=\"step.icon\"></it-icon>\r\n              }\r\n              @if (steppersNumber) {\r\n                <span class=\"steppers-number\">\r\n                  @if (i < activeStep) {\r\n                    <ng-container *ngTemplateOutlet=\"checkIcon\"></ng-container>\r\n                  } @else {\r\n                    <span class=\"visually-hidden\">{{ 'it.core.step' | translate }} </span>{{ i + 1 }}\r\n                  }\r\n                </span>\r\n              }\r\n              {{ step.label }}\r\n              @if (i < activeStep && !steppersNumber) {\r\n                <ng-container *ngTemplateOutlet=\"checkIcon\"></ng-container>\r\n              }\r\n              @if (i === activeStep) {\r\n                <span class=\"visually-hidden\">{{ 'it.core.active' | translate }}</span>\r\n              }\r\n            </li>\r\n          }\r\n        </ul>\r\n      }\r\n      @if (steps) {\r\n        <span class=\"steppers-index\" aria-hidden=\"true\">\r\n          @if (!steppersNumber) {\r\n            {{ activeStep + 1 + '/' + steps.length }}\r\n          } @else {\r\n            @for (step of steps; track step.id; let i = $index) {\r\n              <span [class.active]=\"i === activeStep\">{{ i + 1 }}</span>\r\n            }\r\n          }\r\n        </span>\r\n      }\r\n    </div>\r\n  }\r\n\r\n  @if (steps?.get(activeStep); as step) {\r\n    <div class=\"steppers-content\" aria-live=\"polite\">\r\n      <ng-container *ngTemplateOutlet=\"step.htmlContent\"></ng-container>\r\n    </div>\r\n  }\r\n\r\n  @if (showBackButton || showSaveButton || showForwardButton || showConfirmButton || !!progressStyle) {\r\n    <nav class=\"steppers-nav\">\r\n      @if (showBackButton) {\r\n        <button\r\n          type=\"button\"\r\n          itButton=\"outline-primary\"\r\n          size=\"sm\"\r\n          class=\"steppers-btn-prev\"\r\n          [disabled]=\"disableBackButton\"\r\n          (click)=\"backClick.emit(activeStep)\">\r\n          <it-icon [labelWaria]=\"'it.core.back' | translate\" name=\"chevron-left\" color=\"primary\"></it-icon>\r\n          {{ 'it.core.back' | translate }}\r\n        </button>\r\n      }\r\n      @if (!!progressStyle && steps) {\r\n        @if (progressStyle === 'dots') {\r\n          <ul class=\"steppers-dots\">\r\n            @for (step of steps; track step; let i = $index) {\r\n              <li [class.done]=\"i < activeStep\">\r\n                <span class=\"visually-hidden\">\r\n                  {{ 'it.core.step-of' | translate: { current: activeStep + 1, available: $safeNavigationMigration(steps?.length) } }}\r\n                  {{ i < activeStep ? '- ' + (confirmedLabel ? confirmedLabel : ('it.core.confirmed' | translate)) : '' }}\r\n                </span>\r\n              </li>\r\n            }\r\n          </ul>\r\n        } @else {\r\n          <div class=\"steppers-progress\">\r\n            <it-progress-bar [color]=\"progressColor\" [value]=\"(activeStep / (steps?.length || 1)) * 100\"></it-progress-bar>\r\n          </div>\r\n        }\r\n      }\r\n      @if (showSaveButton) {\r\n        <button\r\n          type=\"button\"\r\n          itButton=\"primary\"\r\n          size=\"sm\"\r\n          class=\"steppers-btn-save\"\r\n          [progress]=\"saveLoading\"\r\n          [disabled]=\"saveLoading || disableSaveButton\"\r\n          (click)=\"saveClick.emit(activeStep)\">\r\n          {{ 'it.general.save' | translate }}\r\n        </button>\r\n      }\r\n      @if (showForwardButton) {\r\n        <button\r\n          type=\"button\"\r\n          itButton=\"outline-primary\"\r\n          size=\"sm\"\r\n          class=\"steppers-btn-next\"\r\n          [disabled]=\"disableForwardButton\"\r\n          (click)=\"forwardClick.emit(activeStep)\">\r\n          {{ 'it.core.forward' | translate }}\r\n          <it-icon [labelWaria]=\"'it.core.forward' | translate\" name=\"chevron-right\" color=\"primary\"></it-icon>\r\n        </button>\r\n      }\r\n      @if (showConfirmButton) {\r\n        <button\r\n          type=\"button\"\r\n          itButton=\"primary\"\r\n          size=\"sm\"\r\n          class=\"steppers-btn-confirm d-lg-block\"\r\n          [progress]=\"confirmLoading\"\r\n          [disabled]=\"confirmLoading || disableConfirmButton\"\r\n          (click)=\"confirmClick.emit(activeStep)\">\r\n          {{ confirmedLabel ? confirmedLabel : ('it.core.confirmed' | translate) }}\r\n        </button>\r\n      }\r\n    </nav>\r\n  }\r\n</div>\r\n\r\n<ng-template #checkIcon>\r\n  <it-icon\r\n    [labelWaria]=\"confirmedLabel ? confirmedLabel : ('it.core.confirmed' | translate)\"\r\n    name=\"check\"\r\n    class=\"steppers-success\"></it-icon>\r\n  <span class=\"visually-hidden\">{{ confirmedLabel ? confirmedLabel : ('it.core.confirmed' | translate) }}</span>\r\n</ng-template>\r\n",
			dependencies: [
				{
					kind: "component",
					type: ItIconComponent,
					selector: "it-icon",
					inputs: [
						"name",
						"size",
						"color",
						"padded",
						"svgClass",
						"title",
						"labelWaria"
					]
				},
				{
					kind: "directive",
					type: NgTemplateOutlet,
					selector: "[ngTemplateOutlet]",
					inputs: [
						"ngTemplateOutletContext",
						"ngTemplateOutlet",
						"ngTemplateOutletInjector"
					]
				},
				{
					kind: "ngmodule",
					type: TranslateModule
				},
				{
					kind: "directive",
					type: ItButtonDirective,
					selector: "[itButton]",
					inputs: [
						"itButton",
						"size",
						"block",
						"disabled",
						"type"
					],
					exportAs: ["itButton"]
				},
				{
					kind: "component",
					type: ItProgressBarComponent,
					selector: "it-progress-bar",
					inputs: [
						"value",
						"showLabel",
						"indeterminate",
						"color"
					]
				},
				{
					kind: "component",
					type: ItProgressButtonComponent,
					selector: "button[itButton][progress]",
					inputs: ["progress", "progressColor"]
				},
				{
					kind: "pipe",
					type: i1$1.TranslatePipe,
					name: "translate"
				}
			],
			changeDetection: i0.ChangeDetectionStrategy.OnPush
		});
	}
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.1",
	ngImport: i0,
	type: ItSteppersContainerComponent,
	decorators: [{
		type: Component,
		args: [{
			selector: "it-steppers-container",
			changeDetection: ChangeDetectionStrategy.OnPush,
			imports: [
				ItIconComponent,
				NgTemplateOutlet,
				TranslateModule,
				ItButtonDirective,
				ItProgressBarComponent,
				ItProgressButtonComponent
			],
			template: "<div class=\"steppers\" [class.bg-dark]=\"dark\">\r\n  @if (showHeader) {\r\n    <div class=\"steppers-header\">\r\n      @if (steps) {\r\n        <ul>\r\n          @for (step of steps; track step.id; let i = $index) {\r\n            <li [class.confirmed]=\"i < activeStep\" [class.active]=\"i === activeStep\" [class.no-line]=\"i === activeStep && steppersNumber\">\r\n              @if (step.icon && !steppersNumber) {\r\n                <it-icon [title]=\"step.iconTitle\" [name]=\"step.icon\"></it-icon>\r\n              }\r\n              @if (steppersNumber) {\r\n                <span class=\"steppers-number\">\r\n                  @if (i < activeStep) {\r\n                    <ng-container *ngTemplateOutlet=\"checkIcon\"></ng-container>\r\n                  } @else {\r\n                    <span class=\"visually-hidden\">{{ 'it.core.step' | translate }} </span>{{ i + 1 }}\r\n                  }\r\n                </span>\r\n              }\r\n              {{ step.label }}\r\n              @if (i < activeStep && !steppersNumber) {\r\n                <ng-container *ngTemplateOutlet=\"checkIcon\"></ng-container>\r\n              }\r\n              @if (i === activeStep) {\r\n                <span class=\"visually-hidden\">{{ 'it.core.active' | translate }}</span>\r\n              }\r\n            </li>\r\n          }\r\n        </ul>\r\n      }\r\n      @if (steps) {\r\n        <span class=\"steppers-index\" aria-hidden=\"true\">\r\n          @if (!steppersNumber) {\r\n            {{ activeStep + 1 + '/' + steps.length }}\r\n          } @else {\r\n            @for (step of steps; track step.id; let i = $index) {\r\n              <span [class.active]=\"i === activeStep\">{{ i + 1 }}</span>\r\n            }\r\n          }\r\n        </span>\r\n      }\r\n    </div>\r\n  }\r\n\r\n  @if (steps?.get(activeStep); as step) {\r\n    <div class=\"steppers-content\" aria-live=\"polite\">\r\n      <ng-container *ngTemplateOutlet=\"step.htmlContent\"></ng-container>\r\n    </div>\r\n  }\r\n\r\n  @if (showBackButton || showSaveButton || showForwardButton || showConfirmButton || !!progressStyle) {\r\n    <nav class=\"steppers-nav\">\r\n      @if (showBackButton) {\r\n        <button\r\n          type=\"button\"\r\n          itButton=\"outline-primary\"\r\n          size=\"sm\"\r\n          class=\"steppers-btn-prev\"\r\n          [disabled]=\"disableBackButton\"\r\n          (click)=\"backClick.emit(activeStep)\">\r\n          <it-icon [labelWaria]=\"'it.core.back' | translate\" name=\"chevron-left\" color=\"primary\"></it-icon>\r\n          {{ 'it.core.back' | translate }}\r\n        </button>\r\n      }\r\n      @if (!!progressStyle && steps) {\r\n        @if (progressStyle === 'dots') {\r\n          <ul class=\"steppers-dots\">\r\n            @for (step of steps; track step; let i = $index) {\r\n              <li [class.done]=\"i < activeStep\">\r\n                <span class=\"visually-hidden\">\r\n                  {{ 'it.core.step-of' | translate: { current: activeStep + 1, available: $safeNavigationMigration(steps?.length) } }}\r\n                  {{ i < activeStep ? '- ' + (confirmedLabel ? confirmedLabel : ('it.core.confirmed' | translate)) : '' }}\r\n                </span>\r\n              </li>\r\n            }\r\n          </ul>\r\n        } @else {\r\n          <div class=\"steppers-progress\">\r\n            <it-progress-bar [color]=\"progressColor\" [value]=\"(activeStep / (steps?.length || 1)) * 100\"></it-progress-bar>\r\n          </div>\r\n        }\r\n      }\r\n      @if (showSaveButton) {\r\n        <button\r\n          type=\"button\"\r\n          itButton=\"primary\"\r\n          size=\"sm\"\r\n          class=\"steppers-btn-save\"\r\n          [progress]=\"saveLoading\"\r\n          [disabled]=\"saveLoading || disableSaveButton\"\r\n          (click)=\"saveClick.emit(activeStep)\">\r\n          {{ 'it.general.save' | translate }}\r\n        </button>\r\n      }\r\n      @if (showForwardButton) {\r\n        <button\r\n          type=\"button\"\r\n          itButton=\"outline-primary\"\r\n          size=\"sm\"\r\n          class=\"steppers-btn-next\"\r\n          [disabled]=\"disableForwardButton\"\r\n          (click)=\"forwardClick.emit(activeStep)\">\r\n          {{ 'it.core.forward' | translate }}\r\n          <it-icon [labelWaria]=\"'it.core.forward' | translate\" name=\"chevron-right\" color=\"primary\"></it-icon>\r\n        </button>\r\n      }\r\n      @if (showConfirmButton) {\r\n        <button\r\n          type=\"button\"\r\n          itButton=\"primary\"\r\n          size=\"sm\"\r\n          class=\"steppers-btn-confirm d-lg-block\"\r\n          [progress]=\"confirmLoading\"\r\n          [disabled]=\"confirmLoading || disableConfirmButton\"\r\n          (click)=\"confirmClick.emit(activeStep)\">\r\n          {{ confirmedLabel ? confirmedLabel : ('it.core.confirmed' | translate) }}\r\n        </button>\r\n      }\r\n    </nav>\r\n  }\r\n</div>\r\n\r\n<ng-template #checkIcon>\r\n  <it-icon\r\n    [labelWaria]=\"confirmedLabel ? confirmedLabel : ('it.core.confirmed' | translate)\"\r\n    name=\"check\"\r\n    class=\"steppers-success\"></it-icon>\r\n  <span class=\"visually-hidden\">{{ confirmedLabel ? confirmedLabel : ('it.core.confirmed' | translate) }}</span>\r\n</ng-template>\r\n"
		}]
	}],
	ctorParameters: () => [],
	propDecorators: {
		confirmedLabel: [{ type: Input }],
		activeStep: [{
			type: Input,
			args: [{ required: true }]
		}],
		showHeader: [{
			type: Input,
			args: [{ transform: inputToBoolean }]
		}],
		dark: [{
			type: Input,
			args: [{ transform: inputToBoolean }]
		}],
		steppersNumber: [{
			type: Input,
			args: [{ transform: inputToBoolean }]
		}],
		progressStyle: [{ type: Input }],
		progressColor: [{ type: Input }],
		showBackButton: [{
			type: Input,
			args: [{ transform: inputToBoolean }]
		}],
		disableBackButton: [{
			type: Input,
			args: [{ transform: inputToBoolean }]
		}],
		showForwardButton: [{
			type: Input,
			args: [{ transform: inputToBoolean }]
		}],
		disableForwardButton: [{
			type: Input,
			args: [{ transform: inputToBoolean }]
		}],
		showConfirmButton: [{
			type: Input,
			args: [{ transform: inputToBoolean }]
		}],
		disableConfirmButton: [{
			type: Input,
			args: [{ transform: inputToBoolean }]
		}],
		confirmLoading: [{
			type: Input,
			args: [{ transform: inputToBoolean }]
		}],
		showSaveButton: [{
			type: Input,
			args: [{ transform: inputToBoolean }]
		}],
		disableSaveButton: [{
			type: Input,
			args: [{ transform: inputToBoolean }]
		}],
		saveLoading: [{
			type: Input,
			args: [{ transform: inputToBoolean }]
		}],
		steps: [{
			type: ContentChildren,
			args: [ItSteppersItemComponent]
		}],
		backClick: [{ type: Output }],
		forwardClick: [{ type: Output }],
		confirmClick: [{ type: Output }],
		saveClick: [{ type: Output }]
	}
});
const steppersComponents = [ItSteppersContainerComponent, ItSteppersItemComponent];
var ItSteppersModule = class ItSteppersModule {
	static {
		this.ɵfac = i0.ɵɵngDeclareFactory({
			minVersion: "12.0.0",
			version: "22.2.1",
			ngImport: i0,
			type: ItSteppersModule,
			deps: [],
			target: i0.ɵɵFactoryTarget.NgModule
		});
	}
	static {
		this.ɵmod = i0.ɵɵngDeclareNgModule({
			minVersion: "14.0.0",
			version: "22.2.1",
			ngImport: i0,
			type: ItSteppersModule,
			imports: [ItSteppersContainerComponent, ItSteppersItemComponent],
			exports: [ItSteppersContainerComponent, ItSteppersItemComponent]
		});
	}
	static {
		this.ɵinj = i0.ɵɵngDeclareInjector({
			minVersion: "12.0.0",
			version: "22.2.1",
			ngImport: i0,
			type: ItSteppersModule,
			imports: [ItSteppersContainerComponent]
		});
	}
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.1",
	ngImport: i0,
	type: ItSteppersModule,
	decorators: [{
		type: NgModule,
		args: [{
			imports: steppersComponents,
			exports: steppersComponents
		}]
	}]
});
var ItTabItemComponent = class ItTabItemComponent extends ItAbstractComponent {
	constructor() {
		super(...arguments);
		this.class = "";
	}
	ngAfterViewInit() {
		super.ngAfterViewInit();
		this._renderer.removeAttribute(this._elementRef.nativeElement, "class");
	}
	static {
		this.ɵfac = i0.ɵɵngDeclareFactory({
			minVersion: "12.0.0",
			version: "22.2.1",
			ngImport: i0,
			type: ItTabItemComponent,
			deps: null,
			target: i0.ɵɵFactoryTarget.Component
		});
	}
	static {
		this.ɵcmp = i0.ɵɵngDeclareComponent({
			minVersion: "16.1.0",
			version: "22.2.1",
			type: ItTabItemComponent,
			isStandalone: true,
			selector: "it-tab-item",
			inputs: {
				label: "label",
				icon: "icon",
				active: [
					"active",
					"active",
					inputToBoolean
				],
				disabled: [
					"disabled",
					"disabled",
					inputToBoolean
				],
				class: "class"
			},
			viewQueries: [{
				propertyName: "htmlContent",
				first: true,
				predicate: TemplateRef,
				descendants: true
			}],
			usesInheritance: true,
			ngImport: i0,
			template: "<ng-template>\r\n  <ng-content></ng-content>\r\n</ng-template>\r\n",
			changeDetection: i0.ChangeDetectionStrategy.OnPush
		});
	}
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.1",
	ngImport: i0,
	type: ItTabItemComponent,
	decorators: [{
		type: Component,
		args: [{
			selector: "it-tab-item",
			changeDetection: ChangeDetectionStrategy.OnPush,
			imports: [],
			template: "<ng-template>\r\n  <ng-content></ng-content>\r\n</ng-template>\r\n"
		}]
	}],
	propDecorators: {
		label: [{ type: Input }],
		icon: [{ type: Input }],
		active: [{
			type: Input,
			args: [{ transform: inputToBoolean }]
		}],
		disabled: [{
			type: Input,
			args: [{ transform: inputToBoolean }]
		}],
		class: [{ type: Input }],
		htmlContent: [{
			type: ViewChild,
			args: [TemplateRef]
		}]
	}
});
var ItTabContainerComponent = class ItTabContainerComponent extends ItAbstractComponent {
	constructor() {
		super();
		this.tabSelected = new EventEmitter();
		this.tabClosed = new EventEmitter();
		this.tabAdded = new EventEmitter();
	}
	ngAfterViewInit() {
		super.ngAfterViewInit();
		this.tabs?.changes.pipe(startWith(void 0), tap(() => {
			this.tabSubscriptions?.forEach((sub) => sub.unsubscribe());
			this.tabSubscriptions = this.tabs?.map((tab) => tab.valueChanges.subscribe(() => {
				this._changeDetectorRef.detectChanges();
			}));
			this._changeDetectorRef.detectChanges();
		}), switchMap(() => this.tabNavLinks?.changes.pipe(startWith(void 0)) || of(void 0))).subscribe(() => {
			this.tabNavLinks?.forEach((tabNavLink) => {
				const triggerEl = tabNavLink.nativeElement, tabTrigger = Tab.getOrCreateInstance(triggerEl);
				if (triggerEl.getAttribute("tab-listener") !== "true") {
					triggerEl.addEventListener("click", (event) => {
						event.preventDefault();
						tabTrigger.show();
						this._changeDetectorRef.detectChanges();
					});
					triggerEl.setAttribute("tab-listener", "true");
				}
			});
		});
	}
	ngOnDestroy() {
		this.tabSubscriptions?.forEach((sub) => sub.unsubscribe());
	}
	onTab(tab) {
		this.tabSelected.emit(tab);
	}
	clickToClose(index) {
		this.tabClosed.emit(index);
	}
	clickToAdd($event) {
		$event.preventDefault();
		this.tabAdded.emit();
	}
	static {
		this.ɵfac = i0.ɵɵngDeclareFactory({
			minVersion: "12.0.0",
			version: "22.2.1",
			ngImport: i0,
			type: ItTabContainerComponent,
			deps: [],
			target: i0.ɵɵFactoryTarget.Component
		});
	}
	static {
		this.ɵcmp = i0.ɵɵngDeclareComponent({
			minVersion: "17.0.0",
			version: "22.2.1",
			type: ItTabContainerComponent,
			isStandalone: true,
			selector: "it-tab-container",
			inputs: {
				auto: [
					"auto",
					"auto",
					inputToBoolean
				],
				iconText: [
					"iconText",
					"iconText",
					inputToBoolean
				],
				dark: [
					"dark",
					"dark",
					inputToBoolean
				],
				cards: [
					"cards",
					"cards",
					inputToBoolean
				],
				vertical: [
					"vertical",
					"vertical",
					inputToBoolean
				],
				inverted: [
					"inverted",
					"inverted",
					inputToBoolean
				],
				editable: [
					"editable",
					"editable",
					inputToBoolean
				]
			},
			outputs: {
				tabSelected: "tabSelected",
				tabClosed: "tabClosed",
				tabAdded: "tabAdded"
			},
			queries: [{
				propertyName: "tabs",
				predicate: ItTabItemComponent
			}],
			viewQueries: [{
				propertyName: "tabNavLinks",
				predicate: ["tabNavLinks"],
				descendants: true
			}],
			usesInheritance: true,
			ngImport: i0,
			template: "<div\r\n  [class.row]=\"vertical\"\r\n  [class.flex-row-reverse]=\"inverted && vertical\"\r\n  [class.d-flex]=\"inverted && !vertical\"\r\n  [class.flex-column-reverse]=\"inverted && !vertical\">\r\n  <div\r\n    [class.col-5]=\"inverted && vertical\"\r\n    [class.col-md-4]=\"inverted && vertical\"\r\n    [class.col-lg-3]=\"inverted && vertical\"\r\n    [class.col-4]=\"!inverted && vertical\"\r\n    [class.col-md-3]=\"!inverted && vertical\">\r\n    @if (tabs) {\r\n      <ul\r\n        class=\"nav nav-tabs\"\r\n        [class.nav-tabs-editable]=\"editable\"\r\n        [class.nav-tabs-cards]=\"cards\"\r\n        [class.nav-tabs-vertical]=\"vertical\"\r\n        [class.auto]=\"auto\"\r\n        [class.nav-tabs-icon-text]=\"iconText\"\r\n        [class.nav-dark]=\"dark\"\r\n        role=\"tablist\">\r\n        @for (tab of tabs; track tab.id; let i = $index) {\r\n          <li class=\"nav-item\">\r\n            <a\r\n              #tabNavLinks\r\n              [id]=\"tab.id + '-tab-link'\"\r\n              role=\"tab\"\r\n              class=\"nav-link\"\r\n              [class.active]=\"tab.active\"\r\n              [class.disabled]=\"tab.disabled\"\r\n              [attr.href]=\"'#' + tab.id + '-tab'\"\r\n              [attr.aria-controls]=\"tab.id + '-tab'\"\r\n              (click)=\"onTab(tab)\">\r\n              @if (tab.icon) {\r\n                <it-icon [name]=\"tab.icon\" class=\"me-2\"></it-icon>\r\n              }\r\n              {{ tab.label }}\r\n            </a>\r\n            @if (editable) {\r\n              <a class=\"nav-link-close\" (click)=\"clickToClose(i)\" (keypress)=\"clickToClose(i)\" [attr.disabled]=\"tab.disabled\">\r\n                <it-icon name=\"close\"></it-icon>\r\n              </a>\r\n            }\r\n          </li>\r\n        }\r\n        @if (editable) {\r\n          <li class=\"nav-item\">\r\n            <a href=\"#\" class=\"nav-tab-add\" (click)=\"clickToAdd($event)\" (keypress)=\"clickToAdd($event)\"\r\n              ><span class=\"visually-hidden\"> Aggiungi un tab</span></a\r\n            >\r\n          </li>\r\n        }\r\n      </ul>\r\n    }\r\n  </div>\r\n  <div\r\n    [class.col-7]=\"inverted && vertical\"\r\n    [class.col-md-8]=\"inverted && vertical\"\r\n    [class.col-lg-9]=\"inverted && vertical\"\r\n    [class.col-8]=\"!inverted && vertical\"\r\n    [class.col-md-9]=\"!inverted && vertical\">\r\n    @if (tabs) {\r\n      <div class=\"tab-content\">\r\n        @for (tab of tabs; track tab.id) {\r\n          <div\r\n            [id]=\"tab.id + '-tab'\"\r\n            class=\"tab-pane p-4 fade {{ tab.class ?? '' }}\"\r\n            [class.active]=\"tab.active\"\r\n            [class.show]=\"tab.active\"\r\n            role=\"tabpanel\"\r\n            [attr.aria-labelledby]=\"tab.id + '-tab-link'\">\r\n            <ng-container *ngTemplateOutlet=\"tab.htmlContent\"></ng-container>\r\n          </div>\r\n        }\r\n      </div>\r\n    }\r\n  </div>\r\n</div>\r\n",
			dependencies: [{
				kind: "component",
				type: ItIconComponent,
				selector: "it-icon",
				inputs: [
					"name",
					"size",
					"color",
					"padded",
					"svgClass",
					"title",
					"labelWaria"
				]
			}, {
				kind: "directive",
				type: NgTemplateOutlet,
				selector: "[ngTemplateOutlet]",
				inputs: [
					"ngTemplateOutletContext",
					"ngTemplateOutlet",
					"ngTemplateOutletInjector"
				]
			}],
			changeDetection: i0.ChangeDetectionStrategy.OnPush
		});
	}
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.1",
	ngImport: i0,
	type: ItTabContainerComponent,
	decorators: [{
		type: Component,
		args: [{
			selector: "it-tab-container",
			changeDetection: ChangeDetectionStrategy.OnPush,
			imports: [ItIconComponent, NgTemplateOutlet],
			template: "<div\r\n  [class.row]=\"vertical\"\r\n  [class.flex-row-reverse]=\"inverted && vertical\"\r\n  [class.d-flex]=\"inverted && !vertical\"\r\n  [class.flex-column-reverse]=\"inverted && !vertical\">\r\n  <div\r\n    [class.col-5]=\"inverted && vertical\"\r\n    [class.col-md-4]=\"inverted && vertical\"\r\n    [class.col-lg-3]=\"inverted && vertical\"\r\n    [class.col-4]=\"!inverted && vertical\"\r\n    [class.col-md-3]=\"!inverted && vertical\">\r\n    @if (tabs) {\r\n      <ul\r\n        class=\"nav nav-tabs\"\r\n        [class.nav-tabs-editable]=\"editable\"\r\n        [class.nav-tabs-cards]=\"cards\"\r\n        [class.nav-tabs-vertical]=\"vertical\"\r\n        [class.auto]=\"auto\"\r\n        [class.nav-tabs-icon-text]=\"iconText\"\r\n        [class.nav-dark]=\"dark\"\r\n        role=\"tablist\">\r\n        @for (tab of tabs; track tab.id; let i = $index) {\r\n          <li class=\"nav-item\">\r\n            <a\r\n              #tabNavLinks\r\n              [id]=\"tab.id + '-tab-link'\"\r\n              role=\"tab\"\r\n              class=\"nav-link\"\r\n              [class.active]=\"tab.active\"\r\n              [class.disabled]=\"tab.disabled\"\r\n              [attr.href]=\"'#' + tab.id + '-tab'\"\r\n              [attr.aria-controls]=\"tab.id + '-tab'\"\r\n              (click)=\"onTab(tab)\">\r\n              @if (tab.icon) {\r\n                <it-icon [name]=\"tab.icon\" class=\"me-2\"></it-icon>\r\n              }\r\n              {{ tab.label }}\r\n            </a>\r\n            @if (editable) {\r\n              <a class=\"nav-link-close\" (click)=\"clickToClose(i)\" (keypress)=\"clickToClose(i)\" [attr.disabled]=\"tab.disabled\">\r\n                <it-icon name=\"close\"></it-icon>\r\n              </a>\r\n            }\r\n          </li>\r\n        }\r\n        @if (editable) {\r\n          <li class=\"nav-item\">\r\n            <a href=\"#\" class=\"nav-tab-add\" (click)=\"clickToAdd($event)\" (keypress)=\"clickToAdd($event)\"\r\n              ><span class=\"visually-hidden\"> Aggiungi un tab</span></a\r\n            >\r\n          </li>\r\n        }\r\n      </ul>\r\n    }\r\n  </div>\r\n  <div\r\n    [class.col-7]=\"inverted && vertical\"\r\n    [class.col-md-8]=\"inverted && vertical\"\r\n    [class.col-lg-9]=\"inverted && vertical\"\r\n    [class.col-8]=\"!inverted && vertical\"\r\n    [class.col-md-9]=\"!inverted && vertical\">\r\n    @if (tabs) {\r\n      <div class=\"tab-content\">\r\n        @for (tab of tabs; track tab.id) {\r\n          <div\r\n            [id]=\"tab.id + '-tab'\"\r\n            class=\"tab-pane p-4 fade {{ tab.class ?? '' }}\"\r\n            [class.active]=\"tab.active\"\r\n            [class.show]=\"tab.active\"\r\n            role=\"tabpanel\"\r\n            [attr.aria-labelledby]=\"tab.id + '-tab-link'\">\r\n            <ng-container *ngTemplateOutlet=\"tab.htmlContent\"></ng-container>\r\n          </div>\r\n        }\r\n      </div>\r\n    }\r\n  </div>\r\n</div>\r\n"
		}]
	}],
	ctorParameters: () => [],
	propDecorators: {
		auto: [{
			type: Input,
			args: [{ transform: inputToBoolean }]
		}],
		iconText: [{
			type: Input,
			args: [{ transform: inputToBoolean }]
		}],
		dark: [{
			type: Input,
			args: [{ transform: inputToBoolean }]
		}],
		cards: [{
			type: Input,
			args: [{ transform: inputToBoolean }]
		}],
		vertical: [{
			type: Input,
			args: [{ transform: inputToBoolean }]
		}],
		inverted: [{
			type: Input,
			args: [{ transform: inputToBoolean }]
		}],
		editable: [{
			type: Input,
			args: [{ transform: inputToBoolean }]
		}],
		tabs: [{
			type: ContentChildren,
			args: [ItTabItemComponent]
		}],
		tabNavLinks: [{
			type: ViewChildren,
			args: ["tabNavLinks"]
		}],
		tabSelected: [{ type: Output }],
		tabClosed: [{ type: Output }],
		tabAdded: [{ type: Output }]
	}
});
const tabComponents = [ItTabContainerComponent, ItTabItemComponent];
var ItTabModule = class ItTabModule {
	static {
		this.ɵfac = i0.ɵɵngDeclareFactory({
			minVersion: "12.0.0",
			version: "22.2.1",
			ngImport: i0,
			type: ItTabModule,
			deps: [],
			target: i0.ɵɵFactoryTarget.NgModule
		});
	}
	static {
		this.ɵmod = i0.ɵɵngDeclareNgModule({
			minVersion: "14.0.0",
			version: "22.2.1",
			ngImport: i0,
			type: ItTabModule,
			imports: [ItTabContainerComponent, ItTabItemComponent],
			exports: [ItTabContainerComponent, ItTabItemComponent]
		});
	}
	static {
		this.ɵinj = i0.ɵɵngDeclareInjector({
			minVersion: "12.0.0",
			version: "22.2.1",
			ngImport: i0,
			type: ItTabModule
		});
	}
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.1",
	ngImport: i0,
	type: ItTabModule,
	decorators: [{
		type: NgModule,
		args: [{
			imports: tabComponents,
			exports: tabComponents
		}]
	}]
});
var ItTableComponent = class ItTableComponent {
	constructor() {
		this.responsive = "responsive";
	}
	static {
		this.ɵfac = i0.ɵɵngDeclareFactory({
			minVersion: "12.0.0",
			version: "22.2.1",
			ngImport: i0,
			type: ItTableComponent,
			deps: [],
			target: i0.ɵɵFactoryTarget.Component
		});
	}
	static {
		this.ɵcmp = i0.ɵɵngDeclareComponent({
			minVersion: "16.1.0",
			version: "22.2.1",
			type: ItTableComponent,
			isStandalone: true,
			selector: "it-table",
			inputs: {
				color: "color",
				headColor: "headColor",
				alignment: "alignment",
				striped: [
					"striped",
					"striped",
					inputToBoolean
				],
				hover: [
					"hover",
					"hover",
					inputToBoolean
				],
				bordered: [
					"bordered",
					"bordered",
					inputToBoolean
				],
				borderless: [
					"borderless",
					"borderless",
					inputToBoolean
				],
				compact: [
					"compact",
					"compact",
					inputToBoolean
				],
				captionTop: [
					"captionTop",
					"captionTop",
					inputToBoolean
				],
				responsive: "responsive"
			},
			ngImport: i0,
			template: "<div [class]=\"responsive ? 'table-' + responsive : undefined\">\r\n  <table\r\n    class=\"table{{ color ? ' table-' + color : '' }}{{ alignment ? ' ' + alignment : '' }}\"\r\n    [class.table-striped]=\"striped\"\r\n    [class.table-hover]=\"hover\"\r\n    [class.table-bordered]=\"bordered\"\r\n    [class.table-borderless]=\"borderless\"\r\n    [class.table-sm]=\"compact\"\r\n    [class.caption-top]=\"captionTop\">\r\n    <caption>\r\n      <ng-content select=\"[caption]\"></ng-content>\r\n    </caption>\r\n    <thead [class]=\"headColor ? 'table-' + headColor : undefined\">\r\n      <ng-content select=\"[thead]\"></ng-content>\r\n    </thead>\r\n    <tbody>\r\n      <ng-content select=\"[tbody]\"></ng-content>\r\n    </tbody>\r\n    <tfoot>\r\n      <ng-content select=\"[tfoot]\"></ng-content>\r\n    </tfoot>\r\n  </table>\r\n</div>\r\n",
			styles: ["caption:empty{display:none}caption:empty~thead{border-top:none!important}\n"],
			changeDetection: i0.ChangeDetectionStrategy.OnPush
		});
	}
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.1",
	ngImport: i0,
	type: ItTableComponent,
	decorators: [{
		type: Component,
		args: [{
			selector: "it-table",
			changeDetection: ChangeDetectionStrategy.OnPush,
			imports: [],
			template: "<div [class]=\"responsive ? 'table-' + responsive : undefined\">\r\n  <table\r\n    class=\"table{{ color ? ' table-' + color : '' }}{{ alignment ? ' ' + alignment : '' }}\"\r\n    [class.table-striped]=\"striped\"\r\n    [class.table-hover]=\"hover\"\r\n    [class.table-bordered]=\"bordered\"\r\n    [class.table-borderless]=\"borderless\"\r\n    [class.table-sm]=\"compact\"\r\n    [class.caption-top]=\"captionTop\">\r\n    <caption>\r\n      <ng-content select=\"[caption]\"></ng-content>\r\n    </caption>\r\n    <thead [class]=\"headColor ? 'table-' + headColor : undefined\">\r\n      <ng-content select=\"[thead]\"></ng-content>\r\n    </thead>\r\n    <tbody>\r\n      <ng-content select=\"[tbody]\"></ng-content>\r\n    </tbody>\r\n    <tfoot>\r\n      <ng-content select=\"[tfoot]\"></ng-content>\r\n    </tfoot>\r\n  </table>\r\n</div>\r\n",
			styles: ["caption:empty{display:none}caption:empty~thead{border-top:none!important}\n"]
		}]
	}],
	propDecorators: {
		color: [{ type: Input }],
		headColor: [{ type: Input }],
		alignment: [{ type: Input }],
		striped: [{
			type: Input,
			args: [{ transform: inputToBoolean }]
		}],
		hover: [{
			type: Input,
			args: [{ transform: inputToBoolean }]
		}],
		bordered: [{
			type: Input,
			args: [{ transform: inputToBoolean }]
		}],
		borderless: [{
			type: Input,
			args: [{ transform: inputToBoolean }]
		}],
		compact: [{
			type: Input,
			args: [{ transform: inputToBoolean }]
		}],
		captionTop: [{
			type: Input,
			args: [{ transform: inputToBoolean }]
		}],
		responsive: [{ type: Input }]
	}
});
const IT_SORT_DEFAULT_OPTIONS = new InjectionToken("IT_SORT_DEFAULT_OPTIONS");
var ItSortDirective = class ItSortDirective {
	constructor() {
		this._defaultOptions = inject(IT_SORT_DEFAULT_OPTIONS, { optional: true });
		this.start = "asc";
		this.sortDisabled = false;
		this.sortChange = new EventEmitter();
		this.sortDirectiveClass = "it-sort";
		this.sortables = /* @__PURE__ */ new Map();
		this._stateChanges = new Subject();
	}
	get direction() {
		return this._direction;
	}
	set direction(direction) {
		this._direction = direction;
	}
	register(sortable) {
		this.sortables.set(sortable.id, sortable);
	}
	deregister(sortable) {
		this.sortables.delete(sortable.id);
	}
	sort(sortable) {
		if (this.active != sortable.id) {
			this.active = sortable.id;
			this.direction = sortable.start ? sortable.start : this.start;
		} else this.direction = this.getNextSortDirection(sortable);
		this.sortChange.emit({
			active: this.active,
			direction: this.direction
		});
	}
	getNextSortDirection(sortable) {
		if (!sortable) return;
		const disableClear = sortable?.disableSortClear ?? this.disableSortClear ?? !!this._defaultOptions?.disableClear;
		const sortDirectionCycle = getSortDirectionCycle(sortable.start || this.start, disableClear);
		let nextDirectionIndex = sortDirectionCycle.indexOf(this.direction) + 1;
		if (nextDirectionIndex >= sortDirectionCycle.length) nextDirectionIndex = 0;
		return sortDirectionCycle[nextDirectionIndex];
	}
	ngOnChanges() {
		this._stateChanges.next();
	}
	ngOnDestroy() {
		this._stateChanges.complete();
	}
	static {
		this.ɵfac = i0.ɵɵngDeclareFactory({
			minVersion: "12.0.0",
			version: "22.2.1",
			ngImport: i0,
			type: ItSortDirective,
			deps: [],
			target: i0.ɵɵFactoryTarget.Directive
		});
	}
	static {
		this.ɵdir = i0.ɵɵngDeclareDirective({
			minVersion: "16.1.0",
			version: "22.2.1",
			type: ItSortDirective,
			isStandalone: true,
			selector: "[itSort]",
			inputs: {
				active: ["itSortActive", "active"],
				start: ["itSortStart", "start"],
				direction: ["itSortDirection", "direction"],
				disableSortClear: [
					"disableSortClear",
					"disableSortClear",
					booleanAttribute
				],
				sortDisabled: [
					"sortDisabled",
					"sortDisabled",
					booleanAttribute
				]
			},
			outputs: { sortChange: "sortChange" },
			host: { properties: { "class": "this.sortDirectiveClass" } },
			exportAs: ["itSort"],
			usesOnChanges: true,
			ngImport: i0
		});
	}
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.1",
	ngImport: i0,
	type: ItSortDirective,
	decorators: [{
		type: Directive,
		args: [{
			standalone: true,
			selector: "[itSort]",
			exportAs: "itSort"
		}]
	}],
	propDecorators: {
		active: [{
			type: Input,
			args: ["itSortActive"]
		}],
		start: [{
			type: Input,
			args: ["itSortStart"]
		}],
		direction: [{
			type: Input,
			args: ["itSortDirection"]
		}],
		disableSortClear: [{
			type: Input,
			args: [{ transform: booleanAttribute }]
		}],
		sortDisabled: [{
			type: Input,
			args: [{ transform: booleanAttribute }]
		}],
		sortChange: [{ type: Output }],
		sortDirectiveClass: [{
			type: HostBinding,
			args: ["class"]
		}]
	}
});
function getSortDirectionCycle(start, disableClear) {
	const sortOrder = ["asc", "desc"];
	if (start == "desc") sortOrder.reverse();
	if (!disableClear) sortOrder.push(void 0);
	return sortOrder;
}
var ItSortHeaderComponent = class ItSortHeaderComponent {
	constructor() {
		this._changeDetectorRef = inject(ChangeDetectorRef);
		this._sort = inject(ItSortDirective, { optional: true });
		this.arrowPosition = "after";
		this.sortDisabled = false;
		this.sortHeaderClass = "it-sort-header";
		const defaultOptions = inject(IT_SORT_DEFAULT_OPTIONS, { optional: true });
		if (defaultOptions?.arrowPosition) this.arrowPosition = defaultOptions?.arrowPosition;
		this._handleStateChanges();
	}
	ngOnInit() {
		this.updateArrowDirection();
		this._sort.register(this);
	}
	ngOnDestroy() {
		this._sort.deregister(this);
		this._rerenderSubscription?.unsubscribe();
	}
	_handleClick() {
		if (!this.isDisabled) this._sort.sort(this);
	}
	get isSorted() {
		return this._sort.active == this.id && (this._sort.direction === "asc" || this._sort.direction === "desc");
	}
	get arrowIconClass() {
		return `${this._arrowDirection == "asc" ? "arrow-up" : "arrow-down"}`;
	}
	updateArrowDirection() {
		this._arrowDirection = this.isSorted ? this._sort.direction : this.start || this._sort.start;
	}
	get isDisabled() {
		return this._sort.sortDisabled || this.sortDisabled;
	}
	get ariaSortAttribute() {
		if (!this.isSorted) return "none";
		return this._sort.direction == "asc" ? "ascending" : "descending";
	}
	_handleStateChanges() {
		this._rerenderSubscription = merge(this._sort.sortChange, this._sort._stateChanges).subscribe(() => {
			if (this.isSorted) this.updateArrowDirection();
			this._changeDetectorRef.markForCheck();
		});
	}
	static {
		this.ɵfac = i0.ɵɵngDeclareFactory({
			minVersion: "12.0.0",
			version: "22.2.1",
			ngImport: i0,
			type: ItSortHeaderComponent,
			deps: [],
			target: i0.ɵɵFactoryTarget.Component
		});
	}
	static {
		this.ɵcmp = i0.ɵɵngDeclareComponent({
			minVersion: "16.1.0",
			version: "22.2.1",
			type: ItSortHeaderComponent,
			isStandalone: true,
			selector: "[it-sort-header]",
			inputs: {
				id: ["it-sort-header", "id"],
				arrowPosition: "arrowPosition",
				start: "start",
				sortDisabled: [
					"sortDisabled",
					"sortDisabled",
					booleanAttribute
				],
				disableSortClear: [
					"disableSortClear",
					"disableSortClear",
					booleanAttribute
				]
			},
			host: {
				listeners: { "click": "_handleClick()" },
				properties: {
					"class": "this.sortHeaderClass",
					"class.it-sort-header-disabled": "this.isDisabled",
					"attr.aria-sort": "this.ariaSortAttribute"
				}
			},
			exportAs: ["itSortHeader"],
			ngImport: i0,
			template: "<!--\r\n  We set the `tabindex` on an element inside the table header, rather than the header itself,\r\n  because of a bug in NVDA where having a `tabindex` on a `th` breaks keyboard navigation in the\r\n  table (see https://github.com/nvaccess/nvda/issues/7718). This allows for the header to both\r\n  be focusable, and have screen readers read out its `aria-sort` state. We prefer this approach\r\n  over having a button with an `aria-label` inside the header, because the button's `aria-label`\r\n  will be read out as the user is navigating the table's cell (see #13012).\r\n\r\n  The approach is based off of: https://dequeuniversity.com/library/aria/tables/sf-sortable-grid\r\n-->\r\n<div\r\n  class=\"it-sort-header-container it-focus-indicator\"\r\n  [class.it-sort-header-sorted]=\"isSorted\"\r\n  [class.it-sort-header-position-before]=\"arrowPosition === 'before'\"\r\n  [attr.tabindex]=\"isDisabled ? null : 0\"\r\n  [attr.role]=\"isDisabled ? null : 'button'\">\r\n  <!--\r\n    We have to keep it due to a large number of screenshot diff failures. It should be removed eventually.\r\n    Note that the difference isn't visible with a shorter header, but once it breaks up into multiple lines, this element\r\n    causes it to be center-aligned, whereas removing it will keep the text to the left.\r\n  -->\r\n  <div class=\"it-sort-header-content\">\r\n    <ng-content></ng-content>\r\n  </div>\r\n\r\n  <it-icon class=\"it-sort-arrow\" size=\"sm\" [name]=\"arrowIconClass\" />\r\n</div>\r\n",
			styles: [".it-sort-header-container{display:flex;cursor:pointer;align-items:center;justify-content:space-between;letter-spacing:normal;outline:0}.it-sort-header-disabled .it-sort-header-container{cursor:default}.it-sort-header-disabled .it-sort-header-container .it-sort-arrow{opacity:0!important;fill-opacity:0!important}.it-sort-header-container:before{margin:-5px}.it-sort-header-container.it-sort-header-position-before{flex-direction:row-reverse;justify-content:left;gap:.5rem}.it-sort-header-container .it-sort-arrow{opacity:0;fill-opacity:0;transition:fill-opacity .3s ease-out,opacity .3s ease-out;-moz-transition:fill-opacity .3s ease-out,opacity .3s ease-out;-webkit-transition:fill-opacity .3s ease-out,opacity .3s ease-out;-o-transition:fill-opacity .3s ease-out,opacity .3s ease-out}.it-sort-header-container:hover .it-sort-arrow{opacity:.5;fill-opacity:.5}.it-sort-header-container.it-sort-header-sorted .it-sort-arrow{opacity:1!important;fill-opacity:1!important}\n"],
			dependencies: [{
				kind: "component",
				type: ItIconComponent,
				selector: "it-icon",
				inputs: [
					"name",
					"size",
					"color",
					"padded",
					"svgClass",
					"title",
					"labelWaria"
				]
			}],
			changeDetection: i0.ChangeDetectionStrategy.OnPush,
			encapsulation: i0.ViewEncapsulation.None
		});
	}
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.1",
	ngImport: i0,
	type: ItSortHeaderComponent,
	decorators: [{
		type: Component,
		args: [{
			selector: "[it-sort-header]",
			exportAs: "itSortHeader",
			imports: [ItIconComponent],
			encapsulation: ViewEncapsulation.None,
			changeDetection: ChangeDetectionStrategy.OnPush,
			template: "<!--\r\n  We set the `tabindex` on an element inside the table header, rather than the header itself,\r\n  because of a bug in NVDA where having a `tabindex` on a `th` breaks keyboard navigation in the\r\n  table (see https://github.com/nvaccess/nvda/issues/7718). This allows for the header to both\r\n  be focusable, and have screen readers read out its `aria-sort` state. We prefer this approach\r\n  over having a button with an `aria-label` inside the header, because the button's `aria-label`\r\n  will be read out as the user is navigating the table's cell (see #13012).\r\n\r\n  The approach is based off of: https://dequeuniversity.com/library/aria/tables/sf-sortable-grid\r\n-->\r\n<div\r\n  class=\"it-sort-header-container it-focus-indicator\"\r\n  [class.it-sort-header-sorted]=\"isSorted\"\r\n  [class.it-sort-header-position-before]=\"arrowPosition === 'before'\"\r\n  [attr.tabindex]=\"isDisabled ? null : 0\"\r\n  [attr.role]=\"isDisabled ? null : 'button'\">\r\n  <!--\r\n    We have to keep it due to a large number of screenshot diff failures. It should be removed eventually.\r\n    Note that the difference isn't visible with a shorter header, but once it breaks up into multiple lines, this element\r\n    causes it to be center-aligned, whereas removing it will keep the text to the left.\r\n  -->\r\n  <div class=\"it-sort-header-content\">\r\n    <ng-content></ng-content>\r\n  </div>\r\n\r\n  <it-icon class=\"it-sort-arrow\" size=\"sm\" [name]=\"arrowIconClass\" />\r\n</div>\r\n",
			styles: [".it-sort-header-container{display:flex;cursor:pointer;align-items:center;justify-content:space-between;letter-spacing:normal;outline:0}.it-sort-header-disabled .it-sort-header-container{cursor:default}.it-sort-header-disabled .it-sort-header-container .it-sort-arrow{opacity:0!important;fill-opacity:0!important}.it-sort-header-container:before{margin:-5px}.it-sort-header-container.it-sort-header-position-before{flex-direction:row-reverse;justify-content:left;gap:.5rem}.it-sort-header-container .it-sort-arrow{opacity:0;fill-opacity:0;transition:fill-opacity .3s ease-out,opacity .3s ease-out;-moz-transition:fill-opacity .3s ease-out,opacity .3s ease-out;-webkit-transition:fill-opacity .3s ease-out,opacity .3s ease-out;-o-transition:fill-opacity .3s ease-out,opacity .3s ease-out}.it-sort-header-container:hover .it-sort-arrow{opacity:.5;fill-opacity:.5}.it-sort-header-container.it-sort-header-sorted .it-sort-arrow{opacity:1!important;fill-opacity:1!important}\n"]
		}]
	}],
	ctorParameters: () => [],
	propDecorators: {
		id: [{
			type: Input,
			args: ["it-sort-header"]
		}],
		arrowPosition: [{ type: Input }],
		start: [{ type: Input }],
		sortDisabled: [{
			type: Input,
			args: [{ transform: booleanAttribute }]
		}],
		disableSortClear: [{
			type: Input,
			args: [{ transform: booleanAttribute }]
		}],
		sortHeaderClass: [{
			type: HostBinding,
			args: ["class"]
		}],
		_handleClick: [{
			type: HostListener,
			args: ["click"]
		}],
		isDisabled: [{
			type: HostBinding,
			args: ["class.it-sort-header-disabled"]
		}],
		ariaSortAttribute: [{
			type: HostBinding,
			args: ["attr.aria-sort"]
		}]
	}
});
const tableComponents = [
	ItTableComponent,
	ItSortDirective,
	ItSortHeaderComponent
];
var ItTableModule = class ItTableModule {
	static {
		this.ɵfac = i0.ɵɵngDeclareFactory({
			minVersion: "12.0.0",
			version: "22.2.1",
			ngImport: i0,
			type: ItTableModule,
			deps: [],
			target: i0.ɵɵFactoryTarget.NgModule
		});
	}
	static {
		this.ɵmod = i0.ɵɵngDeclareNgModule({
			minVersion: "14.0.0",
			version: "22.2.1",
			ngImport: i0,
			type: ItTableModule,
			imports: [
				ItTableComponent,
				ItSortDirective,
				ItSortHeaderComponent
			],
			exports: [
				ItTableComponent,
				ItSortDirective,
				ItSortHeaderComponent
			]
		});
	}
	static {
		this.ɵinj = i0.ɵɵngDeclareInjector({
			minVersion: "12.0.0",
			version: "22.2.1",
			ngImport: i0,
			type: ItTableModule
		});
	}
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.1",
	ngImport: i0,
	type: ItTableModule,
	decorators: [{
		type: NgModule,
		args: [{
			imports: tableComponents,
			exports: tableComponents
		}]
	}]
});
var ItTimelineItemComponent = class ItTimelineItemComponent extends ItAbstractComponent {
	constructor() {
		super(...arguments);
		this.dateFormat = "dd/MM/yyyy";
		this.pinType = "default";
		this.pinIcon = "code-circle";
		this.categoryLabel = "Categoria evento: ";
		this.dateLabel = "Data evento: ";
		this.showReadMore = false;
		this.readMoreLink = "#";
	}
	static {
		this.ɵfac = i0.ɵɵngDeclareFactory({
			minVersion: "12.0.0",
			version: "22.2.1",
			ngImport: i0,
			type: ItTimelineItemComponent,
			deps: null,
			target: i0.ɵɵFactoryTarget.Component
		});
	}
	static {
		this.ɵcmp = i0.ɵɵngDeclareComponent({
			minVersion: "17.0.0",
			version: "22.2.1",
			type: ItTimelineItemComponent,
			isStandalone: true,
			selector: "it-timeline-item",
			inputs: {
				title: "title",
				text: "text",
				signature: "signature",
				eventDate: "eventDate",
				dateFormat: "dateFormat",
				pinText: "pinText",
				pinType: "pinType",
				pinIcon: "pinIcon",
				pinIconTitle: "pinIconTitle",
				categoryLabel: "categoryLabel",
				dateLabel: "dateLabel",
				categoryTitle: "categoryTitle",
				categoryLink: "categoryLink",
				showReadMore: [
					"showReadMore",
					"showReadMore",
					inputToBoolean
				],
				readMoreLink: "readMoreLink"
			},
			usesInheritance: true,
			ngImport: i0,
			template: "<div class=\"timeline-element\">\r\n  @if (pinType === 'now') {\r\n    <span class=\"it-now-label d-none d-lg-flex\">{{ 'it.timeline.today' | translate }}</span>\r\n  }\r\n  <h3 class=\"it-pin-wrapper\" [ngClass]=\"{ 'it-evidence': pinType === 'evidence', 'it-now': pinType === 'now' }\">\r\n    <div class=\"pin-icon\">\r\n      @if (pinIcon) {\r\n        <it-icon [name]=\"pinIcon\" [title]=\"pinIconTitle\" [attr.role]=\"pinIconTitle ? 'img' : null\"></it-icon>\r\n      } @else {\r\n        <it-icon name=\"code-circle\"></it-icon>\r\n      }\r\n    </div>\r\n    <div class=\"pin-text\">\r\n      <span>{{ pinText }}</span>\r\n    </div>\r\n  </h3>\r\n  <div class=\"card-wrapper\">\r\n    <div class=\"card\">\r\n      <div class=\"card-body\">\r\n        @if ((categoryTitle && categoryLink) || eventDate) {\r\n          <div class=\"category-top\">\r\n            @if (categoryTitle) {\r\n              <span class=\"visually-hidden\">{{ categoryLabel }}</span>\r\n              <a class=\"category\" [href]=\"categoryLink\">{{ categoryTitle }}</a>\r\n            }\r\n            @if (eventDate) {\r\n              <span class=\"visually-hidden\">{{ dateLabel }}</span>\r\n              <span class=\"data\">{{ eventDate | date: dateFormat }}</span>\r\n            }\r\n          </div>\r\n        }\r\n        <h4 class=\"card-title\">{{ title }}</h4>\r\n        <p class=\"card-text\">{{ text }}</p>\r\n        @if (signature) {\r\n          <span class=\"card-signature\">{{ signature }}</span>\r\n        }\r\n        @if (showReadMore) {\r\n          <a class=\"read-more\" [href]=\"readMoreLink\">\r\n            <span class=\"text\">{{ 'it.timeline.read-more' | translate }}</span>\r\n            <span class=\"visually-hidden\">{{ 'it.timeline.read-more-on' | translate: { title: title } }}</span>\r\n            <it-icon name=\"arrow-right\"></it-icon>\r\n          </a>\r\n        }\r\n      </div>\r\n    </div>\r\n  </div>\r\n</div>\r\n",
			dependencies: [
				{
					kind: "component",
					type: ItIconComponent,
					selector: "it-icon",
					inputs: [
						"name",
						"size",
						"color",
						"padded",
						"svgClass",
						"title",
						"labelWaria"
					]
				},
				{
					kind: "ngmodule",
					type: TranslateModule
				},
				{
					kind: "directive",
					type: NgClass,
					selector: "[ngClass]",
					inputs: ["class", "ngClass"]
				},
				{
					kind: "pipe",
					type: DatePipe,
					name: "date"
				},
				{
					kind: "pipe",
					type: i1$1.TranslatePipe,
					name: "translate"
				}
			],
			changeDetection: i0.ChangeDetectionStrategy.OnPush
		});
	}
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.1",
	ngImport: i0,
	type: ItTimelineItemComponent,
	decorators: [{
		type: Component,
		args: [{
			selector: "it-timeline-item",
			changeDetection: ChangeDetectionStrategy.OnPush,
			imports: [
				ItIconComponent,
				DatePipe,
				TranslateModule,
				NgClass
			],
			template: "<div class=\"timeline-element\">\r\n  @if (pinType === 'now') {\r\n    <span class=\"it-now-label d-none d-lg-flex\">{{ 'it.timeline.today' | translate }}</span>\r\n  }\r\n  <h3 class=\"it-pin-wrapper\" [ngClass]=\"{ 'it-evidence': pinType === 'evidence', 'it-now': pinType === 'now' }\">\r\n    <div class=\"pin-icon\">\r\n      @if (pinIcon) {\r\n        <it-icon [name]=\"pinIcon\" [title]=\"pinIconTitle\" [attr.role]=\"pinIconTitle ? 'img' : null\"></it-icon>\r\n      } @else {\r\n        <it-icon name=\"code-circle\"></it-icon>\r\n      }\r\n    </div>\r\n    <div class=\"pin-text\">\r\n      <span>{{ pinText }}</span>\r\n    </div>\r\n  </h3>\r\n  <div class=\"card-wrapper\">\r\n    <div class=\"card\">\r\n      <div class=\"card-body\">\r\n        @if ((categoryTitle && categoryLink) || eventDate) {\r\n          <div class=\"category-top\">\r\n            @if (categoryTitle) {\r\n              <span class=\"visually-hidden\">{{ categoryLabel }}</span>\r\n              <a class=\"category\" [href]=\"categoryLink\">{{ categoryTitle }}</a>\r\n            }\r\n            @if (eventDate) {\r\n              <span class=\"visually-hidden\">{{ dateLabel }}</span>\r\n              <span class=\"data\">{{ eventDate | date: dateFormat }}</span>\r\n            }\r\n          </div>\r\n        }\r\n        <h4 class=\"card-title\">{{ title }}</h4>\r\n        <p class=\"card-text\">{{ text }}</p>\r\n        @if (signature) {\r\n          <span class=\"card-signature\">{{ signature }}</span>\r\n        }\r\n        @if (showReadMore) {\r\n          <a class=\"read-more\" [href]=\"readMoreLink\">\r\n            <span class=\"text\">{{ 'it.timeline.read-more' | translate }}</span>\r\n            <span class=\"visually-hidden\">{{ 'it.timeline.read-more-on' | translate: { title: title } }}</span>\r\n            <it-icon name=\"arrow-right\"></it-icon>\r\n          </a>\r\n        }\r\n      </div>\r\n    </div>\r\n  </div>\r\n</div>\r\n"
		}]
	}],
	propDecorators: {
		title: [{
			type: Input,
			args: [{ required: true }]
		}],
		text: [{
			type: Input,
			args: [{ required: true }]
		}],
		signature: [{ type: Input }],
		eventDate: [{ type: Input }],
		dateFormat: [{ type: Input }],
		pinText: [{
			type: Input,
			args: [{ required: true }]
		}],
		pinType: [{ type: Input }],
		pinIcon: [{ type: Input }],
		pinIconTitle: [{ type: Input }],
		categoryLabel: [{ type: Input }],
		dateLabel: [{ type: Input }],
		categoryTitle: [{ type: Input }],
		categoryLink: [{ type: Input }],
		showReadMore: [{
			type: Input,
			args: [{ transform: inputToBoolean }]
		}],
		readMoreLink: [{ type: Input }]
	}
});
var ItTimelineComponent = class ItTimelineComponent extends ItAbstractComponent {
	constructor() {
		super(...arguments);
		this.timelineElements = [];
		this.dateFormat = "dd/MM/yyyy";
	}
	static {
		this.ɵfac = i0.ɵɵngDeclareFactory({
			minVersion: "12.0.0",
			version: "22.2.1",
			ngImport: i0,
			type: ItTimelineComponent,
			deps: null,
			target: i0.ɵɵFactoryTarget.Component
		});
	}
	static {
		this.ɵcmp = i0.ɵɵngDeclareComponent({
			minVersion: "17.0.0",
			version: "22.2.1",
			type: ItTimelineComponent,
			isStandalone: true,
			selector: "it-timeline",
			inputs: {
				timelineElements: "timelineElements",
				dateFormat: "dateFormat"
			},
			usesInheritance: true,
			ngImport: i0,
			template: "<div class=\"it-timeline-wrapper\">\r\n  <div class=\"row\">\r\n    @for (element of timelineElements; track $index) {\r\n      <div class=\"col-12\">\r\n        <it-timeline-item\r\n          [title]=\"element.title\"\r\n          [text]=\"element.text\"\r\n          [signature]=\"element.signature\"\r\n          [pinType]=\"$safeNavigationMigration(element.pin?.type)\"\r\n          [pinIcon]=\"$safeNavigationMigration(element.pin?.icon)\"\r\n          [pinText]=\"$safeNavigationMigration(element.pin?.text)\"\r\n          [eventDate]=\"element.eventDate\"\r\n          [dateFormat]=\"dateFormat\"\r\n          [categoryTitle]=\"$safeNavigationMigration(element.category?.title)\"\r\n          [categoryLink]=\"$safeNavigationMigration(element.category?.link)\"\r\n          [showReadMore]=\"!!element.link?.length\"\r\n          [readMoreLink]=\"element.link\" />\r\n      </div>\r\n    }\r\n  </div>\r\n</div>\r\n",
			dependencies: [{
				kind: "ngmodule",
				type: TranslateModule
			}, {
				kind: "component",
				type: ItTimelineItemComponent,
				selector: "it-timeline-item",
				inputs: [
					"title",
					"text",
					"signature",
					"eventDate",
					"dateFormat",
					"pinText",
					"pinType",
					"pinIcon",
					"pinIconTitle",
					"categoryLabel",
					"dateLabel",
					"categoryTitle",
					"categoryLink",
					"showReadMore",
					"readMoreLink"
				]
			}],
			changeDetection: i0.ChangeDetectionStrategy.OnPush
		});
	}
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.1",
	ngImport: i0,
	type: ItTimelineComponent,
	decorators: [{
		type: Component,
		args: [{
			selector: "it-timeline",
			changeDetection: ChangeDetectionStrategy.OnPush,
			imports: [TranslateModule, ItTimelineItemComponent],
			template: "<div class=\"it-timeline-wrapper\">\r\n  <div class=\"row\">\r\n    @for (element of timelineElements; track $index) {\r\n      <div class=\"col-12\">\r\n        <it-timeline-item\r\n          [title]=\"element.title\"\r\n          [text]=\"element.text\"\r\n          [signature]=\"element.signature\"\r\n          [pinType]=\"$safeNavigationMigration(element.pin?.type)\"\r\n          [pinIcon]=\"$safeNavigationMigration(element.pin?.icon)\"\r\n          [pinText]=\"$safeNavigationMigration(element.pin?.text)\"\r\n          [eventDate]=\"element.eventDate\"\r\n          [dateFormat]=\"dateFormat\"\r\n          [categoryTitle]=\"$safeNavigationMigration(element.category?.title)\"\r\n          [categoryLink]=\"$safeNavigationMigration(element.category?.link)\"\r\n          [showReadMore]=\"!!element.link?.length\"\r\n          [readMoreLink]=\"element.link\" />\r\n      </div>\r\n    }\r\n  </div>\r\n</div>\r\n"
		}]
	}],
	propDecorators: {
		timelineElements: [{ type: Input }],
		dateFormat: [{ type: Input }]
	}
});
const timelineComponents = [ItTimelineComponent, ItTimelineItemComponent];
var ItTimelineModule = class ItTimelineModule {
	static {
		this.ɵfac = i0.ɵɵngDeclareFactory({
			minVersion: "12.0.0",
			version: "22.2.1",
			ngImport: i0,
			type: ItTimelineModule,
			deps: [],
			target: i0.ɵɵFactoryTarget.NgModule
		});
	}
	static {
		this.ɵmod = i0.ɵɵngDeclareNgModule({
			minVersion: "14.0.0",
			version: "22.2.1",
			ngImport: i0,
			type: ItTimelineModule,
			imports: [ItTimelineComponent, ItTimelineItemComponent],
			exports: [ItTimelineComponent, ItTimelineItemComponent]
		});
	}
	static {
		this.ɵinj = i0.ɵɵngDeclareInjector({
			minVersion: "12.0.0",
			version: "22.2.1",
			ngImport: i0,
			type: ItTimelineModule,
			imports: [timelineComponents]
		});
	}
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.1",
	ngImport: i0,
	type: ItTimelineModule,
	decorators: [{
		type: NgModule,
		args: [{
			imports: timelineComponents,
			exports: timelineComponents
		}]
	}]
});
var ItTooltipDirective = class ItTooltipDirective {
	set title(title) {
		if (title) this.element.setAttribute("data-bs-original-title", title);
	}
	set tooltipPlacement(placement) {
		this.element.setAttribute("data-bs-placement", placement);
	}
	set tooltipHtml(html) {
		this.element.setAttribute("data-bs-html", html ? "true" : "false");
	}
	constructor() {
		this._elementRef = inject(ElementRef);
		this.showEvent = new EventEmitter();
		this.shownEvent = new EventEmitter();
		this.hideEvent = new EventEmitter();
		this.hiddenEvent = new EventEmitter();
		this.insertedEvent = new EventEmitter();
		this.element = this._elementRef.nativeElement;
	}
	ngAfterViewInit() {
		this.element.setAttribute("data-bs-toggle", "tooltip");
		this.tooltip = Tooltip.getOrCreateInstance(this.element);
		this.element.addEventListener("show.bs.tooltip", (event) => this.showEvent.emit(event));
		this.element.addEventListener("shown.bs.tooltip", (event) => this.shownEvent.emit(event));
		this.element.addEventListener("hide.bs.tooltip", (event) => this.hideEvent.emit(event));
		this.element.addEventListener("hidden.bs.tooltip", (event) => this.hiddenEvent.emit(event));
		this.element.addEventListener("inserted.bs.tooltip", (event) => this.insertedEvent.emit(event));
	}
	ngOnDestroy() {
		this.dispose();
	}
	show() {
		this.tooltip?.show();
	}
	hide() {
		this.tooltip?.hide();
	}
	toggle() {
		this.tooltip?.toggle();
	}
	dispose() {
		this.tooltip?.dispose();
	}
	enable() {
		this.tooltip?.enable();
	}
	disable() {
		this.tooltip?.disable();
	}
	toggleEnabled() {
		this.tooltip?.disable();
	}
	update() {
		this.tooltip?.disable();
	}
	static {
		this.ɵfac = i0.ɵɵngDeclareFactory({
			minVersion: "12.0.0",
			version: "22.2.1",
			ngImport: i0,
			type: ItTooltipDirective,
			deps: [],
			target: i0.ɵɵFactoryTarget.Directive
		});
	}
	static {
		this.ɵdir = i0.ɵɵngDeclareDirective({
			minVersion: "16.1.0",
			version: "22.2.1",
			type: ItTooltipDirective,
			isStandalone: true,
			selector: "[itTooltip]",
			inputs: {
				title: ["itTooltip", "title"],
				tooltipPlacement: "tooltipPlacement",
				tooltipHtml: [
					"tooltipHtml",
					"tooltipHtml",
					inputToBoolean
				]
			},
			outputs: {
				showEvent: "showEvent",
				shownEvent: "shownEvent",
				hideEvent: "hideEvent",
				hiddenEvent: "hiddenEvent",
				insertedEvent: "insertedEvent"
			},
			exportAs: ["itTooltip"],
			ngImport: i0
		});
	}
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.1",
	ngImport: i0,
	type: ItTooltipDirective,
	decorators: [{
		type: Directive,
		args: [{
			standalone: true,
			selector: "[itTooltip]",
			exportAs: "itTooltip"
		}]
	}],
	ctorParameters: () => [],
	propDecorators: {
		title: [{
			type: Input,
			args: ["itTooltip"]
		}],
		tooltipPlacement: [{ type: Input }],
		tooltipHtml: [{
			type: Input,
			args: [{ transform: inputToBoolean }]
		}],
		showEvent: [{ type: Output }],
		shownEvent: [{ type: Output }],
		hideEvent: [{ type: Output }],
		hiddenEvent: [{ type: Output }],
		insertedEvent: [{ type: Output }]
	}
});
var ItCheckboxComponent = class ItCheckboxComponent extends ItAbstractFormComponent {
	ngOnInit() {
		super.ngOnInit();
		this.markAsChecked();
	}
	ngOnChanges(changes) {
		if (changes["checked"]) this.markAsChecked();
	}
	markAsChecked() {
		if (this.control.value || this.checked === void 0) return;
		const value = this.checked;
		this.writeValue(value);
		return this.onChange(value);
	}
	static {
		this.ɵfac = i0.ɵɵngDeclareFactory({
			minVersion: "12.0.0",
			version: "22.2.1",
			ngImport: i0,
			type: ItCheckboxComponent,
			deps: null,
			target: i0.ɵɵFactoryTarget.Component
		});
	}
	static {
		this.ɵcmp = i0.ɵɵngDeclareComponent({
			minVersion: "17.0.0",
			version: "22.2.1",
			type: ItCheckboxComponent,
			isStandalone: true,
			selector: "it-checkbox",
			inputs: {
				toggle: [
					"toggle",
					"toggle",
					inputToBoolean
				],
				inline: [
					"inline",
					"inline",
					inputToBoolean
				],
				group: [
					"group",
					"group",
					inputToBoolean
				],
				checked: [
					"checked",
					"checked",
					inputToBoolean
				],
				indeterminate: [
					"indeterminate",
					"indeterminate",
					inputToBoolean
				]
			},
			usesInheritance: true,
			usesOnChanges: true,
			ngImport: i0,
			template: "<ng-container>\r\n  <div class=\"form-check\" [class.form-check-group]=\"group\" [class.form-check-inline]=\"inline\">\r\n    @if (toggle) {\r\n      <div class=\"toggles\">\r\n        <label [for]=\"id\">\r\n          <ng-container *ngTemplateOutlet=\"htmlLabel\"></ng-container>\r\n          <input\r\n            [id]=\"id\"\r\n            type=\"checkbox\"\r\n            [formControl]=\"control\"\r\n            [attr.aria-describedby]=\"group ? id + '-help' : null\"\r\n            (click)=\"$event.stopPropagation()\" />\r\n          <span class=\"lever\"></span>\r\n        </label>\r\n      </div>\r\n    } @else {\r\n      <input\r\n        [id]=\"id\"\r\n        type=\"checkbox\"\r\n        [class.is-invalid]=\"isInvalid\"\r\n        [class.is-valid]=\"isValid\"\r\n        [class.semi-checked]=\"indeterminate\"\r\n        [formControl]=\"control\"\r\n        [attr.aria-describedby]=\"group ? id + '-help' : undefined\"\r\n        (click)=\"$event.stopPropagation()\" />\r\n      <label class=\"form-check-label\" [for]=\"id\">\r\n        <ng-container *ngTemplateOutlet=\"htmlLabel\"></ng-container>\r\n      </label>\r\n    }\r\n\r\n    @if (group) {\r\n      <small [id]=\"id + '-help'\" class=\"form-text\">\r\n        <ng-content></ng-content>\r\n      </small>\r\n    }\r\n\r\n    @if (isInvalid && group) {\r\n      <div class=\"form-feedback just-validate-error-label\" [id]=\"id + '-error'\">\r\n        <ng-container *ngTemplateOutlet=\"error\"></ng-container>\r\n      </div>\r\n    }\r\n  </div>\r\n\r\n  @if (isInvalid && !group) {\r\n    <div class=\"form-feedback just-validate-error-label\" [id]=\"id + '-error'\">\r\n      <ng-container *ngTemplateOutlet=\"error\"></ng-container>\r\n    </div>\r\n  }\r\n</ng-container>\r\n\r\n<ng-template #error>\r\n  <div #customError>\r\n    <ng-content select=\"[error]\"></ng-content>\r\n  </div>\r\n  @if (!customError.hasChildNodes()) {\r\n    {{ invalidMessage | async }}\r\n  }\r\n</ng-template>\r\n\r\n<ng-template #htmlLabel>\r\n  <div #customLabel>\r\n    <ng-content select=\"[label]\"></ng-content>\r\n  </div>\r\n  @if (!customLabel.hasChildNodes()) {\r\n    {{ label }}\r\n  }\r\n</ng-template>\r\n",
			dependencies: [
				{
					kind: "directive",
					type: NgTemplateOutlet,
					selector: "[ngTemplateOutlet]",
					inputs: [
						"ngTemplateOutletContext",
						"ngTemplateOutlet",
						"ngTemplateOutletInjector"
					]
				},
				{
					kind: "ngmodule",
					type: ReactiveFormsModule
				},
				{
					kind: "directive",
					type: i1.CheckboxControlValueAccessor,
					selector: "input[type=checkbox]:not([ngNoCva])[formControlName],input[type=checkbox]:not([ngNoCva])[formControl],input[type=checkbox]:not([ngNoCva])[ngModel]"
				},
				{
					kind: "directive",
					type: i1.NgControlStatus,
					selector: "[formControlName],[ngModel],[formControl]"
				},
				{
					kind: "directive",
					type: i1.FormControlDirective,
					selector: "[formControl]",
					inputs: [
						"formControl",
						"disabled",
						"ngModel"
					],
					outputs: ["ngModelChange"],
					exportAs: ["ngForm"]
				},
				{
					kind: "pipe",
					type: AsyncPipe,
					name: "async"
				}
			],
			changeDetection: i0.ChangeDetectionStrategy.OnPush
		});
	}
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.1",
	ngImport: i0,
	type: ItCheckboxComponent,
	decorators: [{
		type: Component,
		args: [{
			selector: "it-checkbox",
			changeDetection: ChangeDetectionStrategy.OnPush,
			imports: [
				NgTemplateOutlet,
				ReactiveFormsModule,
				AsyncPipe
			],
			template: "<ng-container>\r\n  <div class=\"form-check\" [class.form-check-group]=\"group\" [class.form-check-inline]=\"inline\">\r\n    @if (toggle) {\r\n      <div class=\"toggles\">\r\n        <label [for]=\"id\">\r\n          <ng-container *ngTemplateOutlet=\"htmlLabel\"></ng-container>\r\n          <input\r\n            [id]=\"id\"\r\n            type=\"checkbox\"\r\n            [formControl]=\"control\"\r\n            [attr.aria-describedby]=\"group ? id + '-help' : null\"\r\n            (click)=\"$event.stopPropagation()\" />\r\n          <span class=\"lever\"></span>\r\n        </label>\r\n      </div>\r\n    } @else {\r\n      <input\r\n        [id]=\"id\"\r\n        type=\"checkbox\"\r\n        [class.is-invalid]=\"isInvalid\"\r\n        [class.is-valid]=\"isValid\"\r\n        [class.semi-checked]=\"indeterminate\"\r\n        [formControl]=\"control\"\r\n        [attr.aria-describedby]=\"group ? id + '-help' : undefined\"\r\n        (click)=\"$event.stopPropagation()\" />\r\n      <label class=\"form-check-label\" [for]=\"id\">\r\n        <ng-container *ngTemplateOutlet=\"htmlLabel\"></ng-container>\r\n      </label>\r\n    }\r\n\r\n    @if (group) {\r\n      <small [id]=\"id + '-help'\" class=\"form-text\">\r\n        <ng-content></ng-content>\r\n      </small>\r\n    }\r\n\r\n    @if (isInvalid && group) {\r\n      <div class=\"form-feedback just-validate-error-label\" [id]=\"id + '-error'\">\r\n        <ng-container *ngTemplateOutlet=\"error\"></ng-container>\r\n      </div>\r\n    }\r\n  </div>\r\n\r\n  @if (isInvalid && !group) {\r\n    <div class=\"form-feedback just-validate-error-label\" [id]=\"id + '-error'\">\r\n      <ng-container *ngTemplateOutlet=\"error\"></ng-container>\r\n    </div>\r\n  }\r\n</ng-container>\r\n\r\n<ng-template #error>\r\n  <div #customError>\r\n    <ng-content select=\"[error]\"></ng-content>\r\n  </div>\r\n  @if (!customError.hasChildNodes()) {\r\n    {{ invalidMessage | async }}\r\n  }\r\n</ng-template>\r\n\r\n<ng-template #htmlLabel>\r\n  <div #customLabel>\r\n    <ng-content select=\"[label]\"></ng-content>\r\n  </div>\r\n  @if (!customLabel.hasChildNodes()) {\r\n    {{ label }}\r\n  }\r\n</ng-template>\r\n"
		}]
	}],
	propDecorators: {
		toggle: [{
			type: Input,
			args: [{ transform: inputToBoolean }]
		}],
		inline: [{
			type: Input,
			args: [{ transform: inputToBoolean }]
		}],
		group: [{
			type: Input,
			args: [{ transform: inputToBoolean }]
		}],
		checked: [{
			type: Input,
			args: [{ transform: inputToBoolean }]
		}],
		indeterminate: [{
			type: Input,
			args: [{ transform: inputToBoolean }]
		}]
	}
});
var ItPasswordInputComponent = class ItPasswordInputComponent extends ItAbstractFormComponent {
	constructor() {
		super(...arguments);
		this.required = true;
		this.minLength = 10;
		this.useNumber = true;
		this.useCapitalCase = true;
		this.useSmallCase = true;
		this.useSpecialCharacters = true;
		this.placeholder = "";
	}
	ngOnInit() {
		super.ngOnInit();
		if (!this.confirmPasswordField) this.addValidators(ItValidators.password(this.minLength, this.useNumber, this.useCapitalCase, this.useSmallCase, this.useSpecialCharacters, this.required));
		else if (this.required) this.addValidators(Validators.required);
	}
	ngAfterViewInit() {
		super.ngAfterViewInit();
		if (this.inputElement) this.inputPasswordBs = InputPassword.getOrCreateInstance(this.inputElement.nativeElement, {
			showText: this.isStrengthMeter,
			minimumLength: this.minLength
		});
	}
	get isStrengthMeter() {
		return !this.confirmPasswordField && !!this.showStrengthMeter;
	}
	get invalidMessage() {
		if (this.hasError("noPasswordMatch")) return this._translateService.get("it.errors.password-no-match");
		if (this.hasError("minlength")) return this._translateService.get("it.errors.password-min-length", { minLength: this.minLength });
		if (this.hasError("hasNumber")) return this._translateService.get("it.errors.password-number");
		if (this.hasError("hasCapitalCase")) return this._translateService.get("it.errors.password-capital-case");
		if (this.hasError("hasSmallCase")) return this._translateService.get("it.errors.password-capital-case");
		if (this.hasError("hasSpecialCharacters")) return this._translateService.get("it.errors.password-special-character");
		return super.invalidMessage;
	}
	get strengthMeterDescription() {
		const keys = ["it.form.password-strength-meter.description.default"];
		if (this.useNumber) keys.push("it.form.password-strength-meter.description.number");
		if (this.useCapitalCase) keys.push("it.form.password-strength-meter.description.capital-case");
		if (this.useSpecialCharacters) keys.push("it.form.password-strength-meter.description.special-character");
		return this._translateService.get(keys, { minLength: this.minLength }).pipe(map((labels) => Object.values(labels).join(", ")));
	}
	static {
		this.ɵfac = i0.ɵɵngDeclareFactory({
			minVersion: "12.0.0",
			version: "22.2.1",
			ngImport: i0,
			type: ItPasswordInputComponent,
			deps: null,
			target: i0.ɵɵFactoryTarget.Component
		});
	}
	static {
		this.ɵcmp = i0.ɵɵngDeclareComponent({
			minVersion: "17.0.0",
			version: "22.2.1",
			type: ItPasswordInputComponent,
			isStandalone: true,
			selector: "it-password-input",
			inputs: {
				required: "required",
				minLength: "minLength",
				useNumber: "useNumber",
				useCapitalCase: "useCapitalCase",
				useSmallCase: "useSmallCase",
				useSpecialCharacters: "useSpecialCharacters",
				placeholder: "placeholder",
				description: "description",
				showStrengthMeter: [
					"showStrengthMeter",
					"showStrengthMeter",
					inputToBoolean
				],
				confirmPasswordField: [
					"confirmPasswordField",
					"confirmPasswordField",
					inputToBoolean
				],
				autocomplete: "autocomplete"
			},
			viewQueries: [{
				propertyName: "inputElement",
				first: true,
				predicate: ["input"],
				descendants: true
			}],
			usesInheritance: true,
			ngImport: i0,
			template: "<div class=\"form-group\">\r\n  @if (label) {\r\n    <label [for]=\"id\" [class.active]=\"!!control.value || !!placeholder\">{{ label }}</label>\r\n  }\r\n  <input\r\n    #input\r\n    [id]=\"id\"\r\n    type=\"password\"\r\n    class=\"form-control input-password\"\r\n    [class.is-invalid]=\"isInvalid\"\r\n    [class.is-valid]=\"isValid\"\r\n    [formControl]=\"control\"\r\n    [placeholder]=\"placeholder\"\r\n    [attr.aria-describedby]=\"description !== undefined || isStrengthMeter ? id + '-description' : null\"\r\n    [autocomplete]=\"confirmPasswordField ? 'off' : autocomplete\" />\r\n\r\n  <span class=\"password-icon\" aria-hidden=\"true\">\r\n    <it-icon name=\"password-visible\" size=\"sm\" class=\"password-icon-visible\"></it-icon>\r\n    <it-icon name=\"password-invisible\" size=\"sm\" class=\"password-icon-invisible d-none\"></it-icon>\r\n  </span>\r\n\r\n  @if (isInvalid) {\r\n    <div [id]=\"id + '-error'\" class=\"form-feedback just-validate-error-label\">\r\n      <div #customError>\r\n        <ng-content select=\"[error]\"></ng-content>\r\n      </div>\r\n      @if (!customError.hasChildNodes()) {\r\n        {{ invalidMessage | async }}\r\n      }\r\n    </div>\r\n  }\r\n\r\n  @if (description !== undefined && !isStrengthMeter) {\r\n    <small [id]=\"id + '-description'\" class=\"form-text\">\r\n      {{ description !== true ? description : (strengthMeterDescription | async) }}\r\n    </small>\r\n  }\r\n\r\n  <small class=\"password-caps form-text text-warning position-absolute bg-white w-100\">\r\n    {{ 'it.form.caps-inserted' | translate }}\r\n  </small>\r\n\r\n  @if (isStrengthMeter) {\r\n    <div class=\"password-strength-meter\">\r\n      <small\r\n        [id]=\"id + '-description'\"\r\n        class=\"form-text text-muted\"\r\n        [attr.data-bs-short-pass]=\"'it.form.password-strength-meter.password-short' | translate\"\r\n        [attr.data-bs-bad-pas]=\"'it.form.password-strength-meter.password-bad' | translate\"\r\n        [attr.data-bs-good-pass]=\"'it.form.password-strength-meter.password-good' | translate\"\r\n        [attr.data-bs-strong-pass]=\"'it.form.password-strength-meter.password-strong' | translate\">\r\n        {{ description !== undefined && description !== true ? description : (strengthMeterDescription | async) }}\r\n      </small>\r\n      <div class=\"password-meter progress rounded-0 position-absolute\">\r\n        <div class=\"row position-absolute w-100 m-0\">\r\n          <div class=\"col-3 border-start border-end border-white\"></div>\r\n          <div class=\"col-3 border-start border-end border-white\"></div>\r\n          <div class=\"col-3 border-start border-end border-white\"></div>\r\n          <div class=\"col-3 border-start border-end border-white\"></div>\r\n        </div>\r\n        <div class=\"progress-bar bg-muted\" role=\"progressbar\" aria-valuenow=\"0\" aria-valuemin=\"0\" aria-valuemax=\"100\"></div>\r\n      </div>\r\n    </div>\r\n  }\r\n</div>\r\n",
			styles: [".form-group input:focus:not(.focus--mouse){box-shadow:inherit!important;border-color:inherit!important}.form-group label:not(.active):has(+input:-webkit-autofill){transform:translateY(-75%)}\n"],
			dependencies: [
				{
					kind: "ngmodule",
					type: ReactiveFormsModule
				},
				{
					kind: "directive",
					type: i1.DefaultValueAccessor,
					selector: "input:not([type=checkbox]):not([ngNoCva])[formControlName],textarea:not([ngNoCva])[formControlName],input:not([type=checkbox]):not([ngNoCva])[formControl],textarea:not([ngNoCva])[formControl],input:not([type=checkbox]):not([ngNoCva])[ngModel],textarea:not([ngNoCva])[ngModel],[ngDefaultControl]"
				},
				{
					kind: "directive",
					type: i1.NgControlStatus,
					selector: "[formControlName],[ngModel],[formControl]"
				},
				{
					kind: "directive",
					type: i1.FormControlDirective,
					selector: "[formControl]",
					inputs: [
						"formControl",
						"disabled",
						"ngModel"
					],
					outputs: ["ngModelChange"],
					exportAs: ["ngForm"]
				},
				{
					kind: "component",
					type: ItIconComponent,
					selector: "it-icon",
					inputs: [
						"name",
						"size",
						"color",
						"padded",
						"svgClass",
						"title",
						"labelWaria"
					]
				},
				{
					kind: "ngmodule",
					type: TranslateModule
				},
				{
					kind: "pipe",
					type: AsyncPipe,
					name: "async"
				},
				{
					kind: "pipe",
					type: i1$1.TranslatePipe,
					name: "translate"
				}
			],
			changeDetection: i0.ChangeDetectionStrategy.OnPush
		});
	}
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.1",
	ngImport: i0,
	type: ItPasswordInputComponent,
	decorators: [{
		type: Component,
		args: [{
			selector: "it-password-input",
			changeDetection: ChangeDetectionStrategy.OnPush,
			imports: [
				ReactiveFormsModule,
				ItIconComponent,
				AsyncPipe,
				TranslateModule
			],
			template: "<div class=\"form-group\">\r\n  @if (label) {\r\n    <label [for]=\"id\" [class.active]=\"!!control.value || !!placeholder\">{{ label }}</label>\r\n  }\r\n  <input\r\n    #input\r\n    [id]=\"id\"\r\n    type=\"password\"\r\n    class=\"form-control input-password\"\r\n    [class.is-invalid]=\"isInvalid\"\r\n    [class.is-valid]=\"isValid\"\r\n    [formControl]=\"control\"\r\n    [placeholder]=\"placeholder\"\r\n    [attr.aria-describedby]=\"description !== undefined || isStrengthMeter ? id + '-description' : null\"\r\n    [autocomplete]=\"confirmPasswordField ? 'off' : autocomplete\" />\r\n\r\n  <span class=\"password-icon\" aria-hidden=\"true\">\r\n    <it-icon name=\"password-visible\" size=\"sm\" class=\"password-icon-visible\"></it-icon>\r\n    <it-icon name=\"password-invisible\" size=\"sm\" class=\"password-icon-invisible d-none\"></it-icon>\r\n  </span>\r\n\r\n  @if (isInvalid) {\r\n    <div [id]=\"id + '-error'\" class=\"form-feedback just-validate-error-label\">\r\n      <div #customError>\r\n        <ng-content select=\"[error]\"></ng-content>\r\n      </div>\r\n      @if (!customError.hasChildNodes()) {\r\n        {{ invalidMessage | async }}\r\n      }\r\n    </div>\r\n  }\r\n\r\n  @if (description !== undefined && !isStrengthMeter) {\r\n    <small [id]=\"id + '-description'\" class=\"form-text\">\r\n      {{ description !== true ? description : (strengthMeterDescription | async) }}\r\n    </small>\r\n  }\r\n\r\n  <small class=\"password-caps form-text text-warning position-absolute bg-white w-100\">\r\n    {{ 'it.form.caps-inserted' | translate }}\r\n  </small>\r\n\r\n  @if (isStrengthMeter) {\r\n    <div class=\"password-strength-meter\">\r\n      <small\r\n        [id]=\"id + '-description'\"\r\n        class=\"form-text text-muted\"\r\n        [attr.data-bs-short-pass]=\"'it.form.password-strength-meter.password-short' | translate\"\r\n        [attr.data-bs-bad-pas]=\"'it.form.password-strength-meter.password-bad' | translate\"\r\n        [attr.data-bs-good-pass]=\"'it.form.password-strength-meter.password-good' | translate\"\r\n        [attr.data-bs-strong-pass]=\"'it.form.password-strength-meter.password-strong' | translate\">\r\n        {{ description !== undefined && description !== true ? description : (strengthMeterDescription | async) }}\r\n      </small>\r\n      <div class=\"password-meter progress rounded-0 position-absolute\">\r\n        <div class=\"row position-absolute w-100 m-0\">\r\n          <div class=\"col-3 border-start border-end border-white\"></div>\r\n          <div class=\"col-3 border-start border-end border-white\"></div>\r\n          <div class=\"col-3 border-start border-end border-white\"></div>\r\n          <div class=\"col-3 border-start border-end border-white\"></div>\r\n        </div>\r\n        <div class=\"progress-bar bg-muted\" role=\"progressbar\" aria-valuenow=\"0\" aria-valuemin=\"0\" aria-valuemax=\"100\"></div>\r\n      </div>\r\n    </div>\r\n  }\r\n</div>\r\n",
			styles: [".form-group input:focus:not(.focus--mouse){box-shadow:inherit!important;border-color:inherit!important}.form-group label:not(.active):has(+input:-webkit-autofill){transform:translateY(-75%)}\n"]
		}]
	}],
	propDecorators: {
		required: [{ type: Input }],
		minLength: [{ type: Input }],
		useNumber: [{ type: Input }],
		useCapitalCase: [{ type: Input }],
		useSmallCase: [{ type: Input }],
		useSpecialCharacters: [{ type: Input }],
		placeholder: [{ type: Input }],
		description: [{ type: Input }],
		showStrengthMeter: [{
			type: Input,
			args: [{ transform: inputToBoolean }]
		}],
		confirmPasswordField: [{
			type: Input,
			args: [{ transform: inputToBoolean }]
		}],
		autocomplete: [{ type: Input }],
		inputElement: [{
			type: ViewChild,
			args: ["input"]
		}]
	}
});
var ItRadioButtonComponent = class ItRadioButtonComponent extends ItAbstractFormComponent {
	get name() {
		if (this.forceRadioName) return this.forceRadioName;
		let name = "";
		if (this._ngControl) {
			name = this._ngControl.name?.toString() || "";
			let control = this._ngControl.control?.parent;
			while (control?.parent) {
				const controls = control?.parent?.controls || {};
				const parentName = Object.keys(controls).find((name) => control === controls[name]) || null;
				if (!parentName) break;
				name = `${parentName}.${name}`;
				control = control.parent;
			}
		}
		return name;
	}
	ngOnInit() {
		super.ngOnInit();
		if (this.control.value || !this.value || !this.checked) return;
		this.writeValue(this.value);
		return this.onChange(this.value);
	}
	static {
		this.ɵfac = i0.ɵɵngDeclareFactory({
			minVersion: "12.0.0",
			version: "22.2.1",
			ngImport: i0,
			type: ItRadioButtonComponent,
			deps: null,
			target: i0.ɵɵFactoryTarget.Component
		});
	}
	static {
		this.ɵcmp = i0.ɵɵngDeclareComponent({
			minVersion: "17.0.0",
			version: "22.2.1",
			type: ItRadioButtonComponent,
			isStandalone: true,
			selector: "it-radio-button",
			inputs: {
				value: "value",
				inline: [
					"inline",
					"inline",
					inputToBoolean
				],
				group: [
					"group",
					"group",
					inputToBoolean
				],
				checked: [
					"checked",
					"checked",
					inputToBoolean
				],
				forceRadioName: "forceRadioName"
			},
			usesInheritance: true,
			ngImport: i0,
			template: "<ng-container>\r\n  <div class=\"form-check\" [class.form-check-group]=\"group\" [class.form-check-inline]=\"inline\">\r\n    <input\r\n      [id]=\"id\"\r\n      type=\"radio\"\r\n      [value]=\"value\"\r\n      [name]=\"name\"\r\n      [class.is-invalid]=\"isInvalid\"\r\n      [class.is-valid]=\"isValid\"\r\n      [formControl]=\"control\"\r\n      [attr.aria-describedby]=\"group ? id + '-help' : null\" />\r\n\r\n    <label class=\"form-check-label\" [for]=\"id\">\r\n      <div #customLabel>\r\n        <ng-content select=\"[label]\"></ng-content>\r\n      </div>\r\n      @if (!customLabel.hasChildNodes()) {\r\n        {{ label }}\r\n      }\r\n    </label>\r\n\r\n    @if (group) {\r\n      <small [id]=\"id + '-help'\" class=\"form-text\">\r\n        <ng-content></ng-content>\r\n      </small>\r\n    }\r\n\r\n    @if (isInvalid && group) {\r\n      <div class=\"form-feedback just-validate-error-label\" [id]=\"id + '-error'\">\r\n        <div #customError>\r\n          <ng-content select=\"[error]\"></ng-content>\r\n        </div>\r\n        @if (!customError.hasChildNodes()) {\r\n          {{ invalidMessage | async }}\r\n        }\r\n      </div>\r\n    }\r\n  </div>\r\n\r\n  @if (isInvalid && !group) {\r\n    <div class=\"form-feedback just-validate-error-label\" [id]=\"id + '-error'\">\r\n      <div #customError>\r\n        <ng-content select=\"[error]\"></ng-content>\r\n      </div>\r\n      @if (!customError.hasChildNodes()) {\r\n        {{ invalidMessage | async }}\r\n      }\r\n    </div>\r\n  }\r\n</ng-container>\r\n",
			styles: [""],
			dependencies: [
				{
					kind: "ngmodule",
					type: ReactiveFormsModule
				},
				{
					kind: "directive",
					type: i1.DefaultValueAccessor,
					selector: "input:not([type=checkbox]):not([ngNoCva])[formControlName],textarea:not([ngNoCva])[formControlName],input:not([type=checkbox]):not([ngNoCva])[formControl],textarea:not([ngNoCva])[formControl],input:not([type=checkbox]):not([ngNoCva])[ngModel],textarea:not([ngNoCva])[ngModel],[ngDefaultControl]"
				},
				{
					kind: "directive",
					type: i1.RadioControlValueAccessor,
					selector: "input[type=radio]:not([ngNoCva])[formControlName],input[type=radio]:not([ngNoCva])[formControl],input[type=radio]:not([ngNoCva])[ngModel]",
					inputs: [
						"name",
						"formControlName",
						"value"
					]
				},
				{
					kind: "directive",
					type: i1.NgControlStatus,
					selector: "[formControlName],[ngModel],[formControl]"
				},
				{
					kind: "directive",
					type: i1.FormControlDirective,
					selector: "[formControl]",
					inputs: [
						"formControl",
						"disabled",
						"ngModel"
					],
					outputs: ["ngModelChange"],
					exportAs: ["ngForm"]
				},
				{
					kind: "pipe",
					type: AsyncPipe,
					name: "async"
				}
			],
			changeDetection: i0.ChangeDetectionStrategy.OnPush
		});
	}
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.1",
	ngImport: i0,
	type: ItRadioButtonComponent,
	decorators: [{
		type: Component,
		args: [{
			selector: "it-radio-button",
			changeDetection: ChangeDetectionStrategy.OnPush,
			imports: [ReactiveFormsModule, AsyncPipe],
			template: "<ng-container>\r\n  <div class=\"form-check\" [class.form-check-group]=\"group\" [class.form-check-inline]=\"inline\">\r\n    <input\r\n      [id]=\"id\"\r\n      type=\"radio\"\r\n      [value]=\"value\"\r\n      [name]=\"name\"\r\n      [class.is-invalid]=\"isInvalid\"\r\n      [class.is-valid]=\"isValid\"\r\n      [formControl]=\"control\"\r\n      [attr.aria-describedby]=\"group ? id + '-help' : null\" />\r\n\r\n    <label class=\"form-check-label\" [for]=\"id\">\r\n      <div #customLabel>\r\n        <ng-content select=\"[label]\"></ng-content>\r\n      </div>\r\n      @if (!customLabel.hasChildNodes()) {\r\n        {{ label }}\r\n      }\r\n    </label>\r\n\r\n    @if (group) {\r\n      <small [id]=\"id + '-help'\" class=\"form-text\">\r\n        <ng-content></ng-content>\r\n      </small>\r\n    }\r\n\r\n    @if (isInvalid && group) {\r\n      <div class=\"form-feedback just-validate-error-label\" [id]=\"id + '-error'\">\r\n        <div #customError>\r\n          <ng-content select=\"[error]\"></ng-content>\r\n        </div>\r\n        @if (!customError.hasChildNodes()) {\r\n          {{ invalidMessage | async }}\r\n        }\r\n      </div>\r\n    }\r\n  </div>\r\n\r\n  @if (isInvalid && !group) {\r\n    <div class=\"form-feedback just-validate-error-label\" [id]=\"id + '-error'\">\r\n      <div #customError>\r\n        <ng-content select=\"[error]\"></ng-content>\r\n      </div>\r\n      @if (!customError.hasChildNodes()) {\r\n        {{ invalidMessage | async }}\r\n      }\r\n    </div>\r\n  }\r\n</ng-container>\r\n"
		}]
	}],
	propDecorators: {
		value: [{
			type: Input,
			args: [{ required: true }]
		}],
		inline: [{
			type: Input,
			args: [{ transform: inputToBoolean }]
		}],
		group: [{
			type: Input,
			args: [{ transform: inputToBoolean }]
		}],
		checked: [{
			type: Input,
			args: [{ transform: inputToBoolean }]
		}],
		forceRadioName: [{ type: Input }]
	}
});
var ItRangeComponent = class ItRangeComponent extends ItAbstractFormComponent {
	ngOnInit() {
		super.ngOnInit();
		this.subscription = this.control.valueChanges.pipe(distinctUntilChanged(), startWith(void 0)).subscribe(() => this.updateSliderColor());
	}
	ngOnChanges(changes) {
		if (changes["leftColor"]) this.slider.nativeElement.style.setProperty("--range-left-color", this.leftColor ?? null);
		if (changes["rightColor"]) this.slider.nativeElement.style.setProperty("--range-right-color", this.rightColor ?? null);
	}
	ngOnDestroy() {
		this.subscription?.unsubscribe();
	}
	writeValue(value) {
		super.writeValue(value);
		this.updateSliderColor();
	}
	updateSliderColor() {
		if (!this.leftColor || !this.rightColor) return;
		const max = Number(this.slider.nativeElement.max) || 100;
		const min = Number(this.slider.nativeElement.min) || 0;
		const diff = max - min;
		const val = ((this.control.value ?? diff / 2) - min) * 100 / diff;
		this.slider.nativeElement.style.setProperty("--range-percentage", `${val}%`);
	}
	static {
		this.ɵfac = i0.ɵɵngDeclareFactory({
			minVersion: "12.0.0",
			version: "22.2.1",
			ngImport: i0,
			type: ItRangeComponent,
			deps: null,
			target: i0.ɵɵFactoryTarget.Component
		});
	}
	static {
		this.ɵcmp = i0.ɵɵngDeclareComponent({
			minVersion: "17.0.0",
			version: "22.2.1",
			type: ItRangeComponent,
			isStandalone: true,
			selector: "it-range",
			inputs: {
				max: "max",
				min: "min",
				step: "step",
				leftColor: "leftColor",
				rightColor: "rightColor"
			},
			viewQueries: [{
				propertyName: "slider",
				first: true,
				predicate: ["slider"],
				descendants: true,
				static: true
			}],
			usesInheritance: true,
			usesOnChanges: true,
			ngImport: i0,
			template: "<div class=\"d-flex justify-content-between align-items-center\">\r\n  @if (label) {\r\n    <label [for]=\"id\" class=\"form-label\">{{ label }}</label>\r\n  }\r\n  <ng-content></ng-content>\r\n</div>\r\n\r\n<input\r\n  #slider\r\n  [id]=\"id\"\r\n  type=\"range\"\r\n  [min]=\"min\"\r\n  [max]=\"max\"\r\n  [step]=\"step\"\r\n  class=\"form-range\"\r\n  [class.double-color]=\"!!leftColor && !!rightColor\"\r\n  [formControl]=\"control\" />\r\n",
			styles: [".form-range.double-color::-webkit-slider-runnable-track{background:linear-gradient(to right,var(--range-left-color) var(--range-percentage),var(--range-right-color) var(--range-percentage))}.form-range.double-color::-moz-range-track{background:linear-gradient(to right,var(--range-left-color) var(--range-percentage),var(--range-right-color) var(--range-percentage))}\n"],
			dependencies: [
				{
					kind: "ngmodule",
					type: ReactiveFormsModule
				},
				{
					kind: "directive",
					type: i1.DefaultValueAccessor,
					selector: "input:not([type=checkbox]):not([ngNoCva])[formControlName],textarea:not([ngNoCva])[formControlName],input:not([type=checkbox]):not([ngNoCva])[formControl],textarea:not([ngNoCva])[formControl],input:not([type=checkbox]):not([ngNoCva])[ngModel],textarea:not([ngNoCva])[ngModel],[ngDefaultControl]"
				},
				{
					kind: "directive",
					type: i1.RangeValueAccessor,
					selector: "input[type=range]:not([ngNoCva])[formControlName],input[type=range]:not([ngNoCva])[formControl],input[type=range]:not([ngNoCva])[ngModel]"
				},
				{
					kind: "directive",
					type: i1.NgControlStatus,
					selector: "[formControlName],[ngModel],[formControl]"
				},
				{
					kind: "directive",
					type: i1.FormControlDirective,
					selector: "[formControl]",
					inputs: [
						"formControl",
						"disabled",
						"ngModel"
					],
					outputs: ["ngModelChange"],
					exportAs: ["ngForm"]
				}
			],
			changeDetection: i0.ChangeDetectionStrategy.OnPush
		});
	}
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.1",
	ngImport: i0,
	type: ItRangeComponent,
	decorators: [{
		type: Component,
		args: [{
			selector: "it-range",
			imports: [ReactiveFormsModule],
			changeDetection: ChangeDetectionStrategy.OnPush,
			template: "<div class=\"d-flex justify-content-between align-items-center\">\r\n  @if (label) {\r\n    <label [for]=\"id\" class=\"form-label\">{{ label }}</label>\r\n  }\r\n  <ng-content></ng-content>\r\n</div>\r\n\r\n<input\r\n  #slider\r\n  [id]=\"id\"\r\n  type=\"range\"\r\n  [min]=\"min\"\r\n  [max]=\"max\"\r\n  [step]=\"step\"\r\n  class=\"form-range\"\r\n  [class.double-color]=\"!!leftColor && !!rightColor\"\r\n  [formControl]=\"control\" />\r\n",
			styles: [".form-range.double-color::-webkit-slider-runnable-track{background:linear-gradient(to right,var(--range-left-color) var(--range-percentage),var(--range-right-color) var(--range-percentage))}.form-range.double-color::-moz-range-track{background:linear-gradient(to right,var(--range-left-color) var(--range-percentage),var(--range-right-color) var(--range-percentage))}\n"]
		}]
	}],
	propDecorators: {
		max: [{ type: Input }],
		min: [{ type: Input }],
		step: [{ type: Input }],
		leftColor: [{ type: Input }],
		rightColor: [{ type: Input }],
		slider: [{
			type: ViewChild,
			args: ["slider", { static: true }]
		}]
	}
});
var ItRatingComponent = class ItRatingComponent extends ItAbstractFormComponent {
	constructor() {
		super(...arguments);
		this.starCount = 5;
		this.stars = this.generateStars();
	}
	ngOnChanges(changes) {
		super.ngOnChanges(changes);
		if (changes["starCount"] || !this.stars.length) this.stars = this.generateStars();
	}
	ngOnInit() {
		super.ngOnInit();
		if (!this.control.value && !!this.value) {
			this.writeValue(this.value);
			this.onChange(this.value);
		}
	}
	generateStars() {
		return Array.from({ length: this.starCount }, (_, i) => i + 1).reverse();
	}
	static {
		this.ɵfac = i0.ɵɵngDeclareFactory({
			minVersion: "12.0.0",
			version: "22.2.1",
			ngImport: i0,
			type: ItRatingComponent,
			deps: null,
			target: i0.ɵɵFactoryTarget.Component
		});
	}
	static {
		this.ɵcmp = i0.ɵɵngDeclareComponent({
			minVersion: "17.0.0",
			version: "22.2.1",
			type: ItRatingComponent,
			isStandalone: true,
			selector: "it-rating",
			inputs: {
				value: "value",
				starCount: "starCount"
			},
			usesInheritance: true,
			usesOnChanges: true,
			ngImport: i0,
			template: "<fieldset class=\"rating\" [class.rating-label]=\"!!label\" [class.rating-read-only]=\"control.disabled\">\r\n  <legend>\r\n    <span>{{ label }}</span>\r\n    <span class=\"visually-hidden\">\r\n      {{ 'it.core.rating-star' | translate: { current: control.value || 0, total: stars.length } }}\r\n    </span>\r\n  </legend>\r\n\r\n  @for (starValue of stars; track starValue) {\r\n    <input\r\n      [id]=\"id + '-' + starValue\"\r\n      type=\"radio\"\r\n      [name]=\"id\"\r\n      [value]=\"starValue\"\r\n      [attr.aria-hidden]=\"control.disabled\"\r\n      [formControl]=\"control\" />\r\n    <label class=\"full\" [for]=\"id + '-' + starValue\">\r\n      <it-icon name=\"star-full\" size=\"sm\" aria-hidden=\"true\"></it-icon>\r\n      <span class=\"visually-hidden\">\r\n        {{ 'it.core.rate-star' | translate: { current: starValue, total: stars.length } }}\r\n      </span>\r\n    </label>\r\n  }\r\n</fieldset>\r\n",
			dependencies: [
				{
					kind: "ngmodule",
					type: TranslateModule
				},
				{
					kind: "ngmodule",
					type: ReactiveFormsModule
				},
				{
					kind: "directive",
					type: i1.DefaultValueAccessor,
					selector: "input:not([type=checkbox]):not([ngNoCva])[formControlName],textarea:not([ngNoCva])[formControlName],input:not([type=checkbox]):not([ngNoCva])[formControl],textarea:not([ngNoCva])[formControl],input:not([type=checkbox]):not([ngNoCva])[ngModel],textarea:not([ngNoCva])[ngModel],[ngDefaultControl]"
				},
				{
					kind: "directive",
					type: i1.RadioControlValueAccessor,
					selector: "input[type=radio]:not([ngNoCva])[formControlName],input[type=radio]:not([ngNoCva])[formControl],input[type=radio]:not([ngNoCva])[ngModel]",
					inputs: [
						"name",
						"formControlName",
						"value"
					]
				},
				{
					kind: "directive",
					type: i1.NgControlStatus,
					selector: "[formControlName],[ngModel],[formControl]"
				},
				{
					kind: "directive",
					type: i1.FormControlDirective,
					selector: "[formControl]",
					inputs: [
						"formControl",
						"disabled",
						"ngModel"
					],
					outputs: ["ngModelChange"],
					exportAs: ["ngForm"]
				},
				{
					kind: "component",
					type: ItIconComponent,
					selector: "it-icon",
					inputs: [
						"name",
						"size",
						"color",
						"padded",
						"svgClass",
						"title",
						"labelWaria"
					]
				},
				{
					kind: "pipe",
					type: i1$1.TranslatePipe,
					name: "translate"
				}
			],
			changeDetection: i0.ChangeDetectionStrategy.OnPush
		});
	}
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.1",
	ngImport: i0,
	type: ItRatingComponent,
	decorators: [{
		type: Component,
		args: [{
			selector: "it-rating",
			changeDetection: ChangeDetectionStrategy.OnPush,
			imports: [
				TranslateModule,
				ReactiveFormsModule,
				ItIconComponent
			],
			template: "<fieldset class=\"rating\" [class.rating-label]=\"!!label\" [class.rating-read-only]=\"control.disabled\">\r\n  <legend>\r\n    <span>{{ label }}</span>\r\n    <span class=\"visually-hidden\">\r\n      {{ 'it.core.rating-star' | translate: { current: control.value || 0, total: stars.length } }}\r\n    </span>\r\n  </legend>\r\n\r\n  @for (starValue of stars; track starValue) {\r\n    <input\r\n      [id]=\"id + '-' + starValue\"\r\n      type=\"radio\"\r\n      [name]=\"id\"\r\n      [value]=\"starValue\"\r\n      [attr.aria-hidden]=\"control.disabled\"\r\n      [formControl]=\"control\" />\r\n    <label class=\"full\" [for]=\"id + '-' + starValue\">\r\n      <it-icon name=\"star-full\" size=\"sm\" aria-hidden=\"true\"></it-icon>\r\n      <span class=\"visually-hidden\">\r\n        {{ 'it.core.rate-star' | translate: { current: starValue, total: stars.length } }}\r\n      </span>\r\n    </label>\r\n  }\r\n</fieldset>\r\n"
		}]
	}],
	propDecorators: {
		value: [{ type: Input }],
		starCount: [{ type: Input }]
	}
});
var ItSelectComponent = class ItSelectComponent extends ItAbstractFormComponent {
	ngOnInit() {
		super.ngOnInit();
		if (this.control.value) return;
		const selectedOption = this.options?.find(this.optionIsSelected);
		if (selectedOption) {
			this.writeValue(selectedOption.value);
			if (this._ngControl?.control && selectedOption.value !== this._ngControl.control.value) this.onChange(selectedOption.value);
			return;
		}
		const selectedGroupOption = this.groups?.flatMap((g) => g.options).find(this.optionIsSelected);
		if (selectedGroupOption) {
			this.writeValue(selectedGroupOption.value);
			if (this._ngControl?.control && selectedGroupOption.value !== this._ngControl.control.value) this.onChange(selectedGroupOption.value);
		}
	}
	optionIsSelected(option) {
		if (option.selected === true) return true;
		if (typeof option.selected === "function") return option.selected(this.control.value);
		return false;
	}
	optionIsDisabled(option) {
		if (option.disabled === true) return true;
		if (typeof option.disabled === "function") return option.disabled(this.control.value);
		return false;
	}
	static {
		this.ɵfac = i0.ɵɵngDeclareFactory({
			minVersion: "12.0.0",
			version: "22.2.1",
			ngImport: i0,
			type: ItSelectComponent,
			deps: null,
			target: i0.ɵɵFactoryTarget.Component
		});
	}
	static {
		this.ɵcmp = i0.ɵɵngDeclareComponent({
			minVersion: "17.0.0",
			version: "22.2.1",
			type: ItSelectComponent,
			isStandalone: true,
			selector: "it-select",
			inputs: {
				options: "options",
				groups: "groups",
				description: "description",
				defaultOption: "defaultOption"
			},
			usesInheritance: true,
			ngImport: i0,
			template: "<div class=\"select-wrapper\">\r\n  @if (label) {\r\n    <label [for]=\"id\">{{ label }}</label>\r\n  }\r\n  <select\r\n    [id]=\"id\"\r\n    [formControl]=\"control\"\r\n    [class.is-invalid]=\"isInvalid\"\r\n    [class.is-valid]=\"isValid\"\r\n    (blur)=\"markAsTouched()\"\r\n    [attr.aria-describedby]=\"description ? id + '-description' : null\">\r\n    @if (defaultOption) {\r\n      <option [ngValue]=\"null\" disabled selected>\r\n        {{ defaultOption }}\r\n      </option>\r\n    }\r\n\r\n    <ng-content></ng-content>\r\n\r\n    @if (options) {\r\n      @for (option of options; track option.value) {\r\n        <option [disabled]=\"optionIsDisabled(option)\" [ngValue]=\"option.value\">\r\n          {{ option.text ?? option.value }}\r\n        </option>\r\n      }\r\n    }\r\n\r\n    @if (groups) {\r\n      @for (group of groups; track group) {\r\n        <optgroup [label]=\"group.label\">\r\n          @for (option of group.options; track option.value) {\r\n            <option [disabled]=\"optionIsDisabled(option)\" [ngValue]=\"option.value\">\r\n              {{ option.text ?? option.value }}\r\n            </option>\r\n          }\r\n        </optgroup>\r\n      }\r\n    }\r\n  </select>\r\n  @if (description) {\r\n    <small [id]=\"id + '-description'\" class=\"form-text\">{{ description }}</small>\r\n  }\r\n\r\n  @if (isInvalid) {\r\n    <div class=\"form-feedback just-validate-error-label\" [id]=\"id + '-error'\">\r\n      <div #customError>\r\n        <ng-content select=\"[error]\"></ng-content>\r\n      </div>\r\n      @if (!customError.hasChildNodes()) {\r\n        {{ invalidMessage | async }}\r\n      }\r\n    </div>\r\n  }\r\n</div>\r\n",
			styles: [".select-wrapper{margin-bottom:1.7rem}\n"],
			dependencies: [
				{
					kind: "ngmodule",
					type: ReactiveFormsModule
				},
				{
					kind: "directive",
					type: i1.NgSelectOption,
					selector: "option",
					inputs: ["ngValue", "value"]
				},
				{
					kind: "directive",
					type: i1.ɵNgSelectMultipleOption,
					selector: "option",
					inputs: ["ngValue", "value"]
				},
				{
					kind: "directive",
					type: i1.SelectControlValueAccessor,
					selector: "select:not([multiple]):not([ngNoCva])[formControlName],select:not([multiple]):not([ngNoCva])[formControl],select:not([multiple]):not([ngNoCva])[ngModel]",
					inputs: ["compareWith"]
				},
				{
					kind: "directive",
					type: i1.NgControlStatus,
					selector: "[formControlName],[ngModel],[formControl]"
				},
				{
					kind: "directive",
					type: i1.FormControlDirective,
					selector: "[formControl]",
					inputs: [
						"formControl",
						"disabled",
						"ngModel"
					],
					outputs: ["ngModelChange"],
					exportAs: ["ngForm"]
				},
				{
					kind: "pipe",
					type: AsyncPipe,
					name: "async"
				}
			],
			changeDetection: i0.ChangeDetectionStrategy.Eager
		});
	}
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.1",
	ngImport: i0,
	type: ItSelectComponent,
	decorators: [{
		type: Component,
		args: [{
			selector: "it-select",
			changeDetection: ChangeDetectionStrategy.Eager,
			imports: [ReactiveFormsModule, AsyncPipe],
			template: "<div class=\"select-wrapper\">\r\n  @if (label) {\r\n    <label [for]=\"id\">{{ label }}</label>\r\n  }\r\n  <select\r\n    [id]=\"id\"\r\n    [formControl]=\"control\"\r\n    [class.is-invalid]=\"isInvalid\"\r\n    [class.is-valid]=\"isValid\"\r\n    (blur)=\"markAsTouched()\"\r\n    [attr.aria-describedby]=\"description ? id + '-description' : null\">\r\n    @if (defaultOption) {\r\n      <option [ngValue]=\"null\" disabled selected>\r\n        {{ defaultOption }}\r\n      </option>\r\n    }\r\n\r\n    <ng-content></ng-content>\r\n\r\n    @if (options) {\r\n      @for (option of options; track option.value) {\r\n        <option [disabled]=\"optionIsDisabled(option)\" [ngValue]=\"option.value\">\r\n          {{ option.text ?? option.value }}\r\n        </option>\r\n      }\r\n    }\r\n\r\n    @if (groups) {\r\n      @for (group of groups; track group) {\r\n        <optgroup [label]=\"group.label\">\r\n          @for (option of group.options; track option.value) {\r\n            <option [disabled]=\"optionIsDisabled(option)\" [ngValue]=\"option.value\">\r\n              {{ option.text ?? option.value }}\r\n            </option>\r\n          }\r\n        </optgroup>\r\n      }\r\n    }\r\n  </select>\r\n  @if (description) {\r\n    <small [id]=\"id + '-description'\" class=\"form-text\">{{ description }}</small>\r\n  }\r\n\r\n  @if (isInvalid) {\r\n    <div class=\"form-feedback just-validate-error-label\" [id]=\"id + '-error'\">\r\n      <div #customError>\r\n        <ng-content select=\"[error]\"></ng-content>\r\n      </div>\r\n      @if (!customError.hasChildNodes()) {\r\n        {{ invalidMessage | async }}\r\n      }\r\n    </div>\r\n  }\r\n</div>\r\n",
			styles: [".select-wrapper{margin-bottom:1.7rem}\n"]
		}]
	}],
	propDecorators: {
		options: [{ type: Input }],
		groups: [{ type: Input }],
		description: [{ type: Input }],
		defaultOption: [{ type: Input }]
	}
});
var ItTextareaComponent = class ItTextareaComponent extends ItAbstractFormComponent {
	constructor() {
		super(...arguments);
		this.rows = 3;
		this.placeholder = "";
	}
	get invalidMessage() {
		if (this.hasError("maxlength")) {
			const error = this.getError("maxlength");
			return this._translateService.get("it.errors.max-length-invalid", { max: error.requiredLength });
		}
		if (this.hasError("pattern")) {
			const error = this.getError("pattern");
			return this._translateService.get("it.errors.pattern-invalid", { pattern: error.requiredPattern });
		}
		return super.invalidMessage;
	}
	get isReadonly() {
		return this.readonly === "plaintext" || !!this.readonly;
	}
	static {
		this.ɵfac = i0.ɵɵngDeclareFactory({
			minVersion: "12.0.0",
			version: "22.2.1",
			ngImport: i0,
			type: ItTextareaComponent,
			deps: null,
			target: i0.ɵɵFactoryTarget.Component
		});
	}
	static {
		this.ɵcmp = i0.ɵɵngDeclareComponent({
			minVersion: "17.0.0",
			version: "22.2.1",
			type: ItTextareaComponent,
			isStandalone: true,
			selector: "it-textarea",
			inputs: {
				rows: "rows",
				placeholder: "placeholder",
				description: "description",
				readonly: "readonly"
			},
			usesInheritance: true,
			ngImport: i0,
			template: "<div class=\"form-group\">\r\n  @if (label) {\r\n    <label [for]=\"id\" [class.active]=\"!!control.value || !!placeholder\">{{ label }}</label>\r\n  }\r\n  <textarea\r\n    [id]=\"id\"\r\n    [rows]=\"rows\"\r\n    [class.form-control]=\"readonly !== 'plaintext'\"\r\n    [class.form-control-plaintext]=\"readonly === 'plaintext'\"\r\n    [class.is-invalid]=\"isInvalid\"\r\n    [class.is-valid]=\"isValid\"\r\n    [placeholder]=\"placeholder\"\r\n    [formControl]=\"control\"\r\n    [readonly]=\"isReadonly\"\r\n    (blur)=\"markAsTouched()\"></textarea>\r\n\r\n  @if (description) {\r\n    <small [id]=\"id + '-description'\" class=\"form-text\">{{ description }}</small>\r\n  }\r\n  @if (isInvalid) {\r\n    <div class=\"form-feedback just-validate-error-label\" [id]=\"id + '-error'\">\r\n      <div #customError><ng-content select=\"[error]\"></ng-content></div>\r\n      @if (!customError.hasChildNodes()) {\r\n        {{ invalidMessage | async }}\r\n      }\r\n    </div>\r\n  }\r\n</div>\r\n",
			styles: ["textarea.is-invalid{border-color:#cc334d}\n"],
			dependencies: [
				{
					kind: "ngmodule",
					type: ReactiveFormsModule
				},
				{
					kind: "directive",
					type: i1.DefaultValueAccessor,
					selector: "input:not([type=checkbox]):not([ngNoCva])[formControlName],textarea:not([ngNoCva])[formControlName],input:not([type=checkbox]):not([ngNoCva])[formControl],textarea:not([ngNoCva])[formControl],input:not([type=checkbox]):not([ngNoCva])[ngModel],textarea:not([ngNoCva])[ngModel],[ngDefaultControl]"
				},
				{
					kind: "directive",
					type: i1.NgControlStatus,
					selector: "[formControlName],[ngModel],[formControl]"
				},
				{
					kind: "directive",
					type: i1.FormControlDirective,
					selector: "[formControl]",
					inputs: [
						"formControl",
						"disabled",
						"ngModel"
					],
					outputs: ["ngModelChange"],
					exportAs: ["ngForm"]
				},
				{
					kind: "pipe",
					type: AsyncPipe,
					name: "async"
				}
			],
			changeDetection: i0.ChangeDetectionStrategy.OnPush
		});
	}
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.1",
	ngImport: i0,
	type: ItTextareaComponent,
	decorators: [{
		type: Component,
		args: [{
			selector: "it-textarea",
			changeDetection: ChangeDetectionStrategy.OnPush,
			imports: [ReactiveFormsModule, AsyncPipe],
			template: "<div class=\"form-group\">\r\n  @if (label) {\r\n    <label [for]=\"id\" [class.active]=\"!!control.value || !!placeholder\">{{ label }}</label>\r\n  }\r\n  <textarea\r\n    [id]=\"id\"\r\n    [rows]=\"rows\"\r\n    [class.form-control]=\"readonly !== 'plaintext'\"\r\n    [class.form-control-plaintext]=\"readonly === 'plaintext'\"\r\n    [class.is-invalid]=\"isInvalid\"\r\n    [class.is-valid]=\"isValid\"\r\n    [placeholder]=\"placeholder\"\r\n    [formControl]=\"control\"\r\n    [readonly]=\"isReadonly\"\r\n    (blur)=\"markAsTouched()\"></textarea>\r\n\r\n  @if (description) {\r\n    <small [id]=\"id + '-description'\" class=\"form-text\">{{ description }}</small>\r\n  }\r\n  @if (isInvalid) {\r\n    <div class=\"form-feedback just-validate-error-label\" [id]=\"id + '-error'\">\r\n      <div #customError><ng-content select=\"[error]\"></ng-content></div>\r\n      @if (!customError.hasChildNodes()) {\r\n        {{ invalidMessage | async }}\r\n      }\r\n    </div>\r\n  }\r\n</div>\r\n",
			styles: ["textarea.is-invalid{border-color:#cc334d}\n"]
		}]
	}],
	propDecorators: {
		rows: [{ type: Input }],
		placeholder: [{ type: Input }],
		description: [{ type: Input }],
		readonly: [{ type: Input }]
	}
});
var ItFileUtils = class ItFileUtils {
	static getFileSizeString(file, decimals = 2) {
		const bytes = file.size;
		if (!+bytes) return "0 Bytes";
		const k = 1024;
		const dm = decimals < 0 ? 0 : decimals;
		const sizes = [
			"Bytes",
			"KB",
			"MB",
			"GB",
			"TB",
			"PB",
			"EB",
			"ZB",
			"YB"
		];
		const i = Math.floor(Math.log(bytes) / Math.log(k));
		return `${parseFloat((bytes / Math.pow(k, i)).toFixed(dm))} ${sizes[i]}`;
	}
	static fileToBase64(file) {
		const reader = new FileReader();
		reader.readAsDataURL(file);
		return new Observable((observer) => {
			reader.onload = (e) => {
				const target = e.target;
				if (!target?.result || target.result instanceof ArrayBuffer) return observer.error("Error on parse");
				observer.next(target.result);
				observer.complete();
			};
			reader.onerror = (error) => {
				observer.error(error);
			};
		});
	}
	static base64ToBlob(base64, mimeType) {
		const byteString = window.atob(base64);
		const arrayBuffer = new ArrayBuffer(byteString.length);
		const int8Array = new Uint8Array(arrayBuffer);
		for (let i = 0; i < byteString.length; i++) int8Array[i] = byteString.charCodeAt(i);
		return new Blob([int8Array], { type: mimeType });
	}
	static base64ToFile(base64, mimeType, filename) {
		const fileBlob = ItFileUtils.base64ToBlob(base64, mimeType);
		return new File([fileBlob], filename, { type: mimeType });
	}
	static getMimeTypeFromBase64(base64) {
		const mime = base64.match(/data:([a-zA-Z0-9]+\/[a-zA-Z0-9-.+]+).*,.*/);
		return mime?.length ? mime[1] : void 0;
	}
};
var ItUploadDragDropComponent = class ItUploadDragDropComponent extends ItAbstractComponent {
	constructor() {
		super();
		this.accept = "*";
		this.fileStartUpload = new EventEmitter();
		this.isDragover = false;
		this.isLoading = false;
		this.isSuccess = false;
		this.assetBasePath = inject(IT_ASSET_BASE_PATH);
	}
	ngAfterViewInit() {
		super.ngAfterViewInit();
		if (this.donutElement) this.donut = ProgressDonut.getOrCreateInstance(this.donutElement.nativeElement);
	}
	onDragOver(evt) {
		evt.preventDefault();
		evt.stopPropagation();
		this.isDragover = !this.isLoading;
	}
	onDragLeave(evt) {
		evt.preventDefault();
		evt.stopPropagation();
		this.isDragover = false;
	}
	onDrop(evt) {
		evt.preventDefault();
		evt.stopPropagation();
		this.isDragover = false;
		const files = evt.dataTransfer?.files;
		if (this.isLoading || !files?.length) return;
		this.start(files[0]);
	}
	onLoadFile(event) {
		const files = event.target?.files;
		if (!files?.length) return;
		this.start(files[0]);
	}
	start(file) {
		if (this.accept !== "*" && !this.accept.includes(file.type)) return;
		this.reset();
		this.isLoading = true;
		const splitName = file.name.split(".");
		this.filename = splitName[0];
		this.extension = splitName[1]?.toUpperCase();
		this.fileSize = ItFileUtils.getFileSizeString(file);
		this.fileStartUpload.emit(file);
	}
	progress(value) {
		if (!this.isLoading) return;
		if (value >= 100) this.success();
		else this.donut?.set((value < 0 ? 0 : value) / 100);
	}
	success() {
		this.isLoading = false;
		this.isSuccess = true;
		this._changeDetectorRef.detectChanges();
	}
	reset() {
		this.isLoading = false;
		this.isSuccess = false;
		this.filename = this.extension = this.fileSize = void 0;
		this.donut?.set(0);
		this._changeDetectorRef.detectChanges();
	}
	static {
		this.ɵfac = i0.ɵɵngDeclareFactory({
			minVersion: "12.0.0",
			version: "22.2.1",
			ngImport: i0,
			type: ItUploadDragDropComponent,
			deps: [],
			target: i0.ɵɵFactoryTarget.Component
		});
	}
	static {
		this.ɵcmp = i0.ɵɵngDeclareComponent({
			minVersion: "17.0.0",
			version: "22.2.1",
			type: ItUploadDragDropComponent,
			isStandalone: true,
			selector: "it-upload-drag-drop",
			inputs: { accept: "accept" },
			outputs: { fileStartUpload: "fileStartUpload" },
			host: { listeners: {
				"dragover": "onDragOver($event)",
				"dragleave": "onDragLeave($event)",
				"drop": "onDrop($event)"
			} },
			viewQueries: [{
				propertyName: "donutElement",
				first: true,
				predicate: ["donutElement"],
				descendants: true
			}],
			exportAs: ["itUploadDragDrop"],
			usesInheritance: true,
			ngImport: i0,
			template: "<div class=\"upload-dragdrop\" [class.dragover]=\"isDragover\" [class.loading]=\"isLoading\" [class.success]=\"isSuccess\">\r\n  <div class=\"upload-dragdrop-image\">\r\n    <img\r\n      [ngSrc]=\"assetBasePath + '/dist/assets/upload-drag-drop-icon.svg'\"\r\n      alt=\"drag-drop-icon\"\r\n      aria-hidden=\"true\"\r\n      [width]=\"180\"\r\n      [height]=\"180\" />\r\n    <div class=\"upload-dragdrop-loading\">\r\n      <div class=\"progress-donut\" #donutElement></div>\r\n    </div>\r\n    <div class=\"upload-dragdrop-success\">\r\n      <it-icon name=\"check\"></it-icon>\r\n    </div>\r\n  </div>\r\n  <div class=\"upload-dragdrop-text\">\r\n    <p class=\"upload-dragdrop-weight\">\r\n      <it-icon name=\"file\" size=\"xs\"></it-icon>\r\n      {{ extension }} ({{ fileSize }})\r\n    </p>\r\n    <h5>{{ filename || ('it.form.upload-drag-file' | translate) }}</h5>\r\n    @if (isLoading) {\r\n      <p>{{ 'it.form.upload-loading' | translate }}</p>\r\n    }\r\n    @if (isSuccess) {\r\n      <p>{{ 'it.form.upload-complete' | translate }}</p>\r\n    }\r\n    @if (!isLoading && !isSuccess) {\r\n      <p>\r\n        {{ 'it.form.upload-or' | translate }}\r\n        <input type=\"file\" [id]=\"id\" class=\"upload-dragdrop-input\" [accept]=\"accept\" (change)=\"onLoadFile($event)\" />\r\n        <label [for]=\"id\">{{ 'it.form.upload-select-device' | translate }}</label>\r\n      </p>\r\n    }\r\n  </div>\r\n</div>\r\n",
			dependencies: [
				{
					kind: "component",
					type: ItIconComponent,
					selector: "it-icon",
					inputs: [
						"name",
						"size",
						"color",
						"padded",
						"svgClass",
						"title",
						"labelWaria"
					]
				},
				{
					kind: "ngmodule",
					type: TranslateModule
				},
				{
					kind: "directive",
					type: NgOptimizedImage,
					selector: "img[ngSrc]",
					inputs: [
						"ngSrc",
						"ngSrcset",
						"sizes",
						"width",
						"height",
						"decoding",
						"loading",
						"priority",
						"loaderParams",
						"disableOptimizedSrcset",
						"fill",
						"placeholder",
						"placeholderConfig",
						"src",
						"srcset"
					]
				},
				{
					kind: "pipe",
					type: i1$1.TranslatePipe,
					name: "translate"
				}
			],
			changeDetection: i0.ChangeDetectionStrategy.OnPush
		});
	}
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.1",
	ngImport: i0,
	type: ItUploadDragDropComponent,
	decorators: [{
		type: Component,
		args: [{
			selector: "it-upload-drag-drop",
			exportAs: "itUploadDragDrop",
			changeDetection: ChangeDetectionStrategy.OnPush,
			imports: [
				ItIconComponent,
				TranslateModule,
				NgOptimizedImage
			],
			template: "<div class=\"upload-dragdrop\" [class.dragover]=\"isDragover\" [class.loading]=\"isLoading\" [class.success]=\"isSuccess\">\r\n  <div class=\"upload-dragdrop-image\">\r\n    <img\r\n      [ngSrc]=\"assetBasePath + '/dist/assets/upload-drag-drop-icon.svg'\"\r\n      alt=\"drag-drop-icon\"\r\n      aria-hidden=\"true\"\r\n      [width]=\"180\"\r\n      [height]=\"180\" />\r\n    <div class=\"upload-dragdrop-loading\">\r\n      <div class=\"progress-donut\" #donutElement></div>\r\n    </div>\r\n    <div class=\"upload-dragdrop-success\">\r\n      <it-icon name=\"check\"></it-icon>\r\n    </div>\r\n  </div>\r\n  <div class=\"upload-dragdrop-text\">\r\n    <p class=\"upload-dragdrop-weight\">\r\n      <it-icon name=\"file\" size=\"xs\"></it-icon>\r\n      {{ extension }} ({{ fileSize }})\r\n    </p>\r\n    <h5>{{ filename || ('it.form.upload-drag-file' | translate) }}</h5>\r\n    @if (isLoading) {\r\n      <p>{{ 'it.form.upload-loading' | translate }}</p>\r\n    }\r\n    @if (isSuccess) {\r\n      <p>{{ 'it.form.upload-complete' | translate }}</p>\r\n    }\r\n    @if (!isLoading && !isSuccess) {\r\n      <p>\r\n        {{ 'it.form.upload-or' | translate }}\r\n        <input type=\"file\" [id]=\"id\" class=\"upload-dragdrop-input\" [accept]=\"accept\" (change)=\"onLoadFile($event)\" />\r\n        <label [for]=\"id\">{{ 'it.form.upload-select-device' | translate }}</label>\r\n      </p>\r\n    }\r\n  </div>\r\n</div>\r\n"
		}]
	}],
	ctorParameters: () => [],
	propDecorators: {
		accept: [{ type: Input }],
		fileStartUpload: [{ type: Output }],
		donutElement: [{
			type: ViewChild,
			args: ["donutElement"]
		}],
		onDragOver: [{
			type: HostListener,
			args: ["dragover", ["$event"]]
		}],
		onDragLeave: [{
			type: HostListener,
			args: ["dragleave", ["$event"]]
		}],
		onDrop: [{
			type: HostListener,
			args: ["drop", ["$event"]]
		}]
	}
});
var ItUploadFileListComponent = class ItUploadFileListComponent extends ItAbstractComponent {
	constructor() {
		super(...arguments);
		this.accept = "*";
		this.multiple = true;
		this.uploadFiles = new EventEmitter();
		this.deleteItem = new EventEmitter();
		this.previewImages = /* @__PURE__ */ new Map();
	}
	ngOnInit() {
		if (!!this.images && this.accept === "*") this.accept = "image/*";
	}
	ngOnChanges(changes) {
		if (changes["fileList"] && !!this.images) {
			const images$ = this.fileList.map((item) => ItFileUtils.fileToBase64(item.file).pipe(take(1), tap((base64) => this.previewImages.set(item.id, base64))));
			forkJoin(images$).subscribe(() => {
				this._changeDetectorRef.detectChanges();
				super.ngOnChanges(changes);
			});
		} else super.ngOnChanges(changes);
	}
	onLoadFiles(event) {
		const input = event.target;
		const files = input?.files;
		if (!files?.length) return;
		const newFiles = Array.from(files).filter((file) => !this.fileList.some((item) => {
			return item.file.name === file.name && item.file.size === file.size && item.file.type === file.type;
		}));
		const fileList = new DataTransfer();
		newFiles.forEach((file) => fileList.items.add(file));
		this.uploadFiles.emit(fileList.files);
		input.value = "";
	}
	getFileSize(file) {
		return ItFileUtils.getFileSizeString(file);
	}
	static {
		this.ɵfac = i0.ɵɵngDeclareFactory({
			minVersion: "12.0.0",
			version: "22.2.1",
			ngImport: i0,
			type: ItUploadFileListComponent,
			deps: null,
			target: i0.ɵɵFactoryTarget.Component
		});
	}
	static {
		this.ɵcmp = i0.ɵɵngDeclareComponent({
			minVersion: "17.0.0",
			version: "22.2.1",
			type: ItUploadFileListComponent,
			isStandalone: true,
			selector: "it-upload-file-list",
			inputs: {
				fileList: "fileList",
				accept: "accept",
				label: "label",
				multiple: [
					"multiple",
					"multiple",
					inputToBoolean
				],
				images: [
					"images",
					"images",
					inputToBoolean
				],
				hideLoadButton: [
					"hideLoadButton",
					"hideLoadButton",
					inputToBoolean
				]
			},
			outputs: {
				uploadFiles: "uploadFiles",
				deleteItem: "deleteItem"
			},
			usesInheritance: true,
			usesOnChanges: true,
			ngImport: i0,
			template: "@if (!hideLoadButton) {\r\n  <input type=\"file\" [id]=\"id\" class=\"upload\" [accept]=\"accept\" [multiple]=\"multiple\" (change)=\"onLoadFiles($event)\" />\r\n  <label [for]=\"id\">\r\n    @if (label) {\r\n      <it-icon name=\"upload\" size=\"sm\"></it-icon>\r\n      <span>{{ label }}</span>\r\n    } @else {\r\n      <it-icon name=\"upload\" size=\"sm\"></it-icon>\r\n      <span>{{ 'it.form.upload' | translate }}</span>\r\n    }\r\n  </label>\r\n}\r\n\r\n@if (fileList.length) {\r\n  <ul class=\"upload-file-list\" [class.upload-file-list-image]=\"images\">\r\n    @for (item of fileList; track item.id) {\r\n      <li\r\n        class=\"upload-file\"\r\n        [class.error]=\"item.error\"\r\n        [class.uploading]=\"!item.error && item.progress !== undefined && item.progress > 0 && item.progress < 100\"\r\n        [class.success]=\"!item.error && (!item.progress || item.progress >= 100)\">\r\n        @if (images) {\r\n          <div class=\"upload-image\">\r\n            <img [attr.src]=\"previewImages.get(item.id)\" [alt]=\"item.file.name\" />\r\n          </div>\r\n        } @else {\r\n          <it-icon name=\"file\" size=\"sm\" [color]=\"!item.error ? (item.progress ? 'secondary' : 'primary') : 'danger'\"></it-icon>\r\n        }\r\n        <p [itTooltip]=\"item.tooltip\">\r\n          <span class=\"visually-hidden\">{{ 'it.form.uploaded-file' | translate: { name: item.file.name } }}</span>\r\n          {{ item.file.name }} <span class=\"upload-file-weight\">{{ getFileSize(item.file) }}</span>\r\n        </p>\r\n        @if (item.removable && (!item.progress || item.progress < 100)) {\r\n          <button type=\"button\" (click)=\"deleteItem.emit(item)\">\r\n            <span class=\"visually-hidden\">{{ 'it.form.delete-file' | translate: { name: item.file.name } }}</span>\r\n            <it-icon name=\"close\"></it-icon>\r\n          </button>\r\n        }\r\n        @if ((!item.removable && !item.progress) || (item.progress !== undefined && item.progress >= 100)) {\r\n          <button type=\"button\" disabled>\r\n            <span class=\"visually-hidden\">{{ 'it.form.upload-complete' | translate }}</span>\r\n            <it-icon name=\"check\"></it-icon>\r\n          </button>\r\n        }\r\n        @if (!item.error && item.progress !== undefined && item.progress > 0 && item.progress < 100) {\r\n          <it-progress-bar [value]=\"item.progress!\"></it-progress-bar>\r\n        }\r\n      </li>\r\n    }\r\n  </ul>\r\n}\r\n",
			dependencies: [
				{
					kind: "component",
					type: ItIconComponent,
					selector: "it-icon",
					inputs: [
						"name",
						"size",
						"color",
						"padded",
						"svgClass",
						"title",
						"labelWaria"
					]
				},
				{
					kind: "ngmodule",
					type: TranslateModule
				},
				{
					kind: "directive",
					type: ItTooltipDirective,
					selector: "[itTooltip]",
					inputs: [
						"itTooltip",
						"tooltipPlacement",
						"tooltipHtml"
					],
					outputs: [
						"showEvent",
						"shownEvent",
						"hideEvent",
						"hiddenEvent",
						"insertedEvent"
					],
					exportAs: ["itTooltip"]
				},
				{
					kind: "component",
					type: ItProgressBarComponent,
					selector: "it-progress-bar",
					inputs: [
						"value",
						"showLabel",
						"indeterminate",
						"color"
					]
				},
				{
					kind: "pipe",
					type: i1$1.TranslatePipe,
					name: "translate"
				}
			],
			changeDetection: i0.ChangeDetectionStrategy.Eager
		});
	}
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.1",
	ngImport: i0,
	type: ItUploadFileListComponent,
	decorators: [{
		type: Component,
		args: [{
			selector: "it-upload-file-list",
			changeDetection: ChangeDetectionStrategy.Eager,
			imports: [
				ItIconComponent,
				TranslateModule,
				ItTooltipDirective,
				ItProgressBarComponent
			],
			template: "@if (!hideLoadButton) {\r\n  <input type=\"file\" [id]=\"id\" class=\"upload\" [accept]=\"accept\" [multiple]=\"multiple\" (change)=\"onLoadFiles($event)\" />\r\n  <label [for]=\"id\">\r\n    @if (label) {\r\n      <it-icon name=\"upload\" size=\"sm\"></it-icon>\r\n      <span>{{ label }}</span>\r\n    } @else {\r\n      <it-icon name=\"upload\" size=\"sm\"></it-icon>\r\n      <span>{{ 'it.form.upload' | translate }}</span>\r\n    }\r\n  </label>\r\n}\r\n\r\n@if (fileList.length) {\r\n  <ul class=\"upload-file-list\" [class.upload-file-list-image]=\"images\">\r\n    @for (item of fileList; track item.id) {\r\n      <li\r\n        class=\"upload-file\"\r\n        [class.error]=\"item.error\"\r\n        [class.uploading]=\"!item.error && item.progress !== undefined && item.progress > 0 && item.progress < 100\"\r\n        [class.success]=\"!item.error && (!item.progress || item.progress >= 100)\">\r\n        @if (images) {\r\n          <div class=\"upload-image\">\r\n            <img [attr.src]=\"previewImages.get(item.id)\" [alt]=\"item.file.name\" />\r\n          </div>\r\n        } @else {\r\n          <it-icon name=\"file\" size=\"sm\" [color]=\"!item.error ? (item.progress ? 'secondary' : 'primary') : 'danger'\"></it-icon>\r\n        }\r\n        <p [itTooltip]=\"item.tooltip\">\r\n          <span class=\"visually-hidden\">{{ 'it.form.uploaded-file' | translate: { name: item.file.name } }}</span>\r\n          {{ item.file.name }} <span class=\"upload-file-weight\">{{ getFileSize(item.file) }}</span>\r\n        </p>\r\n        @if (item.removable && (!item.progress || item.progress < 100)) {\r\n          <button type=\"button\" (click)=\"deleteItem.emit(item)\">\r\n            <span class=\"visually-hidden\">{{ 'it.form.delete-file' | translate: { name: item.file.name } }}</span>\r\n            <it-icon name=\"close\"></it-icon>\r\n          </button>\r\n        }\r\n        @if ((!item.removable && !item.progress) || (item.progress !== undefined && item.progress >= 100)) {\r\n          <button type=\"button\" disabled>\r\n            <span class=\"visually-hidden\">{{ 'it.form.upload-complete' | translate }}</span>\r\n            <it-icon name=\"check\"></it-icon>\r\n          </button>\r\n        }\r\n        @if (!item.error && item.progress !== undefined && item.progress > 0 && item.progress < 100) {\r\n          <it-progress-bar [value]=\"item.progress!\"></it-progress-bar>\r\n        }\r\n      </li>\r\n    }\r\n  </ul>\r\n}\r\n"
		}]
	}],
	propDecorators: {
		fileList: [{
			type: Input,
			args: [{ required: true }]
		}],
		accept: [{ type: Input }],
		label: [{
			type: Input,
			args: [{ required: false }]
		}],
		multiple: [{
			type: Input,
			args: [{ transform: inputToBoolean }]
		}],
		images: [{
			type: Input,
			args: [{ transform: inputToBoolean }]
		}],
		hideLoadButton: [{
			type: Input,
			args: [{ transform: inputToBoolean }]
		}],
		uploadFiles: [{ type: Output }],
		deleteItem: [{ type: Output }]
	}
});
var ItMarkMatchingTextPipe = class ItMarkMatchingTextPipe {
	constructor() {
		this.domSanitizer = inject(DomSanitizer);
	}
	transform(allString, searchString) {
		if (!searchString) return allString;
		else if (!allString) return "";
		if (typeof searchString === "number") searchString = searchString.toString();
		const idxOfMatchString = allString.toLowerCase().indexOf(searchString.toLowerCase());
		if (idxOfMatchString !== -1) {
			const matchingString = allString.substring(idxOfMatchString, idxOfMatchString + searchString.length);
			const regEx = new RegExp("(" + matchingString + ")", "gi");
			const res = allString.replace(regEx, "<mark>$1</mark>");
			return this.domSanitizer.bypassSecurityTrustHtml(res);
		}
		return allString;
	}
	static {
		this.ɵfac = i0.ɵɵngDeclareFactory({
			minVersion: "12.0.0",
			version: "22.2.1",
			ngImport: i0,
			type: ItMarkMatchingTextPipe,
			deps: [],
			target: i0.ɵɵFactoryTarget.Pipe
		});
	}
	static {
		this.ɵpipe = i0.ɵɵngDeclarePipe({
			minVersion: "14.0.0",
			version: "22.2.1",
			ngImport: i0,
			type: ItMarkMatchingTextPipe,
			isStandalone: true,
			name: "itMarkMatchingText"
		});
	}
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.1",
	ngImport: i0,
	type: ItMarkMatchingTextPipe,
	decorators: [{
		type: Pipe,
		args: [{
			standalone: true,
			name: "itMarkMatchingText"
		}]
	}]
});
var ItSearchComponent = class ItSearchComponent extends ItAbstractFormComponent {
	constructor() {
		super(...arguments);
		this.debounceTime = 300;
		this.placeholder = "";
		this.labelWaria = void 0;
		this.forceShowLabel = true;
		this.searchSelectedEvent = new EventEmitter();
		this.showAutocompletion = false;
		this.searchResults$ = new Observable();
	}
	ngOnInit() {
		super.ngOnInit();
		this.searchResults$ = this.getSearchResults$();
	}
	getSearchResults$() {
		return this.control.valueChanges.pipe(debounceTime(this.debounceTime), distinctUntilChanged(), switchMap((searchedValue) => {
			if (!this.searchData) return of({
				searchedValue,
				relatedEntries: []
			});
			return (Array.isArray(this.searchData) ? of(this.searchData) : this.searchData(searchedValue)).pipe(map((searchData) => {
				if (!searchedValue || typeof searchedValue === "number") return {
					searchedValue,
					relatedEntries: []
				};
				const lowercaseValue = searchedValue.toLowerCase();
				return {
					searchedValue,
					relatedEntries: searchData.filter((item) => item.value?.toLowerCase().includes(lowercaseValue))
				};
			}));
		}));
	}
	onEntryClick(entry, event) {
		if (!entry.link) event.preventDefault();
		this.searchSelectedEvent.next(entry);
		this.control.setValue(entry.value);
		this.showAutocompletion = false;
	}
	searchItemTrackByValueFn(index, item) {
		return item.value;
	}
	onKeyDown() {
		this.showAutocompletion = true;
	}
	static {
		this.ɵfac = i0.ɵɵngDeclareFactory({
			minVersion: "12.0.0",
			version: "22.2.1",
			ngImport: i0,
			type: ItSearchComponent,
			deps: null,
			target: i0.ɵɵFactoryTarget.Component
		});
	}
	static {
		this.ɵcmp = i0.ɵɵngDeclareComponent({
			minVersion: "17.0.0",
			version: "22.2.1",
			type: ItSearchComponent,
			isStandalone: true,
			selector: "it-search",
			inputs: {
				searchData: "searchData",
				big: [
					"big",
					"big",
					inputToBoolean
				],
				debounceTime: "debounceTime",
				placeholder: "placeholder",
				labelWaria: "labelWaria",
				forceShowLabel: [
					"forceShowLabel",
					"forceShowLabel",
					inputToBoolean
				]
			},
			outputs: { searchSelectedEvent: "searchSelectedEvent" },
			usesInheritance: true,
			ngImport: i0,
			template: "<div class=\"form-group\" [class.autocomplete-wrapper-big]=\"big\">\r\n  @if (label) {\r\n    <label [for]=\"id\" [class.active]=\"true\">\r\n      {{ label }}\r\n    </label>\r\n  }\r\n\r\n  <input\r\n    [id]=\"id\"\r\n    type=\"search\"\r\n    class=\"autocomplete form-control\"\r\n    [placeholder]=\"placeholder\"\r\n    [formControl]=\"control\"\r\n    [class.is-invalid]=\"isInvalid\"\r\n    [class.is-valid]=\"isValid\"\r\n    (blur)=\"markAsTouched()\"\r\n    (keydown)=\"onKeyDown()\" />\r\n\r\n  <span class=\"autocomplete-icon\" aria-hidden=\"true\">\r\n    <it-icon [labelWaria]=\"labelWaria\" name=\"search\" size=\"sm\"></it-icon>\r\n  </span>\r\n\r\n  @if (searchResults$ | async; as autocomplete) {\r\n    <ul class=\"autocomplete-list\" [class.autocomplete-list-show]=\"autocomplete.relatedEntries?.length && showAutocompletion\">\r\n      @for (entry of autocomplete.relatedEntries; track searchItemTrackByValueFn($index, entry)) {\r\n        <li>\r\n          <a [href]=\"entry.link\" (click)=\"onEntryClick(entry, $event)\">\r\n            @if (entry.avatarSrcPath) {\r\n              <div class=\"avatar size-sm\">\r\n                <img [src]=\"entry.avatarSrcPath\" [alt]=\"entry.avatarAltText\" />\r\n              </div>\r\n            }\r\n            @if (entry.icon) {\r\n              <it-icon [name]=\"entry.icon\" size=\"sm\"></it-icon>\r\n            }\r\n            <span class=\"autocomplete-list-text\">\r\n              <span [innerHTML]=\"entry.value | itMarkMatchingText: autocomplete.searchedValue\"></span>\r\n              @if (entry.label) {\r\n                <em>{{ entry.label }}</em>\r\n              }\r\n            </span>\r\n          </a>\r\n        </li>\r\n      }\r\n    </ul>\r\n  }\r\n\r\n  @if (isInvalid) {\r\n    <div class=\"form-feedback just-validate-error-label\" [id]=\"id + '-error'\">\r\n      <div #customError>\r\n        <ng-content select=\"[error]\"></ng-content>\r\n      </div>\r\n      @if (!customError.hasChildNodes()) {\r\n        {{ invalidMessage | async }}\r\n      }\r\n    </div>\r\n  }\r\n</div>\r\n",
			dependencies: [
				{
					kind: "component",
					type: ItIconComponent,
					selector: "it-icon",
					inputs: [
						"name",
						"size",
						"color",
						"padded",
						"svgClass",
						"title",
						"labelWaria"
					]
				},
				{
					kind: "ngmodule",
					type: ReactiveFormsModule
				},
				{
					kind: "directive",
					type: i1.DefaultValueAccessor,
					selector: "input:not([type=checkbox]):not([ngNoCva])[formControlName],textarea:not([ngNoCva])[formControlName],input:not([type=checkbox]):not([ngNoCva])[formControl],textarea:not([ngNoCva])[formControl],input:not([type=checkbox]):not([ngNoCva])[ngModel],textarea:not([ngNoCva])[ngModel],[ngDefaultControl]"
				},
				{
					kind: "directive",
					type: i1.NgControlStatus,
					selector: "[formControlName],[ngModel],[formControl]"
				},
				{
					kind: "directive",
					type: i1.FormControlDirective,
					selector: "[formControl]",
					inputs: [
						"formControl",
						"disabled",
						"ngModel"
					],
					outputs: ["ngModelChange"],
					exportAs: ["ngForm"]
				},
				{
					kind: "pipe",
					type: AsyncPipe,
					name: "async"
				},
				{
					kind: "pipe",
					type: ItMarkMatchingTextPipe,
					name: "itMarkMatchingText"
				}
			],
			changeDetection: i0.ChangeDetectionStrategy.OnPush
		});
	}
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.1",
	ngImport: i0,
	type: ItSearchComponent,
	decorators: [{
		type: Component,
		args: [{
			standalone: true,
			selector: "it-search",
			imports: [
				AsyncPipe,
				ItIconComponent,
				ItMarkMatchingTextPipe,
				ReactiveFormsModule
			],
			changeDetection: ChangeDetectionStrategy.OnPush,
			template: "<div class=\"form-group\" [class.autocomplete-wrapper-big]=\"big\">\r\n  @if (label) {\r\n    <label [for]=\"id\" [class.active]=\"true\">\r\n      {{ label }}\r\n    </label>\r\n  }\r\n\r\n  <input\r\n    [id]=\"id\"\r\n    type=\"search\"\r\n    class=\"autocomplete form-control\"\r\n    [placeholder]=\"placeholder\"\r\n    [formControl]=\"control\"\r\n    [class.is-invalid]=\"isInvalid\"\r\n    [class.is-valid]=\"isValid\"\r\n    (blur)=\"markAsTouched()\"\r\n    (keydown)=\"onKeyDown()\" />\r\n\r\n  <span class=\"autocomplete-icon\" aria-hidden=\"true\">\r\n    <it-icon [labelWaria]=\"labelWaria\" name=\"search\" size=\"sm\"></it-icon>\r\n  </span>\r\n\r\n  @if (searchResults$ | async; as autocomplete) {\r\n    <ul class=\"autocomplete-list\" [class.autocomplete-list-show]=\"autocomplete.relatedEntries?.length && showAutocompletion\">\r\n      @for (entry of autocomplete.relatedEntries; track searchItemTrackByValueFn($index, entry)) {\r\n        <li>\r\n          <a [href]=\"entry.link\" (click)=\"onEntryClick(entry, $event)\">\r\n            @if (entry.avatarSrcPath) {\r\n              <div class=\"avatar size-sm\">\r\n                <img [src]=\"entry.avatarSrcPath\" [alt]=\"entry.avatarAltText\" />\r\n              </div>\r\n            }\r\n            @if (entry.icon) {\r\n              <it-icon [name]=\"entry.icon\" size=\"sm\"></it-icon>\r\n            }\r\n            <span class=\"autocomplete-list-text\">\r\n              <span [innerHTML]=\"entry.value | itMarkMatchingText: autocomplete.searchedValue\"></span>\r\n              @if (entry.label) {\r\n                <em>{{ entry.label }}</em>\r\n              }\r\n            </span>\r\n          </a>\r\n        </li>\r\n      }\r\n    </ul>\r\n  }\r\n\r\n  @if (isInvalid) {\r\n    <div class=\"form-feedback just-validate-error-label\" [id]=\"id + '-error'\">\r\n      <div #customError>\r\n        <ng-content select=\"[error]\"></ng-content>\r\n      </div>\r\n      @if (!customError.hasChildNodes()) {\r\n        {{ invalidMessage | async }}\r\n      }\r\n    </div>\r\n  }\r\n</div>\r\n"
		}]
	}],
	propDecorators: {
		searchData: [{
			type: Input,
			args: [{ required: true }]
		}],
		big: [{
			type: Input,
			args: [{ transform: inputToBoolean }]
		}],
		debounceTime: [{ type: Input }],
		placeholder: [{ type: Input }],
		labelWaria: [{ type: Input }],
		forceShowLabel: [{
			type: Input,
			args: [{ transform: inputToBoolean }]
		}],
		searchSelectedEvent: [{ type: Output }]
	}
});
const generateSelectAll = (checked, items) => {
	const selected = /* @__PURE__ */ new Set();
	if (checked) items.forEach((item) => selected.add(item));
	return selected;
};
const updateSelected = (set, item) => {
	if (set.has(item)) set.delete(item);
	else set.add(item);
	return set;
};
const init = (state, { source, target }) => ({
	...state,
	initialItems: {
		source: [...source],
		target: [...target]
	},
	current: {
		source: [...source],
		target: [...target]
	}
});
const transfer = (state) => {
	return {
		...state,
		current: {
			...state.current,
			source: state.current.source.filter((i) => !state.selections.source.has(i)),
			target: Array.from(/* @__PURE__ */ new Set([...state.current.target, ...Array.from(state.selections.source)]))
		},
		selections: {
			...state.selections,
			source: /* @__PURE__ */ new Set()
		},
		operationsEnabled: {
			...state.operationsEnabled,
			transfer: false,
			reset: true
		}
	};
};
const backtransfer = (state) => {
	return {
		...state,
		current: {
			...state.current,
			target: state.current.target.filter((i) => !state.selections.target.has(i)),
			source: Array.from(/* @__PURE__ */ new Set([...state.current.source, ...Array.from(state.selections.target)]))
		},
		selections: {
			...state.selections,
			target: /* @__PURE__ */ new Set()
		},
		operationsEnabled: {
			...state.operationsEnabled,
			backtransfer: false,
			reset: true
		}
	};
};
const reset = (state) => {
	return {
		...state,
		current: {
			source: [...state.initialItems.source],
			target: [...state.initialItems.target]
		},
		operationsEnabled: {
			...state.operationsEnabled,
			reset: false
		}
	};
};
const selectAllSource = (state, { checked }) => {
	const items = state.current.source;
	const selected = generateSelectAll(checked, items);
	const transfer = Boolean(selected.size);
	return {
		...state,
		selections: {
			...state.selections,
			source: selected
		},
		operationsEnabled: {
			...state.operationsEnabled,
			transfer
		}
	};
};
const selectAllTarget = (state, { checked }) => {
	const items = state.current.target;
	const selected = generateSelectAll(checked, items);
	const backtransfer = Boolean(selected.size);
	return {
		...state,
		selections: {
			...state.selections,
			target: selected
		},
		operationsEnabled: {
			...state.operationsEnabled,
			backtransfer
		}
	};
};
const selectionItemSource = (previousState, { item }) => {
	const selected = updateSelected(previousState.selections.source, item);
	const selectedItems = Array.from(selected);
	const transfer = Boolean(selectedItems.length);
	const source = /* @__PURE__ */ new Set([...selectedItems]);
	return {
		...previousState,
		selections: {
			...previousState.selections,
			source
		},
		operationsEnabled: {
			...previousState.operationsEnabled,
			transfer
		}
	};
};
const selectionItemTarget = (previousState, { item }) => {
	const selected = updateSelected(previousState.selections.target, item);
	const selectedItems = Array.from(selected);
	const backtransfer = Boolean(selectedItems.length);
	const target = /* @__PURE__ */ new Set([...selectedItems]);
	return {
		...previousState,
		selections: {
			...previousState.selections,
			target
		},
		operationsEnabled: {
			...previousState.operationsEnabled,
			backtransfer
		}
	};
};
const initialStateFn = () => ({
	initialItems: {
		source: [],
		target: []
	},
	current: {
		source: [],
		target: []
	},
	selections: {
		source: /* @__PURE__ */ new Set(),
		target: /* @__PURE__ */ new Set()
	},
	operationsEnabled: {
		transfer: false,
		backtransfer: false,
		reset: false
	}
});
const initFn = (payload) => (state) => init(state, payload);
const transferFn = () => (state) => transfer(state);
const backtransferFn = () => (state) => backtransfer(state);
const resetFn = () => (state) => reset(state);
const selectAllSourceFn = ({ checked }) => (state) => selectAllSource(state, { checked });
const selectAllTargetFn = ({ checked }) => (state) => selectAllTarget(state, { checked });
const selectionItemSourceFn = ({ item }) => (state) => selectionItemSource(state, { item });
const selectionItemTargetFn = ({ item }) => (state) => selectionItemTarget(state, { item });
var transfer_reducers_default = {
	initialStateFn,
	initFn,
	transferFn,
	backtransferFn,
	resetFn,
	selectAllSourceFn,
	selectAllTargetFn,
	selectionItemSourceFn,
	selectionItemTargetFn
};
var TransferStore = class TransferStore {
	constructor() {
		this._state = new BehaviorSubject(transfer_reducers_default.initialStateFn());
		this.sourceItems = this._state.pipe(map((state) => state.current.source));
		this.targetItems = this._state.pipe(map((state) => state.current.target));
		this.valueChanged = this._state.pipe(map((state) => state.current.target), distinctUntilChanged());
		this.selectItems = (sourceType) => {
			if (sourceType === "source") return this.sourceItems;
			if (sourceType === "target") return this.targetItems;
			return of([]);
		};
		this.selectSelectedItems = (sourceType) => {
			if (sourceType === "source") return this._state.pipe(map((state) => state.selections.source));
			if (sourceType === "target") return this._state.pipe(map((state) => state.selections.target));
			return of(/* @__PURE__ */ new Set());
		};
		this.transferEnabled = this._state.pipe(map((state) => state.operationsEnabled.transfer));
		this.backtransferEnabled = this._state.pipe(map((state) => state.operationsEnabled.backtransfer));
		this.resetEnabled = this._state.pipe(map((state) => state.operationsEnabled.reset));
	}
	init({ source, target }) {
		this.updateState(transfer_reducers_default.initFn({
			source,
			target
		}));
	}
	transfer() {
		this.updateState(transfer_reducers_default.transferFn());
	}
	backtransfer() {
		this.updateState(transfer_reducers_default.backtransferFn());
	}
	reset() {
		this.updateState(transfer_reducers_default.resetFn());
	}
	checkboxSelection(item, sourceType) {
		if (sourceType === "source") this.updateState(transfer_reducers_default.selectionItemSourceFn({ item }));
		if (sourceType === "target") this.updateState(transfer_reducers_default.selectionItemTargetFn({ item }));
	}
	selectAllSelection(checked, sourceType) {
		if (sourceType === "source") this.updateState(transfer_reducers_default.selectAllSourceFn({ checked }));
		if (sourceType === "target") this.updateState(transfer_reducers_default.selectAllTargetFn({ checked }));
	}
	updateState(reducerFn) {
		this._state.next(reducerFn(this._state.value));
	}
	static {
		this.ɵfac = i0.ɵɵngDeclareFactory({
			minVersion: "12.0.0",
			version: "22.2.1",
			ngImport: i0,
			type: TransferStore,
			deps: [],
			target: i0.ɵɵFactoryTarget.Injectable
		});
	}
	static {
		this.ɵprov = i0.ɵɵngDeclareInjectable({
			minVersion: "12.0.0",
			version: "22.2.1",
			ngImport: i0,
			type: TransferStore
		});
	}
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.1",
	ngImport: i0,
	type: TransferStore,
	decorators: [{ type: Injectable }]
});
var ItTransferListComponent = class ItTransferListComponent extends ItAbstractComponent {
	constructor() {
		super();
		this.store = inject(TransferStore);
		this.title = inject(new HostAttributeToken("title"), { optional: true });
		this.sourceType = inject(new HostAttributeToken("sourceType"), { optional: true });
		this.items = this.store.selectItems(this.sourceType).pipe(distinctUntilChanged(), shareReplay());
		this.selected = this.store.selectSelectedItems(this.sourceType).pipe(distinctUntilChanged(), shareReplay());
		this.numberOfItems$ = this.items.pipe(map((items) => ({ length: items.length })), startWith({ length: 0 }));
		this.selectAllDisabled = this.items.pipe(map((items) => items.length === 0));
		this.items$ = combineLatest([this.items, this.selected]).pipe(map(([items, selected]) => items.map((item) => {
			item.selected = selected.has(item);
			return item;
		})));
		this.instanceId = this.getInstanceId();
		this.onItemsUpdate();
	}
	checkboxSelectionHandler(item) {
		this.store.checkboxSelection(item, this.sourceType);
	}
	checkboxSelectAllHandler(event) {
		const checked = event.target.checked;
		this.store.selectAllSelection(checked, this.sourceType);
	}
	onItemsUpdate() {
		this.items.pipe(takeUntilDestroyed(), skip(1), tap(() => {
			if (this.selectAllCheckboxRef) this.selectAllCheckboxRef.nativeElement.checked = false;
		})).subscribe();
	}
	getInstanceId() {
		return Math.floor(Math.random() * 1e8).toString();
	}
	static {
		this.ɵfac = i0.ɵɵngDeclareFactory({
			minVersion: "12.0.0",
			version: "22.2.1",
			ngImport: i0,
			type: ItTransferListComponent,
			deps: [],
			target: i0.ɵɵFactoryTarget.Component
		});
	}
	static {
		this.ɵcmp = i0.ɵɵngDeclareComponent({
			minVersion: "17.0.0",
			version: "22.2.1",
			type: ItTransferListComponent,
			isStandalone: true,
			selector: "it-transfer-list",
			viewQueries: [{
				propertyName: "selectAllCheckboxRef",
				first: true,
				predicate: ["selectAllCheckbox"],
				descendants: true
			}],
			usesInheritance: true,
			ngImport: i0,
			template: "<div class=\"it-transfer-wrapper source\">\r\n  <div class=\"transfer-header\">\r\n    <div class=\"form-check\">\r\n      <input\r\n        #selectAllCheckbox\r\n        type=\"checkbox\"\r\n        id=\"{{ instanceId }}checkbox{{ title }}\"\r\n        [disabled]=\"selectAllDisabled | async\"\r\n        (click)=\"checkboxSelectAllHandler($event)\" />\r\n      <label for=\"{{ instanceId }}checkbox{{ title }}\">\r\n        <span>\r\n          @if (numberOfItems$ | async; as numberOfItems) {\r\n            <span class=\"num\"> {{ numberOfItems.length }}</span>\r\n            <span> {{ (numberOfItems.length === 1 ? 'it.transfer.item' : 'it.transfer.items') | translate }}</span>\r\n          }\r\n        </span>\r\n        <span class=\"descr\">{{ title | titlecase }}</span>\r\n      </label>\r\n    </div>\r\n    <!-- form check -->\r\n  </div>\r\n  <!-- transfer-header -->\r\n  <div class=\"transfer-scroll\">\r\n    <div class=\"transfer-group\">\r\n      @for (item of items$ | async; track item.value) {\r\n        <div class=\"form-check\">\r\n          <input\r\n            type=\"checkbox\"\r\n            id=\"{{ instanceId }}-{{ item.value }}\"\r\n            [checked]=\"item.selected\"\r\n            (click)=\"checkboxSelectionHandler(item)\" />\r\n          <label for=\"{{ instanceId }}-{{ item.value }}\">\r\n            <span>\r\n              <span>{{ item.text }}</span>\r\n            </span>\r\n          </label>\r\n        </div>\r\n      }\r\n    </div>\r\n  </div>\r\n</div>\r\n<!-- it-transfer-wrapper -->\r\n",
			dependencies: [
				{
					kind: "ngmodule",
					type: TranslateModule
				},
				{
					kind: "pipe",
					type: i1$1.TranslatePipe,
					name: "translate"
				},
				{
					kind: "pipe",
					type: AsyncPipe,
					name: "async"
				},
				{
					kind: "pipe",
					type: TitleCasePipe,
					name: "titlecase"
				}
			],
			changeDetection: i0.ChangeDetectionStrategy.OnPush
		});
	}
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.1",
	ngImport: i0,
	type: ItTransferListComponent,
	decorators: [{
		type: Component,
		args: [{
			selector: "it-transfer-list",
			imports: [
				TranslateModule,
				AsyncPipe,
				TitleCasePipe
			],
			changeDetection: ChangeDetectionStrategy.OnPush,
			template: "<div class=\"it-transfer-wrapper source\">\r\n  <div class=\"transfer-header\">\r\n    <div class=\"form-check\">\r\n      <input\r\n        #selectAllCheckbox\r\n        type=\"checkbox\"\r\n        id=\"{{ instanceId }}checkbox{{ title }}\"\r\n        [disabled]=\"selectAllDisabled | async\"\r\n        (click)=\"checkboxSelectAllHandler($event)\" />\r\n      <label for=\"{{ instanceId }}checkbox{{ title }}\">\r\n        <span>\r\n          @if (numberOfItems$ | async; as numberOfItems) {\r\n            <span class=\"num\"> {{ numberOfItems.length }}</span>\r\n            <span> {{ (numberOfItems.length === 1 ? 'it.transfer.item' : 'it.transfer.items') | translate }}</span>\r\n          }\r\n        </span>\r\n        <span class=\"descr\">{{ title | titlecase }}</span>\r\n      </label>\r\n    </div>\r\n    <!-- form check -->\r\n  </div>\r\n  <!-- transfer-header -->\r\n  <div class=\"transfer-scroll\">\r\n    <div class=\"transfer-group\">\r\n      @for (item of items$ | async; track item.value) {\r\n        <div class=\"form-check\">\r\n          <input\r\n            type=\"checkbox\"\r\n            id=\"{{ instanceId }}-{{ item.value }}\"\r\n            [checked]=\"item.selected\"\r\n            (click)=\"checkboxSelectionHandler(item)\" />\r\n          <label for=\"{{ instanceId }}-{{ item.value }}\">\r\n            <span>\r\n              <span>{{ item.text }}</span>\r\n            </span>\r\n          </label>\r\n        </div>\r\n      }\r\n    </div>\r\n  </div>\r\n</div>\r\n<!-- it-transfer-wrapper -->\r\n"
		}]
	}],
	ctorParameters: () => [],
	propDecorators: { selectAllCheckboxRef: [{
		type: ViewChild,
		args: ["selectAllCheckbox"]
	}] }
});
var ItTransferComponent = class ItTransferComponent extends ItAbstractFormComponent {
	constructor() {
		super(...arguments);
		this._ngControl = inject(NgControl, {
			self: true,
			optional: true
		});
		this._translateService = inject(TranslateService);
		this.store = inject(TransferStore);
		this.options = [];
		this.selected = [];
		this.transferChanges = new EventEmitter();
		this.transferEnabled = this.store.transferEnabled;
		this.backtransferEnabled = this.store.backtransferEnabled;
		this.resetEnabled = this.store.resetEnabled;
		this.destroyRef = inject(DestroyRef);
	}
	ngOnInit() {
		super.ngOnInit();
		this.storeInit();
		this.onStoreValueChanged();
	}
	transferClickHandler(event) {
		this.buttonEventHandler(event, () => this.store.transfer());
	}
	transferKeyPressHandler(event) {
		this.buttonEventHandler(event, () => this.store.transfer());
	}
	backtransferClickHandler(event) {
		this.buttonEventHandler(event, () => this.store.backtransfer());
	}
	backtransferKeyPressHandler(event) {
		this.buttonEventHandler(event, () => this.store.backtransfer());
	}
	resetClickHandler(event) {
		this.buttonEventHandler(event, () => this.store.reset());
	}
	resetKeyPressHandler(event) {
		this.buttonEventHandler(event, () => this.store.reset());
	}
	buttonEventHandler(event, updateStoreCb) {
		event.preventDefault();
		updateStoreCb();
	}
	storeInit() {
		let target = [];
		const ngControl = this._ngControl;
		if (Boolean(this._ngControl)) {
			console.debug("ngControl instanceof NgModel:", ngControl instanceof NgModel);
			console.debug("ngControl instanceof FormControlName:", ngControl instanceof FormControlName);
			if (ngControl instanceof NgModel) {
				console.debug("ngControl instanceof NgModel");
				const model = ngControl.model;
				target = Array.isArray(model) ? model : [];
			}
			if (ngControl instanceof FormControlName) {
				console.debug("ngControl instanceof FormControlName");
				const model = ngControl.control.value;
				target = Array.isArray(model) ? model : [];
			}
			console.debug("ngControl is defined. Input() target will be ignored");
		} else if (this.selected && Array.isArray(this.selected)) target = [...this.selected];
		console.debug("target:", this.selected, "formControl:", this.control.value, "ngModel:", this._ngControl);
		this.store.init({
			source: [...this.options],
			target
		});
	}
	onStoreValueChanged() {
		this.store.valueChanged.pipe(takeUntilDestroyed(this.destroyRef), tap((value) => this.writeValue(value)), tap((value) => this.onChange(value)), tap((value) => this.transferChanges.emit(value))).subscribe();
	}
	static {
		this.ɵfac = i0.ɵɵngDeclareFactory({
			minVersion: "12.0.0",
			version: "22.2.1",
			ngImport: i0,
			type: ItTransferComponent,
			deps: null,
			target: i0.ɵɵFactoryTarget.Component
		});
	}
	static {
		this.ɵcmp = i0.ɵɵngDeclareComponent({
			minVersion: "17.0.0",
			version: "22.2.1",
			type: ItTransferComponent,
			isStandalone: true,
			selector: "it-transfer",
			inputs: {
				options: "options",
				selected: "selected"
			},
			outputs: { transferChanges: "transferChanges" },
			providers: [TransferStore],
			usesInheritance: true,
			ngImport: i0,
			template: "<div>\r\n  @if (label) {\r\n    <label [for]=\"id\" [class.active]=\"!!control.value\">{{ label }}</label>\r\n  }\r\n  <div class=\"row\">\r\n    <div class=\"col-xs-12 col-md-5\">\r\n      <it-transfer-list sourceType=\"source\" [title]=\"'it.transfer.source' | translate\"></it-transfer-list>\r\n    </div>\r\n    <!-- col -->\r\n    <div class=\"col-xs-12 col-md-2\">\r\n      <!-- transfer buttons-->\r\n      <div class=\"it-transfer-buttons\">\r\n        <a\r\n          class=\"transfer\"\r\n          role=\"button\"\r\n          href=\"#\"\r\n          [ngClass]=\"{ active: transferEnabled | async }\"\r\n          (click)=\"transferClickHandler($event)\"\r\n          (keypress)=\"transferKeyPressHandler($event)\"\r\n          [attr.aria-label]=\"'it.transfer.aria-label-move-forward' | translate\">\r\n          <it-icon name=\"arrow-right\"></it-icon>\r\n        </a>\r\n        <span class=\"visually-hidden\">{{ 'it.transfer.label-move-forward' | translate }}</span>\r\n        <a\r\n          class=\"backtransfer\"\r\n          role=\"button\"\r\n          href=\"#\"\r\n          [ngClass]=\"{ active: backtransferEnabled | async }\"\r\n          (click)=\"backtransferClickHandler($event)\"\r\n          (keypress)=\"backtransferKeyPressHandler($event)\"\r\n          [attr.aria-label]=\"'it.transfer.aria-label-move-backward' | translate\">\r\n          <it-icon name=\"arrow-left\"></it-icon>\r\n        </a>\r\n        <span class=\"visually-hidden\">{{ 'it.transfer.label-move-backward' | translate }}</span>\r\n        <a\r\n          class=\"reset\"\r\n          role=\"button\"\r\n          href=\"#\"\r\n          [ngClass]=\"{ active: resetEnabled | async }\"\r\n          (click)=\"resetClickHandler($event)\"\r\n          (keypress)=\"resetKeyPressHandler($event)\"\r\n          [attr.aria-label]=\"'it.transfer.aria-label-reset' | translate\">\r\n          <it-icon name=\"restore\"></it-icon>\r\n        </a>\r\n        <span class=\"visually-hidden\">{{ 'it.transfer.label-reset' | translate }}</span>\r\n      </div>\r\n    </div>\r\n    <div class=\"col-xs-12 col-md-5\">\r\n      <it-transfer-list sourceType=\"target\" [title]=\"'it.transfer.target' | translate\"></it-transfer-list>\r\n    </div>\r\n  </div>\r\n</div>\r\n",
			dependencies: [
				{
					kind: "ngmodule",
					type: TranslateModule
				},
				{
					kind: "component",
					type: ItIconComponent,
					selector: "it-icon",
					inputs: [
						"name",
						"size",
						"color",
						"padded",
						"svgClass",
						"title",
						"labelWaria"
					]
				},
				{
					kind: "component",
					type: ItTransferListComponent,
					selector: "it-transfer-list"
				},
				{
					kind: "directive",
					type: NgClass,
					selector: "[ngClass]",
					inputs: ["class", "ngClass"]
				},
				{
					kind: "ngmodule",
					type: ReactiveFormsModule
				},
				{
					kind: "pipe",
					type: i1$1.TranslatePipe,
					name: "translate"
				},
				{
					kind: "pipe",
					type: AsyncPipe,
					name: "async"
				}
			],
			changeDetection: i0.ChangeDetectionStrategy.OnPush
		});
	}
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.1",
	ngImport: i0,
	type: ItTransferComponent,
	decorators: [{
		type: Component,
		args: [{
			selector: "it-transfer",
			imports: [
				TranslateModule,
				ItIconComponent,
				ItTransferListComponent,
				NgClass,
				AsyncPipe,
				ReactiveFormsModule
			],
			providers: [TransferStore],
			changeDetection: ChangeDetectionStrategy.OnPush,
			template: "<div>\r\n  @if (label) {\r\n    <label [for]=\"id\" [class.active]=\"!!control.value\">{{ label }}</label>\r\n  }\r\n  <div class=\"row\">\r\n    <div class=\"col-xs-12 col-md-5\">\r\n      <it-transfer-list sourceType=\"source\" [title]=\"'it.transfer.source' | translate\"></it-transfer-list>\r\n    </div>\r\n    <!-- col -->\r\n    <div class=\"col-xs-12 col-md-2\">\r\n      <!-- transfer buttons-->\r\n      <div class=\"it-transfer-buttons\">\r\n        <a\r\n          class=\"transfer\"\r\n          role=\"button\"\r\n          href=\"#\"\r\n          [ngClass]=\"{ active: transferEnabled | async }\"\r\n          (click)=\"transferClickHandler($event)\"\r\n          (keypress)=\"transferKeyPressHandler($event)\"\r\n          [attr.aria-label]=\"'it.transfer.aria-label-move-forward' | translate\">\r\n          <it-icon name=\"arrow-right\"></it-icon>\r\n        </a>\r\n        <span class=\"visually-hidden\">{{ 'it.transfer.label-move-forward' | translate }}</span>\r\n        <a\r\n          class=\"backtransfer\"\r\n          role=\"button\"\r\n          href=\"#\"\r\n          [ngClass]=\"{ active: backtransferEnabled | async }\"\r\n          (click)=\"backtransferClickHandler($event)\"\r\n          (keypress)=\"backtransferKeyPressHandler($event)\"\r\n          [attr.aria-label]=\"'it.transfer.aria-label-move-backward' | translate\">\r\n          <it-icon name=\"arrow-left\"></it-icon>\r\n        </a>\r\n        <span class=\"visually-hidden\">{{ 'it.transfer.label-move-backward' | translate }}</span>\r\n        <a\r\n          class=\"reset\"\r\n          role=\"button\"\r\n          href=\"#\"\r\n          [ngClass]=\"{ active: resetEnabled | async }\"\r\n          (click)=\"resetClickHandler($event)\"\r\n          (keypress)=\"resetKeyPressHandler($event)\"\r\n          [attr.aria-label]=\"'it.transfer.aria-label-reset' | translate\">\r\n          <it-icon name=\"restore\"></it-icon>\r\n        </a>\r\n        <span class=\"visually-hidden\">{{ 'it.transfer.label-reset' | translate }}</span>\r\n      </div>\r\n    </div>\r\n    <div class=\"col-xs-12 col-md-5\">\r\n      <it-transfer-list sourceType=\"target\" [title]=\"'it.transfer.target' | translate\"></it-transfer-list>\r\n    </div>\r\n  </div>\r\n</div>\r\n"
		}]
	}],
	propDecorators: {
		options: [{ type: Input }],
		selected: [{ type: Input }],
		transferChanges: [{ type: Output }]
	}
});
var ItAutocompleteComponent = class ItAutocompleteComponent extends ItAbstractFormComponent {
	constructor() {
		super(...arguments);
		this.source = [];
		this.required = false;
		this.minLength = 0;
		this.defaultValue = "";
		this.assistiveHintLabel = () => "Quando i risultati del completamento automatico sono disponibili, usa le frecce su e giù per rivedere e Invio per selezionare. Utenti di dispositivi touch, esplora tramite tocco o con gesti di scorrimento";
		this.noResultsLabel = () => "Nessun risultato trovato";
		this.statusQueryTooShortLabel = (minQueryLength) => `Digita ${minQueryLength} o più caratteri per mostrare le opzioni di ricerca`;
		this.statusNoResultsLabel = () => "Nessun risultato di ricerca";
		this.statusSelectedOptionLabel = (selectedOption, length, index) => `${selectedOption} ${index + 1} di ${length} è sottolineato`;
		this.statusResultsLabel = (length, contentSelectedOption) => {
			const words = {
				result: length === 1 ? "risultato" : "risultati",
				is: length === 1 ? "è" : "sono",
				available: length === 1 ? "disponibile" : "disponibili"
			};
			return `${length} ${words.result} ${words.is} ${words.available}. ${contentSelectedOption}`;
		};
		this.selected = new EventEmitter();
		this.value = "";
		this._interval = 0;
		this._inputEl = null;
	}
	ngOnInit() {
		super.ngOnInit();
		if (!this.control.value && !!this.value) {
			this.writeValue(this.value);
			this.onChange(this.value);
		}
	}
	writeValue(value) {
		super.writeValue(value);
		if (!value && this._inputEl) this.clear();
	}
	clear() {
		this._inputEl.value = "";
	}
	_findInput() {
		this._interval = setInterval(() => {
			this._inputEl = document.getElementById(this.id);
			if (this._inputEl) {
				clearInterval(this._interval);
				this._initInputEl();
			}
		}, 500);
	}
	_setAndCheck(value) {
		this.value = value == "" ? void 0 : value;
		if (this.control.touched) {
			this.writeValue(this.value);
			this.onChange(this.value);
		}
		if (this.isValid == false && this.isInvalid == false) {
			this._inputEl?.classList.remove("just-validate-success-field");
			this._inputEl?.classList.remove("is-invalid");
		} else if (this.isValid == true) {
			this._inputEl?.classList.add("just-validate-success-field");
			this._inputEl?.classList.remove("is-invalid");
		} else if (this.isInvalid == true) {
			this._inputEl?.classList.add("is-invalid");
			this._inputEl?.classList.remove("just-validate-success-field");
		}
	}
	_initInputEl() {
		if (this._inputEl) {
			this._inputEl.onfocus = (ev) => this._setAndCheck(ev.target.value);
			this._inputEl.onblur = (ev) => this._setAndCheck(ev.target.value);
			this._inputEl.oninput = (ev) => {
				this.markAsTouched();
				this._setAndCheck(ev.target.value);
			};
			if (this.label) (this.selectAutocompleteEl?.nativeElement.querySelector("ul[role=\"listbox\"]"))?.setAttribute("aria-labelledby", this.id + "-label");
		}
	}
	ngAfterViewInit() {
		if (this.selectAutocompleteEl) {
			super.ngAfterViewInit();
			const element = this.selectAutocompleteEl.nativeElement;
			this.selectAutocomplete = new SelectAutocomplete(element, {
				id: this.id,
				name: this.name || this.id,
				source: this.source,
				required: this.required,
				minLength: this.minLength,
				defaultValue: this.defaultValue,
				tAssistiveHint: this.assistiveHintLabel,
				tNoResults: this.noResultsLabel,
				tStatusQueryTooShort: this.statusQueryTooShortLabel,
				tStatusNoResults: this.statusNoResultsLabel,
				tStatusSelectedOption: this.statusSelectedOptionLabel,
				tStatusResults: this.statusResultsLabel,
				onConfirm: (selectedElement) => {
					this.markAsTouched();
					this._setAndCheck(selectedElement);
					this.selected.emit(selectedElement);
				}
			});
			this._findInput();
		}
	}
	static {
		this.ɵfac = i0.ɵɵngDeclareFactory({
			minVersion: "12.0.0",
			version: "22.2.1",
			ngImport: i0,
			type: ItAutocompleteComponent,
			deps: null,
			target: i0.ɵɵFactoryTarget.Component
		});
	}
	static {
		this.ɵcmp = i0.ɵɵngDeclareComponent({
			minVersion: "17.0.0",
			version: "22.2.1",
			type: ItAutocompleteComponent,
			isStandalone: true,
			selector: "it-autocomplete",
			inputs: {
				source: "source",
				required: "required",
				name: "name",
				description: "description",
				minLength: "minLength",
				defaultValue: "defaultValue",
				assistiveHintLabel: "assistiveHintLabel",
				noResultsLabel: "noResultsLabel",
				statusQueryTooShortLabel: "statusQueryTooShortLabel",
				statusNoResultsLabel: "statusNoResultsLabel",
				statusSelectedOptionLabel: "statusSelectedOptionLabel",
				statusResultsLabel: "statusResultsLabel"
			},
			outputs: { selected: "selected" },
			viewQueries: [{
				propertyName: "selectAutocompleteEl",
				first: true,
				predicate: ["selectAutocomplete"],
				descendants: true
			}],
			usesInheritance: true,
			ngImport: i0,
			template: "<div class=\"form-group\">\r\n  @if (label) {\r\n    <label [for]=\"id\" [id]=\"id + '-label'\" [class.active]=\"!!control.value\">{{ label }}</label>\r\n  }\r\n  <div #selectAutocomplete name=\"region\" [id]=\"id + 'Wrapper'\" class=\"autocomplete-wrapper\"></div>\r\n\r\n  @if (description) {\r\n    <small [id]=\"id + '-description'\" class=\"form-text\">{{ description }}</small>\r\n  }\r\n  @if (isInvalid) {\r\n    <div class=\"form-feedback just-validate-error-label\" [id]=\"id + '-error'\">\r\n      <div #customError><ng-content select=\"[error]\"></ng-content></div>\r\n      @if (!customError.hasChildNodes()) {\r\n        {{ invalidMessage | async }}\r\n      }\r\n    </div>\r\n  }\r\n</div>\r\n",
			dependencies: [{
				kind: "ngmodule",
				type: ReactiveFormsModule
			}, {
				kind: "pipe",
				type: AsyncPipe,
				name: "async"
			}],
			changeDetection: i0.ChangeDetectionStrategy.OnPush
		});
	}
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.1",
	ngImport: i0,
	type: ItAutocompleteComponent,
	decorators: [{
		type: Component,
		args: [{
			selector: "it-autocomplete",
			changeDetection: ChangeDetectionStrategy.OnPush,
			imports: [ReactiveFormsModule, AsyncPipe],
			template: "<div class=\"form-group\">\r\n  @if (label) {\r\n    <label [for]=\"id\" [id]=\"id + '-label'\" [class.active]=\"!!control.value\">{{ label }}</label>\r\n  }\r\n  <div #selectAutocomplete name=\"region\" [id]=\"id + 'Wrapper'\" class=\"autocomplete-wrapper\"></div>\r\n\r\n  @if (description) {\r\n    <small [id]=\"id + '-description'\" class=\"form-text\">{{ description }}</small>\r\n  }\r\n  @if (isInvalid) {\r\n    <div class=\"form-feedback just-validate-error-label\" [id]=\"id + '-error'\">\r\n      <div #customError><ng-content select=\"[error]\"></ng-content></div>\r\n      @if (!customError.hasChildNodes()) {\r\n        {{ invalidMessage | async }}\r\n      }\r\n    </div>\r\n  }\r\n</div>\r\n"
		}]
	}],
	propDecorators: {
		source: [{ type: Input }],
		required: [{ type: Input }],
		name: [{ type: Input }],
		description: [{ type: Input }],
		minLength: [{ type: Input }],
		defaultValue: [{ type: Input }],
		assistiveHintLabel: [{ type: Input }],
		noResultsLabel: [{ type: Input }],
		statusQueryTooShortLabel: [{ type: Input }],
		statusNoResultsLabel: [{ type: Input }],
		statusSelectedOptionLabel: [{ type: Input }],
		statusResultsLabel: [{ type: Input }],
		selected: [{ type: Output }],
		selectAutocompleteEl: [{
			type: ViewChild,
			args: ["selectAutocomplete"]
		}]
	}
});
const formComponents = [
	ItAutocompleteComponent,
	ItSearchComponent,
	ItCheckboxComponent,
	ItInputComponent,
	ItPasswordInputComponent,
	ItRadioButtonComponent,
	ItRangeComponent,
	ItRatingComponent,
	ItSelectComponent,
	ItTextareaComponent,
	ItTransferComponent,
	ItUploadDragDropComponent,
	ItUploadFileListComponent
];
var ItFormModule = class ItFormModule {
	static {
		this.ɵfac = i0.ɵɵngDeclareFactory({
			minVersion: "12.0.0",
			version: "22.2.1",
			ngImport: i0,
			type: ItFormModule,
			deps: [],
			target: i0.ɵɵFactoryTarget.NgModule
		});
	}
	static {
		this.ɵmod = i0.ɵɵngDeclareNgModule({
			minVersion: "14.0.0",
			version: "22.2.1",
			ngImport: i0,
			type: ItFormModule,
			imports: [
				ItAutocompleteComponent,
				ItSearchComponent,
				ItCheckboxComponent,
				ItInputComponent,
				ItPasswordInputComponent,
				ItRadioButtonComponent,
				ItRangeComponent,
				ItRatingComponent,
				ItSelectComponent,
				ItTextareaComponent,
				ItTransferComponent,
				ItUploadDragDropComponent,
				ItUploadFileListComponent
			],
			exports: [
				ItAutocompleteComponent,
				ItSearchComponent,
				ItCheckboxComponent,
				ItInputComponent,
				ItPasswordInputComponent,
				ItRadioButtonComponent,
				ItRangeComponent,
				ItRatingComponent,
				ItSelectComponent,
				ItTextareaComponent,
				ItTransferComponent,
				ItUploadDragDropComponent,
				ItUploadFileListComponent
			]
		});
	}
	static {
		this.ɵinj = i0.ɵɵngDeclareInjector({
			minVersion: "12.0.0",
			version: "22.2.1",
			ngImport: i0,
			type: ItFormModule,
			imports: [formComponents]
		});
	}
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.1",
	ngImport: i0,
	type: ItFormModule,
	decorators: [{
		type: NgModule,
		args: [{
			imports: formComponents,
			exports: formComponents
		}]
	}]
});
var ItBackButtonComponent = class ItBackButtonComponent {
	constructor() {
		this._location = inject(Location);
		this.buttonStyle = "button";
		this.direction = "left";
		this.showIcon = true;
		this.showText = true;
	}
	goBack(event) {
		event.preventDefault();
		if (this.backFn) return this.backFn(this._location);
		this._location.back();
	}
	static {
		this.ɵfac = i0.ɵɵngDeclareFactory({
			minVersion: "12.0.0",
			version: "22.2.1",
			ngImport: i0,
			type: ItBackButtonComponent,
			deps: [],
			target: i0.ɵɵFactoryTarget.Component
		});
	}
	static {
		this.ɵcmp = i0.ɵɵngDeclareComponent({
			minVersion: "17.0.0",
			version: "22.2.1",
			type: ItBackButtonComponent,
			isStandalone: true,
			selector: "it-back-button",
			inputs: {
				buttonStyle: "buttonStyle",
				direction: "direction",
				showIcon: [
					"showIcon",
					"showIcon",
					inputToBoolean
				],
				showText: [
					"showText",
					"showText",
					inputToBoolean
				],
				backFn: "backFn"
			},
			exportAs: ["itBackButton"],
			ngImport: i0,
			template: "@if (buttonStyle === 'link') {\r\n  <a href=\"#\" class=\"go-back\" (click)=\"goBack($event)\">\r\n    <ng-container *ngTemplateOutlet=\"content\"></ng-container>\r\n  </a>\r\n}\r\n\r\n@if (buttonStyle === 'button') {\r\n  <button itButton=\"primary\" class=\"go-back\" (click)=\"goBack($event)\">\r\n    <ng-container *ngTemplateOutlet=\"content\"></ng-container>\r\n  </button>\r\n}\r\n\r\n<ng-template #content>\r\n  @if (showIcon) {\r\n    <it-icon\r\n      size=\"sm\"\r\n      [name]=\"direction === 'left' ? 'arrow-left' : 'arrow-up'\"\r\n      [color]=\"buttonStyle === 'link' ? 'primary' : 'white'\"\r\n      [class.me-2]=\"showText\"></it-icon>\r\n  }\r\n\r\n  <span [class.visually-hidden]=\"!showText\">\r\n    {{ (direction === 'left' ? 'it.navigation.go-back' : 'it.navigation.upper-level') | translate }}\r\n  </span>\r\n</ng-template>\r\n",
			dependencies: [
				{
					kind: "directive",
					type: NgTemplateOutlet,
					selector: "[ngTemplateOutlet]",
					inputs: [
						"ngTemplateOutletContext",
						"ngTemplateOutlet",
						"ngTemplateOutletInjector"
					]
				},
				{
					kind: "directive",
					type: ItButtonDirective,
					selector: "[itButton]",
					inputs: [
						"itButton",
						"size",
						"block",
						"disabled",
						"type"
					],
					exportAs: ["itButton"]
				},
				{
					kind: "component",
					type: ItIconComponent,
					selector: "it-icon",
					inputs: [
						"name",
						"size",
						"color",
						"padded",
						"svgClass",
						"title",
						"labelWaria"
					]
				},
				{
					kind: "ngmodule",
					type: TranslateModule
				},
				{
					kind: "pipe",
					type: i1$1.TranslatePipe,
					name: "translate"
				}
			],
			changeDetection: i0.ChangeDetectionStrategy.OnPush
		});
	}
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.1",
	ngImport: i0,
	type: ItBackButtonComponent,
	decorators: [{
		type: Component,
		args: [{
			selector: "it-back-button",
			exportAs: "itBackButton",
			changeDetection: ChangeDetectionStrategy.OnPush,
			imports: [
				NgTemplateOutlet,
				ItButtonDirective,
				ItIconComponent,
				TranslateModule
			],
			template: "@if (buttonStyle === 'link') {\r\n  <a href=\"#\" class=\"go-back\" (click)=\"goBack($event)\">\r\n    <ng-container *ngTemplateOutlet=\"content\"></ng-container>\r\n  </a>\r\n}\r\n\r\n@if (buttonStyle === 'button') {\r\n  <button itButton=\"primary\" class=\"go-back\" (click)=\"goBack($event)\">\r\n    <ng-container *ngTemplateOutlet=\"content\"></ng-container>\r\n  </button>\r\n}\r\n\r\n<ng-template #content>\r\n  @if (showIcon) {\r\n    <it-icon\r\n      size=\"sm\"\r\n      [name]=\"direction === 'left' ? 'arrow-left' : 'arrow-up'\"\r\n      [color]=\"buttonStyle === 'link' ? 'primary' : 'white'\"\r\n      [class.me-2]=\"showText\"></it-icon>\r\n  }\r\n\r\n  <span [class.visually-hidden]=\"!showText\">\r\n    {{ (direction === 'left' ? 'it.navigation.go-back' : 'it.navigation.upper-level') | translate }}\r\n  </span>\r\n</ng-template>\r\n"
		}]
	}],
	propDecorators: {
		buttonStyle: [{ type: Input }],
		direction: [{ type: Input }],
		showIcon: [{
			type: Input,
			args: [{ transform: inputToBoolean }]
		}],
		showText: [{
			type: Input,
			args: [{ transform: inputToBoolean }]
		}],
		backFn: [{ type: Input }]
	}
});
var ItBackToTopComponent = class ItBackToTopComponent extends ItAbstractComponent {
	constructor() {
		super(...arguments);
		this.ariaLabel = "Torna su";
	}
	ngAfterViewInit() {
		super.ngAfterViewInit();
		if (this.backToTopElement) {
			const element = this.backToTopElement.nativeElement;
			this.backToTop = BackToTop.getOrCreateInstance(element);
		}
	}
	show() {
		this.backToTop?.show();
	}
	hide() {
		this.backToTop?.hide();
	}
	scrollToTop() {
		this.backToTop?.scrollToTop();
	}
	dispose() {
		this.backToTop?.dispose();
	}
	static {
		this.ɵfac = i0.ɵɵngDeclareFactory({
			minVersion: "12.0.0",
			version: "22.2.1",
			ngImport: i0,
			type: ItBackToTopComponent,
			deps: null,
			target: i0.ɵɵFactoryTarget.Component
		});
	}
	static {
		this.ɵcmp = i0.ɵɵngDeclareComponent({
			minVersion: "16.1.0",
			version: "22.2.1",
			type: ItBackToTopComponent,
			isStandalone: true,
			selector: "it-back-to-top",
			inputs: {
				ariaLabel: "ariaLabel",
				small: [
					"small",
					"small",
					inputToBoolean
				],
				shadow: [
					"shadow",
					"shadow",
					inputToBoolean
				],
				dark: [
					"dark",
					"dark",
					inputToBoolean
				]
			},
			viewQueries: [{
				propertyName: "backToTopElement",
				first: true,
				predicate: ["backToTop"],
				descendants: true
			}],
			exportAs: ["itBackToTop"],
			usesInheritance: true,
			ngImport: i0,
			template: "<a\r\n  #backToTop\r\n  [id]=\"id\"\r\n  href=\"#\"\r\n  [attr.aria-label]=\"ariaLabel\"\r\n  class=\"back-to-top\"\r\n  [class.back-to-top-small]=\"small\"\r\n  [class.shadow]=\"shadow\"\r\n  [class.dark]=\"dark\">\r\n  <it-icon name=\"arrow-up\" [color]=\"dark ? 'secondary' : 'light'\"></it-icon>\r\n</a>\r\n",
			dependencies: [{
				kind: "component",
				type: ItIconComponent,
				selector: "it-icon",
				inputs: [
					"name",
					"size",
					"color",
					"padded",
					"svgClass",
					"title",
					"labelWaria"
				]
			}],
			changeDetection: i0.ChangeDetectionStrategy.OnPush
		});
	}
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.1",
	ngImport: i0,
	type: ItBackToTopComponent,
	decorators: [{
		type: Component,
		args: [{
			selector: "it-back-to-top",
			exportAs: "itBackToTop",
			changeDetection: ChangeDetectionStrategy.OnPush,
			imports: [ItIconComponent],
			template: "<a\r\n  #backToTop\r\n  [id]=\"id\"\r\n  href=\"#\"\r\n  [attr.aria-label]=\"ariaLabel\"\r\n  class=\"back-to-top\"\r\n  [class.back-to-top-small]=\"small\"\r\n  [class.shadow]=\"shadow\"\r\n  [class.dark]=\"dark\">\r\n  <it-icon name=\"arrow-up\" [color]=\"dark ? 'secondary' : 'light'\"></it-icon>\r\n</a>\r\n"
		}]
	}],
	propDecorators: {
		ariaLabel: [{ type: Input }],
		small: [{
			type: Input,
			args: [{ transform: inputToBoolean }]
		}],
		shadow: [{
			type: Input,
			args: [{ transform: inputToBoolean }]
		}],
		dark: [{
			type: Input,
			args: [{ transform: inputToBoolean }]
		}],
		backToTopElement: [{
			type: ViewChild,
			args: ["backToTop"]
		}]
	}
});
var ItBreadcrumbItemComponent = class ItBreadcrumbItemComponent extends ItLinkComponent {
	static {
		this.ɵfac = i0.ɵɵngDeclareFactory({
			minVersion: "12.0.0",
			version: "22.2.1",
			ngImport: i0,
			type: ItBreadcrumbItemComponent,
			deps: null,
			target: i0.ɵɵFactoryTarget.Component
		});
	}
	static {
		this.ɵcmp = i0.ɵɵngDeclareComponent({
			minVersion: "16.1.0",
			version: "22.2.1",
			type: ItBreadcrumbItemComponent,
			isStandalone: true,
			selector: "it-breadcrumb-item",
			inputs: {
				active: [
					"active",
					"active",
					inputToBoolean
				],
				iconName: "iconName"
			},
			viewQueries: [{
				propertyName: "htmlContent",
				first: true,
				predicate: TemplateRef,
				descendants: true
			}],
			usesInheritance: true,
			ngImport: i0,
			template: "<ng-template>\r\n  <ng-content></ng-content>\r\n</ng-template>\r\n",
			changeDetection: i0.ChangeDetectionStrategy.OnPush
		});
	}
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.1",
	ngImport: i0,
	type: ItBreadcrumbItemComponent,
	decorators: [{
		type: Component,
		args: [{
			selector: "it-breadcrumb-item",
			changeDetection: ChangeDetectionStrategy.OnPush,
			imports: [],
			template: "<ng-template>\r\n  <ng-content></ng-content>\r\n</ng-template>\r\n"
		}]
	}],
	propDecorators: {
		active: [{
			type: Input,
			args: [{ transform: inputToBoolean }]
		}],
		iconName: [{ type: Input }],
		htmlContent: [{
			type: ViewChild,
			args: [TemplateRef]
		}]
	}
});
var ItBreadcrumbComponent = class ItBreadcrumbComponent {
	constructor() {
		this._changeDetectorRef = inject(ChangeDetectorRef);
		this.separator = "/";
	}
	ngAfterViewInit() {
		this.items?.changes.pipe(startWith(void 0)).subscribe(() => {
			this.itemSubscriptions?.forEach((sub) => sub.unsubscribe());
			this.itemSubscriptions = this.items?.map((item) => item.valueChanges.subscribe(() => {
				this._changeDetectorRef.detectChanges();
			}));
			this._changeDetectorRef.detectChanges();
		});
	}
	ngOnDestroy() {
		this.itemSubscriptions?.forEach((item) => item.unsubscribe());
	}
	static {
		this.ɵfac = i0.ɵɵngDeclareFactory({
			minVersion: "12.0.0",
			version: "22.2.1",
			ngImport: i0,
			type: ItBreadcrumbComponent,
			deps: [],
			target: i0.ɵɵFactoryTarget.Component
		});
	}
	static {
		this.ɵcmp = i0.ɵɵngDeclareComponent({
			minVersion: "17.0.0",
			version: "22.2.1",
			type: ItBreadcrumbComponent,
			isStandalone: true,
			selector: "it-breadcrumb",
			inputs: {
				separator: "separator",
				dark: [
					"dark",
					"dark",
					inputToBoolean
				]
			},
			queries: [{
				propertyName: "items",
				predicate: ItBreadcrumbItemComponent
			}],
			ngImport: i0,
			template: "<nav class=\"breadcrumb-container\" [attr.aria-label]=\"'it.navigation.navigation-path' | translate\">\r\n  @if (items) {\r\n    <ol class=\"breadcrumb\" [class.dark]=\"dark\" [class.px-3]=\"dark\">\r\n      @for (item of items; track item; let isLast = $last) {\r\n        <li class=\"breadcrumb-item\" [class.active]=\"item.active\" [attr.aria-current]=\"item.active ? 'page' : null\">\r\n          @if (item.iconName) {\r\n            <it-icon [name]=\"item.iconName\" [color]=\"dark ? 'white' : 'secondary'\" size=\"sm\" svgClass=\"align-top me-1\"></it-icon>\r\n          }\r\n          @if (!item.active && !isLast) {\r\n            <it-link [href]=\"item.href\" [class]=\"item.class\" [externalLink]=\"item.externalLink\" [disabled]=\"item.disabled\">\r\n              <ng-container *ngTemplateOutlet=\"item.htmlContent\"></ng-container>\r\n            </it-link>\r\n          } @else {\r\n            <ng-container *ngTemplateOutlet=\"item.htmlContent\"></ng-container>\r\n          }\r\n          @if (!isLast) {\r\n            <span class=\"separator\">{{ separator }}</span>\r\n          }\r\n        </li>\r\n      }\r\n    </ol>\r\n  }\r\n</nav>\r\n",
			dependencies: [
				{
					kind: "ngmodule",
					type: TranslateModule
				},
				{
					kind: "component",
					type: ItIconComponent,
					selector: "it-icon",
					inputs: [
						"name",
						"size",
						"color",
						"padded",
						"svgClass",
						"title",
						"labelWaria"
					]
				},
				{
					kind: "component",
					type: ItLinkComponent,
					selector: "it-link",
					inputs: [
						"href",
						"externalLink",
						"disabled",
						"class"
					]
				},
				{
					kind: "directive",
					type: NgTemplateOutlet,
					selector: "[ngTemplateOutlet]",
					inputs: [
						"ngTemplateOutletContext",
						"ngTemplateOutlet",
						"ngTemplateOutletInjector"
					]
				},
				{
					kind: "pipe",
					type: i1$1.TranslatePipe,
					name: "translate"
				}
			],
			changeDetection: i0.ChangeDetectionStrategy.OnPush
		});
	}
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.1",
	ngImport: i0,
	type: ItBreadcrumbComponent,
	decorators: [{
		type: Component,
		args: [{
			selector: "it-breadcrumb",
			changeDetection: ChangeDetectionStrategy.OnPush,
			imports: [
				TranslateModule,
				ItIconComponent,
				ItLinkComponent,
				NgTemplateOutlet
			],
			template: "<nav class=\"breadcrumb-container\" [attr.aria-label]=\"'it.navigation.navigation-path' | translate\">\r\n  @if (items) {\r\n    <ol class=\"breadcrumb\" [class.dark]=\"dark\" [class.px-3]=\"dark\">\r\n      @for (item of items; track item; let isLast = $last) {\r\n        <li class=\"breadcrumb-item\" [class.active]=\"item.active\" [attr.aria-current]=\"item.active ? 'page' : null\">\r\n          @if (item.iconName) {\r\n            <it-icon [name]=\"item.iconName\" [color]=\"dark ? 'white' : 'secondary'\" size=\"sm\" svgClass=\"align-top me-1\"></it-icon>\r\n          }\r\n          @if (!item.active && !isLast) {\r\n            <it-link [href]=\"item.href\" [class]=\"item.class\" [externalLink]=\"item.externalLink\" [disabled]=\"item.disabled\">\r\n              <ng-container *ngTemplateOutlet=\"item.htmlContent\"></ng-container>\r\n            </it-link>\r\n          } @else {\r\n            <ng-container *ngTemplateOutlet=\"item.htmlContent\"></ng-container>\r\n          }\r\n          @if (!isLast) {\r\n            <span class=\"separator\">{{ separator }}</span>\r\n          }\r\n        </li>\r\n      }\r\n    </ol>\r\n  }\r\n</nav>\r\n"
		}]
	}],
	propDecorators: {
		separator: [{ type: Input }],
		dark: [{
			type: Input,
			args: [{ transform: inputToBoolean }]
		}],
		items: [{
			type: ContentChildren,
			args: [ItBreadcrumbItemComponent]
		}]
	}
});
const breadcrumb = [ItBreadcrumbComponent, ItBreadcrumbItemComponent];
var ItBreadcrumbsModule = class ItBreadcrumbsModule {
	static {
		this.ɵfac = i0.ɵɵngDeclareFactory({
			minVersion: "12.0.0",
			version: "22.2.1",
			ngImport: i0,
			type: ItBreadcrumbsModule,
			deps: [],
			target: i0.ɵɵFactoryTarget.NgModule
		});
	}
	static {
		this.ɵmod = i0.ɵɵngDeclareNgModule({
			minVersion: "14.0.0",
			version: "22.2.1",
			ngImport: i0,
			type: ItBreadcrumbsModule,
			imports: [ItBreadcrumbComponent, ItBreadcrumbItemComponent],
			exports: [ItBreadcrumbComponent, ItBreadcrumbItemComponent]
		});
	}
	static {
		this.ɵinj = i0.ɵɵngDeclareInjector({
			minVersion: "12.0.0",
			version: "22.2.1",
			ngImport: i0,
			type: ItBreadcrumbsModule,
			imports: [ItBreadcrumbComponent]
		});
	}
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.1",
	ngImport: i0,
	type: ItBreadcrumbsModule,
	decorators: [{
		type: NgModule,
		args: [{
			imports: breadcrumb,
			exports: breadcrumb
		}]
	}]
});
var ItNavBarComponent = class ItNavBarComponent {
	constructor() {
		this.expand = true;
	}
	ngAfterViewInit() {
		if (this.collapseButton && this.collapseView?.nativeElement != void 0) setTimeout(() => {
			this.navbar = NavBarCollapsible.getOrCreateInstance(this.collapseView.nativeElement);
		}, 300);
	}
	get isOpen() {
		return this.navbar?._isShown;
	}
	open() {
		this.navbar?.show(this.collapseButton?.nativeElement);
	}
	close() {
		this.navbar?.hide();
	}
	toggleCollapse() {
		this.navbar?.toggle(this.collapseButton?.nativeElement);
	}
	static {
		this.ɵfac = i0.ɵɵngDeclareFactory({
			minVersion: "12.0.0",
			version: "22.2.1",
			ngImport: i0,
			type: ItNavBarComponent,
			deps: [],
			target: i0.ɵɵFactoryTarget.Component
		});
	}
	static {
		this.ɵcmp = i0.ɵɵngDeclareComponent({
			minVersion: "16.1.0",
			version: "22.2.1",
			type: ItNavBarComponent,
			isStandalone: true,
			selector: "it-navbar",
			inputs: {
				megamenu: [
					"megamenu",
					"megamenu",
					inputToBoolean
				],
				expand: [
					"expand",
					"expand",
					inputToBoolean
				]
			},
			viewQueries: [{
				propertyName: "collapseButton",
				first: true,
				predicate: ["collapseButton"],
				descendants: true
			}, {
				propertyName: "collapseView",
				first: true,
				predicate: ["collapseView"],
				descendants: true
			}],
			ngImport: i0,
			template: "<nav\r\n  class=\"navbar\"\r\n  [class.navbar-expand-lg]=\"expand\"\r\n  [class.has-megamenu]=\"megamenu\"\r\n  [attr.aria-label]=\"'it.navbar.aria-label-main' | translate\">\r\n  <button\r\n    (click)=\"toggleCollapse()\"\r\n    #collapseButton\r\n    class=\"custom-navbar-toggler\"\r\n    type=\"button\"\r\n    [attr.aria-label]=\"'it.navbar.aria-label-toggle' | translate\">\r\n    <it-icon name=\"burger\"></it-icon>\r\n  </button>\r\n  <div #collapseView class=\"navbar-collapsable\" tabindex=\"-1\">\r\n    <div class=\"close-div\">\r\n      <button class=\"btn close-menu\" type=\"button\">\r\n        <span class=\"visually-hidden\">{{ 'it.navbar.hide' | translate }}</span>\r\n        <it-icon name=\"close-big\"></it-icon>\r\n      </button>\r\n    </div>\r\n    <div class=\"menu-wrapper\">\r\n      <ul class=\"navbar-nav\">\r\n        <ng-content select=\"[navItems]\"></ng-content>\r\n      </ul>\r\n    </div>\r\n  </div>\r\n</nav>\r\n",
			dependencies: [
				{
					kind: "ngmodule",
					type: TranslateModule
				},
				{
					kind: "component",
					type: ItIconComponent,
					selector: "it-icon",
					inputs: [
						"name",
						"size",
						"color",
						"padded",
						"svgClass",
						"title",
						"labelWaria"
					]
				},
				{
					kind: "pipe",
					type: i1$1.TranslatePipe,
					name: "translate"
				}
			],
			changeDetection: i0.ChangeDetectionStrategy.OnPush
		});
	}
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.1",
	ngImport: i0,
	type: ItNavBarComponent,
	decorators: [{
		type: Component,
		args: [{
			selector: "it-navbar",
			changeDetection: ChangeDetectionStrategy.OnPush,
			imports: [TranslateModule, ItIconComponent],
			template: "<nav\r\n  class=\"navbar\"\r\n  [class.navbar-expand-lg]=\"expand\"\r\n  [class.has-megamenu]=\"megamenu\"\r\n  [attr.aria-label]=\"'it.navbar.aria-label-main' | translate\">\r\n  <button\r\n    (click)=\"toggleCollapse()\"\r\n    #collapseButton\r\n    class=\"custom-navbar-toggler\"\r\n    type=\"button\"\r\n    [attr.aria-label]=\"'it.navbar.aria-label-toggle' | translate\">\r\n    <it-icon name=\"burger\"></it-icon>\r\n  </button>\r\n  <div #collapseView class=\"navbar-collapsable\" tabindex=\"-1\">\r\n    <div class=\"close-div\">\r\n      <button class=\"btn close-menu\" type=\"button\">\r\n        <span class=\"visually-hidden\">{{ 'it.navbar.hide' | translate }}</span>\r\n        <it-icon name=\"close-big\"></it-icon>\r\n      </button>\r\n    </div>\r\n    <div class=\"menu-wrapper\">\r\n      <ul class=\"navbar-nav\">\r\n        <ng-content select=\"[navItems]\"></ng-content>\r\n      </ul>\r\n    </div>\r\n  </div>\r\n</nav>\r\n"
		}]
	}],
	propDecorators: {
		megamenu: [{
			type: Input,
			args: [{ transform: inputToBoolean }]
		}],
		expand: [{
			type: Input,
			args: [{ transform: inputToBoolean }]
		}],
		collapseButton: [{
			type: ViewChild,
			args: ["collapseButton"]
		}],
		collapseView: [{
			type: ViewChild,
			args: ["collapseView"]
		}]
	}
});
var ItNavBarItemComponent = class ItNavBarItemComponent {
	static {
		this.ɵfac = i0.ɵɵngDeclareFactory({
			minVersion: "12.0.0",
			version: "22.2.1",
			ngImport: i0,
			type: ItNavBarItemComponent,
			deps: [],
			target: i0.ɵɵFactoryTarget.Component
		});
	}
	static {
		this.ɵcmp = i0.ɵɵngDeclareComponent({
			minVersion: "14.0.0",
			version: "22.2.1",
			type: ItNavBarItemComponent,
			isStandalone: true,
			selector: "it-navbar-item",
			ngImport: i0,
			template: "<li class=\"nav-item\">\r\n  <ng-content></ng-content>\r\n</li>\r\n",
			changeDetection: i0.ChangeDetectionStrategy.OnPush
		});
	}
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.1",
	ngImport: i0,
	type: ItNavBarItemComponent,
	decorators: [{
		type: Component,
		args: [{
			selector: "it-navbar-item",
			changeDetection: ChangeDetectionStrategy.OnPush,
			imports: [],
			template: "<li class=\"nav-item\">\r\n  <ng-content></ng-content>\r\n</li>\r\n"
		}]
	}]
});
const navbarComponents = [ItNavBarComponent, ItNavBarItemComponent];
var ItNavBarModule = class ItNavBarModule {
	static {
		this.ɵfac = i0.ɵɵngDeclareFactory({
			minVersion: "12.0.0",
			version: "22.2.1",
			ngImport: i0,
			type: ItNavBarModule,
			deps: [],
			target: i0.ɵɵFactoryTarget.NgModule
		});
	}
	static {
		this.ɵmod = i0.ɵɵngDeclareNgModule({
			minVersion: "14.0.0",
			version: "22.2.1",
			ngImport: i0,
			type: ItNavBarModule,
			imports: [ItNavBarComponent, ItNavBarItemComponent],
			exports: [ItNavBarComponent, ItNavBarItemComponent]
		});
	}
	static {
		this.ɵinj = i0.ɵɵngDeclareInjector({
			minVersion: "12.0.0",
			version: "22.2.1",
			ngImport: i0,
			type: ItNavBarModule,
			imports: [ItNavBarComponent]
		});
	}
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.1",
	ngImport: i0,
	type: ItNavBarModule,
	decorators: [{
		type: NgModule,
		args: [{
			imports: navbarComponents,
			exports: navbarComponents
		}]
	}]
});
var ItHeaderComponent = class ItHeaderComponent {
	constructor() {
		this.showSlim = true;
		this.smallHeader = true;
		this.showSearch = true;
		this.idCollapsable = "menuCollapsable";
		this.slimTitleLink = "#";
		this.loginStyle = "none";
		this.expand = true;
		this.router = inject(Router);
		this.cdr = inject(ChangeDetectorRef);
		this.loginClick = new EventEmitter();
		this.searchClick = new EventEmitter();
		this.router.events.pipe(filter((e) => e instanceof NavigationEnd), takeUntilDestroyed()).subscribe(() => {
			this.closeNavBar();
			this.cdr.detectChanges();
		});
	}
	ngAfterViewInit() {
		this.updateListeners();
	}
	ngOnChanges(changes) {
		if (changes["sticky"] && changes["sticky"].currentValue == true && !changes["sticky"].firstChange) this.updateListeners();
		if (changes["sticky"] && changes["sticky"].currentValue == false) {
			this.stickyHeader?._elementObj?._unsetSticky();
			this.stickyHeader?._elementObj?.dispose();
			delete this.stickyHeader;
			this.stickyHeader = void 0;
		}
	}
	updateListeners() {
		if (!this.stickyHeader && this.headerWrapper?.nativeElement != void 0 && this.sticky) setTimeout(() => {
			this.stickyHeader = new HeaderSticky(this.headerWrapper.nativeElement);
		}, 300);
	}
	openNavBar() {
		this.itNavBarComponent?.open();
	}
	closeNavBar() {
		this.itNavBarComponent?.close();
	}
	emitLoginClick(event) {
		event.preventDefault();
		this.loginClick.emit(event);
	}
	emitSearchClick(event) {
		event.preventDefault();
		this.searchClick.emit(event);
	}
	toggleCollapse() {
		this.itNavBarComponent?.toggleCollapse();
	}
	static {
		this.ɵfac = i0.ɵɵngDeclareFactory({
			minVersion: "12.0.0",
			version: "22.2.1",
			ngImport: i0,
			type: ItHeaderComponent,
			deps: [],
			target: i0.ɵɵFactoryTarget.Component
		});
	}
	static {
		this.ɵcmp = i0.ɵɵngDeclareComponent({
			minVersion: "17.0.0",
			version: "22.2.1",
			type: ItHeaderComponent,
			isStandalone: true,
			selector: "it-header",
			inputs: {
				light: [
					"light",
					"light",
					inputToBoolean
				],
				sticky: [
					"sticky",
					"sticky",
					inputToBoolean
				],
				showSlim: [
					"showSlim",
					"showSlim",
					inputToBoolean
				],
				smallHeader: [
					"smallHeader",
					"smallHeader",
					inputToBoolean
				],
				showSearch: [
					"showSearch",
					"showSearch",
					inputToBoolean
				],
				idCollapsable: "idCollapsable",
				slimTitle: "slimTitle",
				slimTitleLink: "slimTitleLink",
				loginStyle: "loginStyle",
				megamenu: [
					"megamenu",
					"megamenu",
					inputToBoolean
				],
				expand: [
					"expand",
					"expand",
					inputToBoolean
				]
			},
			outputs: {
				loginClick: "loginClick",
				searchClick: "searchClick"
			},
			viewQueries: [{
				propertyName: "headerWrapper",
				first: true,
				predicate: ["headerWrapper"],
				descendants: true
			}, {
				propertyName: "itNavBarComponent",
				first: true,
				predicate: ItNavBarComponent,
				descendants: true
			}],
			usesOnChanges: true,
			ngImport: i0,
			template: "<header\r\n  #headerWrapper\r\n  class=\"it-header-wrapper\"\r\n  [class.it-header-sticky]=\"sticky\"\r\n  data-bs-position-type=\"fixed\"\r\n  data-bs-sticky-class-name=\"is-sticky\"\r\n  data-bs-target=\"#header-nav-wrapper\">\r\n  @if (showSlim) {\r\n    <div class=\"it-header-slim-wrapper\" [class.theme-light]=\"light\">\r\n      <div class=\"container-xxl\">\r\n        <div class=\"row\">\r\n          <div class=\"col-12\">\r\n            <div class=\"it-header-slim-wrapper-content\">\r\n              <a class=\"d-none d-lg-block navbar-brand\" [href]=\"slimTitleLink\" [target]=\"slimTitleLink !== '#' ? '_blank' : '_self'\">\r\n                {{ slimTitle }}\r\n              </a>\r\n              <div class=\"nav-mobile\">\r\n                <nav [attr.aria-label]=\"'it.navigation.secondary-navigation' | translate\">\r\n                  <a\r\n                    class=\"it-opener d-lg-none\"\r\n                    data-bs-toggle=\"collapse\"\r\n                    [href]=\"'#' + idCollapsable\"\r\n                    role=\"button\"\r\n                    [attr.aria-controls]=\"idCollapsable\">\r\n                    <span>{{ slimTitle }}</span>\r\n                    <it-icon name=\"expand\"></it-icon>\r\n                  </a>\r\n                  <div class=\"link-list-wrapper collapse\" [id]=\"idCollapsable\">\r\n                    <ng-content select=\"[slimLinkList]\"></ng-content>\r\n                  </div>\r\n                </nav>\r\n              </div>\r\n              <div class=\"it-header-slim-right-zone\">\r\n                <ng-content select=\"[slimRightZone]\"></ng-content>\r\n                @if (loginStyle === 'default') {\r\n                  <div class=\"it-access-top-wrapper\">\r\n                    <a class=\"btn btn-primary btn-sm\" (click)=\"emitLoginClick($event)\" href=\"#\">\r\n                      {{ 'it.navigation.login' | translate }}\r\n                    </a>\r\n                  </div>\r\n                }\r\n                @if (loginStyle === 'full') {\r\n                  <a itButton=\"primary\" class=\"btn-full btn-icon\" (click)=\"emitLoginClick($event)\" href=\"#\">\r\n                    <span class=\"rounded-icon\">\r\n                      <it-icon name=\"user\" color=\"primary\"></it-icon>\r\n                    </span>\r\n                    <span class=\"d-none d-lg-block\">{{ 'it.navigation.full-login' | translate }}</span>\r\n                  </a>\r\n                }\r\n              </div>\r\n            </div>\r\n          </div>\r\n        </div>\r\n      </div>\r\n    </div>\r\n  }\r\n  <div class=\"it-nav-wrapper\">\r\n    <div class=\"it-header-center-wrapper\" [class.it-small-header]=\"smallHeader\" [class.theme-light]=\"light\">\r\n      <div class=\"container\">\r\n        <div class=\"row\">\r\n          <div class=\"col-12\">\r\n            <div class=\"it-header-center-content-wrapper\">\r\n              <div class=\"it-brand-wrapper\">\r\n                <ng-content select=\"[brand]\"></ng-content>\r\n              </div>\r\n              <div class=\"it-right-zone\">\r\n                <ng-content select=\"[rightZone]\"></ng-content>\r\n\r\n                @if (showSearch) {\r\n                  <div class=\"it-search-wrapper\">\r\n                    <span class=\"d-none d-md-block\">{{ 'it.navigation.search' | translate }}</span>\r\n                    <a\r\n                      href=\"#\"\r\n                      class=\"search-link rounded-icon\"\r\n                      [attr.aria-label]=\"'it.navigation.website-search' | translate\"\r\n                      (click)=\"emitSearchClick($event)\">\r\n                      <it-icon name=\"search\"></it-icon>\r\n                    </a>\r\n                  </div>\r\n                }\r\n              </div>\r\n            </div>\r\n          </div>\r\n        </div>\r\n      </div>\r\n    </div>\r\n    <div class=\"it-header-navbar-wrapper\" [class.theme-light-desk]=\"light\" id=\"header-nav-wrapper\">\r\n      <div class=\"container\">\r\n        <div class=\"row\">\r\n          <div class=\"col-12\">\r\n            <it-navbar [megamenu]=\"megamenu\" [expand]=\"expand\">\r\n              <ng-container navItems>\r\n                <ng-content select=\"[navItems]\"></ng-content>\r\n              </ng-container>\r\n            </it-navbar>\r\n          </div>\r\n        </div>\r\n      </div>\r\n    </div>\r\n  </div>\r\n</header>\r\n",
			styles: [".nav-mobile:has(.link-list-wrapper:empty){display:none}\n"],
			dependencies: [
				{
					kind: "ngmodule",
					type: TranslateModule
				},
				{
					kind: "component",
					type: ItIconComponent,
					selector: "it-icon",
					inputs: [
						"name",
						"size",
						"color",
						"padded",
						"svgClass",
						"title",
						"labelWaria"
					]
				},
				{
					kind: "directive",
					type: ItButtonDirective,
					selector: "[itButton]",
					inputs: [
						"itButton",
						"size",
						"block",
						"disabled",
						"type"
					],
					exportAs: ["itButton"]
				},
				{
					kind: "ngmodule",
					type: ItNavBarModule
				},
				{
					kind: "component",
					type: ItNavBarComponent,
					selector: "it-navbar",
					inputs: ["megamenu", "expand"]
				},
				{
					kind: "pipe",
					type: i1$1.TranslatePipe,
					name: "translate"
				}
			],
			changeDetection: i0.ChangeDetectionStrategy.OnPush
		});
	}
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.1",
	ngImport: i0,
	type: ItHeaderComponent,
	decorators: [{
		type: Component,
		args: [{
			selector: "it-header",
			changeDetection: ChangeDetectionStrategy.OnPush,
			imports: [
				TranslateModule,
				ItIconComponent,
				ItButtonDirective,
				ItNavBarModule
			],
			template: "<header\r\n  #headerWrapper\r\n  class=\"it-header-wrapper\"\r\n  [class.it-header-sticky]=\"sticky\"\r\n  data-bs-position-type=\"fixed\"\r\n  data-bs-sticky-class-name=\"is-sticky\"\r\n  data-bs-target=\"#header-nav-wrapper\">\r\n  @if (showSlim) {\r\n    <div class=\"it-header-slim-wrapper\" [class.theme-light]=\"light\">\r\n      <div class=\"container-xxl\">\r\n        <div class=\"row\">\r\n          <div class=\"col-12\">\r\n            <div class=\"it-header-slim-wrapper-content\">\r\n              <a class=\"d-none d-lg-block navbar-brand\" [href]=\"slimTitleLink\" [target]=\"slimTitleLink !== '#' ? '_blank' : '_self'\">\r\n                {{ slimTitle }}\r\n              </a>\r\n              <div class=\"nav-mobile\">\r\n                <nav [attr.aria-label]=\"'it.navigation.secondary-navigation' | translate\">\r\n                  <a\r\n                    class=\"it-opener d-lg-none\"\r\n                    data-bs-toggle=\"collapse\"\r\n                    [href]=\"'#' + idCollapsable\"\r\n                    role=\"button\"\r\n                    [attr.aria-controls]=\"idCollapsable\">\r\n                    <span>{{ slimTitle }}</span>\r\n                    <it-icon name=\"expand\"></it-icon>\r\n                  </a>\r\n                  <div class=\"link-list-wrapper collapse\" [id]=\"idCollapsable\">\r\n                    <ng-content select=\"[slimLinkList]\"></ng-content>\r\n                  </div>\r\n                </nav>\r\n              </div>\r\n              <div class=\"it-header-slim-right-zone\">\r\n                <ng-content select=\"[slimRightZone]\"></ng-content>\r\n                @if (loginStyle === 'default') {\r\n                  <div class=\"it-access-top-wrapper\">\r\n                    <a class=\"btn btn-primary btn-sm\" (click)=\"emitLoginClick($event)\" href=\"#\">\r\n                      {{ 'it.navigation.login' | translate }}\r\n                    </a>\r\n                  </div>\r\n                }\r\n                @if (loginStyle === 'full') {\r\n                  <a itButton=\"primary\" class=\"btn-full btn-icon\" (click)=\"emitLoginClick($event)\" href=\"#\">\r\n                    <span class=\"rounded-icon\">\r\n                      <it-icon name=\"user\" color=\"primary\"></it-icon>\r\n                    </span>\r\n                    <span class=\"d-none d-lg-block\">{{ 'it.navigation.full-login' | translate }}</span>\r\n                  </a>\r\n                }\r\n              </div>\r\n            </div>\r\n          </div>\r\n        </div>\r\n      </div>\r\n    </div>\r\n  }\r\n  <div class=\"it-nav-wrapper\">\r\n    <div class=\"it-header-center-wrapper\" [class.it-small-header]=\"smallHeader\" [class.theme-light]=\"light\">\r\n      <div class=\"container\">\r\n        <div class=\"row\">\r\n          <div class=\"col-12\">\r\n            <div class=\"it-header-center-content-wrapper\">\r\n              <div class=\"it-brand-wrapper\">\r\n                <ng-content select=\"[brand]\"></ng-content>\r\n              </div>\r\n              <div class=\"it-right-zone\">\r\n                <ng-content select=\"[rightZone]\"></ng-content>\r\n\r\n                @if (showSearch) {\r\n                  <div class=\"it-search-wrapper\">\r\n                    <span class=\"d-none d-md-block\">{{ 'it.navigation.search' | translate }}</span>\r\n                    <a\r\n                      href=\"#\"\r\n                      class=\"search-link rounded-icon\"\r\n                      [attr.aria-label]=\"'it.navigation.website-search' | translate\"\r\n                      (click)=\"emitSearchClick($event)\">\r\n                      <it-icon name=\"search\"></it-icon>\r\n                    </a>\r\n                  </div>\r\n                }\r\n              </div>\r\n            </div>\r\n          </div>\r\n        </div>\r\n      </div>\r\n    </div>\r\n    <div class=\"it-header-navbar-wrapper\" [class.theme-light-desk]=\"light\" id=\"header-nav-wrapper\">\r\n      <div class=\"container\">\r\n        <div class=\"row\">\r\n          <div class=\"col-12\">\r\n            <it-navbar [megamenu]=\"megamenu\" [expand]=\"expand\">\r\n              <ng-container navItems>\r\n                <ng-content select=\"[navItems]\"></ng-content>\r\n              </ng-container>\r\n            </it-navbar>\r\n          </div>\r\n        </div>\r\n      </div>\r\n    </div>\r\n  </div>\r\n</header>\r\n",
			styles: [".nav-mobile:has(.link-list-wrapper:empty){display:none}\n"]
		}]
	}],
	ctorParameters: () => [],
	propDecorators: {
		light: [{
			type: Input,
			args: [{ transform: inputToBoolean }]
		}],
		sticky: [{
			type: Input,
			args: [{ transform: inputToBoolean }]
		}],
		showSlim: [{
			type: Input,
			args: [{ transform: inputToBoolean }]
		}],
		smallHeader: [{
			type: Input,
			args: [{ transform: inputToBoolean }]
		}],
		showSearch: [{
			type: Input,
			args: [{ transform: inputToBoolean }]
		}],
		idCollapsable: [{ type: Input }],
		slimTitle: [{ type: Input }],
		slimTitleLink: [{ type: Input }],
		loginStyle: [{ type: Input }],
		loginClick: [{ type: Output }],
		searchClick: [{ type: Output }],
		headerWrapper: [{
			type: ViewChild,
			args: ["headerWrapper"]
		}],
		itNavBarComponent: [{
			type: ViewChild,
			args: [ItNavBarComponent]
		}],
		megamenu: [{
			type: Input,
			args: [{ transform: inputToBoolean }]
		}],
		expand: [{
			type: Input,
			args: [{ transform: inputToBoolean }]
		}]
	}
});
var ItFooterComponent = class ItFooterComponent extends ItAbstractComponent {
	static {
		this.ɵfac = i0.ɵɵngDeclareFactory({
			minVersion: "12.0.0",
			version: "22.2.1",
			ngImport: i0,
			type: ItFooterComponent,
			deps: null,
			target: i0.ɵɵFactoryTarget.Component
		});
	}
	static {
		this.ɵcmp = i0.ɵɵngDeclareComponent({
			minVersion: "14.0.0",
			version: "22.2.1",
			type: ItFooterComponent,
			isStandalone: true,
			selector: "it-footer",
			exportAs: ["itFooter"],
			usesInheritance: true,
			ngImport: i0,
			template: "<footer class=\"it-footer\">\r\n  <div class=\"it-footer-main\">\r\n    <div class=\"container\">\r\n      <section>\r\n        <div class=\"row clearfix\">\r\n          <div class=\"col-sm-12\">\r\n            <ng-content select=\"[header]\"></ng-content>\r\n          </div>\r\n        </div>\r\n      </section>\r\n      <section>\r\n        <ng-content select=\"[links]\"></ng-content>\r\n      </section>\r\n      <section class=\"py-4 border-white border-top\">\r\n        <ng-content select=\"[contacts]\"></ng-content>\r\n      </section>\r\n    </div>\r\n  </div>\r\n  <div class=\"it-footer-small-prints clearfix\">\r\n    <div class=\"container\">\r\n      <ul class=\"it-footer-small-prints-list list-inline mb-0 d-flex flex-column flex-md-row\">\r\n        <ng-content select=\"[small-links]\"></ng-content>\r\n      </ul>\r\n    </div>\r\n  </div>\r\n</footer>\r\n",
			changeDetection: i0.ChangeDetectionStrategy.OnPush
		});
	}
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.1",
	ngImport: i0,
	type: ItFooterComponent,
	decorators: [{
		type: Component,
		args: [{
			standalone: true,
			selector: "it-footer",
			exportAs: "itFooter",
			changeDetection: ChangeDetectionStrategy.OnPush,
			imports: [],
			template: "<footer class=\"it-footer\">\r\n  <div class=\"it-footer-main\">\r\n    <div class=\"container\">\r\n      <section>\r\n        <div class=\"row clearfix\">\r\n          <div class=\"col-sm-12\">\r\n            <ng-content select=\"[header]\"></ng-content>\r\n          </div>\r\n        </div>\r\n      </section>\r\n      <section>\r\n        <ng-content select=\"[links]\"></ng-content>\r\n      </section>\r\n      <section class=\"py-4 border-white border-top\">\r\n        <ng-content select=\"[contacts]\"></ng-content>\r\n      </section>\r\n    </div>\r\n  </div>\r\n  <div class=\"it-footer-small-prints clearfix\">\r\n    <div class=\"container\">\r\n      <ul class=\"it-footer-small-prints-list list-inline mb-0 d-flex flex-column flex-md-row\">\r\n        <ng-content select=\"[small-links]\"></ng-content>\r\n      </ul>\r\n    </div>\r\n  </div>\r\n</footer>\r\n"
		}]
	}]
});
var ItMegamenuComponent = class ItMegamenuComponent {
	constructor() {
		this.mode = "normal";
	}
	static {
		this.ɵfac = i0.ɵɵngDeclareFactory({
			minVersion: "12.0.0",
			version: "22.2.1",
			ngImport: i0,
			type: ItMegamenuComponent,
			deps: [],
			target: i0.ɵɵFactoryTarget.Component
		});
	}
	static {
		this.ɵcmp = i0.ɵɵngDeclareComponent({
			minVersion: "17.0.0",
			version: "22.2.1",
			type: ItMegamenuComponent,
			isStandalone: true,
			selector: "it-megamenu",
			inputs: {
				mode: "mode",
				header: [
					"header",
					"header",
					inputToBoolean
				],
				footer: [
					"footer",
					"footer",
					inputToBoolean
				]
			},
			ngImport: i0,
			template: "<div class=\"megamenu pb-5 pt-3 py-lg-0\">\r\n  <div class=\"row\">\r\n    @if (mode === 'left-section') {\r\n      <div class=\"col-xs-12 col-lg-4 px-0\">\r\n        <div class=\"row\">\r\n          <div class=\"col-12 it-vertical it-description pb-lg-3\">\r\n            <div class=\"description-content ps-4 ps-sm-5 ms-3\">\r\n              <ng-content select=\"[megamenuLeftZone]\"></ng-content>\r\n            </div>\r\n          </div>\r\n        </div>\r\n      </div>\r\n    }\r\n    <div class=\"col-12\" [class.col-lg-8]=\"mode !== 'normal'\">\r\n      @if (header) {\r\n        <div class=\"it-heading-link-wrapper\">\r\n          <ng-content select=\"[megamenuHeadingLink]\"></ng-content>\r\n        </div>\r\n      }\r\n      <div class=\"row\">\r\n        <ng-content select=\"[megamenuLinkList]\"></ng-content>\r\n      </div>\r\n    </div>\r\n    @if (footer || mode === 'right-section') {\r\n      <div [class.col-xs-12]=\"mode === 'right-section'\" [class.col-lg-4]=\"mode === 'right-section'\" [class.px-0]=\"mode === 'right-section'\">\r\n        <div [class.it-footer-link-wrapper]=\"footer\" [class.it-footer-link-wrapper-vertical]=\"mode === 'right-section'\">\r\n          <div class=\"d-flex flex-column justify-content-around\" [class.flex-lg-row]=\"mode !== 'right-section'\">\r\n            <ng-content select=\"[megamenuFooter]\"></ng-content>\r\n          </div>\r\n        </div>\r\n      </div>\r\n    }\r\n  </div>\r\n</div>\r\n",
			styles: ["::ng-deep .theme-light-desk .nav-link:before{background-color:#06c}\n"],
			changeDetection: i0.ChangeDetectionStrategy.OnPush
		});
	}
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.1",
	ngImport: i0,
	type: ItMegamenuComponent,
	decorators: [{
		type: Component,
		args: [{
			selector: "it-megamenu",
			changeDetection: ChangeDetectionStrategy.OnPush,
			template: "<div class=\"megamenu pb-5 pt-3 py-lg-0\">\r\n  <div class=\"row\">\r\n    @if (mode === 'left-section') {\r\n      <div class=\"col-xs-12 col-lg-4 px-0\">\r\n        <div class=\"row\">\r\n          <div class=\"col-12 it-vertical it-description pb-lg-3\">\r\n            <div class=\"description-content ps-4 ps-sm-5 ms-3\">\r\n              <ng-content select=\"[megamenuLeftZone]\"></ng-content>\r\n            </div>\r\n          </div>\r\n        </div>\r\n      </div>\r\n    }\r\n    <div class=\"col-12\" [class.col-lg-8]=\"mode !== 'normal'\">\r\n      @if (header) {\r\n        <div class=\"it-heading-link-wrapper\">\r\n          <ng-content select=\"[megamenuHeadingLink]\"></ng-content>\r\n        </div>\r\n      }\r\n      <div class=\"row\">\r\n        <ng-content select=\"[megamenuLinkList]\"></ng-content>\r\n      </div>\r\n    </div>\r\n    @if (footer || mode === 'right-section') {\r\n      <div [class.col-xs-12]=\"mode === 'right-section'\" [class.col-lg-4]=\"mode === 'right-section'\" [class.px-0]=\"mode === 'right-section'\">\r\n        <div [class.it-footer-link-wrapper]=\"footer\" [class.it-footer-link-wrapper-vertical]=\"mode === 'right-section'\">\r\n          <div class=\"d-flex flex-column justify-content-around\" [class.flex-lg-row]=\"mode !== 'right-section'\">\r\n            <ng-content select=\"[megamenuFooter]\"></ng-content>\r\n          </div>\r\n        </div>\r\n      </div>\r\n    }\r\n  </div>\r\n</div>\r\n",
			styles: ["::ng-deep .theme-light-desk .nav-link:before{background-color:#06c}\n"]
		}]
	}],
	propDecorators: {
		mode: [{ type: Input }],
		header: [{
			type: Input,
			args: [{ transform: inputToBoolean }]
		}],
		footer: [{
			type: Input,
			args: [{ transform: inputToBoolean }]
		}]
	}
});
function searchFn(items, item) {
	const parent = Array.from(items).find((i) => i.childs.includes(item));
	return [item, ...parent?.childs?.length ? searchFn(items, parent) : []];
}
function flattenNavscrollItemsFn(items) {
	const result = [];
	function flatten(items) {
		for (const item of items) {
			result.push(item);
			if (item.childs && item.childs.length > 0) flatten(item.childs);
		}
	}
	flatten(items);
	return result;
}
const search = searchFn;
const flattenNavscrollItems = flattenNavscrollItemsFn;
var NavscrollStore = class {
	constructor() {
		this.#state = new BehaviorSubject({
			items: /* @__PURE__ */ new Set(),
			active: [],
			selected: void 0,
			progressBar: 0,
			isMobile: false
		});
		this.#state$ = this.#state.asObservable();
		this.selected = this.#state$.pipe(map(({ selected }) => selected), distinctUntilChanged());
		this.progressBar = this.#state$.pipe(map(({ progressBar }) => progressBar), distinctUntilChanged());
		this.isMobile = this.#state$.pipe(map(({ isMobile }) => isMobile), distinctUntilChanged());
		this.#menuItemSelected = new Subject();
		this.menuItemSelected = this.#menuItemSelected.asObservable();
	}
	#state;
	#state$;
	#menuItemSelected;
	init(navscrollItems) {
		const flattenItems = flattenNavscrollItems(navscrollItems);
		const selected = (flattenItems && flattenItems.length && flattenItems[0]) ?? void 0;
		const state = {
			items: new Set(flattenItems),
			active: selected ? [selected] : [],
			selected,
			progressBar: 0,
			isMobile: false
		};
		this.#state.next(state);
	}
	setActive(item) {
		const { items } = this.#state.value;
		const active = search(items, item);
		const state = this.#state.value;
		this.#state.next({
			...state,
			items,
			selected: item,
			active
		});
	}
	isActive$(item) {
		return this.#state.asObservable().pipe(map((state) => state.active.includes(item)));
	}
	updateProgressBar(container) {
		if (!container) return;
		const scrollAmount = Math.abs(container.getBoundingClientRect().top) / container.getBoundingClientRect().height * 100;
		const scrollValue = Math.min(100, Math.max(0, scrollAmount));
		const state = this.#state.value;
		this.#state.next({
			...state,
			progressBar: container.getBoundingClientRect().y > 0 ? 0 : scrollValue
		});
	}
	selectMenuItem() {
		this.#menuItemSelected.next(void 0);
	}
	setMobile({ innerWidth }) {
		const isMobile = innerWidth < 992;
		const state = this.#state.value;
		this.#state.next({
			...state,
			isMobile
		});
	}
};
const ROUTER_LINK_ACTIVE_OPTIONS = {
	fragment: "exact",
	paths: "exact",
	queryParams: "exact",
	matrixParams: "exact"
};
var ItNavscrollListItemComponent = class ItNavscrollListItemComponent {
	constructor() {
		this.checkActive = new EventEmitter();
		this.routerLinkActiveOptions = ROUTER_LINK_ACTIVE_OPTIONS;
		this.#initIsActive = new AsyncSubject();
		this.active = this.#initIsActive.asObservable().pipe(switchMap((item) => this.#store.isActive$(item)));
		this.#router = inject(Router);
		this.#store = inject(NavscrollStore);
		this.#destroyRef = inject(DestroyRef);
	}
	#initIsActive;
	#router;
	#store;
	#destroyRef;
	ngOnInit() {
		this.#initIsActiveSub();
		this.#router.events.pipe(takeUntilDestroyed(this.#destroyRef), filter((event) => {
			const isNavigationEndEvent = event instanceof NavigationEnd;
			const isScrollEvent = event instanceof Scroll && event.routerEvent instanceof NavigationEnd;
			return isNavigationEndEvent || isScrollEvent;
		}), tap(() => {
			if (this.rtl?.isActive) this.#store.setActive(this.item);
		})).subscribe();
	}
	clickHandler(event) {
		event.preventDefault();
		this.#store.selectMenuItem();
		this.#router.navigate([], { fragment: this.item.href });
	}
	#initIsActiveSub() {
		this.#initIsActive.next(this.item);
		this.#initIsActive.complete();
	}
	static {
		this.ɵfac = i0.ɵɵngDeclareFactory({
			minVersion: "12.0.0",
			version: "22.2.1",
			ngImport: i0,
			type: ItNavscrollListItemComponent,
			deps: [],
			target: i0.ɵɵFactoryTarget.Component
		});
	}
	static {
		this.ɵcmp = i0.ɵɵngDeclareComponent({
			minVersion: "14.0.0",
			version: "22.2.1",
			type: ItNavscrollListItemComponent,
			isStandalone: true,
			selector: "it-navscroll-list-item",
			inputs: { item: "item" },
			outputs: { checkActive: "checkActive" },
			viewQueries: [{
				propertyName: "rtl",
				first: true,
				predicate: ["rtl"],
				descendants: true
			}],
			ngImport: i0,
			template: `
    <a
      class="nav-link"
      [class.active]="active | async"
      [routerLink]="[]"
      routerLinkActive
      [fragment]="$safeNavigationMigration(item?.href)"
      [routerLinkActiveOptions]="routerLinkActiveOptions"
      ariaCurrentWhenActive="page"
      #rtl="routerLinkActive"
      (click)="clickHandler($event)"
      ><span>{{ item?.title }}</span></a
    >
  `,
			isInline: true,
			dependencies: [
				{
					kind: "directive",
					type: RouterLink,
					selector: "[routerLink]",
					inputs: [
						"target",
						"queryParams",
						"fragment",
						"queryParamsHandling",
						"state",
						"info",
						"relativeTo",
						"preserveFragment",
						"skipLocationChange",
						"replaceUrl",
						"browserUrl",
						"routerLink"
					]
				},
				{
					kind: "directive",
					type: RouterLinkActive,
					selector: "[routerLinkActive]",
					inputs: [
						"routerLinkActiveOptions",
						"ariaCurrentWhenActive",
						"routerLinkActive"
					],
					outputs: ["isActiveChange"],
					exportAs: ["routerLinkActive"]
				},
				{
					kind: "pipe",
					type: AsyncPipe,
					name: "async"
				}
			],
			changeDetection: i0.ChangeDetectionStrategy.OnPush
		});
	}
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.1",
	ngImport: i0,
	type: ItNavscrollListItemComponent,
	decorators: [{
		type: Component,
		args: [{
			selector: "it-navscroll-list-item",
			standalone: true,
			imports: [
				RouterLink,
				RouterLinkActive,
				RouterLinkWithHref,
				AsyncPipe
			],
			changeDetection: ChangeDetectionStrategy.OnPush,
			template: `
    <a
      class="nav-link"
      [class.active]="active | async"
      [routerLink]="[]"
      routerLinkActive
      [fragment]="$safeNavigationMigration(item?.href)"
      [routerLinkActiveOptions]="routerLinkActiveOptions"
      ariaCurrentWhenActive="page"
      #rtl="routerLinkActive"
      (click)="clickHandler($event)"
      ><span>{{ item?.title }}</span></a
    >
  `
		}]
	}],
	propDecorators: {
		item: [{ type: Input }],
		checkActive: [{ type: Output }],
		rtl: [{
			type: ViewChild,
			args: ["rtl"]
		}]
	}
});
var ItNavscrollListItemsComponent = class ItNavscrollListItemsComponent {
	static {
		this.ɵfac = i0.ɵɵngDeclareFactory({
			minVersion: "12.0.0",
			version: "22.2.1",
			ngImport: i0,
			type: ItNavscrollListItemsComponent,
			deps: [],
			target: i0.ɵɵFactoryTarget.Component
		});
	}
	static {
		this.ɵcmp = i0.ɵɵngDeclareComponent({
			minVersion: "17.0.0",
			version: "22.2.1",
			type: ItNavscrollListItemsComponent,
			isStandalone: true,
			selector: "it-navscroll-list-items",
			inputs: { items: "items" },
			ngImport: i0,
			template: `
    <ul class="link-list">
      @for (item of items; track item.href) {
        <li class="nav-item">
          <it-navscroll-list-item [item]="item"></it-navscroll-list-item>
          @if (item.childs?.length) {
            <it-navscroll-list-items [items]="item.childs"></it-navscroll-list-items>
          }
        </li>
      }
    </ul>
  `,
			isInline: true,
			dependencies: [{
				kind: "component",
				type: ItNavscrollListItemsComponent,
				selector: "it-navscroll-list-items",
				inputs: ["items"]
			}, {
				kind: "component",
				type: ItNavscrollListItemComponent,
				selector: "it-navscroll-list-item",
				inputs: ["item"],
				outputs: ["checkActive"]
			}],
			changeDetection: i0.ChangeDetectionStrategy.OnPush
		});
	}
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.1",
	ngImport: i0,
	type: ItNavscrollListItemsComponent,
	decorators: [{
		type: Component,
		args: [{
			selector: "it-navscroll-list-items",
			imports: [ItNavscrollListItemComponent],
			changeDetection: ChangeDetectionStrategy.OnPush,
			template: `
    <ul class="link-list">
      @for (item of items; track item.href) {
        <li class="nav-item">
          <it-navscroll-list-item [item]="item"></it-navscroll-list-item>
          @if (item.childs?.length) {
            <it-navscroll-list-items [items]="item.childs"></it-navscroll-list-items>
          }
        </li>
      }
    </ul>
  `
		}]
	}],
	propDecorators: { items: [{ type: Input }] }
});
var ItNavscrollComponent = class ItNavscrollComponent {
	static {
		this._nextId = 0;
	}
	onScroll() {
		const sectionContainer = this.#elementRef.nativeElement.querySelector(".it-page-sections-container");
		this.#store.updateProgressBar(sectionContainer);
	}
	onResize() {
		this.#setMobile();
	}
	#store;
	#scroller;
	#destroyRef;
	#elementRef;
	constructor() {
		this.accordionId = `navscroll-accordion-${ItNavscrollComponent._nextId++}`;
		this.header = "";
		this.accordionExpanded = true;
		this.borderPosition = "left";
		this.alignment = "top";
		this.theme = "light";
		this.#store = inject(NavscrollStore);
		this.#scroller = inject(ViewportScroller);
		this.#destroyRef = inject(DestroyRef);
		this.#elementRef = inject(ElementRef);
		this.selectedTitle = this.#store.selected.pipe(map((selected) => selected?.title ?? ""));
		this.progressBarValue = this.#store.progressBar;
		this.isMobile = this.#store.isMobile;
		this.isNotMobile = this.#store.isMobile.pipe(map((v) => !v));
		this.#store.menuItemSelected.pipe(takeUntilDestroyed(), withLatestFrom(this.isMobile), tap((v) => {
			if (v[1]) this.toggleButtonRef.nativeElement.click();
		})).subscribe();
	}
	ngOnInit() {
		this.#initViewScrollerSubscription();
		this.#store.init(this.items);
		this.#setMobile();
	}
	#initViewScrollerSubscription() {
		this.#store.selected.pipe(takeUntilDestroyed(this.#destroyRef), filter((selected) => Boolean(selected)), map((v) => v), delay(0), tap({ next: ({ href }) => {
			this.#scroller.scrollToAnchor(href);
		} })).subscribe();
	}
	#setMobile() {
		this.#store.setMobile(window);
	}
	static {
		this.ɵfac = i0.ɵɵngDeclareFactory({
			minVersion: "12.0.0",
			version: "22.2.1",
			ngImport: i0,
			type: ItNavscrollComponent,
			deps: [],
			target: i0.ɵɵFactoryTarget.Component
		});
	}
	static {
		this.ɵcmp = i0.ɵɵngDeclareComponent({
			minVersion: "17.0.0",
			version: "22.2.1",
			type: ItNavscrollComponent,
			isStandalone: true,
			selector: "it-navscroll",
			inputs: {
				header: "header",
				headerAsAccordion: [
					"headerAsAccordion",
					"headerAsAccordion",
					inputToBoolean
				],
				hideNavigationOnMobile: [
					"hideNavigationOnMobile",
					"hideNavigationOnMobile",
					inputToBoolean
				],
				accordionExpanded: [
					"accordionExpanded",
					"accordionExpanded",
					inputToBoolean
				],
				items: "items",
				borderPosition: "borderPosition",
				alignment: "alignment",
				theme: "theme",
				pageSectionsTemplate: "pageSectionsTemplate"
			},
			host: { listeners: {
				"window:scroll": "onScroll()",
				"window:resize": "onResize()"
			} },
			providers: [NavscrollStore],
			viewQueries: [{
				propertyName: "toggleButtonRef",
				first: true,
				predicate: ["toggleButtonRef"],
				descendants: true
			}],
			ngImport: i0,
			template: "<div class=\"container py-lg-5\">\r\n  <div class=\"row\">\r\n    @if (!hideNavigationOnMobile || (isNotMobile | async)) {\r\n      <div class=\"col-12 col-lg-4\">\r\n        <div class=\"it-navscroll-sticky\" [ngClass]=\"{ 'it-navscroll-sticky-mobile': isMobile | async }\" data-bs-stackable=\"true\">\r\n          <nav\r\n            class=\"navbar it-navscroll-wrapper navbar-expand-lg\"\r\n            [class.it-top-navscroll]=\"alignment === 'top'\"\r\n            [class.it-bottom-navscroll]=\"alignment === 'bottom'\"\r\n            [class.it-left-side]=\"borderPosition === 'left'\"\r\n            [class.it-right-side]=\"borderPosition === 'right'\"\r\n            [class.theme-dark-mobile]=\"theme === 'dark'\"\r\n            [class.theme-dark-desktop]=\"theme === 'dark'\">\r\n            <button\r\n              class=\"custom-navbar-toggler\"\r\n              type=\"button\"\r\n              aria-controls=\"navbarNav\"\r\n              [attr.aria-label]=\"'it.navigation.aria-label-toggle' | translate\"\r\n              data-bs-toggle=\"navbarcollapsible\"\r\n              data-bs-target=\"#navbarNav\"\r\n              #toggleButtonRef>\r\n              <span class=\"it-list\"></span>{{ selectedTitle | async }}\r\n            </button>\r\n            <div class=\"progress custom-navbar-progressbar\">\r\n              <div\r\n                class=\"progress-bar it-navscroll-progressbar\"\r\n                role=\"progressbar\"\r\n                [style.width.%]=\"progressBarValue | async\"\r\n                [attr.aria-valuenow]=\"progressBarValue | async\"\r\n                aria-valuemin=\"0\"\r\n                aria-valuemax=\"100\"></div>\r\n            </div>\r\n            <div class=\"navbar-collapsable\" id=\"navbarNav\" tabindex=\"-1\">\r\n              <div class=\"close-div visually-hidden\">\r\n                <button class=\"btn close-menu\" type=\"button\"><span class=\"it-close\"></span>Chiudi</button>\r\n              </div>\r\n              <button type=\"button\" class=\"it-back-button btn w-100 text-start\">\r\n                <svg class=\"icon icon-sm icon-primary align-top\">\r\n                  <use\r\n                    href=\"/bootstrap-italia/dist/svg/sprites.svg#it-chevron-left\"\r\n                    xlink:href=\"/bootstrap-italia/dist/svg/sprites.svg#it-chevron-left\"></use>\r\n                </svg>\r\n                <span>Indietro</span>\r\n              </button>\r\n              <div class=\"menu-wrapper\" tabindex=\"-1\">\r\n                <div class=\"link-list-wrapper\">\r\n                  @if (headerAsAccordion) {\r\n                    <div class=\"accordion\" [id]=\"accordionId\">\r\n                      <div class=\"accordion-item\">\r\n                        <h3 class=\"accordion-header\" [id]=\"accordionId + '-heading'\">\r\n                          <button\r\n                            class=\"accordion-button\"\r\n                            [class.collapsed]=\"!accordionExpanded\"\r\n                            type=\"button\"\r\n                            data-bs-toggle=\"collapse\"\r\n                            [attr.data-bs-target]=\"'#' + accordionId + '-body'\"\r\n                            [attr.aria-expanded]=\"accordionExpanded\"\r\n                            [attr.aria-controls]=\"accordionId + '-body'\">\r\n                            {{ header }}\r\n                          </button>\r\n                        </h3>\r\n                        <div\r\n                          [id]=\"accordionId + '-body'\"\r\n                          class=\"accordion-collapse collapse\"\r\n                          [class.show]=\"accordionExpanded\"\r\n                          [attr.aria-labelledby]=\"accordionId + '-heading'\">\r\n                          <div class=\"accordion-body\">\r\n                            <it-navscroll-list-items [items]=\"items\"></it-navscroll-list-items>\r\n                          </div>\r\n                        </div>\r\n                      </div>\r\n                    </div>\r\n                  } @else {\r\n                    <h3>{{ header }}</h3>\r\n                    <div class=\"progress\">\r\n                      <div\r\n                        class=\"progress-bar it-navscroll-progressbar\"\r\n                        role=\"progressbar\"\r\n                        [style.width.%]=\"progressBarValue | async\"\r\n                        [attr.aria-valuenow]=\"progressBarValue | async\"\r\n                        aria-valuemin=\"0\"\r\n                        aria-valuemax=\"100\"></div>\r\n                    </div>\r\n                    <it-navscroll-list-items [items]=\"items\"></it-navscroll-list-items>\r\n                  }\r\n                </div>\r\n              </div>\r\n            </div>\r\n          </nav>\r\n        </div>\r\n      </div>\r\n    }\r\n    <div class=\"col-12 col-lg-8 it-page-sections-container\">\r\n      <ng-container\r\n        *ngTemplateOutlet=\"pageSectionsTemplate ? pageSectionsTemplate : defaultPageSectionsTemplate; context: { items: items }\">\r\n      </ng-container>\r\n    </div>\r\n  </div>\r\n</div>\r\n\r\n<ng-template #defaultPageSectionsTemplate let-items=\"items\">\r\n  @for (item of items; track item.href) {\r\n    <ng-container *ngTemplateOutlet=\"paragraphTemplate; context: { item: item, level: 1 }\"></ng-container>\r\n  }\r\n</ng-template>\r\n\r\n<ng-template #paragraphTemplate let-item=\"item\" let-level=\"level\" let-nextLevel=\"level+1\">\r\n  @switch (level) {\r\n    @case (1) {\r\n      <h2 class=\"it-page-section\" id=\"{{ item.href }}\">{{ item.title }}</h2>\r\n    }\r\n    @case (2) {\r\n      <h3 class=\"it-page-section\" id=\"{{ item.href }}\">{{ item.title }}</h3>\r\n    }\r\n    @case (3) {\r\n      <h4 class=\"it-page-section\" id=\"{{ item.href }}\">{{ item.title }}</h4>\r\n    }\r\n    @case (4) {\r\n      <h5 class=\"it-page-section\" id=\"{{ item.href }}\">{{ item.title }}</h5>\r\n    }\r\n    @default {\r\n      <h6 class=\"it-page-section\" id=\"{{ item.href }}\">{{ item.title }}</h6>\r\n    }\r\n  }\r\n  @if (item.html) {\r\n    <div [innerHTML]=\"item.html\"></div>\r\n  } @else {\r\n    <p>{{ item.text }}</p>\r\n  }\r\n  @for (item of item.childs; track item.href) {\r\n    <ng-container *ngTemplateOutlet=\"paragraphTemplate; context: { item: item, level: nextLevel }\"></ng-container>\r\n  }\r\n</ng-template>\r\n",
			styles: [".it-navscroll-sticky{position:sticky;top:0}.it-navscroll-sticky-mobile{z-index:1020}\n"],
			dependencies: [
				{
					kind: "component",
					type: ItNavscrollListItemsComponent,
					selector: "it-navscroll-list-items",
					inputs: ["items"]
				},
				{
					kind: "directive",
					type: NgTemplateOutlet,
					selector: "[ngTemplateOutlet]",
					inputs: [
						"ngTemplateOutletContext",
						"ngTemplateOutlet",
						"ngTemplateOutletInjector"
					]
				},
				{
					kind: "ngmodule",
					type: TranslateModule
				},
				{
					kind: "directive",
					type: NgClass,
					selector: "[ngClass]",
					inputs: ["class", "ngClass"]
				},
				{
					kind: "pipe",
					type: AsyncPipe,
					name: "async"
				},
				{
					kind: "pipe",
					type: i1$1.TranslatePipe,
					name: "translate"
				}
			],
			changeDetection: i0.ChangeDetectionStrategy.OnPush
		});
	}
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.1",
	ngImport: i0,
	type: ItNavscrollComponent,
	decorators: [{
		type: Component,
		args: [{
			selector: "it-navscroll",
			imports: [
				ItNavscrollListItemsComponent,
				AsyncPipe,
				NgTemplateOutlet,
				TranslateModule,
				AsyncPipe,
				NgClass
			],
			changeDetection: ChangeDetectionStrategy.OnPush,
			providers: [NavscrollStore],
			template: "<div class=\"container py-lg-5\">\r\n  <div class=\"row\">\r\n    @if (!hideNavigationOnMobile || (isNotMobile | async)) {\r\n      <div class=\"col-12 col-lg-4\">\r\n        <div class=\"it-navscroll-sticky\" [ngClass]=\"{ 'it-navscroll-sticky-mobile': isMobile | async }\" data-bs-stackable=\"true\">\r\n          <nav\r\n            class=\"navbar it-navscroll-wrapper navbar-expand-lg\"\r\n            [class.it-top-navscroll]=\"alignment === 'top'\"\r\n            [class.it-bottom-navscroll]=\"alignment === 'bottom'\"\r\n            [class.it-left-side]=\"borderPosition === 'left'\"\r\n            [class.it-right-side]=\"borderPosition === 'right'\"\r\n            [class.theme-dark-mobile]=\"theme === 'dark'\"\r\n            [class.theme-dark-desktop]=\"theme === 'dark'\">\r\n            <button\r\n              class=\"custom-navbar-toggler\"\r\n              type=\"button\"\r\n              aria-controls=\"navbarNav\"\r\n              [attr.aria-label]=\"'it.navigation.aria-label-toggle' | translate\"\r\n              data-bs-toggle=\"navbarcollapsible\"\r\n              data-bs-target=\"#navbarNav\"\r\n              #toggleButtonRef>\r\n              <span class=\"it-list\"></span>{{ selectedTitle | async }}\r\n            </button>\r\n            <div class=\"progress custom-navbar-progressbar\">\r\n              <div\r\n                class=\"progress-bar it-navscroll-progressbar\"\r\n                role=\"progressbar\"\r\n                [style.width.%]=\"progressBarValue | async\"\r\n                [attr.aria-valuenow]=\"progressBarValue | async\"\r\n                aria-valuemin=\"0\"\r\n                aria-valuemax=\"100\"></div>\r\n            </div>\r\n            <div class=\"navbar-collapsable\" id=\"navbarNav\" tabindex=\"-1\">\r\n              <div class=\"close-div visually-hidden\">\r\n                <button class=\"btn close-menu\" type=\"button\"><span class=\"it-close\"></span>Chiudi</button>\r\n              </div>\r\n              <button type=\"button\" class=\"it-back-button btn w-100 text-start\">\r\n                <svg class=\"icon icon-sm icon-primary align-top\">\r\n                  <use\r\n                    href=\"/bootstrap-italia/dist/svg/sprites.svg#it-chevron-left\"\r\n                    xlink:href=\"/bootstrap-italia/dist/svg/sprites.svg#it-chevron-left\"></use>\r\n                </svg>\r\n                <span>Indietro</span>\r\n              </button>\r\n              <div class=\"menu-wrapper\" tabindex=\"-1\">\r\n                <div class=\"link-list-wrapper\">\r\n                  @if (headerAsAccordion) {\r\n                    <div class=\"accordion\" [id]=\"accordionId\">\r\n                      <div class=\"accordion-item\">\r\n                        <h3 class=\"accordion-header\" [id]=\"accordionId + '-heading'\">\r\n                          <button\r\n                            class=\"accordion-button\"\r\n                            [class.collapsed]=\"!accordionExpanded\"\r\n                            type=\"button\"\r\n                            data-bs-toggle=\"collapse\"\r\n                            [attr.data-bs-target]=\"'#' + accordionId + '-body'\"\r\n                            [attr.aria-expanded]=\"accordionExpanded\"\r\n                            [attr.aria-controls]=\"accordionId + '-body'\">\r\n                            {{ header }}\r\n                          </button>\r\n                        </h3>\r\n                        <div\r\n                          [id]=\"accordionId + '-body'\"\r\n                          class=\"accordion-collapse collapse\"\r\n                          [class.show]=\"accordionExpanded\"\r\n                          [attr.aria-labelledby]=\"accordionId + '-heading'\">\r\n                          <div class=\"accordion-body\">\r\n                            <it-navscroll-list-items [items]=\"items\"></it-navscroll-list-items>\r\n                          </div>\r\n                        </div>\r\n                      </div>\r\n                    </div>\r\n                  } @else {\r\n                    <h3>{{ header }}</h3>\r\n                    <div class=\"progress\">\r\n                      <div\r\n                        class=\"progress-bar it-navscroll-progressbar\"\r\n                        role=\"progressbar\"\r\n                        [style.width.%]=\"progressBarValue | async\"\r\n                        [attr.aria-valuenow]=\"progressBarValue | async\"\r\n                        aria-valuemin=\"0\"\r\n                        aria-valuemax=\"100\"></div>\r\n                    </div>\r\n                    <it-navscroll-list-items [items]=\"items\"></it-navscroll-list-items>\r\n                  }\r\n                </div>\r\n              </div>\r\n            </div>\r\n          </nav>\r\n        </div>\r\n      </div>\r\n    }\r\n    <div class=\"col-12 col-lg-8 it-page-sections-container\">\r\n      <ng-container\r\n        *ngTemplateOutlet=\"pageSectionsTemplate ? pageSectionsTemplate : defaultPageSectionsTemplate; context: { items: items }\">\r\n      </ng-container>\r\n    </div>\r\n  </div>\r\n</div>\r\n\r\n<ng-template #defaultPageSectionsTemplate let-items=\"items\">\r\n  @for (item of items; track item.href) {\r\n    <ng-container *ngTemplateOutlet=\"paragraphTemplate; context: { item: item, level: 1 }\"></ng-container>\r\n  }\r\n</ng-template>\r\n\r\n<ng-template #paragraphTemplate let-item=\"item\" let-level=\"level\" let-nextLevel=\"level+1\">\r\n  @switch (level) {\r\n    @case (1) {\r\n      <h2 class=\"it-page-section\" id=\"{{ item.href }}\">{{ item.title }}</h2>\r\n    }\r\n    @case (2) {\r\n      <h3 class=\"it-page-section\" id=\"{{ item.href }}\">{{ item.title }}</h3>\r\n    }\r\n    @case (3) {\r\n      <h4 class=\"it-page-section\" id=\"{{ item.href }}\">{{ item.title }}</h4>\r\n    }\r\n    @case (4) {\r\n      <h5 class=\"it-page-section\" id=\"{{ item.href }}\">{{ item.title }}</h5>\r\n    }\r\n    @default {\r\n      <h6 class=\"it-page-section\" id=\"{{ item.href }}\">{{ item.title }}</h6>\r\n    }\r\n  }\r\n  @if (item.html) {\r\n    <div [innerHTML]=\"item.html\"></div>\r\n  } @else {\r\n    <p>{{ item.text }}</p>\r\n  }\r\n  @for (item of item.childs; track item.href) {\r\n    <ng-container *ngTemplateOutlet=\"paragraphTemplate; context: { item: item, level: nextLevel }\"></ng-container>\r\n  }\r\n</ng-template>\r\n",
			styles: [".it-navscroll-sticky{position:sticky;top:0}.it-navscroll-sticky-mobile{z-index:1020}\n"]
		}]
	}],
	ctorParameters: () => [],
	propDecorators: {
		header: [{ type: Input }],
		headerAsAccordion: [{
			type: Input,
			args: [{ transform: inputToBoolean }]
		}],
		hideNavigationOnMobile: [{
			type: Input,
			args: [{ transform: inputToBoolean }]
		}],
		accordionExpanded: [{
			type: Input,
			args: [{ transform: inputToBoolean }]
		}],
		items: [{ type: Input }],
		borderPosition: [{ type: Input }],
		alignment: [{ type: Input }],
		theme: [{ type: Input }],
		pageSectionsTemplate: [{ type: Input }],
		onScroll: [{
			type: HostListener,
			args: ["window:scroll"]
		}],
		onResize: [{
			type: HostListener,
			args: ["window:resize"]
		}],
		toggleButtonRef: [{
			type: ViewChild,
			args: ["toggleButtonRef"]
		}]
	}
});
var ItSidebarComponent = class ItSidebarComponent {
	constructor() {
		this.withRightLine = false;
		this.withLeftLine = false;
		this.dark = false;
		this.componentClass = "d-block sidebar-wrapper";
	}
	static {
		this.ɵfac = i0.ɵɵngDeclareFactory({
			minVersion: "12.0.0",
			version: "22.2.1",
			ngImport: i0,
			type: ItSidebarComponent,
			deps: [],
			target: i0.ɵɵFactoryTarget.Component
		});
	}
	static {
		this.ɵcmp = i0.ɵɵngDeclareComponent({
			minVersion: "17.0.0",
			version: "22.2.1",
			type: ItSidebarComponent,
			isStandalone: true,
			selector: "it-sidebar",
			inputs: {
				withRightLine: [
					"withRightLine",
					"withRightLine",
					inputToBoolean
				],
				withLeftLine: [
					"withLeftLine",
					"withLeftLine",
					inputToBoolean
				],
				dark: [
					"dark",
					"dark",
					inputToBoolean
				],
				header: "header"
			},
			host: { properties: {
				"class.it-line-right-side": "this.withRightLine",
				"class.it-line-left-side": "this.withLeftLine",
				"class.theme-dark": "this.dark",
				"class": "this.componentClass"
			} },
			ngImport: i0,
			template: "@if (header) {\r\n  <h3>{{ header }}</h3>\r\n}\r\n<div class=\"sidebar-linklist-wrapper\">\r\n  <!--TODO: wrap ng-content with it-list -> inside content use a list of it-list-item directives-->\r\n  <ng-content></ng-content>\r\n</div>\r\n<div class=\"sidebar-linklist-wrapper linklist-secondary\">\r\n  <!--TODO: wrap ng-content with it-list -> inside content use a list of it-list-item directives-->\r\n  <ng-content select=\"[secondary]\"></ng-content>\r\n</div>\r\n",
			changeDetection: i0.ChangeDetectionStrategy.OnPush
		});
	}
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.1",
	ngImport: i0,
	type: ItSidebarComponent,
	decorators: [{
		type: Component,
		args: [{
			selector: "it-sidebar",
			imports: [],
			changeDetection: ChangeDetectionStrategy.OnPush,
			template: "@if (header) {\r\n  <h3>{{ header }}</h3>\r\n}\r\n<div class=\"sidebar-linklist-wrapper\">\r\n  <!--TODO: wrap ng-content with it-list -> inside content use a list of it-list-item directives-->\r\n  <ng-content></ng-content>\r\n</div>\r\n<div class=\"sidebar-linklist-wrapper linklist-secondary\">\r\n  <!--TODO: wrap ng-content with it-list -> inside content use a list of it-list-item directives-->\r\n  <ng-content select=\"[secondary]\"></ng-content>\r\n</div>\r\n"
		}]
	}],
	propDecorators: {
		withRightLine: [{
			type: Input,
			args: [{ transform: inputToBoolean }]
		}, {
			type: HostBinding,
			args: ["class.it-line-right-side"]
		}],
		withLeftLine: [{
			type: Input,
			args: [{ transform: inputToBoolean }]
		}, {
			type: HostBinding,
			args: ["class.it-line-left-side"]
		}],
		dark: [{
			type: Input,
			args: [{ transform: inputToBoolean }]
		}, {
			type: HostBinding,
			args: ["class.theme-dark"]
		}],
		header: [{ type: Input }],
		componentClass: [{
			type: HostBinding,
			args: ["class"]
		}]
	}
});
var ItSkiplinkComponent = class ItSkiplinkComponent {
	constructor() {
		this.ariaLabel = "Scorciatoie di navigazione";
	}
	static {
		this.ɵfac = i0.ɵɵngDeclareFactory({
			minVersion: "12.0.0",
			version: "22.2.1",
			ngImport: i0,
			type: ItSkiplinkComponent,
			deps: [],
			target: i0.ɵɵFactoryTarget.Component
		});
	}
	static {
		this.ɵcmp = i0.ɵɵngDeclareComponent({
			minVersion: "17.0.0",
			version: "22.2.1",
			type: ItSkiplinkComponent,
			isStandalone: true,
			selector: "it-skiplink",
			inputs: {
				ariaLabel: "ariaLabel",
				nav: [
					"nav",
					"nav",
					inputToBoolean
				]
			},
			exportAs: ["itSkipLink"],
			ngImport: i0,
			template: "@if (nav) {\r\n  <nav class=\"skiplinks\">\r\n    <ul>\r\n      <ng-container *ngTemplateOutlet=\"linkContent\"></ng-container>\r\n    </ul>\r\n  </nav>\r\n} @else {\r\n  <div class=\"skiplinks\">\r\n    <ng-container *ngTemplateOutlet=\"linkContent\"></ng-container>\r\n  </div>\r\n}\r\n\r\n<ng-template #linkContent>\r\n  <ng-content></ng-content>\r\n</ng-template>\r\n",
			dependencies: [{
				kind: "directive",
				type: NgTemplateOutlet,
				selector: "[ngTemplateOutlet]",
				inputs: [
					"ngTemplateOutletContext",
					"ngTemplateOutlet",
					"ngTemplateOutletInjector"
				]
			}, {
				kind: "ngmodule",
				type: TranslateModule
			}],
			changeDetection: i0.ChangeDetectionStrategy.OnPush
		});
	}
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.1",
	ngImport: i0,
	type: ItSkiplinkComponent,
	decorators: [{
		type: Component,
		args: [{
			selector: "it-skiplink",
			exportAs: "itSkipLink",
			changeDetection: ChangeDetectionStrategy.OnPush,
			imports: [NgTemplateOutlet, TranslateModule],
			template: "@if (nav) {\r\n  <nav class=\"skiplinks\">\r\n    <ul>\r\n      <ng-container *ngTemplateOutlet=\"linkContent\"></ng-container>\r\n    </ul>\r\n  </nav>\r\n} @else {\r\n  <div class=\"skiplinks\">\r\n    <ng-container *ngTemplateOutlet=\"linkContent\"></ng-container>\r\n  </div>\r\n}\r\n\r\n<ng-template #linkContent>\r\n  <ng-content></ng-content>\r\n</ng-template>\r\n"
		}]
	}],
	propDecorators: {
		ariaLabel: [{ type: Input }],
		nav: [{
			type: Input,
			args: [{ transform: inputToBoolean }]
		}]
	}
});
var ItSkiplinkItemComponent = class ItSkiplinkItemComponent {
	constructor() {
		const parent = inject(ItSkiplinkComponent, { host: true });
		this.inNav = parent.nav ? true : false;
	}
	static {
		this.ɵfac = i0.ɵɵngDeclareFactory({
			minVersion: "12.0.0",
			version: "22.2.1",
			ngImport: i0,
			type: ItSkiplinkItemComponent,
			deps: [],
			target: i0.ɵɵFactoryTarget.Component
		});
	}
	static {
		this.ɵcmp = i0.ɵɵngDeclareComponent({
			minVersion: "17.0.0",
			version: "22.2.1",
			type: ItSkiplinkItemComponent,
			isStandalone: true,
			selector: "it-skiplink-item",
			inputs: {
				href: "href",
				externalLink: [
					"externalLink",
					"externalLink",
					inputToBoolean
				]
			},
			exportAs: ["itSkipLinkItem"],
			ngImport: i0,
			template: "@if (inNav) {\r\n  <li class=\"visually-hidden-focusable\">\r\n    <it-link [href]=\"href\" [externalLink]=\"externalLink\">\r\n      <ng-container *ngTemplateOutlet=\"linkContent\"></ng-container>\r\n    </it-link>\r\n  </li>\r\n} @else {\r\n  <it-link class=\"visually-hidden-focusable\" [href]=\"href\" [externalLink]=\"externalLink\">\r\n    <ng-container *ngTemplateOutlet=\"linkContent\"></ng-container>\r\n  </it-link>\r\n}\r\n\r\n<ng-template #linkContent>\r\n  <ng-content></ng-content>\r\n</ng-template>\r\n",
			dependencies: [
				{
					kind: "directive",
					type: NgTemplateOutlet,
					selector: "[ngTemplateOutlet]",
					inputs: [
						"ngTemplateOutletContext",
						"ngTemplateOutlet",
						"ngTemplateOutletInjector"
					]
				},
				{
					kind: "ngmodule",
					type: TranslateModule
				},
				{
					kind: "component",
					type: ItLinkComponent,
					selector: "it-link",
					inputs: [
						"href",
						"externalLink",
						"disabled",
						"class"
					]
				}
			],
			changeDetection: i0.ChangeDetectionStrategy.OnPush
		});
	}
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.1",
	ngImport: i0,
	type: ItSkiplinkItemComponent,
	decorators: [{
		type: Component,
		args: [{
			selector: "it-skiplink-item",
			exportAs: "itSkipLinkItem",
			changeDetection: ChangeDetectionStrategy.OnPush,
			imports: [
				NgTemplateOutlet,
				TranslateModule,
				ItLinkComponent
			],
			template: "@if (inNav) {\r\n  <li class=\"visually-hidden-focusable\">\r\n    <it-link [href]=\"href\" [externalLink]=\"externalLink\">\r\n      <ng-container *ngTemplateOutlet=\"linkContent\"></ng-container>\r\n    </it-link>\r\n  </li>\r\n} @else {\r\n  <it-link class=\"visually-hidden-focusable\" [href]=\"href\" [externalLink]=\"externalLink\">\r\n    <ng-container *ngTemplateOutlet=\"linkContent\"></ng-container>\r\n  </it-link>\r\n}\r\n\r\n<ng-template #linkContent>\r\n  <ng-content></ng-content>\r\n</ng-template>\r\n"
		}]
	}],
	ctorParameters: () => [],
	propDecorators: {
		href: [{ type: Input }],
		externalLink: [{
			type: Input,
			args: [{ transform: inputToBoolean }]
		}]
	}
});
const skiplinkComponents = [ItSkiplinkComponent, ItSkiplinkItemComponent];
var ItSkiplinkModule = class ItSkiplinkModule {
	static {
		this.ɵfac = i0.ɵɵngDeclareFactory({
			minVersion: "12.0.0",
			version: "22.2.1",
			ngImport: i0,
			type: ItSkiplinkModule,
			deps: [],
			target: i0.ɵɵFactoryTarget.NgModule
		});
	}
	static {
		this.ɵmod = i0.ɵɵngDeclareNgModule({
			minVersion: "14.0.0",
			version: "22.2.1",
			ngImport: i0,
			type: ItSkiplinkModule,
			imports: [ItSkiplinkComponent, ItSkiplinkItemComponent],
			exports: [ItSkiplinkComponent, ItSkiplinkItemComponent]
		});
	}
	static {
		this.ɵinj = i0.ɵɵngDeclareInjector({
			minVersion: "12.0.0",
			version: "22.2.1",
			ngImport: i0,
			type: ItSkiplinkModule,
			imports: [skiplinkComponents]
		});
	}
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.1",
	ngImport: i0,
	type: ItSkiplinkModule,
	decorators: [{
		type: NgModule,
		args: [{
			imports: skiplinkComponents,
			exports: skiplinkComponents
		}]
	}]
});
var ItErrorPageComponent = class ItErrorPageComponent {
	constructor() {
		this.route = inject(ActivatedRoute);
		this.showErrorCode = true;
		this.showBackButton = true;
		this.showHomeButton = true;
		this.route.data.subscribe((data) => {
			if (!this.errorCode && data["errorCode"]) this.errorCode = data["errorCode"];
			if (data["showErrorCode"] !== void 0) this.showErrorCode = data["showErrorCode"];
			if (!this.errorTitle && data["errorTitle"]) this.errorTitle = data["errorTitle"];
			if (!this.errorDescription && data["errorDescription"]) this.errorDescription = data["errorDescription"];
			if (data["showBackButton"] !== void 0) this.showBackButton = data["showBackButton"];
			if (data["showHomeButton"] !== void 0) this.showHomeButton = data["showHomeButton"];
		});
	}
	get isDefaultErrorCode() {
		return this.errorCode === 404 || this.errorCode === 403 || this.errorCode === 500;
	}
	static {
		this.ɵfac = i0.ɵɵngDeclareFactory({
			minVersion: "12.0.0",
			version: "22.2.1",
			ngImport: i0,
			type: ItErrorPageComponent,
			deps: [],
			target: i0.ɵɵFactoryTarget.Component
		});
	}
	static {
		this.ɵcmp = i0.ɵɵngDeclareComponent({
			minVersion: "17.0.0",
			version: "22.2.1",
			type: ItErrorPageComponent,
			isStandalone: true,
			selector: "it-error-page",
			inputs: {
				errorCode: "errorCode",
				showErrorCode: [
					"showErrorCode",
					"showErrorCode",
					inputToBoolean
				],
				errorTitle: "errorTitle",
				errorDescription: "errorDescription",
				showBackButton: [
					"showBackButton",
					"showBackButton",
					inputToBoolean
				],
				showHomeButton: [
					"showHomeButton",
					"showHomeButton",
					inputToBoolean
				]
			},
			ngImport: i0,
			template: "<div class=\"container text-center mt-5\">\r\n  @if (errorCode && showErrorCode) {\r\n    <h1>{{ errorCode }}</h1>\r\n  }\r\n  <h2>\r\n    @if (!errorTitle && isDefaultErrorCode) {\r\n      {{ 'it.utils.error-page.' + errorCode + '.title' | translate }}\r\n    } @else {\r\n      {{ errorTitle || 'it.errors.generic' | translate }}\r\n    }\r\n  </h2>\r\n\r\n  <p class=\"mt-3 w-75 mx-auto\">\r\n    @if (!errorDescription && isDefaultErrorCode) {\r\n      {{ 'it.utils.error-page.' + errorCode + '.description' | translate }}\r\n    } @else {\r\n      {{ errorDescription || 'it.errors.generic-support-message' | translate }}\r\n    }\r\n  </p>\r\n\r\n  @if (showBackButton || showHomeButton) {\r\n    <div class=\"mt-5\">\r\n      @if (showBackButton) {\r\n        <it-back-button></it-back-button>\r\n      }\r\n      @if (showHomeButton) {\r\n        <a itButton=\"outline-primary\" class=\"ms-3\" routerLink=\"/\" title=\"{{ 'it.utils.error-page.go-to-homepage' | translate }}\">\r\n          {{ 'it.utils.error-page.go-to-homepage' | translate }}\r\n        </a>\r\n      }\r\n    </div>\r\n  }\r\n</div>\r\n",
			dependencies: [
				{
					kind: "ngmodule",
					type: TranslateModule
				},
				{
					kind: "directive",
					type: RouterLink,
					selector: "[routerLink]",
					inputs: [
						"target",
						"queryParams",
						"fragment",
						"queryParamsHandling",
						"state",
						"info",
						"relativeTo",
						"preserveFragment",
						"skipLocationChange",
						"replaceUrl",
						"browserUrl",
						"routerLink"
					]
				},
				{
					kind: "component",
					type: ItBackButtonComponent,
					selector: "it-back-button",
					inputs: [
						"buttonStyle",
						"direction",
						"showIcon",
						"showText",
						"backFn"
					],
					exportAs: ["itBackButton"]
				},
				{
					kind: "directive",
					type: ItButtonDirective,
					selector: "[itButton]",
					inputs: [
						"itButton",
						"size",
						"block",
						"disabled",
						"type"
					],
					exportAs: ["itButton"]
				},
				{
					kind: "pipe",
					type: i1$1.TranslatePipe,
					name: "translate"
				}
			],
			changeDetection: i0.ChangeDetectionStrategy.OnPush
		});
	}
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.1",
	ngImport: i0,
	type: ItErrorPageComponent,
	decorators: [{
		type: Component,
		args: [{
			selector: "it-error-page",
			changeDetection: ChangeDetectionStrategy.OnPush,
			imports: [
				TranslateModule,
				RouterLink,
				ItBackButtonComponent,
				ItButtonDirective
			],
			template: "<div class=\"container text-center mt-5\">\r\n  @if (errorCode && showErrorCode) {\r\n    <h1>{{ errorCode }}</h1>\r\n  }\r\n  <h2>\r\n    @if (!errorTitle && isDefaultErrorCode) {\r\n      {{ 'it.utils.error-page.' + errorCode + '.title' | translate }}\r\n    } @else {\r\n      {{ errorTitle || 'it.errors.generic' | translate }}\r\n    }\r\n  </h2>\r\n\r\n  <p class=\"mt-3 w-75 mx-auto\">\r\n    @if (!errorDescription && isDefaultErrorCode) {\r\n      {{ 'it.utils.error-page.' + errorCode + '.description' | translate }}\r\n    } @else {\r\n      {{ errorDescription || 'it.errors.generic-support-message' | translate }}\r\n    }\r\n  </p>\r\n\r\n  @if (showBackButton || showHomeButton) {\r\n    <div class=\"mt-5\">\r\n      @if (showBackButton) {\r\n        <it-back-button></it-back-button>\r\n      }\r\n      @if (showHomeButton) {\r\n        <a itButton=\"outline-primary\" class=\"ms-3\" routerLink=\"/\" title=\"{{ 'it.utils.error-page.go-to-homepage' | translate }}\">\r\n          {{ 'it.utils.error-page.go-to-homepage' | translate }}\r\n        </a>\r\n      }\r\n    </div>\r\n  }\r\n</div>\r\n"
		}]
	}],
	ctorParameters: () => [],
	propDecorators: {
		errorCode: [{ type: Input }],
		showErrorCode: [{
			type: Input,
			args: [{ transform: inputToBoolean }]
		}],
		errorTitle: [{ type: Input }],
		errorDescription: [{ type: Input }],
		showBackButton: [{
			type: Input,
			args: [{ transform: inputToBoolean }]
		}],
		showHomeButton: [{
			type: Input,
			args: [{ transform: inputToBoolean }]
		}]
	}
});
var ItLanguageSwitcherComponent = class ItLanguageSwitcherComponent {
	constructor() {
		this.translateService = inject(TranslateService);
		this.mode = "link";
		const translateService = this.translateService;
		this.currentLang$ = this.translateService.onLangChange.pipe(startWith({ lang: translateService.getCurrentLang() }), map((event) => this.availableLanguages?.find((l) => l.code === event.lang)));
	}
	ngOnInit() {
		if (!this.availableLanguages) this.availableLanguages = this.translateService.getLangs().map((lang) => ({
			code: lang,
			label: lang,
			...lang === "it" && { label: "ITA" },
			...lang === "en" && { label: "ENG" }
		}));
		else this.translateService.addLangs(this.availableLanguages.map((l) => l.code));
	}
	changeLanguage(lang) {
		this.translateService.use(lang);
	}
	static {
		this.ɵfac = i0.ɵɵngDeclareFactory({
			minVersion: "12.0.0",
			version: "22.2.1",
			ngImport: i0,
			type: ItLanguageSwitcherComponent,
			deps: [],
			target: i0.ɵɵFactoryTarget.Component
		});
	}
	static {
		this.ɵcmp = i0.ɵɵngDeclareComponent({
			minVersion: "17.0.0",
			version: "22.2.1",
			type: ItLanguageSwitcherComponent,
			isStandalone: true,
			selector: "it-language-switcher",
			inputs: {
				availableLanguages: "availableLanguages",
				mode: "mode"
			},
			ngImport: i0,
			template: "<it-dropdown [mode]=\"mode\">\r\n  <ng-container button>\r\n    <span class=\"visually-hidden\">{{\r\n      'it.utils.selected' | translate: { lang: $safeNavigationMigration((currentLang$ | async)?.label) }\r\n    }}</span>\r\n    <span>{{ (currentLang$ | async)?.label || ('it.utils.select-language' | translate) }}</span>\r\n  </ng-container>\r\n\r\n  @if (availableLanguages) {\r\n    <ng-container list>\r\n      @for (lang of availableLanguages; track lang.code) {\r\n        <it-dropdown-item\r\n          (click)=\"changeLanguage(lang.code)\"\r\n          (keydown)=\"changeLanguage(lang.code)\"\r\n          [active]=\"lang.code === (currentLang$ | async)?.code\">\r\n          {{ lang.label }}\r\n          @if (lang.code === (currentLang$ | async)?.code) {\r\n            <span class=\"visually-hidden\">\r\n              {{ 'it.utils.selected' | translate }}\r\n            </span>\r\n          }\r\n        </it-dropdown-item>\r\n      }\r\n    </ng-container>\r\n  }\r\n</it-dropdown>\r\n",
			dependencies: [
				{
					kind: "ngmodule",
					type: TranslateModule
				},
				{
					kind: "ngmodule",
					type: ItDropdownModule
				},
				{
					kind: "component",
					type: ItDropdownComponent,
					selector: "it-dropdown",
					inputs: [
						"mode",
						"color",
						"direction",
						"fullWidth",
						"megamenu",
						"dark"
					],
					outputs: [
						"showEvent",
						"shownEvent",
						"hideEvent",
						"hiddenEvent"
					],
					exportAs: ["itDropdown"]
				},
				{
					kind: "component",
					type: ItDropdownItemComponent,
					selector: "it-dropdown-item, li[itDropdownItem]",
					inputs: [
						"divider",
						"active",
						"large",
						"iconName",
						"iconPosition",
						"mode"
					]
				},
				{
					kind: "pipe",
					type: AsyncPipe,
					name: "async"
				},
				{
					kind: "pipe",
					type: i1$1.TranslatePipe,
					name: "translate"
				}
			],
			changeDetection: i0.ChangeDetectionStrategy.OnPush
		});
	}
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.1",
	ngImport: i0,
	type: ItLanguageSwitcherComponent,
	decorators: [{
		type: Component,
		args: [{
			selector: "it-language-switcher",
			changeDetection: ChangeDetectionStrategy.OnPush,
			imports: [
				AsyncPipe,
				TranslateModule,
				ItDropdownModule
			],
			template: "<it-dropdown [mode]=\"mode\">\r\n  <ng-container button>\r\n    <span class=\"visually-hidden\">{{\r\n      'it.utils.selected' | translate: { lang: $safeNavigationMigration((currentLang$ | async)?.label) }\r\n    }}</span>\r\n    <span>{{ (currentLang$ | async)?.label || ('it.utils.select-language' | translate) }}</span>\r\n  </ng-container>\r\n\r\n  @if (availableLanguages) {\r\n    <ng-container list>\r\n      @for (lang of availableLanguages; track lang.code) {\r\n        <it-dropdown-item\r\n          (click)=\"changeLanguage(lang.code)\"\r\n          (keydown)=\"changeLanguage(lang.code)\"\r\n          [active]=\"lang.code === (currentLang$ | async)?.code\">\r\n          {{ lang.label }}\r\n          @if (lang.code === (currentLang$ | async)?.code) {\r\n            <span class=\"visually-hidden\">\r\n              {{ 'it.utils.selected' | translate }}\r\n            </span>\r\n          }\r\n        </it-dropdown-item>\r\n      }\r\n    </ng-container>\r\n  }\r\n</it-dropdown>\r\n"
		}]
	}],
	ctorParameters: () => [],
	propDecorators: {
		availableLanguages: [{ type: Input }],
		mode: [{ type: Input }]
	}
});
var ItDateAgoPipe = class ItDateAgoPipe extends TranslatePipe {
	transform(value) {
		if (!value) return "";
		const seconds = Math.floor((+/* @__PURE__ */ new Date() - +new Date(value)) / 1e3);
		if (isNaN(seconds)) return "";
		if (seconds < 29) return super.transform("it.date-ago-pipe.just-now");
		const intervals = /* @__PURE__ */ new Map([
			["year", 31536e3],
			["month", 2592e3],
			["week", 604800],
			["day", 86400],
			["hour", 3600],
			["minute", 60],
			["second", 1]
		]);
		for (const interval of intervals) {
			const counter = Math.floor(seconds / interval[1]);
			if (counter > 0) return super.transform(`it.date-ago-pipe.${counter === 1 ? "singular-" : ""}${interval[0]}-ago`, { count: counter });
		}
		return "";
	}
	static {
		this.ɵfac = i0.ɵɵngDeclareFactory({
			minVersion: "12.0.0",
			version: "22.2.1",
			ngImport: i0,
			type: ItDateAgoPipe,
			deps: null,
			target: i0.ɵɵFactoryTarget.Pipe
		});
	}
	static {
		this.ɵpipe = i0.ɵɵngDeclarePipe({
			minVersion: "14.0.0",
			version: "22.2.1",
			ngImport: i0,
			type: ItDateAgoPipe,
			isStandalone: true,
			name: "itDateAgo",
			pure: false
		});
	}
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.1",
	ngImport: i0,
	type: ItDateAgoPipe,
	decorators: [{
		type: Pipe,
		args: [{
			name: "itDateAgo",
			pure: false,
			standalone: true
		}]
	}]
});
var ItDurationPipe = class ItDurationPipe extends TranslatePipe {
	transform(value, type) {
		let valueAdjust = Number(value);
		if (isNaN(valueAdjust) || value === null) return "";
		switch (type) {
			case "second":
				if (valueAdjust < 60) return super.transform(`it.duration.${type}${valueAdjust === 1 ? "" : "s"}`, { count: valueAdjust });
				valueAdjust = Math.round(valueAdjust / 60);
			case "minute":
				if (valueAdjust < 60) return super.transform(`it.duration.${type}${valueAdjust === 1 ? "" : "s"}`, { count: valueAdjust });
				valueAdjust = Math.round(valueAdjust / 60);
			case "hour":
				if (valueAdjust < 24) return super.transform(`it.duration.${type}${valueAdjust === 1 ? "" : "s"}`, { count: valueAdjust });
				valueAdjust = Math.round(valueAdjust / 24);
			case "day":
				if (valueAdjust < 7) return super.transform(`it.duration.${type}${valueAdjust === 1 ? "" : "s"}`, { count: valueAdjust });
				valueAdjust = Math.round(valueAdjust / 7);
			case "week":
				if (valueAdjust < 5) return super.transform(`it.duration.${type}${valueAdjust === 1 ? "" : "s"}`, { count: valueAdjust });
				valueAdjust = Math.round(valueAdjust / 5);
			case "month":
				if (valueAdjust < 24) return super.transform(`it.duration.${type}${valueAdjust === 1 ? "" : "s"}`, { count: valueAdjust });
				valueAdjust = Math.round(valueAdjust / 24);
			case "year": return super.transform(`it.duration.${type}${valueAdjust === 1 ? "" : "s"}`, { count: valueAdjust });
			default: return "";
		}
	}
	static {
		this.ɵfac = i0.ɵɵngDeclareFactory({
			minVersion: "12.0.0",
			version: "22.2.1",
			ngImport: i0,
			type: ItDurationPipe,
			deps: null,
			target: i0.ɵɵFactoryTarget.Pipe
		});
	}
	static {
		this.ɵpipe = i0.ɵɵngDeclarePipe({
			minVersion: "14.0.0",
			version: "22.2.1",
			ngImport: i0,
			type: ItDurationPipe,
			isStandalone: true,
			name: "itDuration"
		});
	}
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.1",
	ngImport: i0,
	type: ItDurationPipe,
	decorators: [{
		type: Pipe,
		args: [{
			name: "itDuration",
			standalone: true
		}]
	}]
});
function provideDesignAngularKit(config) {
	let assetBasePath = "./bootstrap-italia";
	if (config?.assetBasePath) assetBasePath = config.assetBasePath.endsWith("/") ? config.assetBasePath.substring(0, config.assetBasePath.lastIndexOf("/")) : config.assetBasePath;
	const providers = [
		{
			provide: IT_ASSET_BASE_PATH,
			useValue: assetBasePath
		},
		provideAnimationsAsync(),
		provideHttpClient(withXhr())
	];
	if (config?.loadFont !== false) providers.push(provideAppInitializer(() => {
		return (() => {
			return () => {
				loadFonts(`${assetBasePath}/dist/fonts`);
			};
		})()();
	}));
	const langPrefix = `${assetBasePath}/i18n/`;
	const langSuffix = `.json`;
	providers.push(provideTranslateService({
		loader: config?.translateLoader?.(langPrefix, langSuffix) ?? provideTranslateHttpLoader({
			prefix: langPrefix,
			suffix: langSuffix
		}),
		fallbackLang: "it"
	}));
	providers.push(provideAppInitializer(() => {
		return ((translateService) => {
			return () => {
				translateService.addLangs(["it", "en"]);
			};
		})(inject(TranslateService))();
	}));
	return makeEnvironmentProviders(providers);
}
const core = [
	ItAccordionComponent,
	ItAlertComponent,
	ItAvatarModule,
	ItBadgeDirective,
	ItButtonDirective,
	ItCalloutComponent,
	ItCardComponent,
	ItCarouselModule,
	ItChipComponent,
	ItCollapseComponent,
	ItDimmerModule,
	ItDropdownModule,
	ItForwardDirective,
	ItLinkComponent,
	ItListModule,
	ItModalComponent,
	ItNotificationsComponent,
	ItPaginationComponent,
	ItPopoverDirective,
	ItProgressBarComponent,
	ItProgressButtonComponent,
	ItSpinnerComponent,
	ItSteppersModule,
	ItTabModule,
	ItTableModule,
	ItTooltipDirective,
	ItTimelineModule,
	ItVideoPlayerComponent
];
const navigation = [
	ItBackButtonComponent,
	ItBackToTopComponent,
	ItBreadcrumbsModule,
	ItHeaderComponent,
	ItFooterComponent,
	ItNavBarModule,
	ItSidebarComponent,
	ItMegamenuComponent,
	ItSkiplinkModule,
	ItNavscrollComponent
];
const utils = [
	ItErrorPageComponent,
	ItIconComponent,
	ItLanguageSwitcherComponent
];
const pipes = [
	ItDateAgoPipe,
	ItDurationPipe,
	ItMarkMatchingTextPipe
];
const components = [
	...core,
	ItFormModule,
	...navigation,
	...utils,
	...pipes
];
var DesignAngularKitModule = class DesignAngularKitModule {
	static forRoot(config) {
		return {
			ngModule: DesignAngularKitModule,
			providers: [provideDesignAngularKit(config)]
		};
	}
	static forChild() {
		return { ngModule: DesignAngularKitModule };
	}
	static {
		this.ɵfac = i0.ɵɵngDeclareFactory({
			minVersion: "12.0.0",
			version: "22.2.1",
			ngImport: i0,
			type: DesignAngularKitModule,
			deps: [],
			target: i0.ɵɵFactoryTarget.NgModule
		});
	}
	static {
		this.ɵmod = i0.ɵɵngDeclareNgModule({
			minVersion: "14.0.0",
			version: "22.2.1",
			ngImport: i0,
			type: DesignAngularKitModule,
			imports: [
				ItAccordionComponent,
				ItAlertComponent,
				ItAvatarModule,
				ItBadgeDirective,
				ItButtonDirective,
				ItCalloutComponent,
				ItCardComponent,
				ItCarouselModule,
				ItChipComponent,
				ItCollapseComponent,
				ItDimmerModule,
				ItDropdownModule,
				ItForwardDirective,
				ItLinkComponent,
				ItListModule,
				ItModalComponent,
				ItNotificationsComponent,
				ItPaginationComponent,
				ItPopoverDirective,
				ItProgressBarComponent,
				ItProgressButtonComponent,
				ItSpinnerComponent,
				ItSteppersModule,
				ItTabModule,
				ItTableModule,
				ItTooltipDirective,
				ItTimelineModule,
				ItVideoPlayerComponent,
				ItFormModule,
				ItBackButtonComponent,
				ItBackToTopComponent,
				ItBreadcrumbsModule,
				ItHeaderComponent,
				ItFooterComponent,
				ItNavBarModule,
				ItSidebarComponent,
				ItMegamenuComponent,
				ItSkiplinkModule,
				ItNavscrollComponent,
				ItErrorPageComponent,
				ItIconComponent,
				ItLanguageSwitcherComponent,
				ItDateAgoPipe,
				ItDurationPipe,
				ItMarkMatchingTextPipe
			],
			exports: [
				ItAccordionComponent,
				ItAlertComponent,
				ItAvatarModule,
				ItBadgeDirective,
				ItButtonDirective,
				ItCalloutComponent,
				ItCardComponent,
				ItCarouselModule,
				ItChipComponent,
				ItCollapseComponent,
				ItDimmerModule,
				ItDropdownModule,
				ItForwardDirective,
				ItLinkComponent,
				ItListModule,
				ItModalComponent,
				ItNotificationsComponent,
				ItPaginationComponent,
				ItPopoverDirective,
				ItProgressBarComponent,
				ItProgressButtonComponent,
				ItSpinnerComponent,
				ItSteppersModule,
				ItTabModule,
				ItTableModule,
				ItTooltipDirective,
				ItTimelineModule,
				ItVideoPlayerComponent,
				ItFormModule,
				ItBackButtonComponent,
				ItBackToTopComponent,
				ItBreadcrumbsModule,
				ItHeaderComponent,
				ItFooterComponent,
				ItNavBarModule,
				ItSidebarComponent,
				ItMegamenuComponent,
				ItSkiplinkModule,
				ItNavscrollComponent,
				ItErrorPageComponent,
				ItIconComponent,
				ItLanguageSwitcherComponent,
				ItDateAgoPipe,
				ItDurationPipe,
				ItMarkMatchingTextPipe
			]
		});
	}
	static {
		this.ɵinj = i0.ɵɵngDeclareInjector({
			minVersion: "12.0.0",
			version: "22.2.1",
			ngImport: i0,
			type: DesignAngularKitModule,
			imports: [
				ItAlertComponent,
				ItAvatarModule,
				ItCarouselModule,
				ItChipComponent,
				ItDimmerModule,
				ItDropdownModule,
				ItListModule,
				ItModalComponent,
				ItNotificationsComponent,
				ItPaginationComponent,
				ItProgressBarComponent,
				ItProgressButtonComponent,
				ItSpinnerComponent,
				ItSteppersModule,
				ItTabModule,
				ItTableModule,
				ItTimelineModule,
				ItFormModule,
				ItBackButtonComponent,
				ItBreadcrumbsModule,
				ItHeaderComponent,
				ItNavBarModule,
				ItSkiplinkModule,
				ItNavscrollComponent,
				ItErrorPageComponent,
				ItLanguageSwitcherComponent,
				ItAvatarModule,
				ItCarouselModule,
				ItDimmerModule,
				ItDropdownModule,
				ItListModule,
				ItSteppersModule,
				ItTabModule,
				ItTableModule,
				ItTimelineModule,
				ItFormModule,
				ItBreadcrumbsModule,
				ItNavBarModule,
				ItSkiplinkModule
			]
		});
	}
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.1",
	ngImport: i0,
	type: DesignAngularKitModule,
	decorators: [{
		type: NgModule,
		args: [{
			imports: components,
			exports: components
		}]
	}]
});
var ItVideoPlayerModule = class ItVideoPlayerModule {
	static {
		this.ɵfac = i0.ɵɵngDeclareFactory({
			minVersion: "12.0.0",
			version: "22.2.1",
			ngImport: i0,
			type: ItVideoPlayerModule,
			deps: [],
			target: i0.ɵɵFactoryTarget.NgModule
		});
	}
	static {
		this.ɵmod = i0.ɵɵngDeclareNgModule({
			minVersion: "14.0.0",
			version: "22.2.1",
			ngImport: i0,
			type: ItVideoPlayerModule,
			imports: [ItVideoPlayerComponent],
			exports: [ItVideoPlayerComponent]
		});
	}
	static {
		this.ɵinj = i0.ɵɵngDeclareInjector({
			minVersion: "12.0.0",
			version: "22.2.1",
			ngImport: i0,
			type: ItVideoPlayerModule
		});
	}
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.1",
	ngImport: i0,
	type: ItVideoPlayerModule,
	decorators: [{
		type: NgModule,
		args: [{
			imports: [ItVideoPlayerComponent],
			exports: [ItVideoPlayerComponent]
		}]
	}]
});
const IconNameArray = [
	"arrow-down",
	"arrow-down-circle",
	"arrow-down-triangle",
	"arrow-left",
	"arrow-left-circle",
	"arrow-left-triangle",
	"arrow-right",
	"arrow-right-circle",
	"arrow-right-triangle",
	"arrow-up",
	"arrow-up-circle",
	"arrow-up-triangle",
	"ban",
	"bluesky",
	"bookmark",
	"box",
	"burger",
	"calendar",
	"camera",
	"car",
	"card",
	"cart",
	"chart-line",
	"check",
	"check-circle",
	"chevron-left",
	"chevron-right",
	"clip",
	"clock",
	"close",
	"close-big",
	"close-circle",
	"code-circle",
	"comment",
	"copy",
	"delete",
	"download",
	"error",
	"exchange-circle",
	"expand",
	"external-link",
	"flag",
	"folder",
	"fullscreen",
	"funnel",
	"hearing",
	"help",
	"help-circle",
	"horn",
	"inbox",
	"info-circle",
	"key",
	"link",
	"list",
	"locked",
	"logout",
	"mail",
	"mail-open",
	"map-marker",
	"map-marker-circle",
	"map-marker-minus",
	"map-marker-plus",
	"maximize",
	"maximize-alt",
	"minimize",
	"minus",
	"minus-circle",
	"more-actions",
	"more-items",
	"note",
	"pa",
	"password-invisible",
	"password-visible",
	"pencil",
	"piattaforme",
	"pin",
	"plug",
	"plus",
	"plus-circle",
	"presentation",
	"print",
	"refresh",
	"restore",
	"rss",
	"rss-square",
	"search",
	"settings",
	"share",
	"sign",
	"software",
	"star-full",
	"star-outline",
	"telephone",
	"tool",
	"unlocked",
	"upload",
	"user",
	"video",
	"warning",
	"warning-circle",
	"wifi",
	"zoom-in",
	"zoom-out",
	"file",
	"files",
	"file-audio",
	"file-compressed",
	"file-csv",
	"file-docx",
	"file-json",
	"file-image",
	"file-odp",
	"file-ods",
	"file-odt",
	"file-pdf",
	"file-pdf-ext",
	"file-sheet",
	"file-slides",
	"file-ppt",
	"file-signed",
	"file-txt",
	"file-video",
	"file-xlsx",
	"file-xml",
	"behance",
	"android-square",
	"android",
	"apple-square",
	"apple",
	"facebook",
	"facebook-square",
	"figma",
	"figma-square",
	"flickr",
	"flickr-square",
	"github",
	"instagram",
	"linkedin",
	"linkedin-square",
	"mastodon",
	"mastodon-square",
	"medium",
	"medium-square",
	"moodle",
	"moodle-square",
	"pinterest",
	"pinterest-square",
	"quora",
	"quora-square",
	"reddit",
	"reddit-square",
	"slack",
	"slack-square",
	"snapchat",
	"snapchat-square",
	"stackexchange",
	"stackexchange-square",
	"stackoverflow",
	"stackoverflow-square",
	"telegram",
	"threads",
	"threads-square",
	"tiktok",
	"tiktok-square",
	"twitter",
	"twitter-square",
	"vimeo",
	"vimeo-square",
	"whatsapp",
	"whatsapp-square",
	"youtube",
	"google",
	"spotify",
	"designers-italia",
	"team-digitale"
];
var ItDateUtils = class ItDateUtils {
	static addSeconds(date, seconds) {
		const newDate = new Date(date.valueOf());
		newDate.setSeconds(date.getSeconds() + seconds);
		return newDate;
	}
	static addMinutes(date, minutes) {
		const newDate = new Date(date.valueOf());
		newDate.setMinutes(date.getMinutes() + minutes);
		return newDate;
	}
	static addHours(date, hours) {
		const newDate = new Date(date.valueOf());
		newDate.setHours(date.getHours() + hours);
		return newDate;
	}
	static addDays(date, days) {
		const newDate = new Date(date.valueOf());
		newDate.setDate(date.getDate() + days);
		return newDate;
	}
	static addMonths(date, months) {
		const newDate = new Date(date.valueOf());
		newDate.setMonth(date.getMonth() + months);
		return newDate;
	}
	static addYears(date, years) {
		const newDate = new Date(date.valueOf());
		newDate.setFullYear(date.getFullYear() + years);
		return newDate;
	}
	static countDays(startDate, endDate, absolute = false) {
		const differenceInTime = endDate.getTime() - startDate.getTime();
		return Math.ceil((absolute ? Math.abs(differenceInTime) : differenceInTime) / 864e5);
	}
	static isIsoString(value) {
		if (!value || !/\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}.\d{3}Z/.test(value)) return false;
		const d = new Date(value);
		return !!d && !isNaN(d.getTime()) && d.toISOString() === value;
	}
	static isoStringToDate(isoString) {
		return isoString ? new Date(Date.parse(isoString)) : null;
	}
	static isoStringRemoveTime(isoString) {
		let date = ItDateUtils.isoStringToDate(isoString);
		if (!date) return isoString;
		const offset = date.getTimezoneOffset();
		date = /* @__PURE__ */ new Date(date.getTime() - offset * 60 * 1e3);
		return date.toISOString().substring(0, isoString.indexOf("T"));
	}
	static isoStringSetZeroTime(isoString) {
		let date = ItDateUtils.isoStringToDate(isoString);
		if (!date) return isoString;
		const offset = date.getTimezoneOffset();
		date = /* @__PURE__ */ new Date(date.getTime() - offset * 60 * 1e3);
		date.setUTCHours(0, 0, 0, 0);
		return date.toISOString();
	}
	static timeLeftString(endDate) {
		const endTime = endDate.getTime();
		return timer(0, 1e3).pipe(map$1(() => Math.floor((endTime - (/* @__PURE__ */ new Date()).getTime()) / 1e3)), takeWhile((delta) => delta >= 0), map$1((delta) => {
			const arrayResult = [];
			const days = Math.floor(delta / 60 / 60 / 24);
			if (days > 0) arrayResult.push(days + "d");
			delta -= days * 60 * 60 * 24;
			const hours = Math.floor(delta / 60 / 60) % 24;
			if (hours > 0) arrayResult.push(hours + "h");
			delta -= hours * 60 * 60;
			const minutes = Math.floor(delta / 60) % 60;
			arrayResult.push(minutes + "m");
			delta -= minutes * 60;
			const seconds = delta % 60;
			arrayResult.push(seconds + "s");
			return arrayResult.join(" ");
		}), shareReplay(1));
	}
	static nextWeekDayAndTime(dayOfWeek, hour = 0, minute = 0) {
		const now = /* @__PURE__ */ new Date();
		const result = new Date(now.getFullYear(), now.getMonth(), now.getDate() + (7 + dayOfWeek - now.getDay()) % 7, hour, minute, 0, 0);
		if (result < now) result.setDate(result.getDate() + 7);
		return result;
	}
};
export { CAP_REGEX, DesignAngularKitModule, EMAIL_REGEX, IBAN_REGEX, ITALIAN_TAX_CODE_REGEX, IT_ASSET_BASE_PATH, IT_SORT_DEFAULT_OPTIONS, IconNameArray, ItAccordionComponent, ItAlertComponent, ItAutocompleteComponent, ItAvatarDirective, ItAvatarDropdownComponent, ItAvatarDropdownItemComponent, ItAvatarExtraTextDirective, ItAvatarGroupComponent, ItAvatarGroupItemComponent, ItAvatarListItemDirective, ItAvatarModule, ItAvatarPresenceDirective, ItAvatarStatusDirective, ItAvatarWrapperDirective, ItBackButtonComponent, ItBackToTopComponent, ItBadgeDirective, ItBreadcrumbComponent, ItBreadcrumbItemComponent, ItBreadcrumbsModule, ItButtonDirective, ItCalloutComponent, ItCardComponent, ItCarouselComponent, ItCarouselItemComponent, ItCarouselModule, ItCheckboxComponent, ItChipComponent, ItCollapseComponent, ItDateAgoPipe, ItDateUtils, ItDimmerButtonsComponent, ItDimmerComponent, ItDimmerIconComponent, ItDimmerModule, ItDropdownComponent, ItDropdownItemComponent, ItDropdownModule, ItDurationPipe, ItErrorPageComponent, ItFileUtils, ItFooterComponent, ItFormModule, ItForwardDirective, ItHeaderComponent, ItIconComponent, ItInputComponent, ItLanguageSwitcherComponent, ItLinkComponent, ItListComponent, ItListItemComponent, ItListModule, ItMarkMatchingTextPipe, ItMegamenuComponent, ItModalComponent, ItNavBarComponent, ItNavBarItemComponent, ItNavBarModule, ItNavscrollComponent, ItNotificationService, ItNotificationsComponent, ItPaginationComponent, ItPasswordInputComponent, ItPopoverDirective, ItProgressBarComponent, ItProgressButtonComponent, ItRadioButtonComponent, ItRangeComponent, ItRatingComponent, ItSearchComponent, ItSelectComponent, ItSidebarComponent, ItSkiplinkComponent, ItSkiplinkItemComponent, ItSkiplinkModule, ItSortDirective, ItSortHeaderComponent, ItSpinnerComponent, ItSteppersContainerComponent, ItSteppersItemComponent, ItSteppersModule, ItTabContainerComponent, ItTabItemComponent, ItTabModule, ItTableComponent, ItTableModule, ItTextareaComponent, ItTimelineComponent, ItTimelineItemComponent, ItTimelineModule, ItTooltipDirective, ItTransferComponent, ItUploadDragDropComponent, ItUploadFileListComponent, ItValidators, ItVideoPlayerComponent, ItVideoPlayerModule, NotificationPosition, NotificationType, PHONE_NUMBER_REGEX, PLATE_REGEX, URL_REGEX, VAT_NUMBER_REGEX, provideDesignAngularKit };

//# sourceMappingURL=design-angular-kit.mjs.map